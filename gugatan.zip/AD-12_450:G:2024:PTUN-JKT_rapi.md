# PUTUSAN
## Nomor 450/G/2024/PTUN.JKT
DEMI KEADILAN BERDASARKAN KETUHANAN YANG MAHA ESA
Pengadilan Tata Usaha Negara Jakarta yang memeriksa, memutus
dan  menyelesaikan  sengketa  Tata  Usaha  Negara  pada  Tingkat  Pertama
dengan Acara Biasa secara elektronik  (e-court) melalui Sistem  Informasi
Pengadilan telah menjatuhkan Putusan dalam perkara antara: 
dr.  IVAN ROVIAN  M.Kp,  Kewarganegaraan  Indonesia,  Pekerjan  :
Dosen, Alamat : Jl. Tugu Utara, GG Baru No.36, Rt. 003/RW.004,
Kel. Kepatihan, Kec. Jombang, Kabupaten Jombang, Provinsi Jawa
Timur, domisili elektronik : indocable271096@gmail.com  ; 
Dalam hal ini berdasarkan  Surat   Kuasa   Khusus   tanggal  16
Oktober 2024 memberikan kuasa kepada:
1.Rofiullah, S.H., 
2.Tony Budi Yanto, S.H. 
3.Nigel Alif Yudexfakti, S.H., 
Kesemuanya  Warga  Negara  Indonesia,  pekerjaan  Advokat  yang
pada  kantor hukum  “A.ROFIULLAH, SH & PARTNERS” beralamat
di Jl. Wangun Sari No.45, Rt.003/04, Pamoyanan, Bogor Selatan,
Kota  Bogor,  Jawa  Barat  16136,  domisili  elektronik  :
redolawoffice@yahoo.com  
Selanjutnya disebut sebagai PENGGUGAT;
Lawan
MENTERI  PENDIDIKAN,  SAINS,  DAN  TEKNOLOGI  REPUBLIK
INDONESIA,  tempat  kedudukan  di  Gedung  D  Lantai  8,  Komplek
Perkantoran  Kementerian  Pendidikan  Tinggi,  Sains  dan  Teknologi,
Jalan Jenderal Sudirman, Senayan, Jakarta, Indonesia 10270. 
Dalam  hal  ini  berdasarkan  Surat  Kuasa  Khusus  Nomor
0010/M/HK.10/ 2024 tanggal 29 November 2024 memberikan kuasa
kepada:
1.Inneke Indraswati, S.H., M.H.

Kepaniteraan Mahkamah Agung Republik Indonesia berusaha untuk selalu mencantumkan informasi paling kini dan akurat sebagai bentuk komitmen Mahkamah Agung untuk pelayanan publik, transparansi dan akuntabilitas
pelaksanaan fungsi peradilan. Namun dalam hal-hal tertentu masih dimungkinkan terjadi permasalahan teknis terkait dengan akurasi dan keterkinian informasi yang kami sajikan, hal mana akan terus kami perbaiki dari waktu kewaktu.
Dalam hal Anda menemukan inakurasi informasi yang termuat pada situs ini atau informasi yang seharusnya ada, namun belum tersedia, maka harap segera hubungi Kepaniteraan Mahkamah Agung RI melalui :
2.Suwitno, S.E.
3.Robertus Ulu Wardana, S.H., LL.M.
4.Ahmad Mudzaffar, S.H., M.H.
5.Khoizin Alfani, S.H., M.H.
6.Rina Wirachmawati, S.H., M.H.
7.Ditta Taurina, S.H., M.Si.
8.Stivenly Sumual, S.H., M.Kn.
9.Fadhy Setiadi, S.H., M.H.
10.Arif Fathurahman, S.H.
11.Tetya Dwiamaneva, S.H.
Kesemuanya Warga Negara Indonesia, pekerjaan Pegawai Negeri
Sipil  pada  kantor  Kementerian  Pendidikan  Tinggi,  Sains  dan
Teknologi, beralamat di Gedung D Lantai 8, Komplek Perkantoran
Kementerian Pendidikan Tinggi, Sains dan Teknologi, Jalan Jenderal
Sudirman, Senayan, Jakarta, Indonesia 10270. 
             Selanjutnya disebut sebagai  TERGUGAT;
Pengadilan Tata Usaha Negara Jakarta telah membaca:
-Penetapan  Ketua  Pengadilan  Tata  Usaha  Negara  Jakarta  Nomor:
450/PEN-DIS/2024/PTUN.JKT, tertanggal 21 November 2024,  tentang
pemeriksaan dengan acara biasa;
-Penetapan  Ketua  Pengadilan  Tata  Usaha  Negara  Jakarta  Nomor:
450/PEN-MH/2024/PTUN.JKT,  tanggal  21  November  2024,  tentang
Penunjukan  Majelis  Hakim  yang  memeriksa,  memutus  dan
menyelesaikan sengketa ini;
-Surat  Panitera  Pengadilan  Tata  Usaha  Negara  Jakarta  Nomor:
450/G/2024/PTUN.JKT, tanggal 21 November 2024 , tentang Penunjukan
Panitera Pengganti;
-Penetapan Hakim Ketua Majelis Pengadilan Tata Usaha Negara Jakarta
Nomor:  450/PEN-PP/2024/PTUN.JKT,  tanggal  21  November  2024,
tentang penetapan hari dan tanggal Pemeriksaan Persiapan;

Kepaniteraan Mahkamah Agung Republik Indonesia berusaha untuk selalu mencantumkan informasi paling kini dan akurat sebagai bentuk komitmen Mahkamah Agung untuk pelayanan publik, transparansi dan akuntabilitas
pelaksanaan fungsi peradilan. Namun dalam hal-hal tertentu masih dimungkinkan terjadi permasalahan teknis terkait dengan akurasi dan keterkinian informasi yang kami sajikan, hal mana akan terus kami perbaiki dari waktu kewaktu.
Dalam hal Anda menemukan inakurasi informasi yang termuat pada situs ini atau informasi yang seharusnya ada, namun belum tersedia, maka harap segera hubungi Kepaniteraan Mahkamah Agung RI melalui :
-Penetapan Hakim Ketua Majelis Pengadilan Tata Usaha Negara Jakarta
Nomor:  450/PEN-HS/2024/PTUN.JKT,  tanggal  18  Desember  2024,
tentang penetapan hari dan tanggal sidang terbuka untuk umum;
-Berkas perkara dan bukti surat para pihak yang bersengketa serta telah
mendengar pula keterangan para pihak, ahli, dan saksi dalam perkara
ini;

# DUDUK PERKARA

Bahwa Penggugat telah mengajukan gugatan  tertanggal 11 November
2024, yang telah didaftarkan di Kepaniteraan Pengadilan Tata Usaha Negara
Jakarta secara elektronik pada tanggal 20 November 2024 di bawah register
perkara Nomor: 450/G /2024/PTUN.JKT, dan telah diperbaiki dalam sidang
Pemeriksaan  Persiapan  terakhir  tanggal  18  Desember  2024,  yang  pada
pokoknya mengemukakan alasan-alasan sebagai berikut:
## I. OBJEK SENGKETA
1.Keputusan Menteri Pendidikan Kebudayaan, Riset dan Teknologi
Republik Indonesia Nomor :  93731/RHS/M/08/2024, tertanggal 4
Oktober  2024 Tentang  Pembebasan  Dari  Jabatannya  Menjadi
Jabatan  Pelaksana  selama  12  (dua  belas)  bulan,  atas  nama
dr. IVAN ROVIAN M.Kp. 
2.Keputusan Menteri  Pendidikan  Tinggi, Sains, dan  Teknologi
Republik  Indonesia  No.  137561/RHS/M/08/2024  tanggal  25
November  2024.  tentang  Penguatan  Keputusan  Menteri
Pendidikan Kebudayaan, Riset, dan Teknologi Republik Indonesia
Nomor :  93731/RHS/M/08/2024, tanggal 4 Oktober 2024  Tentang
Pembebasan Dari Jabatannya Menjadi Jabatan Pelaksana selama
12 (dua belas) bulan, atas nama dr.  IVAN ROVIAN M.Kp.   
## II. KEWENANGAN PENGADILAN TATA USAHA NEGARA 
1.Bahwa  Pengadilan  Tata  Usaha  Negara  “PTUN”  berwenang
menerima, memeriksa, dan memutus gugatan sebagaimana diatur
pada Pasal 1 angka 9 UU PTUN juncto SEMA  4/2016 terhadap
Objek  Gugatan  yang  telah  memenuhi  kualifikasi/syarat  KTUN
berdasarkan hukum yang berlaku;

Kepaniteraan Mahkamah Agung Republik Indonesia berusaha untuk selalu mencantumkan informasi paling kini dan akurat sebagai bentuk komitmen Mahkamah Agung untuk pelayanan publik, transparansi dan akuntabilitas
pelaksanaan fungsi peradilan. Namun dalam hal-hal tertentu masih dimungkinkan terjadi permasalahan teknis terkait dengan akurasi dan keterkinian informasi yang kami sajikan, hal mana akan terus kami perbaiki dari waktu kewaktu.
Dalam hal Anda menemukan inakurasi informasi yang termuat pada situs ini atau informasi yang seharusnya ada, namun belum tersedia, maka harap segera hubungi Kepaniteraan Mahkamah Agung RI melalui :
2.Bahwa berdasarkan Pasal 1 angka 9 Undang-Undang Nomor 51
Tahun  2009 tentang Perubahan Kedua atas Undang-Undang
Nomor 5 Tahun 1986 tentang Peradilan Tata Usaha Negara (“UU
PTUN”), 
KTUN didefinisikan sebagai berikut:
“Keputusan  Tata  Usaha  Negara  (yang  selanjutnya  disebut
KTUN) adalah suatu penetapan tertulis yang  dikeluarkan oleh
badan atau pejabat tata usaha negara yang berisi tindakan
hukum  tata  usaha  negara  yang berdasarkan peraturan
perundang-undangan  yang
3.Bahwa menurut Yuslim dalam bukunya yang berjudul Hukum Acara
Peradilan Tata Usaha Negara halaman 47 yang menjelaskan
rumusan KTUN sebagaimana didefinisikan dalam Pasal 1 angka 9
UU PTUN mengandung unsur-unsur sebagai berikut:
a.Penetapan tertulis;
b.Badan atau Pejabat Tata Usaha Negara;
c.Tindakan hukum tata usaha negara;
d.Peraturan perundang-undangan  yang berlaku;
e.Konkret;
f.Individual;
g.Final; dan;
h.Akibat hukum bagi seseorang atau badan hukum perdata;
4.Bahwa  selain  itu,  kualifikasi/syarat  KTUN  sebagaimana  diatur
dalam Pasal 1 angka 9 UU PTUN juncto Pasal 1 angka 7 dan Pasal
87 Undang-Undang Nomor  30  Tahun  2014 tentang Administrasi
Pemerintahan (”UU AP”)  junctis  Surat Edaran Mahkamah Agung
Nomor 4 Tahun 2016 tentang Pemberlakuan Rumusan Hasil Rapat
Pleno  Kamar  Mahkamah  Agung  Tahun  2016  Sebagai  Pedoman
Pelaksanaan Tugas Bagi Pengadilan (”SEMA 4/2016”) adalah
sebagai berikut:
a.Penetapan Tertulis/Konkret:

Kepaniteraan Mahkamah Agung Republik Indonesia berusaha untuk selalu mencantumkan informasi paling kini dan akurat sebagai bentuk komitmen Mahkamah Agung untuk pelayanan publik, transparansi dan akuntabilitas
pelaksanaan fungsi peradilan. Namun dalam hal-hal tertentu masih dimungkinkan terjadi permasalahan teknis terkait dengan akurasi dan keterkinian informasi yang kami sajikan, hal mana akan terus kami perbaiki dari waktu kewaktu.
Dalam hal Anda menemukan inakurasi informasi yang termuat pada situs ini atau informasi yang seharusnya ada, namun belum tersedia, maka harap segera hubungi Kepaniteraan Mahkamah Agung RI melalui :
Objek Gugatan memiliki wujud tertulis yang jelas dan tidak
abstrak;
b.Keputusan  Badan  dan/atau  Pejabat  Tata  Usaha  Negara  di
lingkungan  eksekutif,  legislatif,  yudikatif,  dan  penyelenggara
negara lainnya:
Objek Gugatan diterbitkan oleh Tergugat yang merupakan
Menteri  Pendidikan Kebudayaan, Riset dan Teknologi Republik
Indonesia yang merupakan jabatan pada lembaga eksekutif;
c.Berdasarkan  ketentuan  perundang-undangan  dan  Asas-Asas
Umum Pemerintahan yang Baik (”AUPB”):
Objek  Gugatan  sebenarnya  dikeluarkan  oleh  Tergugat  dalam
rangka menjalankan tugas dan fungsinya untuk
menyelenggarakan urusan pemerintahan di bidang  Pendidikan
Kebudayaan,  Riset  dan  Teknologi  untuk  membantu  Presiden
dalam menyelenggarakan pemerintahan negara. Namun obyek
gugatan dikeluarkan secara melawan  hukum sebagaimana lebih
lanjut akan Penggugat dalilkan dalam Pokok  Perkara;
d.Bersifat final dalam arti lebih luas:
Maksudnya Objek Gugatan (KTUN) sudah definitif dan tidak lagi
memerlukan persetujuan dari atasan pejabat atau instansi lain,
dan karenanya dapat menimbulkan konsekuensi hukum;
e.Keputusan yang berpotensi menimbulkan akibat hukum:
Objek Gugatan dalam perkara  a quo  telah memberikan akibat
hukum atau setidak-tidaknya berpotensi memiliki akibat hukum.
Karena dengan expressis verbis dinyatakan dalam Objek
Gugatan  bahwa  wilayah  adanya  laporan  pengaduan  dari
seseorang dalam hal ini istri sah dari pada Penggugat dengan
adanya  pelanggaran  disiplin  yang  dilakukan  oleh  Penggugat
dengan dugaan telah terjadinya tindak pidana perselingkuhan
sehingga menjadi ranah Pidana oleh karena diterbitkan objek
gugatan tersebut menimbulkan akibat hukum bagi Penggugat;

Kepaniteraan Mahkamah Agung Republik Indonesia berusaha untuk selalu mencantumkan informasi paling kini dan akurat sebagai bentuk komitmen Mahkamah Agung untuk pelayanan publik, transparansi dan akuntabilitas
pelaksanaan fungsi peradilan. Namun dalam hal-hal tertentu masih dimungkinkan terjadi permasalahan teknis terkait dengan akurasi dan keterkinian informasi yang kami sajikan, hal mana akan terus kami perbaiki dari waktu kewaktu.
Dalam hal Anda menemukan inakurasi informasi yang termuat pada situs ini atau informasi yang seharusnya ada, namun belum tersedia, maka harap segera hubungi Kepaniteraan Mahkamah Agung RI melalui :
5.Bahwa berdasarkan penjelasan di atas, maka Objek Gugatan
termasuk KTUN dan merupakan wewenang dari PTUN untuk
mengadilinya;
6.Bahwa kemudian, agar PTUN dapat mengadili gugatan terhadap
suatu KTUN, Penggugat terlebih dahulu mengajukan seluruh upaya
administratif sebagaimana diatur dalam:
a)Undang-Undang Nomor 5 Tahun 1986 tentang Peradilan Tata
Usaha Negara sebagaimana diubah terakhir kali berdasarkan
Undang-Undang Nomor 51 Tahun 2009 tentang Perubahan
Kedua  atas  Undang-Undang  Nomor  5  Tahun  1986  tentang
Peradilan Tata Usaha Negara  (UU PTUN) ;
b)Undang-Undang  Nomor  Nomor  30  Tahun  2014  tentang
Administrasi Pemerintahan (“UU AP”) ;
c)Peraturan  Mahkamah  Agung  Nomor  6  Tahun  2018  tentang
Pedoman Penyelesaian Administrasi Pemerintahan (“Perma
6/2018”); dan ;
d)Surat Edaran Mahkamah Agung RI Nomor 5 Tahun 2021 tentang
Pemberlakuan Rumusan Hasil Rapat Pleno Kamar Mahkamah
Agung Tahun 2021 Sebagai Pedoman Pelaksanaan Tugas Bagi
Pengadilan (“SEMA 5/2021”);
Yang mana ketentuan-ketentuan  di atas mengatur sebagai
berikut: PASAL 48 AYAT (2) UU PTUN:
Pengadilan  baru  berwenang  memeriksa,  memutus,  dan
menyelesaikan  sengketa  Tata  Usaha  Negara  sebagaimana
dimaksud dalam ayat (1) jika seluruh upaya administratif yang
bersangkutan telah digunakan;
7.Bahwa Penggugat telah mengajukan Upaya Administratif berupa
Keberatan melalui  Kuasa Hukumnya tertanggal 17 Oktober 2024
yang  di  tujukan  kepada  Tergugat.  Bahwa  surat  keberatan  dari
Penggugat  tersebu t sampai  Gugatan  ini  dilayangkan  atau  di
daftarkan  pada  Pengadilan  Tata  Usaha  Negara  Jakarta  belum
pernah mendapat Jawaban secara tertulis dari Tergugat;
8.Bahwa atas keberatan yang tidak terselesaikan tersebut Penggugat

Kepaniteraan Mahkamah Agung Republik Indonesia berusaha untuk selalu mencantumkan informasi paling kini dan akurat sebagai bentuk komitmen Mahkamah Agung untuk pelayanan publik, transparansi dan akuntabilitas
pelaksanaan fungsi peradilan. Namun dalam hal-hal tertentu masih dimungkinkan terjadi permasalahan teknis terkait dengan akurasi dan keterkinian informasi yang kami sajikan, hal mana akan terus kami perbaiki dari waktu kewaktu.
Dalam hal Anda menemukan inakurasi informasi yang termuat pada situs ini atau informasi yang seharusnya ada, namun belum tersedia, maka harap segera hubungi Kepaniteraan Mahkamah Agung RI melalui :
mengajukan gugatan kepada Tergugat di Pengadilan Tata Usaha
Negara Indonesia yang terregister di kepaniteraan pada tanggal 20
November 2024; 
9.Bahwa atas  hasil  Keberatan yang tidak  pernah ditanggapi  oleh
Tergugat  maka  Penggugat  berhak  mengajukan  Gugatan  ke
Pengadilan sebagaimana diatur UU AP sebagai berikut:
PASAL 76 AYAT (3) UU AP:
Dalam hal Warga Masyarakat tidak menerima atas penyelesaian
banding  oleh  Atasan  Pejabat,  Warga  Masyarakat  dapat
mengajukan gugatan ke Pengadilan;
PASAL 1 Angka 18 UU AP
Pengadilan adalah Pengadilan Tata Usaha Negara
10.Bahwa berdasarkan argumentasi di atas, maka jelas PTUN
berwenang memeriksa,  mengadili, dan memutus perkara a quo
yang diajukan oleh Penggugat
## III. TENGGANG  WAKTU  MENGAJUKAN  GUGATAN  dan  UPAYA
ADMINISTRATIF:
1.Bahwa pasal 55 Undang-Undang 5 Tahun 1986 tentang Peradilan
Tata Usaha  Negara (sebagaimana  telah  diubah dengan  Undang-
Undang Nomor 9 Tahun 2004 tentang Perubahan Undang-Undang
Nomor 5 Tahun 1986 tentang Peradilan Tata Usaha Negara dan juga
telah  diubah  menjadi  Undang-Undang  Nomor  51  Tahun  2009
tentang  Perubahan  Kedua  Atas  Undang-Undang  Nomor  5  Tahun
1986 tentang Peradilan Tata Usaha Negara) menyebutkan “gugatan
dapat diajukan hanya dalam tenggang waktu 90 (sembilan puluh)
hari terhitung sejak saat diterimanya atau diumumkannya Keputusan
Badan atau Pejabat Tata Usaha Negara” ;
2.Bahwa  ketentuan  pasal  3  ayat  (2)  Peraturan  Mahkamah  Agung
Nomor  2  Tahun  2023  tentang  Pedoman  Penyelesaian  Sengketa
Pemberhentian  Pegawai  Negeri  Sipil  dan  Pemutusan  Hubungan
Perjanjian Kerja Pegawai Pemerintah Dengan Perjanjian Kerja di
Pengadilan  menyatakan  “gugatan  diajukan  paling  lambat  90
(Sembilan puluh) hari setelah diterimanya  surat keputusan tersebut ”;

Kepaniteraan Mahkamah Agung Republik Indonesia berusaha untuk selalu mencantumkan informasi paling kini dan akurat sebagai bentuk komitmen Mahkamah Agung untuk pelayanan publik, transparansi dan akuntabilitas
pelaksanaan fungsi peradilan. Namun dalam hal-hal tertentu masih dimungkinkan terjadi permasalahan teknis terkait dengan akurasi dan keterkinian informasi yang kami sajikan, hal mana akan terus kami perbaiki dari waktu kewaktu.
Dalam hal Anda menemukan inakurasi informasi yang termuat pada situs ini atau informasi yang seharusnya ada, namun belum tersedia, maka harap segera hubungi Kepaniteraan Mahkamah Agung RI melalui :
3.Bahwa Penggugat mengetahui adanya Surat Keputusan Tata Usaha
Negara  yang  menjadi  Objek  Sengketa  dalam  perkara  ini  pada
tanggal  11 Oktober 2024  yang diberikan oleh K epala Pendidikan
Tinggi Wilayah VII  kepada Penggugat secara langsung di ruangan
Kepala Lembaga Pendidikan Wilayah VII ;
4.Bahwa setelah  ditetapkannya  objek  sengketa  oleh  Tergugat,
Penggugat  melalui  Kuasa  Hukumnya  telah  mengajukan  upaya
Administratif  kepada  Menteri  Pendidikan  Budaya  Riset,  dan
Teknologi Republik Indonesia tertanggal 17 Oktober 2024;
5.Bahwa  dengan demikian  sejak  tanggal  diterimanya  Keputusan
Menteri  Pendidikan  Kebudayaan,  Riset  dan  Teknologi  Republik
Indonesia  Nomor  :  93731/RHS/M/08/2024,  tertanggal  4  Oktober
2024.  Tentang  Pembebasan  Dari  Jabatannya  Menjadi  Jabatan
Pelaksana  selama  12  (dua  belas)  bulan,  atas  nama  dr.  IVAN
ROVIAN M.Kp dan Keputusan Menteri Pendidikan Tinggi, Sains dan
Teknologi Republik Indonesia  No. 137561/RHS/M/08/2024 tentang
Penguatan  Keputusan  No.  93731/RHS/M/08/2024  tertanggal  25
November 2024, kepada Penggugat yang masih dalam tenggang
waktu yang di tentukan oleh undang-undang;
6.Bahwa objek sengketa Keputusan Menteri Pendidikan Tinggi, Sains
dan  Teknologi  Republik  Indonesia  No.  137561/RHS/M/08/2024
tanggal  25  November  20024  tentang  Penguatan  Keputusan
Menteri Pendidikan  Kebudayaan,  Riset  dan  Teknologi  Republik
Indonesia  Nomor  :  93731/RHS/M/08/2024, tertanggal  4  Oktober
2024 Tentang  Pembebasan  Dari  Jabatannya  Menjadi  Jabatan
Pelaksana  selama  12  (dua  belas)  bulan,  atas  nama  dr.  IVAN
ROVIAN  M.Kp,,  yang  dikeluarkan  oleh  Tergugat  kami  selakau
Penggugat baru mengetahui keputusan tersebut pada saat siding
persiapan di Pengadilan Tata Usaha Negara Jakarta dalam perkara
Aquo pada tanggal 09 Desember 2024. 
## IV. KEPENTINGAN PENGGUGAT YANG DIRUGIKAN
1.Bahwa Pasal 53 ayat (1) Undang-Undang 5 Tahun 1986 tentang

Kepaniteraan Mahkamah Agung Republik Indonesia berusaha untuk selalu mencantumkan informasi paling kini dan akurat sebagai bentuk komitmen Mahkamah Agung untuk pelayanan publik, transparansi dan akuntabilitas
pelaksanaan fungsi peradilan. Namun dalam hal-hal tertentu masih dimungkinkan terjadi permasalahan teknis terkait dengan akurasi dan keterkinian informasi yang kami sajikan, hal mana akan terus kami perbaiki dari waktu kewaktu.
Dalam hal Anda menemukan inakurasi informasi yang termuat pada situs ini atau informasi yang seharusnya ada, namun belum tersedia, maka harap segera hubungi Kepaniteraan Mahkamah Agung RI melalui :

Peradilan Tata Usaha Negara (sebagaimana telah diubah dengan
Undang-Undang Nomor 9 Tahun 2004 tentang Perubahan Undang-
Undang Nomor 5 Tahun 1986 tentang Peradilan Tata Usaha Negara
dan juga telah diubah menjadi Undang-Undang Nomor 51 Tahun
2009  tentang  Perubahan  Kedua  Atas  Undang-Undang  Nomor  5
Tahun 1986 tentang Peradilan Tata Usaha Negara) menyebutkan  :
“orang atau badan hukum perdata yang merasa kepentingannya
dirugikan  oleh  suatu  Keputusan  Tata  Usaha  Negara  dapat
mengajukan gugatan tertulis kepada Pengadilan yang berwenang
yang  berisi  tuntutan  agar  Keputusan  Tata  Usaha  Negara  yang
disengketakan itu dinyatakan batal atau tidak sah, dengan atau
disertai ganti rugi dan/atau direhabilitasi”;
2.Pasal 17 Undang-Undang Nomor 39 Tahun 1999 tentang Hak Asasi
Manusia  (UU  HAM)  mengatur  bahwa,  “ setiap  orang  tanpa
diskriminasi berhak untuk memperoleh keadilan dengan mengajukan
permohonan, pengaduan, dan gugatan, baik dalam perkara pidana,
perdata, maupun administrasi serta diadili melalui proses peradilan
yang bebas dan tidak memihak, sesuai dengan hukum acara yang
menjamin pemeriksaan yang objektif oleh hakim yang jujur dan adil
untuk memperoleh putusan yang adil dan benar” ;
3.Bahwa  akibat  ditetapkannya  Keputusan  Menteri  Pendidikan
Kebudayaan,  Riset  dan  Teknologi  Republik  Indonesia  Nomor  :
93731/  RHS/M/08/2024,  tertanggal  4  Oktober  2024.  Tentang
Pembebasan Dari Jabatannya Menjadi Jabatan Pelaksana selama
12  (dua  belas)  bulan,  atas  nama  dr.  IVAN  ROVIAN  M.Kp   dan
Keputusan  Menteri  Pendidikan  Tinggi, Sains dan  Teknologi
Republik  Indonesia  No.  137561/RHS/M/08/2024  tentang
Penguatan  Keputusan  No.  93731/RHS/M/08/2024  tertanggal  25
November  2024  (objek  sengketa)  oleh  Tergugat,  Penggugat
kehilangan Jabatannya;
4.Bahwa akibat ditetapkannya Surat  Keputusan Menteri Pendidikan
Kebudayaan,  Riset  dan  Teknologi  Republik  Indonesia  Nomor  :
93731/RHS/M/08/2024,  tertanggal  4  Oktober  2024.  Tentang

Kepaniteraan Mahkamah Agung Republik Indonesia berusaha untuk selalu mencantumkan informasi paling kini dan akurat sebagai bentuk komitmen Mahkamah Agung untuk pelayanan publik, transparansi dan akuntabilitas
pelaksanaan fungsi peradilan. Namun dalam hal-hal tertentu masih dimungkinkan terjadi permasalahan teknis terkait dengan akurasi dan keterkinian informasi yang kami sajikan, hal mana akan terus kami perbaiki dari waktu kewaktu.
Dalam hal Anda menemukan inakurasi informasi yang termuat pada situs ini atau informasi yang seharusnya ada, namun belum tersedia, maka harap segera hubungi Kepaniteraan Mahkamah Agung RI melalui :
Pembebasan Dari Jabatannya Menjadi Jabatan Pelaksana selama
12  (dua  belas)  bulan,  atas  nama  dr.  IVAN  ROVIAN  M.Kp  dan
Keputusan Menteri Pendidikan Tinggi, Sains dan Teknologi Republik
Indonesia  No.  137561/RHS/M/08/2024  tentang  Penguatan
Keputusan  No.  93731/RHS/M/08/2024  tertanggal  25  November
2024, (objek  sengketa)  oleh  Tergugat,  Penggugat  kehilangan
fasilitas dan tunjangan sebagai Kepala Bagian Umum LLDIKTI ;
5.Bahwa akibat ditetapkannya Surat  Keputusan Menteri Pendidikan
Kebudayaan,  Riset  dan  Teknologi  Republik  Indonesia  Nomor  :
93731/RHS/M/08/2024,  tertanggal  4  Oktober  2024.  Tentang
Pembebasan Dari Jabatannya Menjadi Jabatan Pelaksana selama
12  (dua  belas)  bulan,  atas  nama  dr.  IVAN  ROVIAN  M.Kp  dan
Keputusan Menteri Pendidikan Tinggi, Sains dan Teknologi Republik
Indonesia  No.  137561/RHS/M/08/2024  tentang  Penguatan
Keputusan  No.  93731/RHS/M/08/2024  tertanggal  25  November
2024, (objek  sengketa)  oleh  Tergugat,  Penggugat  mendapatkan
perlakuan diskriminasi dan tidak adil dari Tergugat ;
6.Bahwa akibat ditetapkannya Surat  Keputusan Menteri Pendidikan
Kebudayaan,  Riset  dan  Teknologi  Republik  Indonesia  Nomor  :
93731/RHS/M/08/2024,  tertanggal  4  Oktober  2024.  Tentang
Pembebasan Dari Jabatannya Menjadi Jabatan Pelaksana selama
12  (dua  belas)  bulan,  atas  nama  dr.  IVAN  ROVIAN  M.Kp  dan
Keputusan Menteri Pendidikan Tinggi, Sains dan Teknologi Republik
Indonesia  No.  137561/RHS/M/08/2024  tentang  Penguatan
Keputusan  No.  93731/RHS/M/08/2024  tertanggal  25  November
2024,   (objek  sengketa)  oleh  Tergugat,  Penggugat  mengalami
gangguan  psikologis  dari  tekanan  atau  pandangan  bawahannya
serta mendapatkan pertanyaan yang menyudutkan penggugat dari
keluarganya atau anak-anaknya ;
## V. ALASAN DASAR HUKUM GUGATAN
1.Bahwa berdasarkan Pasal 1 angka 9 Undang-Undang 5 Tahun 1986
tentang Peradilan Tata Usaha Negara (sebagaimana telah diubah

Kepaniteraan Mahkamah Agung Republik Indonesia berusaha untuk selalu mencantumkan informasi paling kini dan akurat sebagai bentuk komitmen Mahkamah Agung untuk pelayanan publik, transparansi dan akuntabilitas
pelaksanaan fungsi peradilan. Namun dalam hal-hal tertentu masih dimungkinkan terjadi permasalahan teknis terkait dengan akurasi dan keterkinian informasi yang kami sajikan, hal mana akan terus kami perbaiki dari waktu kewaktu.
Dalam hal Anda menemukan inakurasi informasi yang termuat pada situs ini atau informasi yang seharusnya ada, namun belum tersedia, maka harap segera hubungi Kepaniteraan Mahkamah Agung RI melalui :
dengan Undang-Undang Nomor 9 Tahun 2004 tentang Perubahan
Undang-Undang Nomor 5 Tahun 1986 tentang Peradilan Tata Usaha
Negara dan juga telah diubah menjadi Undang-Undang Nomor 51
Tahun 2009 tentang Perubahan Kedua Atas Undang-Undang Nomor
5 Tahun 1986 tentang Peradilan Tata Usaha Negara) menyebutkan
“keputusan  tata  usaha  negara  adalah  penetapan  tertulis  yang
dikeluarkan oleh badan atau pejabat tata usaha negara yang berisi
tindakan  hukum  tata  usaha  negara  berdasarkan  peraturan
perundang-undangan yang berlaku yang bersifat konkret, individual
dan  final,  yang  menimbulkan  akibat  hukum  bagi  seseorang  atau
badan hukum perdata” ;
2.Bahwa Penggugat selaku Pegawai Negeri Sipil di Daerah Kabupaten
Jombang  Surabaya  Indonesia,  Nyata-nyata  memeliki  kepentingan
dan dampak langsung atas Objek Gugatan dengan alasan sebagai
berikut: 
1)Bahwa Penggugat merupakan  Pegawai Negeri Sipil Daerah
Golongan  III/B  dengan  Tugas  Dokter  Umum,  berdasarkan
Surat  Keputusan  Bupati  Jombang  Nomor  :
813/59/415.43/2009  tentang  Pengangkatan  Calon  Pegawai
Negeri Sipil Daerah terhitung mulai tanggal 1 Januari 2009
dan ditetapkan di Jombang pada tanggal 25 Maret 2009;
2)Kronologi pindah dari PNS Daerah Jombang ke kementerian
kesehatan, dan Mutasi ke Kementerian Ristek Dikti; 
3)Kementerian Ristek  dikti  bergabung  kemendikbud  Ristek,
Kemudian  diangkat  sebagai  pejabat  Fungsional  Analisis
kebijakan Muda.
4)Bahwa  Penggugat di  Berhentikan  dari  Jabatan  Fungsional
dan  Pengangkatan  Sebagai  Pejabatan  Administator  Pada
Lembaga  Layanan  Pendidikan  Tinggi  Wilayah  VII
berdasarakan  Keputusan  Menteri  Pendidikan,  Kebudayaan,
Riset, dan Teknologi Republik Indonesia Nomor 7523/MPK.A/
RHS/KP.07.00/2022 tertanggal 27 Januari 2022:

Kepaniteraan Mahkamah Agung Republik Indonesia berusaha untuk selalu mencantumkan informasi paling kini dan akurat sebagai bentuk komitmen Mahkamah Agung untuk pelayanan publik, transparansi dan akuntabilitas
pelaksanaan fungsi peradilan. Namun dalam hal-hal tertentu masih dimungkinkan terjadi permasalahan teknis terkait dengan akurasi dan keterkinian informasi yang kami sajikan, hal mana akan terus kami perbaiki dari waktu kewaktu.
Dalam hal Anda menemukan inakurasi informasi yang termuat pada situs ini atau informasi yang seharusnya ada, namun belum tersedia, maka harap segera hubungi Kepaniteraan Mahkamah Agung RI melalui :
-Bahwa  berdasarkan  Keputusan  Menteri  Pendidikan,
Kebudayaan, Riset, dan Teknologi Republik Indonesia
Nomor  7523/MPK.A/RHS/KP.07.00/2022  pada  tanggal
27  Januari  2022,  Penggugat  pangkat  Penata  Tk.I,
Golongan ruang III/d, dari Jabatan Analis Kebijakan Ahli
Muda  (AK.300)  pada  Layanan  Pendidikan  Tinggi
Wilayah VII;
-Bahwa  berdasarkan  Keputusan  Menteri  Pendidikan,
Kebudayaan, Riset, dan Teknologi Republik Indonesia
Nomor  7523/MPK.A/RHS/KP.07.00/2022  tentang
Pemberhentian  dari  Jabatan  Fungsional  dan
Pengangkatan  Sebagai  Pejabatan  Administator  Pada
Lembaga  Layanan  Pendidikan  Tinggi  Wilayah  VII,
Penggugat diangkat Sebagai Kepala Bagian Tata Usaha
Lembaga Layanan Pendidikan Tinggi Wilayah VII dan di
berikan tunjangan Jabatan struktural eselon III.a setiap
bulan  sesuai  Peraturan  Perundang-undangan  yang  di
tetapkan pada tanggal 27 Januari 2022;
5)Bahwa Penggugat telah di sumpah berdasarkan Berita Acara
Pengambilan Sumpah Jabatan Pegawai Negri Sipil Nomor :
7590/MPK.A/KP.07.00/2022, Berdasarkan Keputusan Menteri
Pendidikan,  Kebudayaan,  Riset,  dan  Teknologi  Republik
Indonesia Nomor 7523/MPK.A/RHS/KP .07.00/2022 tertanggal 27
Januari 2022, telah di angkat sebagai Kepala Bagian Umum,
Lembaga Layanan Pendidikan Tinggi Wilayah VII;
6)Bahwa  Penggugat  telah  dilantik  berdasarkan  Surat
Pernyataan Pelantikan Nomor : 7952/A3/KP.07.00/2022 pada
tangga  28  Januari  2022,  Berdasarkan  Keputusan  Menteri
Pendidikan,  Kebudayaan,  Riset,  dan  Teknologi  Republik
Indonesia Nomor 7473/MPK.A/RHS/KP .07.00/2022 tertanggal 27
Januari 2022, telah di angkat sebagai Kepala Bagian Umum,
Lembaga Layanan Pendidikan Tinggi Wilayah VII dan dilantik

Kepaniteraan Mahkamah Agung Republik Indonesia berusaha untuk selalu mencantumkan informasi paling kini dan akurat sebagai bentuk komitmen Mahkamah Agung untuk pelayanan publik, transparansi dan akuntabilitas
pelaksanaan fungsi peradilan. Namun dalam hal-hal tertentu masih dimungkinkan terjadi permasalahan teknis terkait dengan akurasi dan keterkinian informasi yang kami sajikan, hal mana akan terus kami perbaiki dari waktu kewaktu.
Dalam hal Anda menemukan inakurasi informasi yang termuat pada situs ini atau informasi yang seharusnya ada, namun belum tersedia, maka harap segera hubungi Kepaniteraan Mahkamah Agung RI melalui :
pada tanggal 28 Januari 2022.
7)Bahwa  berdasarkan  Keputusan  Menteri  Pendidikan,
Kebudayaan, Riset, dan Teknologi Nomor : 10958/S/07/2023
tentang  Kenaikan  Pangkat  Pegawai  Negeri  Sipil  di
Lingkungan Kementerian Pendidikan, Kebudayan, Riset, dan
Teknologi  tertanggal  15  Februari  2023,  PENGGUGAT
berpangkat  Penata  Tingkat  I/III/d/1  Oktober  2019  sebagai
Kepala  Bagian  Umum  yang  diangkat  menjadi  Pembina
Golongan Ruang IV/a, dengan masa kerja 14 Tahun 3 Bulan,
dan diberi gaji pokok sebesar Rp. 3.782.400.00.- ditambah
dengan  penghasilan  lainnya  berdasarkan  peratutan
perundang-undangan terhitung sejak tanggal 1 April 2023;   
8)Bahwa Penggugat  keberatan  dan  dirugikan  sehubungan
dengan  surat Keputusan  Menteri  Pendidikan  Kebudayaan,
Riset dan Teknologi Republik Indonesia Nomor : 93731/RHS/
M/08/2024, tertanggal 4 Oktober 2024  Tentang Pembebasan
Dari Jabatannya Menjadi Jabatan Pelaksana selama 12 (dua
belas) bulan, atas nama dr.  IVAN ROVIAN M.Kp;
9)Bahwa  sebelum dikeluarkan objek sengketa  a quo tersebut
Tergugat telah menerima laporan yang diterima oleh Kepala
Lembaga  Pendidikan  Tinggi  Wilayah  VII  yang  menerima
adanya laporan dugaan pelanggaran pada tahun 2023 atau
pada  suatu  kurun  waktu  tertentu  pada  tahun  2023  telah
melakukan perbuatan yang melanggar ketentuan Pasal 4 ayat
(1) dan Pasal 3 ayat (1) Peraturan Pemerintahan Nomor 45
Tahun 1990;
10)Bahwa Tergugat melakukan Pemanggilan selama 2 (dua) kali
kepada  Penggugat  melalui  Kepala  Lembaga  Layanan
Pendidikan Tinggi Wilayah VII, bahwa panggilan tersebut di
dasari atas adanya laporan dari pihak istri sah dari Penggugat
yang bernama dr. Tri Asih Imro’ati;
11)Bahwa laporan yang telah di terima oleh Lembaga Layanan

Kepaniteraan Mahkamah Agung Republik Indonesia berusaha untuk selalu mencantumkan informasi paling kini dan akurat sebagai bentuk komitmen Mahkamah Agung untuk pelayanan publik, transparansi dan akuntabilitas
pelaksanaan fungsi peradilan. Namun dalam hal-hal tertentu masih dimungkinkan terjadi permasalahan teknis terkait dengan akurasi dan keterkinian informasi yang kami sajikan, hal mana akan terus kami perbaiki dari waktu kewaktu.
Dalam hal Anda menemukan inakurasi informasi yang termuat pada situs ini atau informasi yang seharusnya ada, namun belum tersedia, maka harap segera hubungi Kepaniteraan Mahkamah Agung RI melalui :
Pendidikan Tinggi Wilayah VII dari istri sah Penggugat tidak
mempunyai bukti yang kuat, sebagaimana Penggugat yang
bernama  dr.  Ivan  Rovian,  M.Kp  dengan  istri  dr.  Tri  Asih
Imro’ati sampai sekarang masih mempunyai hubungan suami
istri  yang  sah  dan  tercatat  di  Kantor  Urusan  Agama
Kecamatan Lamongan, Jombang;
12)Bahwa Laporan yang dilakukan oleh istri Penggugat  atas
adanya  dugaan  pernikahan  sirih  yang  dilakukan  oleh
Penggugat kepada wanita lain tidak dibuktikan terlebih dahulu
dengan laporan polisi yang mempunyai kewenangan untuk
melakukan  penyelidikan  dugaan  tindak  pidana  perzinahan
atau  perselingkuhan  di  negara  ini  sehingga  apabila
Penggugat benar-benar telah melakukan perbuatan tersebut
maka  baru  lah  pihak  Tergugat  dapat  melakukan  dan
menindaklanjuti laporan tersebut;
13)Bahwa perbuatan dugaan Perselingkuhan atau perzinahan
sangatlah jelas diatur dalam Kitab Undang-Undang Hukum
Pidana Pasal 284 (KUHP), sehingga dapat dibuktikan dengan
adanya laporan polisi;
14)Bahwa Penggugat menduga tindakan yang dilakukan oleh
Kepala  Lembaga  Pendidikan  Tinggi  Wilayah  VII  dengan
langsung menerima dan menindak lanjuti laporan dari pihak
Istri  Penggugat  bersifat  tendedius,  sentimental  dan
kesewenang-wenangan terhadap penggugat, dimana laporan
yang  menimbulkan  keluarnya  Surat Keputusan  Menteri
Pendidikan  Kebudayaan,  Riset  dan  Teknologi  Republik
Indonesia  Nomor  :  93731/RHS/M/08/2024, tertanggal  4
Oktober 2024 Tentang Pembebasan Dari Jabatannya Menjadi
Jabatan Pelaksana selama 12 (dua belas) bulan, atas nama
dr. IVAN ROVIAN M.Kp  dan  Keputusan  Menteri Pendidikan
Tinggi, Sains dan Teknologi Republik Indonesia No. 137561/
RHS/M/08/2024  tanggal  25  November  2024,  tentang

Kepaniteraan Mahkamah Agung Republik Indonesia berusaha untuk selalu mencantumkan informasi paling kini dan akurat sebagai bentuk komitmen Mahkamah Agung untuk pelayanan publik, transparansi dan akuntabilitas
pelaksanaan fungsi peradilan. Namun dalam hal-hal tertentu masih dimungkinkan terjadi permasalahan teknis terkait dengan akurasi dan keterkinian informasi yang kami sajikan, hal mana akan terus kami perbaiki dari waktu kewaktu.
Dalam hal Anda menemukan inakurasi informasi yang termuat pada situs ini atau informasi yang seharusnya ada, namun belum tersedia, maka harap segera hubungi Kepaniteraan Mahkamah Agung RI melalui :
Penguatan Keputusan Menteri Pendidikan Kebudayaan, Riset
dan Teknologi Republik Indonesia Nomor : 93731/RHS/M/08/
2024, tertanggal 4 Oktober 2024  Tentang  Pembebasan Dari
Jabatannya  Menjadi  Jabatan  Pelaksana  selama  12  (dua
belas) bulan, atas nama dr.  IVAN ROVIAN M.Kp, 4, sangatlah
merampas Hak Asasi Penggugat;      
15)Bahwa Penggugat telah mengirimkan Surat Bantahan kepada
Tergugat berdasarkan Bantahan atas keberatannya terhadap
Surat Keputusan Menteri Pendidikan Kebudayaan, Riset dan
Teknologi Republik Indonesia Nomor : 93731/RHS/M/08/2024,
tertanggal  4  Oktober  2024  Tentang  Pembebasan  Dari
Jabatannya  Menjadi  Jabatan  Pelaksana  selama  12  (dua
belas) bulan, atas nama dr.  IVAN ROVIAN M.Kp,  yang pada
poinnya memberikan  sanggahan serta klarifikasi atas Surat
Keputusan  tersebut , namun  hingga  saat  Bantahan ini
diajukan,  tidak  pernah  ada  jawaban  atau  tanggapan  yang
wajar  dan  layak  dari  Tergugat  sehingga  Penggugat  tidak
dapat melakukan aktivitas Pekerjaan normal.
3.Bahwa Objek Gugatan dalam perkara a quo menimbulkan kerugian
langsung bagi Penggugat, di antaranya: 
(1)Penggugat  tidak  dapat  melaksanakan  aktivitas  pekerjaan
sebagaimana mestinya;  
(2)Tidak terpenuhinya hak asasinya sebagai Pekerja Negeri Sipil ;
Perihal  kerugian-kerugian  yang  dialami  oleh  Penggugat
tersebut lebih lengkap diuraikan dalam Gugatan  a quo  yang
seharusnya  tidak  terjadi  apabila  Tergugat  tidak  melakukan
Objek Gugatan dalam perkara  a quo  atau apabila Tergugat
memenuhi  dan  menjaga  amanat  Undang-Undang  Dasar
Negara  Republik  Indonesia  Tahun  1945  dengan
mengedepankan Asas-Asas Umum Pemerintahan yang Baik; 
4.Bahwa  Penggugat  telah  berhak,  berkepentingan,  dan  berdasar

Kepaniteraan Mahkamah Agung Republik Indonesia berusaha untuk selalu mencantumkan informasi paling kini dan akurat sebagai bentuk komitmen Mahkamah Agung untuk pelayanan publik, transparansi dan akuntabilitas
pelaksanaan fungsi peradilan. Namun dalam hal-hal tertentu masih dimungkinkan terjadi permasalahan teknis terkait dengan akurasi dan keterkinian informasi yang kami sajikan, hal mana akan terus kami perbaiki dari waktu kewaktu.
Dalam hal Anda menemukan inakurasi informasi yang termuat pada situs ini atau informasi yang seharusnya ada, namun belum tersedia, maka harap segera hubungi Kepaniteraan Mahkamah Agung RI melalui :
secara hukum untuk mengajukan Gugatan Tata Usaha Negara  a
quo. Sehingga demikian, kepentingan Penggugat dalam Gugatan a
quo serta kewenangan mengadili Pengadilan Tata Usaha Negara
merupakan  upaya  hukum  yang  sah  dan  konstitusional,  dan
didasarkan atas kerugian yang nyata. Karena itu pula Penggugat
menganggap bahwa adagium “point de interest point de action”  telah
terpenuhi untuk melakukan gugatan ini ;
5.Bahwa Tergugat  melakukan  Pemanggilan  selama  2  (dua)  kali
kepada Penggugat melalui Kepala Lembaga Layanan Pendidikan
Tinggi Wilayah VII, bahwa panggilan tersebut di dasari atas adanya
laporan dari pihak istri sah dari Penggugat yang bernama dr. Tri Asih
Imro’ati;
6.Bahwa  laporan  yang  telah  diterima  oleh  Lembaga  Layanan
Pendidikan  Tinggi  Wilayah  VII  dari  istri  sah  Penggugat  tidak
mempunyai bukti yang kuat, sebagaimana Penggugat yang bernama
dr.  Ivan  Rovian,  M.Kp  dengan  istri  dr.  Tri  Asih  Imro’ati  sampai
sekarang  masih  mempunyai  hubungan  suami  istri  yang  sah  dan
tercatat di Kantor Urusan Agama Kecamatan Lamongan, Jombang;
7.Bahwa  Laporan yang dilakukan oleh istri Penggugat atas adanya
dugaan pernikahan sirih yang dilakukan oleh Penggugat kepadad
wanita lain tidak dibuktikan terlebih dahulu dengan laporan polisi
yang  mempunyai  kewenangan  untuk  melakukan  penyelidikan
dugaan tindak pidana perzinahan atau perselingkuhan di negara ini
sehingga  apabila  Penggugat  benar-benar  telah  melakukan
perbuatan tersebut maka baru lah pihak Tergugat dapat melakukan
dan menindak lanjuti laporan tersebut;
8.Bahwa  perbuatan dugaan  Perselingkuhan  atau  perzinahan
sangatlah jelas diatur dalam Kitab Undang-Undang Hukum Pidana
Pasal  284  (KUHP),  sehingga  dapat  dibuktikan  dengan  adanya
laporan polisi;
9.Bahwa Penggugat menduga tindakan yang dilakukan oleh Kepala
Lembaga Pendidikan Tinggi Wilayah VII dengan langsung menerima

Kepaniteraan Mahkamah Agung Republik Indonesia berusaha untuk selalu mencantumkan informasi paling kini dan akurat sebagai bentuk komitmen Mahkamah Agung untuk pelayanan publik, transparansi dan akuntabilitas
pelaksanaan fungsi peradilan. Namun dalam hal-hal tertentu masih dimungkinkan terjadi permasalahan teknis terkait dengan akurasi dan keterkinian informasi yang kami sajikan, hal mana akan terus kami perbaiki dari waktu kewaktu.
Dalam hal Anda menemukan inakurasi informasi yang termuat pada situs ini atau informasi yang seharusnya ada, namun belum tersedia, maka harap segera hubungi Kepaniteraan Mahkamah Agung RI melalui :
dan  menindak  lanjuti  laporan  dari  pihak  Istri  Penggugat  bersifat
tendedius,  sentimental  dan  kesewenang-wenangan  terhadap
penggugat,  dimana  laporan  yang  menimbulkan  keluarnya  Surat
Keputusan  Menteri  Pendidikan  Kebudayaan,  Riset  dan  Teknologi
Republik  Indonesia  Nomor  :  93731/RHS/M/08/2024, tertanggal  4
Oktober  2024 Tentang  Pembebasan  Dari  Jabatannya  Menjadi
Jabatan Pelaksana selama 12 (dua belas) bulan, atas nama dr.  IVAN
ROVIAN M.Kp, yang sangatlah merampas Hak Asasi Penggugat;      
10.Bahwa  Penggugat  telah  mengirimkan  Surat  Bantahan  kepada
Tergugat berdasarkan  Bantahan atas keberatannya terhadap Surat
Keputusan  Menteri  Pendidikan  Kebudayaan,  Riset  dan  Teknologi
Republik  Indonesia  Nomor  :  93731/RHS/M/08/2024, tertanggal  4
Oktober  2024 Tentang  Pembebasan  Dari  Jabatannya  Menjadi
Jabatan Pelaksana selama 12 (dua belas) bulan, atas nama dr.  IVAN
ROVIAN M.Kp, yang pada poin nya memberikan sanggahan serta
klarifikasi  atas  Surat  Keputusan  tersebut , namun  hingga  saat
Bantahan ini diajukan, tidak pernah ada jawaban atau tanggapan
yang wajar dan layak dari Tergugat sehingga Penggugat tidak dapat
melakukan aktivitas Pekerjaan normal;  
11.Bahwa  berdasarkan alasan-alasan tersebut diatas Pe nggugat tidak
terbukti melanggar Pasal 3 Ayat (1) Jo Pasal 4 Ayat (1) Peraturan
Pemerintah  RI  No  45  Tahun  1990  Perubahan  atas  Peraturan
Pemerintah  RI  No  10  Tahun  1983  tentang  izin  Perkawinan  dan
Perceraian bagi Pegawai Negeri Sipil ;
12.Bahwa Penggugat menolak dan tidak terbukti melakukan melanggar
kewajiban dan atau melanggar disiplin berat berdasarkan Pasal 41
Peraturan Pemerintah RI No. 94 Tahun 202 1;
13.Bahwa  padahal Pejabat  Negara  cq.  Menteri  Pendidikan,
Kebudayaan,  Riset  dan  Teknologi  dalam  mengambil  keputusan
menerbitkan  surat  keputusan  yang  bersifat  strategis,  tidak
dibenarkan  melampaui  batas  kewenangannya  sebagaimana telah

Kepaniteraan Mahkamah Agung Republik Indonesia berusaha untuk selalu mencantumkan informasi paling kini dan akurat sebagai bentuk komitmen Mahkamah Agung untuk pelayanan publik, transparansi dan akuntabilitas
pelaksanaan fungsi peradilan. Namun dalam hal-hal tertentu masih dimungkinkan terjadi permasalahan teknis terkait dengan akurasi dan keterkinian informasi yang kami sajikan, hal mana akan terus kami perbaiki dari waktu kewaktu.
Dalam hal Anda menemukan inakurasi informasi yang termuat pada situs ini atau informasi yang seharusnya ada, namun belum tersedia, maka harap segera hubungi Kepaniteraan Mahkamah Agung RI melalui :
diatur  dalam Undang-undan g  Republik Indonesia Nomor :  30 Tahun
2014 Tentang Administrasi Negara, Asas-asas Pemerintahan yang
Baik Pasal 10 ayat (1) AUPB yang dimaksud dalam Undang-undang
ini meliputi asas :
a.Kepastian hukum;
b.Kemanfaatan;
c.Ketidak berpihakan;
d.Kecermatan;
e.Tidak menyalahgunakan  kewenangan;
f.Keterbukaan;
g.Kepentingan umum, dan;
h.Pelayanan yang baik.
14.Bahwa  pada  poin  1  (satu)  s/d  9 (sembilan)   Penggugat telah
menjelaskan seksama  adanya  dugaan  pelanggaran  administrasif
didahuli dengan surat  peringatan, sehingga ada kesempatan bagi
Penggugat untuk membenahi  kekeliruan/dan  atau  kesalahan
administrasif. Nyatanya surat  peringatan yang diterbitkan Tergugat
kepada  Penggugat Keputusan Menteri Pendidikan Kebudayaan,
Riset dan Teknologi Republik Indonesia Nomor :  93731/RHS/M/08/
2024, tertanggal  4  Oktober  2024  Tentang  Pembebasan  Dari
Jabatannya  Menjadi  Jabatan  Pelaksana  selama  12  (dua  belas)
bulan, atas nama dr.  IVAN ROVIAN M.Kp;
15.Bahwa akibat perbuatan hukum  yang dilakukan oleh  Tergugat telah
menerbitkan  Surat  Keputusan  Menteri  Pendidikan  Kebudayaan,
Riset  dan  Teknologi  Republik  Indonesia  Nomor  :
93731/RHS/M/08/2024, tertanggal  4  Oktober  2024  Tentang
Pembebasan Dari Jabatannya Menjadi Jabatan Pelaksana selama
12  (dua  belas)  bulan,  atas  nama  dr.  IVAN  ROVIAN  M.Kp.  da n
Keputusan Menteri Pendidikan Tinggi, Sains dan Teknologi Republik
Indonesia  No. 137561/RHS/M/08/2024  tanggal 25 November 2024
tentang  Penguatan  Keputusan  Menteri  Pendidikan  Kebudayaan,
Riset  dan  Teknologi  Republik  Indonesia  Nomor  :

Kepaniteraan Mahkamah Agung Republik Indonesia berusaha untuk selalu mencantumkan informasi paling kini dan akurat sebagai bentuk komitmen Mahkamah Agung untuk pelayanan publik, transparansi dan akuntabilitas
pelaksanaan fungsi peradilan. Namun dalam hal-hal tertentu masih dimungkinkan terjadi permasalahan teknis terkait dengan akurasi dan keterkinian informasi yang kami sajikan, hal mana akan terus kami perbaiki dari waktu kewaktu.
Dalam hal Anda menemukan inakurasi informasi yang termuat pada situs ini atau informasi yang seharusnya ada, namun belum tersedia, maka harap segera hubungi Kepaniteraan Mahkamah Agung RI melalui :
93731/RHS/M/08/2024, tertanggal  4  Oktober  2024  Tentang
Pembebasan Dari Jabatannya Menjadi Jabatan Pelaksana selama
12 (dua belas) bulan, atas nama dr.  IVAN ROVIAN M.Kp, , telah
menimbulkan kerugian besar, patut  dan  beralasan  hukum
Keputusan pencabutan izin aquo tidak sah dan  haruslah dibatalkan
atau setidak-tidaknya  dinyatakan tidak berkekuatan  hukum.
## VI. PENUNDAAN PELAKSANAAN OB JEK SENGKETA 
1.Bahwa pelaksanaan objek sengketa yang dikeluarkan oleh Tergugat
untuk  ditunda  selama  pemeriksaan  sengketa  Tata  Usaha  Negara
sedang berjalan sampai dengan adanya putusan Pengadilan yang
memperoleh kekuatan hukum tetap sebagaimana diatur dalam Pasal
67  ayat  (4)  Undang-Undang  Nomor  51  Tahun  2009  tentang
Perubahan  Kedua  atas  Undang-Undang  Nomor  5  Tahun  1986
tentang  Peradilan  Tata  Usaha  Negara  yang  menyatakan:
“Permohonan Penundaan sebagaimana dimaksud pada ayat (2) : a.
Dapat  dikabulkan  hanya  apabila  terdapat  keadaan  yang  sangat
mendesak  yang  mengakibatkan  kepentingan  penggugat  sangat
dirugikan  jika  Keputusan  Tata  Usaha  Negara  yang  digugat  itu
tetap dilaksanakan; b. Tidak dapat dikabulkan apabila kepentingan
umum  dalam  rangka  pembangunan  mengharuskan  dilaksanakan
keputusan tersebut; . 
2.Bahwa yang  dimaksud  “keadaan  yang  sangat  mendesak  yang
mengakibatkan  kepentingan  Penggugat  sangat  dirugikan  jika
Keputusan  Tata  Usaha  Negara  yang  digugat  tersebut  tetap
dilaksanakan”  dan  pentingnya  objek  sengketa  a  quo  untuk  tetap
dilakukan  Penundaan  dalam  pemberlakuannya  adalah  untuk
mencegah Objek Keputusan yang dikeluarkan oleh Tergugat tersebut
akan  menjadi  pangkal  penyebab  kerugian  yang  lebih  besar  bagi
Penggugat  yaitu  hilangnya  hak-hak  Penggugat  untuk
menyelenggarakan  aktivitas  Pekerjaan  di  lingkungan  Layanan
Pendidikan  Negeri  Wilayah  VII  Surabaya  Republik  Indonesia.
Dengan  demikian  keadaan  yang  sangat  mendesak  yang

Kepaniteraan Mahkamah Agung Republik Indonesia berusaha untuk selalu mencantumkan informasi paling kini dan akurat sebagai bentuk komitmen Mahkamah Agung untuk pelayanan publik, transparansi dan akuntabilitas
pelaksanaan fungsi peradilan. Namun dalam hal-hal tertentu masih dimungkinkan terjadi permasalahan teknis terkait dengan akurasi dan keterkinian informasi yang kami sajikan, hal mana akan terus kami perbaiki dari waktu kewaktu.
Dalam hal Anda menemukan inakurasi informasi yang termuat pada situs ini atau informasi yang seharusnya ada, namun belum tersedia, maka harap segera hubungi Kepaniteraan Mahkamah Agung RI melalui :
mengakibatkan  kepentingan  Penggugat  sangat  dirugikan  jika
Keputusan  Tata  Usaha  Negara  yang  digugat  tersebut  tetap
dilaksanakan;
3.Bahwa berdasarkan keadaan yang sangat mendesak sebagaimana
Penggugat telah kemukakan di atas, maka mohon Majelis Hakim
Pemeriksa perkara ini untuk menetapkan dalam Putusan Sela yaitu
Penetapan Penundaan yang berisi perintah kepada Tergugat untuk
menunda pemberlakuan Surat Keputusan Obyek Sengketa yang
Diterbitkan oleh Tergugat pada tanggal 11 Oktober 2024 ; sebagai
objek  sengketa  dalam  Gugata  ini  berikut  tindakan  administratif
lanjutan lainnya selama pemeriksaan perkara ini berlangsung sampai
dengan adanya putusan Pengadilan yang berkekuatan hukum tetap,
sesuai ketentuan Pasal 64 ayat (4) Undang-Undang Nomor 51 Tahun
2009  tentang  Perubahan  Kedua  Atas  Undang-Undang  Nomor  5
Tahun 1986 tentang Peradilan Tata Usaha Negara;
4.Bahwa saat ini Penggugat merupakan pihak yang dirugikan sedang
melakukan  Gugatan  dan  proses  itu  sementara  berjalan  sehingga
mendesak untuk segera memperoleh kepastian hukum. 
## VII. PETITUM/TUNTUTAN  :
Berdasarkan  segala  hal-hal  yang  telah  Penggugat  uraikan  di  atas
berkenan kiranya Majelis Hakim yang memeriksa Perkara ini, agar
dapat memberikan putusan  seperti tersebut di bawah ini :
A.Dalam Penundaan.
1.Mengabulkan Permohonan Penundaan yang  diajukan  oleh
Penggugat; 
2.Mewajibkan kepada Tergugat untuk menunda pelaksanaan objek
sengketa berupa : 
1.  Keputusan  Menteri  Pendidikan  Kebudayaan,  Riset  dan
Teknologi Republik Indonesia Nomor : 93731/RHS/M/08/2024,
tertanggal  4  Oktober  2024  Tentang  Pembebasan  Dari
Jabatannya  Menjadi  Jabatan  Pelaksana  selama  12  (dua
belas) bulan, atas nama dr.  IVAN ROVIAN M.Kp. 

Kepaniteraan Mahkamah Agung Republik Indonesia berusaha untuk selalu mencantumkan informasi paling kini dan akurat sebagai bentuk komitmen Mahkamah Agung untuk pelayanan publik, transparansi dan akuntabilitas
pelaksanaan fungsi peradilan. Namun dalam hal-hal tertentu masih dimungkinkan terjadi permasalahan teknis terkait dengan akurasi dan keterkinian informasi yang kami sajikan, hal mana akan terus kami perbaiki dari waktu kewaktu.
Dalam hal Anda menemukan inakurasi informasi yang termuat pada situs ini atau informasi yang seharusnya ada, namun belum tersedia, maka harap segera hubungi Kepaniteraan Mahkamah Agung RI melalui :
2. Keputusan Menteri  Pendidikan  Tinggi, Sains dan  Teknologi
Republik  Indonesia  No.  137561/RHS/M/08/2024  tanggal  25
November  2024,  tentang  Penguatan  Keputusan  Menteri
Pendidikan  Kebudayaan,  Riset  dan  Teknologi  Republik
Indonesia Nomor : 93731/RHS/M/08/2024, tanggal 4 Oktober
2024 Tentang Pembebasan Dari Jabatannya Menjadi Jabatan
Pelaksana selama 12 (dua belas) bulan, atas nama dr.  IVAN
ROVIAN  M.Kp,, sampai  ada  putusan  pengadilan  yang
berkekuatan  hukum  tetap  atau  ada  penetapan  lain  yang
mencabutnya.
B.Dalam Pokok Perkara.
1.Mengabulkan Gugatan Penggugat Untuk Seluruhnya;
2.Menyatakan batal atau tidak sah : 
1.Keputusan  Menteri  Pendidikan  Kebudayaan,  Riset  dan
Teknologi Republik Indonesia Nomor : 93731/RHS/M/08/2024,
tertanggal  4  Oktober  2024  Tentang  Pembebasan  Dari
Jabatannya  Menjadi  Jabatan  Pelaksana  selama  12  (dua
belas) bulan, atas nama dr. IVAN ROVIAN M.Kp.
2.Keputusan  Menteri  Pendidikan  Tinggi, Sains dan  Teknologi
Republik  Indonesia  No.  137561/RHS/M/08/2024  tanggal  25
November  2024  tentang  Penguatan  Keputusan  Menteri
Pendidikan  Kebudayaan,  Riset  dan  Teknologi  Republik
Indonesia Nomor : 93731/RHS/M/08/2024, tanggal 4 Oktober
2024 Tentang Pembebasan Dari Jabatannya Menjadi Jabatan
Pelaksana selama 12 (dua belas) bulan, atas nama dr.  IVAN
ROVIAN M.Kp,
3.Mewajibkan kepada Tergugat Untuk Mencabut   berupa :
1.Keputusan  Menteri  Pendidikan  Kebudayaan,  Riset  dan
Teknologi Republik Indonesia Nomor : 93731/RHS/M/08/2024,
tertanggal  4  Oktober  2024  Tentang  Pembebasan  Dari
Jabatannya  Menjadi  Jabatan  Pelaksana  selama  12  (dua

Kepaniteraan Mahkamah Agung Republik Indonesia berusaha untuk selalu mencantumkan informasi paling kini dan akurat sebagai bentuk komitmen Mahkamah Agung untuk pelayanan publik, transparansi dan akuntabilitas
pelaksanaan fungsi peradilan. Namun dalam hal-hal tertentu masih dimungkinkan terjadi permasalahan teknis terkait dengan akurasi dan keterkinian informasi yang kami sajikan, hal mana akan terus kami perbaiki dari waktu kewaktu.
Dalam hal Anda menemukan inakurasi informasi yang termuat pada situs ini atau informasi yang seharusnya ada, namun belum tersedia, maka harap segera hubungi Kepaniteraan Mahkamah Agung RI melalui :
belas) bulan, atas nama dr. IVAN ROVIAN M.Kp. 
2.Keputusan  Menteri  Pendidikan  Tinggi, Sains dan  Teknologi
Republik  Indonesia  No.  137561/RHS/M/08/2024  tanggal  25
November  2024  tentang  Penguatan  Keputusan  Menteri
Pendidikan  Kebudayaan,  Riset  dan  Teknologi  Republik
Indonesia Nomor : 93731/RHS/M/08/2024, tanggal 4 Oktober
2024 Tentang Pembebasan Dari Jabatannya Menjadi Jabatan
Pelaksana selama 12 (dua belas) bulan, atas nama dr.  IVAN
ROVIAN M.Kp, 
4.Mewajibkan Tergugat  untuk  merehabilitasi  hak-hak  atau
kedudukan hukum Penggugat sebagaimana semula atau yang
setara;
5.Menghukum Kepada Tergugat Untuk Membayar Biaya Perkara.
Atau setidak-tidaknya apabila Pengadilan Tata Usaha Negara Jakarta
Berpendapat Lain, mohon kiranya putusan yang seadil-adilnya ( Ex Aequo Et
Bono)
Bahwa  terhadap  gugatan  Penggugat  tersebut, Tergugat  telah
mengajukan  Jawaban pada  persidangan  secara  elektronik  tanggal  20
Januari 2025, yaitu sebagai berikut:  

# DALAM EKSEPSI
 
GUGATAN PENGGUGAT PREMATUR
1.Bahwa  Penggugat  mengajukan  gugatan  terhadap  objek  gugatan
Keputusan  Menteri  Pendidikan  Kebudayaan,  Riset  dan  Teknologi
Republik  Indonesia  Nomor:  93731/RHS/M/08/2024,  tertanggal  4
Oktober 2024 Tentang Pembebasan Dari Jabatannya Menjadi Jabatan
Pelaksana selama 12 (dua belas) bulan, atas nama dr. IVAN ROVIAN
M.Kp. (Objek Sengketa 1 ) dan terhadap Keputusan Menteri Pendidikan
Tinggi, Sains dan Teknologi Republik Indonesia Nomor: 137561/RHS/
M/08/2024, tanggal 25 November 2024 tentang penguatan Keputusan
Menteri  Pendidikan,  Kebudayaan,  Riset  dan  Teknologi  Republik
Indonesia Nomor: 93731/RHS/M/08/2024, tertanggal 4 Oktober 2024
Tentang  Pembebasan  Dari  Jabatannya  Menjadi  Jabatan  Pelaksana

Kepaniteraan Mahkamah Agung Republik Indonesia berusaha untuk selalu mencantumkan informasi paling kini dan akurat sebagai bentuk komitmen Mahkamah Agung untuk pelayanan publik, transparansi dan akuntabilitas
pelaksanaan fungsi peradilan. Namun dalam hal-hal tertentu masih dimungkinkan terjadi permasalahan teknis terkait dengan akurasi dan keterkinian informasi yang kami sajikan, hal mana akan terus kami perbaiki dari waktu kewaktu.
Dalam hal Anda menemukan inakurasi informasi yang termuat pada situs ini atau informasi yang seharusnya ada, namun belum tersedia, maka harap segera hubungi Kepaniteraan Mahkamah Agung RI melalui :
selama  12  (dua  belas)  bulan,  atas  nama  dr.  IVAN  ROVIAN  M.Kp.
(Objek Sengketa 2). (Objek Sengketa 1 dan Objek Sengketa 2 secara
bersama-sama selanjutnya disebut Objek Gugatan );
2.Bahwa  Penggugat  dalam  Gugatannya  menyatakan  bahwa  telah
melakukan  Upaya  hukum  administrasi  berupa  keberatan  atas
Keputusan yang dikeluarkan Tergugat;
3.Bahwa  sebagaimana  disebutkan  di  atas,  Penggugat  melayangkan
gugatan  atas  2  Objek  Gugatan,  yang  mana  salah  satunya  adalah
Keputusan Menteri Pendidikan Tinggi, Sains dan Teknologi Republik
Indonesia Nomor: 137561/RHS/M/08/2024, tanggal 25 November 2024
tentang penguatan  Keputusan Menteri Pendidikan, Kebudayaan, Riset
dan  Teknologi  Republik  Indonesia  Nomor:  93731/RHS/M/08/2024,
tertanggal  4  Oktober  2024  Tentang  Pembebasan  Dari  Jabatannya
Menjadi Jabatan Pelaksana selama 12 (dua belas) bulan, atas nama
dr. IVAN ROVIAN M.Kp. (Objek Sengketa 2);
4.Bahwa  apabila  mengikuti  konstruksi  hukum  yang  disampaikan
Penggugat  dalam  gugatannya,  terhadap  Objek  Sengketa  2,  sejak
diterbitkannya Objek Sengketa 2 hingga jawaban ini disampaikan pada
persidangan, Penggugat tidak pernah menempuh Upaya administrasi
kepada Tergugat selaku instansi yang mengeluarkan Keputusan;
5.Bahwa berdasarkan Pasal 48 Undang-Undang Nomor 5 Tahun 1986
tentang  Peradilan  Tata  Usaha  Negara  sebagaimana  telah  diubah
beberapa terakhir oleh Undang-Undang Nomor 51 Tahun 2009 tentang
Perubahan Kedua atas Undang-Undang Nomor 5 Tahun 1986 tentang
Peradilan Tata Usaha Negara (UU PTUN) mengatur sebagai berikut:
“Pengadilan  baru  berwenang  memeriksa,  memutus,  dan
menyelesaikan  sengketa  Tata  Usaha  Negara  sebagaimana
dimaksud  dalam  ayat  (1)  jika  seluruh  upaya  administrative  yang
bersangkutan telah digunakan”
6.Bahwa dalam penjelasan Pasal 48 UU PTUN menjelaskan gugatan
baru dapat diajukan setelah upaya administrative dilakukan dan bukan
sebaliknya yaitu tidak terdapat ketentuan yang mengatur bahwa upaya

Kepaniteraan Mahkamah Agung Republik Indonesia berusaha untuk selalu mencantumkan informasi paling kini dan akurat sebagai bentuk komitmen Mahkamah Agung untuk pelayanan publik, transparansi dan akuntabilitas
pelaksanaan fungsi peradilan. Namun dalam hal-hal tertentu masih dimungkinkan terjadi permasalahan teknis terkait dengan akurasi dan keterkinian informasi yang kami sajikan, hal mana akan terus kami perbaiki dari waktu kewaktu.
Dalam hal Anda menemukan inakurasi informasi yang termuat pada situs ini atau informasi yang seharusnya ada, namun belum tersedia, maka harap segera hubungi Kepaniteraan Mahkamah Agung RI melalui :
administratif  dapat  diajukan  saat  setelah  dilakukan  pendaftaran
gugatan, adapun bunyi penjelasan sebagai berikut:
“Apabila seluruh prosedur dan kesempatan tersebut pada penjelasan
ayat (1) telah ditempuh, dan pihak yang bersangkutan masih tetap
belum  merasa  puas,  barulah  persoalannya  dapat  digugat  dan
diajukan ke Pengadilan.”
7.Bahwa berdasarkan ketentuan tersebut, gugatan baru dapat diajukan
setelah  dilakukan  seluruh  upaya  administratif  baik  untuk  Objek
Gugatan,  oleh  karenanya  Penggugat  terlalu  dini  dan  premature
mengajukan gugatan perkara a quo;
8.Bahwa lebih lanjut berdasarkan Pasal 75 Undang-Undang Nomor 30
Tahun  2014  tentang  Administrasi  Pemerintahan  sebagaimana  telah
diubah  Peraturan  Pemerintah  Pengganti  Undang-Undang  Nomor  2
Tahun 2022 tentang Cipta Kerja (UU AP) menegaskan semua sengketa
tata  usaha  negara  diselesaikan  melalui  upaya  administratif  terlebih
dahulu yang terdiri dari keberatan dan banding administratif. Apabila
telah  dilakukan  upaya  administrative  maka  ia  dapat  mengajukan
gugatan di pengadilan. Adapun Ketentuan ersebut berbunyi sebagai
berikut:
Pasal 75
(1) Warga Masyarakat yang dirugikan terhadap Keputusan dan/atau
Tindakan dapat mengajukan Upaya Administratif kepada Pejabat
Pemerintahan atau Atasan Pejabat yang menetapkan dan/atau
melakukan Keputusan dan/atau Tindakan.
(2)  Upaya Administratif sebagaimana dimaksud pada ayat (1) terdiri
atas:
a.keberatan; dan
b.banding
Pasal 76
Dalam  hal  Warga  Masyarakat  tidak  menerima  atas  penyelesaian
banding oleh Atasan Pejabat, Warga Masyarakat dapat mengajukan
gugatan ke Pengadilan

Kepaniteraan Mahkamah Agung Republik Indonesia berusaha untuk selalu mencantumkan informasi paling kini dan akurat sebagai bentuk komitmen Mahkamah Agung untuk pelayanan publik, transparansi dan akuntabilitas
pelaksanaan fungsi peradilan. Namun dalam hal-hal tertentu masih dimungkinkan terjadi permasalahan teknis terkait dengan akurasi dan keterkinian informasi yang kami sajikan, hal mana akan terus kami perbaiki dari waktu kewaktu.
Dalam hal Anda menemukan inakurasi informasi yang termuat pada situs ini atau informasi yang seharusnya ada, namun belum tersedia, maka harap segera hubungi Kepaniteraan Mahkamah Agung RI melalui :
9.Bahwa  ketentuan  tersebut  juga  diatur  dalam  Pasal  2  Peraturan
Mahkamah  Agung  Nomor  6  Tahun  2018  tentang  Pedoman
Penyelesaian Sengketa Administrasi Pemerintahan Setelah Menempuh
Upaya Administratif (Perma 6/2018)  menjelaskan bahwa Pengadilan
Tata Usaha Negara berwenang setelah menempuh Upaya administratif,
sebagai bunyi pasal berikut:
Pasal 2
Pengadilan  berwenang  menerima,  memeriksa,  memutus  dan
menyelesaikan  sengketa  administrasi  pemerintahan  setelah
menempuh upaya administratif
10.Bahwa  dengan  mencoba  mengikuti  konstruksi  hukum  yang
disampaikan  Penggugat  dalam  gugatannya,  seharusnya  Penggugat
menyelesaikan  terlebih  dahulu  seluruh  tahapan  dalam  upaya
administratif  yaitu  keberatan  administratif  atas  diterbitkannya  Objek
Sengketa 2;
11.Bahwa dalam Pasal 75 ayat 2 UU AP secara tegas menyatakan yang
dimaksud  dengan  upaya  administratif  itu  adalah  Keberatan  Dan
Banding, serta hal tersebut diperkuat dalam Pasal 76 ayat (3) yang
menegaskan  Warga  Masyarakat  dapat  mengajukan  gugatan  ke
Pengadilan apabila tidak menerima atas penyelesaian banding oleh
atasan pejabat;
12.Bahwa hal tersebut juga diperkuat dengan adanya yurisprudensi terkait
gugatan  yang  telah  diajukan  namun  seluruh  rangkaian  upaya
administratif belum tuntas dilakukan yang tertuang dalam Pertimbangan
Majelis  Hakim  Putusan  Pengadilan  Tata  Usaha  Negara  Bandung
Nomor 113/G/2022/PTUN.BDG halaman 86 yang menyatakan: 
“...secara  filosofis,  Upaya  Administratif  berupa  keberatan  dan
banding  warga  kepada  pejabat  tata  usaha  negara  atas  sebuah
persoalan merupakan media untuk melakukan dialog, mediasi atau
musyawarah.  Bahwa  apabila  tidak  ada  respon  dari  pejabat  tata
usaha negara terhadap upaya administratif tersebut, maka upaya
dialog  atau  mediasi  dinyatakan  gagal  dan  warga  negara  dapat
mengajukan  gugatan  ke  Pengadilan  in  casu  PTUN  Bandung.

Kepaniteraan Mahkamah Agung Republik Indonesia berusaha untuk selalu mencantumkan informasi paling kini dan akurat sebagai bentuk komitmen Mahkamah Agung untuk pelayanan publik, transparansi dan akuntabilitas
pelaksanaan fungsi peradilan. Namun dalam hal-hal tertentu masih dimungkinkan terjadi permasalahan teknis terkait dengan akurasi dan keterkinian informasi yang kami sajikan, hal mana akan terus kami perbaiki dari waktu kewaktu.
Dalam hal Anda menemukan inakurasi informasi yang termuat pada situs ini atau informasi yang seharusnya ada, namun belum tersedia, maka harap segera hubungi Kepaniteraan Mahkamah Agung RI melalui :
Sehingga Majelis Hakim berpendapat bahwa tenggang waktu dan
upaya administratif dalam gugatan yang diajukan Penggugat dalam
perkara sengketa ini belum sepenuhnya dilalui dan dengan tenggang
waktu yakni premature sehingga eksepsi Tergugat tentang Tenggang
Waktu dan Upaya Administrtaif atas hal ini secara hukum diterima”
13.Bahwa dengan demikian, berdasarkan uraian di atas mengenai belum
adanya upaya hukum administratif dari Penggugat terhadap salah satu
objek  perkara  sebelum  adanya  gugatan  ini  didaftarkan,  sudah
seharusnya Majelis Hakim yang memeriksa perkara a quo menyatakan
gugatan Penggugat tidak dapat diterima ( Niet Ontvankelujke Verklaard ).
GUGATAN PENGGUGAT TIDAK JELAS ( OBSCUUR LIBEL )
14.Bahwa Penggugat tidak jelas dalam mengurai dalil gugatan maupun
dasar hukum pengajuan gugatannya. Sebagaimana dapat dilihat dalil
Penggugat angka 4 halaman 21 sampai dengan angka 10 halaman 23
hanyalah  pengulangan  dalil  yang  telah  diuraikan  sebelumnya  oleh
Penggugat  sebagaimana  angka  8  halaman  17  hingga  angka  15
halaman 20. Dalil yang demikian membuat kebingungan karena tidak
jelas apa yang coba disampaikan oleh Penggugat. Berdasarkan hal
tersebut, dalil penggugat yang tidak jelas, maka tidak ada alasan bagi
Majelis  untuk  menyatakan  gugatan  Penggugat  tidak  jelas  untuk
selanjutnya gugatan Penggugat dinyatakan tidak dapat diterima;
15.Bahwa penggugat tidak jelas menguraikan dasar hukum yang dijadikan
dasar gugatan, yakni Penggugat mendasarkan pada Undang-Undang
Nomor:  30  Tahun  2014  tentang  tentang  Administrasi  Pemerintahan
dimana  objek  sengketa  adalah  sengketa  administrasi  pemerintahan,
sementara perkara a quo adalah sengketa administrasi kepegawaian,
berupa  hukuman  disiplin  kepegawaian  dengan  dasar  dictum
“mengingat” adalah Undang-Undang Nomor 20 Tahun 2023 tentang
Aparatur Sipil Negara, Peraturan Pemerintah Nomor 11 Tahun 2017 jo.
Peraturan  Pemerintah  Nomor  17  Tahun  2020  tentang  Manajemen
Pegawai Negeri Sipil jo Peraturan Pemerintah Nomor 94 Tahun 2021
tentang  Disiplin  Pengawai  Negeri  Sipil  jo.  Peraturan  Badan

Kepaniteraan Mahkamah Agung Republik Indonesia berusaha untuk selalu mencantumkan informasi paling kini dan akurat sebagai bentuk komitmen Mahkamah Agung untuk pelayanan publik, transparansi dan akuntabilitas
pelaksanaan fungsi peradilan. Namun dalam hal-hal tertentu masih dimungkinkan terjadi permasalahan teknis terkait dengan akurasi dan keterkinian informasi yang kami sajikan, hal mana akan terus kami perbaiki dari waktu kewaktu.
Dalam hal Anda menemukan inakurasi informasi yang termuat pada situs ini atau informasi yang seharusnya ada, namun belum tersedia, maka harap segera hubungi Kepaniteraan Mahkamah Agung RI melalui :
Kepegawaian  Negara  Nomor  6  Tahun  2022  tentang  Pelaksanaan
Peraturan Pemerintah Nomor 94 Tahun 2021 tentang Disiplin Pengawai
Negeri Sipil, dengan demikian, gugatan penggugat tidak jelas dasar
hukumnya. Berdasarkan hal tersebut, gugatan Penggugat yang tidak
jelas dalam menguraikan dasar hukumnya, haruslah dinyatakan tidak
dapat diterima.

# DALAM POKOK PERKARA

1.Bahwa  seluruh  dalil  dalam  jawaban  Tergugat  pada  bagian  eksepsi
menjadi  satu  kesatuan  yang  tidak  terpisahkan  ( mutatis-mutandis ),
dengan jawaban Tergugat.
2.Bahwa  Tergugat  menolak  secara  tegas  seluruh  dalil-dalil  gugatan
Penggugat,  terkecuali  terhadap  hal-hal  yang  diakui  kebenarannya
dan/atau  terhadap  dalil  gugatan  yang  bersesuaian  dan  mendukung/
menguntungkan dalil-dalil jawaban dari pihak Tergugat;
3.Bahwa  setelah  membaca  dan  mencermati  materi  gugatan  Penggugat,
maka Tergugat mengajukan pokok-pokok bantahan sebagaimana berikut.
a.Tergugat berwenang menetapkan objek sengketa;
b.Prosedur  penerbitan  objek  sengketa  sesuai  dengan  peraturan
Perundang-undangan;
c.Penggugat  telah  melanggar  ketentuan  disiplin  Pegawai  Negeri  Sipil
(PNS),  sebagaiman  diatur  dalam   Peraturan  Pemerintah  Nomor  94
Tahun 2021 tentang Disiplin Pegawai PNS, sehingga  substansi objek
sengketa telah sesuai dengan peraturan Perundang-undangan;
d.Objek  sengketa  tidak  bertentangan  dengan  asas-asas  umum
pemerintahan yang baik.
Bahwa  selanjutnya  terhadap  4  (empat)  hal  tersebut  diatas,  Tergugat
akan menyampaikan dalil disertai alasan sekaligus menyampaikan fakta-
fakta sesuai dengan bukti
TERGUGAT BERWENANG MENERBITKAN OBJEK GUGATAN
4.Bahwa benar Tergugat telah mengeluarkan Keputusan berupa:

Kepaniteraan Mahkamah Agung Republik Indonesia berusaha untuk selalu mencantumkan informasi paling kini dan akurat sebagai bentuk komitmen Mahkamah Agung untuk pelayanan publik, transparansi dan akuntabilitas
pelaksanaan fungsi peradilan. Namun dalam hal-hal tertentu masih dimungkinkan terjadi permasalahan teknis terkait dengan akurasi dan keterkinian informasi yang kami sajikan, hal mana akan terus kami perbaiki dari waktu kewaktu.
Dalam hal Anda menemukan inakurasi informasi yang termuat pada situs ini atau informasi yang seharusnya ada, namun belum tersedia, maka harap segera hubungi Kepaniteraan Mahkamah Agung RI melalui :
a.Keputusan Menteri Pendidikan Kebudayaan, Riset dan Teknologi
Republik  Indonesia Nomor: 93731/RHS/M/08/2024,  tertanggal 4
Oktober  2024  Tentang  Pembebasan  Dari  Jabatannya  Menjadi
Jabatan Pelaksana selama 12 (dua belas) bulan, atas nama dr.
IVAN ROVIAN M.Kp. (Objek Sengketa 1)
b.Keputusan  Menteri  Pendidikan  Tinggi,  Sains  dan  Teknologi
Republik  Indonesia  Nomor:  137561/RHS/M/08/2024,  tanggal  25
November 2024 tentang penguatan Keputusan Menteri Pendidikan
Kebudayaan,  Riset  dan  Teknologi  Republik  Indonesia  Nomor:
93731/RHS/M/08/2024,  tertanggal  4  Oktober  2024  Tentang
Pembebasan Dari Jabatannya Menjadi Jabatan Pelaksana selama
12 (dua belas) bulan, atas nama dr. IVAN ROVIAN M.Kp. (Objek
Sengketa 2).
5.Bahwa  sebagaimana  diakui  Penggugat  dalam  gugatannya  bahwa
Penggugat  merupakan  Pegawai  Negeri  Sipil,  Sebagai  PNS,
Penggugat terikat dan tunduk pada berbagai peraturan perundang-
undangan  di  bidang  aparatur  sipil  negara/kepegawaian
negara/pemerintah  Penggugat,  oleh  yang  karenanya  dalam  hal
disiplin  pegawai  tunduk  dan  mengikuti  ketentuan  Peraturan
Pemerintah Nomor 94 Tahun 2021 tentang Disiplin Pegawai Negeri
Sipil (PP 94/2021);
6.Bahwa terhadap jenis Hukuman Disiplin Berat berupa pembebasan
dari jabatannya menjadi jabatan pelaksana selama 12 (dua belas)
bulan (Pasal 8 ayat 4 huruf b PP 94/2021), Tergugat berwenang untuk
menjatuhkan hukuman disiplin, hal demikian sesuai dengan Pasal 16
dan Pasal 18 ayat (1) dan (2) PP 94/2021 menyebutkan:
Pasal 16 
Pejabat yang Berwenang Menghukum terdiri atas:
a.Presiden;
b.Pejabat Pembina Kepegawaian;
c.Kepala Perwakilan Republik Indonesia;

Kepaniteraan Mahkamah Agung Republik Indonesia berusaha untuk selalu mencantumkan informasi paling kini dan akurat sebagai bentuk komitmen Mahkamah Agung untuk pelayanan publik, transparansi dan akuntabilitas
pelaksanaan fungsi peradilan. Namun dalam hal-hal tertentu masih dimungkinkan terjadi permasalahan teknis terkait dengan akurasi dan keterkinian informasi yang kami sajikan, hal mana akan terus kami perbaiki dari waktu kewaktu.
Dalam hal Anda menemukan inakurasi informasi yang termuat pada situs ini atau informasi yang seharusnya ada, namun belum tersedia, maka harap segera hubungi Kepaniteraan Mahkamah Agung RI melalui :
d.Pejabat Pimpinan Tinggi Madya atau pejabat lain yang setara;
e.Pejabat Pimpinan Tinggi Pratama atau pejabat lain yang setara;
f.Pejabat Administrator atau pejabat lain yang setara; dan
g.Pejabat Pengawas atau pejabat lain yang setara.
Pasal 18
(1)  Pejabat  Pembina  Kepegawaian  Instansi  Pusat  dan  Pejabat
Pembina  Kepegawaian  Instansi  Daerah  Provinsi  menetapkan
penjatuhan  Hukuman  Disiplin  bagi  Pejabat  Pimpinan  Tinggi
Madya  di  lingkungannya  untuk  jenis  Hukuman  Disiplin
sebagaimana dimaksud dalam Pasal 8 ayat (2), ayat (3), dan ayat
(a) huruf a dan huruf b.
(2)  Pejabat  Pembina  Kepegawaian  Instansi  Pusat  dan  Pejabat
Pembina  Kepegawaian  Instansi  Daerah  Provinsi  menetapkan
penjatuhan Hukunran Disiplin bagi: 
a.Pejabat  Pimpinan  Tinggi  Pratama  di  lingkungannya  untuk
jenis Hukuman Disiplin sebagaimana dimaksud dalam Pasal 8
ayat (3) dan ayat (4);
b.Pejabat Fungsional jenjang Ahli Utama untuk jenis Hukuman
Disiplin sebagaimana dimaksud dalam Pasal 8 ayat (2), ayat
(3), dan ayat (4) huruf a dan huruf b;
c.Pejabat Administrator ke bawah di lingkungannya untuk jenis
Hukuman Disiplin sebagaimana dimaksud dalam Pasal 8 ayat
(4); dan ;
d.Pejabat  Fungsional  selain  Pejabat  Fungsional  jenjang  Ahli
Utama  di  lingkungannya  untuk  jenis  Hukuman  Disiplin
sebagaimana dimaksud dalam Pasal 8 ayat (4).
7.Bahwa  Tergugat  merupakan  Pejabat  Pembina  Kepegawaian
sebagaimana ditentukan dalam Pasal 53 Undang-undang Nomor 5
Tahun 2014 tentang Aparatur Sipil Negara disebutkan:

Kepaniteraan Mahkamah Agung Republik Indonesia berusaha untuk selalu mencantumkan informasi paling kini dan akurat sebagai bentuk komitmen Mahkamah Agung untuk pelayanan publik, transparansi dan akuntabilitas
pelaksanaan fungsi peradilan. Namun dalam hal-hal tertentu masih dimungkinkan terjadi permasalahan teknis terkait dengan akurasi dan keterkinian informasi yang kami sajikan, hal mana akan terus kami perbaiki dari waktu kewaktu.
Dalam hal Anda menemukan inakurasi informasi yang termuat pada situs ini atau informasi yang seharusnya ada, namun belum tersedia, maka harap segera hubungi Kepaniteraan Mahkamah Agung RI melalui :
Pasal 53
Presiden  selaku  pemegang  kekuasaan  tertinggi  pembinaan  ASN
dapat  mendelegasikan  kewenangan  menetapkan  pengangkatan,
pemindahan,  dan  pemberhentian  pejabat  selain  pejabat  pimpinan
tinggi  utama  dan  madya,  dan  pejabat  fungsional  keahlian  utama
kepada: a. menteri di kementerian
8.Berdasarkan  uraian  tersebut  di  atas,  Tergugat  berwenang  untuk
memberikan hukuman disiplin kepada Penggugat, oleh karena itu dalil
Penggugat yang menyatakan Tergugat melampaui kewenangannya
sebagaimana gugatan pada romawi V angka 13 dalam memberikan
hukuman disiplin adalah dalil yang tidak berdasarkan hukum sehingga
dalil Penggugat tersebut harus dikesampingkan dan ditolak;
PROSEDUR  PENERBITAN  OBJEK  SENGKETA  SESUAI  DENGAN
PERATURAN PERUNDANG-UNDANGAN
9.Bahwa  Tergugat  tegaskan  kembali,  terbitnya  Objek  Gugatan,  baik
Objek  Sengketa  1  maupun  Objek  Sengketa  2  sebagai  penguatan
Objek  Sengketa  1  telah  sesuai  dengan  peraturan  perundang-
undangan,  sehingga  Tergugat  membantah  seluruh  dalil  penggugat
mengenai kecacatan prosedur. Tergugat menegaskan bahwa seluruh
tahapan Pemanggilan, Pemeriksaan, Penjatuhan, Dan Penyampaian
Keputusan  Hukuman  Disiplin,  telah  sesuai  dengan  peraturan
perundang-undangan,  khususnya  berdasarkan  Peraturan  Badan
Kepegawaian  Negara  Nomor  6  Tahun  2022  Tentang  Peraturan
Pelaksanaan Peraturan Pemerintah Nomor 94 Tahun 2021 Tentang
Disiplin Pegawai Negeri Sipil, selanjutnya disebut PerBKN 6/2022);
10.Bahwa  Tergugat  terlebih  dahulu  akan  menyampaikan  fakta-fakta
hukum yang membuktikan prosedur penerbitan Objek Gugatan telah
sesuai  dengan  ketentuan  peraturan  perundang-undangan,  yaitu
sebagai berikut:
a.Terdapat laporan/pengaduan yang diajukan oleh Tri Asih Imro,ati
selaku istri sah dari Pengguat tanggal 5 Agustus 2023;

Kepaniteraan Mahkamah Agung Republik Indonesia berusaha untuk selalu mencantumkan informasi paling kini dan akurat sebagai bentuk komitmen Mahkamah Agung untuk pelayanan publik, transparansi dan akuntabilitas
pelaksanaan fungsi peradilan. Namun dalam hal-hal tertentu masih dimungkinkan terjadi permasalahan teknis terkait dengan akurasi dan keterkinian informasi yang kami sajikan, hal mana akan terus kami perbaiki dari waktu kewaktu.
Dalam hal Anda menemukan inakurasi informasi yang termuat pada situs ini atau informasi yang seharusnya ada, namun belum tersedia, maka harap segera hubungi Kepaniteraan Mahkamah Agung RI melalui :
b.Tergugat  telah  menerima  tembusan  laporan  berupa  Laporan
Perbuatan Zinah yang diajukan oleh Tri Asih Imro’ati, dr., SpPD. K-
GEH, FINASIM selaku istri dari Ivan Rovian, dr. MKP tertanggal 5
Agustus 2023 yang ditujukan kepada Kepala Lembaga Layanan
Pendidikan Tinggi Wilayah VII;
c.Tergugat selanjutnya mengirimkan surat Nomor: 50768/RHS/B/08/
2023  perihal  Laporan  Perbuatan  Zina  tertanggal  12  September
2023 kepada Kepala Lembaga Layanan Pendidikan Tinggi Wilayah
VII  yang  pada  pokoknya  menyampaikan  agar  Kepala  Lembaga
Layanan  Pendidikan  Tinggi  Wilayah  VII  melakukan  klarifikasi
terhada laporan tersebut;
d.Kepala Lembaga Layanan Pendidikan Tinggi Wilayah VII melalui
surat  Nomor:  2254/LL7/RHS/2023  perihal  Laporan  Pelanggaran
Disiplin  Pegawai  tertanggal  25  September  2023  yang  pada
pokoknya  menyampaikan  berdasarkan  hasil  klarifikasi  Kepala
bagian Umum kepada Kepala LLDIKTI Wilayah VII pada tanggal 21
September 2023 menyatakan tidak pernah melakukan yang tertulis
dalam  surat  Sdri  Tri  Asih  Imro’ati,  dr.,  SpPD.  K-GEH,  FINASIM
tanggal 5 Agustus 2023. Panggilan Klarifikasi maupun klarifikasi
dilakukan dalam rangka mengetahui kebenaran laporan;
e.Selanjutnya Tergugat menyampaikan surat 62016/RHS/B/08/2023
Perihal  Laporan  Pelanggaran  Disiplin  Pegawai  tertanggal  20
Oktober  2023,  dimana  dalam  surat  tersebut,  Tergugat
menyampaikan  kepada  Kepala  Lembaga  Layanan  Pendidikan
Tinggi  Wilayah  VII  untuk  segera  melakukan  proses  penjatuhan
hukuman disiplin secara procedural terhadap dr. Ivan Rovian, M.Kp
sesuai dengan Peraturan Pemerintah Nomor 94 Tahun 2021 dan
Peraturan  Badan  Kepegawaian  Negara  Nomor  6  Tahun  2022
dengan memperhatikan:
1)pejabat  yang  mempunyai  kewenangan  membentuk  tim
pemeriksa sampai dengan saat ini adalah Menteri Pendidikan,

Kepaniteraan Mahkamah Agung Republik Indonesia berusaha untuk selalu mencantumkan informasi paling kini dan akurat sebagai bentuk komitmen Mahkamah Agung untuk pelayanan publik, transparansi dan akuntabilitas
pelaksanaan fungsi peradilan. Namun dalam hal-hal tertentu masih dimungkinkan terjadi permasalahan teknis terkait dengan akurasi dan keterkinian informasi yang kami sajikan, hal mana akan terus kami perbaiki dari waktu kewaktu.
Dalam hal Anda menemukan inakurasi informasi yang termuat pada situs ini atau informasi yang seharusnya ada, namun belum tersedia, maka harap segera hubungi Kepaniteraan Mahkamah Agung RI melalui :
Kebudayaan, Riset, dan Teknologi sebagai Pejabat Pembina
Kepegawaian;
2)Kepala  Lembaga  Layanan  Pendidikan  Tinggi  Wilayah  VII
segera  mengusulkan  pembentukan  tim  pemeriksa  kepada
Menteri dengan ketentuan:
a.tim  pemeriksa  terdiri  dari  atasan  langsung,  unsur
pengawasan,  dan  unsur  kepegawaian  dengan  ketentuan
pegawai yang ditugaskan menjadi unsur pengawasan dan
unsur kepegawaian memiliki jabatan paling rendah setingkat
dengan dr. Ivan Rovian, M.Kp.
b.mengusulkan dengan identitas lengkap (nama, NIP, pangkat,
dan  jabatan)  sesuai  dengan  susunan  unsur  kedudukan
dalam tim pemeriksa;
c.tim pemeriksa bersifat temporer (ad hoc).
3)setelah keputusan pembentukan tim pemeriksa ditetapkan oleh
Menteri,  atasan  langsung  bersama  tim  pemeriksa  segera
memanggil  secara  tertulis  dan  melakukan  pemeriksaan
terhadap dr. Ivan Rovian, M.Kp. dengan prosedur antara lain:
a.pemanggilan  secara  tertulis  dilakukan  maksimal  2  (dua)
kali,  apabila  sampai  pemanggilan  kedua  yang
bersangkutan  tidak  hadir  maka  penjatuhan  hukuman
disiplin berdasarkan alat bukti dan keterangan yang ada
tanpa dilakukan pemeriksaan;
b.pemeriksaan  dilakukan  untuk  mengetahui  kebenaran
pelanggaran yang dilakukan oleh dr. Ivan Rovian, M.Kp.
serta untuk mengetahui faktor yang mendorong atau yang
menyebabkan yang bersangkutan melakukan pelanggaran
disiplin;
c.pemeriksaan dilakukan secara teliti dan objektif, sehingga
Pejabat  yang  Berwenang  Menghukum  dapat
mempertimbangkan  jenis  hukukuman  disiplin  yang  akan
dijatuhkan dengan adil;

Kepaniteraan Mahkamah Agung Republik Indonesia berusaha untuk selalu mencantumkan informasi paling kini dan akurat sebagai bentuk komitmen Mahkamah Agung untuk pelayanan publik, transparansi dan akuntabilitas
pelaksanaan fungsi peradilan. Namun dalam hal-hal tertentu masih dimungkinkan terjadi permasalahan teknis terkait dengan akurasi dan keterkinian informasi yang kami sajikan, hal mana akan terus kami perbaiki dari waktu kewaktu.
Dalam hal Anda menemukan inakurasi informasi yang termuat pada situs ini atau informasi yang seharusnya ada, namun belum tersedia, maka harap segera hubungi Kepaniteraan Mahkamah Agung RI melalui :
d.pemeriksaan  dilakukan  secara  tertutup  melalalui  tatap
muka  langsung  maupun  secara  virtual  dan  hasilnya
dituangkan dalam bentuk berita acara pemeriksaan (BAP);
e.tim pemeriksa dapat memanggil dan meminta keterangan
dari  pihak  lain  dalam  pemeriksaan  dugaan  pelanggaran
disiplin.
Pembentukan Tim  Pemeriksa  tersebut  dilakukan  Tergugat
Berdasarkan ketentuan Pasal 37 ayat (2) PerBKN 6/2022 yang
berbunyi:
(2)  Tim  pemeriksa  wajib  dibentuk  dalam  hal  terdapat
Pelanggaran Disiplin yang ancaman hukumannya berat.”
f.Kepala Lembaga Layanan Pendidikan Tinggi Wilayah VII melalui
surat Nomor: 2427/KP/LL7/2023 perihal Usulan Pembentukan Tim
Pemeriksa  tertanggal  25  Oktober  2023,  yang  pada  pokoknya
menyampaikan  usulan  kepada  Tergugat  pembentukan  tim
pemeriksa  yang  terdiri  dari  Prof.  Dr.  Dyah  Sawatri,  S.E.,  M.M.
(atasan langsung) dan Purnomo, S.H., M.H. (Unsur Kepegawaian),
namun  terhadap  Unsur  Pengawas  tidak  dapat  diberikan  usulan
nama karena tidak ada Pegawai dengan jabatan dengan jabatan
paling rendah setingkat di atas Pegawai yang diperiksa;
g.Tergugat  selanjutnya  mengirimkan  surat  Nomor:  68279/RHS/B/
08/2023 perihal Permohonan tim pemeriksa tertanggal 7 Desember
2023  kepada  Inspektur  Jendral  Tergugat  untuk  kesediaannya
menunjuk 1 (satu) auditor untuk menjadi salah satu anggota tim
pemeriksa sebagai unsur pengawasan, dengan jabatan Auditor Ahli
Madya;
h.Inspektur Jendral Tergugat mengirimkan suarat Nomor: 1700/G1/
RHS/KP.04.06/2024  perihal  Usul  Auditor  untuk  menjadi  Tim
Pemeriksa  tertanggal  15  Februari  2024  yang  pada  pokoknya
menyampaikan nama-nama Auditor untuk menjadi Tim Pemeriksa
dugaan pelanggaran disiplin Tingkat berat yang dilakukan oleh PNS
di  Lingkungan  Kementrian  Pendidikan,  Kebudayaan,  Riset  dan
Teknologi;

Kepaniteraan Mahkamah Agung Republik Indonesia berusaha untuk selalu mencantumkan informasi paling kini dan akurat sebagai bentuk komitmen Mahkamah Agung untuk pelayanan publik, transparansi dan akuntabilitas
pelaksanaan fungsi peradilan. Namun dalam hal-hal tertentu masih dimungkinkan terjadi permasalahan teknis terkait dengan akurasi dan keterkinian informasi yang kami sajikan, hal mana akan terus kami perbaiki dari waktu kewaktu.
Dalam hal Anda menemukan inakurasi informasi yang termuat pada situs ini atau informasi yang seharusnya ada, namun belum tersedia, maka harap segera hubungi Kepaniteraan Mahkamah Agung RI melalui :
i.Setelah  Tergugat  membentuk  tim  pemeriksa  sebagaimana
Pembentukan  Tim  Pemeriksa  Nomor  115695/RHS/M/08/2024
tertanggal  4  Maret  2024,  Tim  Pemeriksa,  adapun  terhadap
pembentukan Tim Pemeriksa yang dilakukan telah sesuai dengan
ketentuan Pasal 38 ayat (1) PerBKN 6/2022 yang berbunyi:
(1) Tim pemeriksa sebagaimana dimaksud dalam Pasal 37 ayat
(1) terdiri dari unsur atasan langsung, unsur pengawasan,
dan unsur kepegawaian.
j.Selanjutnya Tim Pemeriksa memanggil Penggugat melalui Surat
Panggilan  I  Nomor:085/LL7/KP/RHS/2024  tertanggal  15  Maret
2024.  Hal  demikian  seturut  dengan  tata  cara  Pemanggilan
sebagaimana Pasal 34 PerBKN 6/2022;
k.Atas  panggilan  tim  pemeriksa  tersebut,  Penggugat  mengajukan
dispensasi penjadwalan ulang pemeriksaan karena kondisi kurang
fit  dan  dalam  suasana  menjalankan  ibadah  suci  di  bulan
Ramadhan, sebagaimana surat Penggugat tanggal 22 Maret 2024;
l.Tim  Pemeriksa  selanjutnya  melakukan  pemanggilan  kembali
kepada Penggugat sebagaimana Surat Panggilan II Nomor: 98/LL7/
KP.04.04/2024 tertanggal 22 Maret 2024;
m.Bahwa  selanjutnya  Tim  Pemeriksa  melakukan  pemeriksaan
sebagaimana  Berita  Acara  Pemeriksaan  terhadap  Pelapor
tertanggal 22 Maret 2024 dan Berita Acara Pemeriksaan terhadap
Terlapor tertanggal 1 April 2024 untuk selanjutnya atasan langsung
Penggugat yang menjadi bagian dalam Tim Pemeriksa membuat
Laporan Hasil Pemeriksaan tertanggal 13 Agustus 2024. Laporan
hasil Pemeriksaan disusun berdasarkan Berita Acara pemeriksaan
sebagaimana diamanatkan Pasal 36 ayat (5) PerBKN 6/2022;
n.Kepala Lembaga Layanan Pendidikan Tinggi Wilayah VII melalui
surat  Nomor:  816/LL7/KP.04.05/2024  perihal  Usulan  Penjatuhan
Hukuman  Disiplin  tertanggal  16  Agustus  2024  menyampaikan
kepada  Tergugat  pada  pokoknya  menjatuhkan  hukuman  disiplin
Tingkat berat untuk dr. Ivan Rovian, M.Kp. berupa pembebasan dari
jabatannya  menjadi  pelaksana  selama  12  bulan  atau  menurut

Kepaniteraan Mahkamah Agung Republik Indonesia berusaha untuk selalu mencantumkan informasi paling kini dan akurat sebagai bentuk komitmen Mahkamah Agung untuk pelayanan publik, transparansi dan akuntabilitas
pelaksanaan fungsi peradilan. Namun dalam hal-hal tertentu masih dimungkinkan terjadi permasalahan teknis terkait dengan akurasi dan keterkinian informasi yang kami sajikan, hal mana akan terus kami perbaiki dari waktu kewaktu.
Dalam hal Anda menemukan inakurasi informasi yang termuat pada situs ini atau informasi yang seharusnya ada, namun belum tersedia, maka harap segera hubungi Kepaniteraan Mahkamah Agung RI melalui :
kebijaksanaan Tergugat sesuai dengan Pasal 8 ayat (4) Peraturan
pemerintah Nomor 94 Tahun 2021 Tentang Disiplin Pegawai negeri
Sipil dikarenakan PNS yang bersangkutan telah terbukti dan secara
sah  telah  melanggar  Pasal  41  terkait  dengan  ketentuan  izin
perkawinan dan perceraian PNS;
o.Berdasarkan pertimbangan hukum yang dibuat oleh Kepala Biro
Sumber  Daya  Manusia,  Sekretaris  Jendral  pada  kementrian
Pendidikan, Kebudayaan, Riset, dan Teknologi menyampaikan usul
kepada Tergugat sebagaimana Surat 92912/RHS/S/08/2024 perihal
Usul  berupa  pembebasan  dari  jabatannya  menjadi  jabatan
pelaksana selama 12 (dua belas) bulan dr. Ivan Rovian, M. Kp,
yang mana usulan tersebut didasari atas pertimbangan:
1)bahwa menurut hasil pemeriksaan, dr. Ivan Rovian, M.Kp
telah melakukan perbuatan beristri lebih dari seorang dan
melakukan  perceraiaian  tanpa  memperoleh  izin  terlebih
dahulu dari Pejabat;
2)bahwa  perbuatan  sebagaimana  dimaksud  pada  huruf  a
merupakan pelanggaran terhadap ketentuan Pasal 3 ayat (1)
dan Pasal 4 ayat (1) Peraturan Pemerintah Nomor 10 Tahun
1983  sebagaimana  diubah  dengan  Peraturan  Pemerintah
Nomor 45 Tahun 19990;
3)bahwa berdasarkan Pasal 15 Peraturan Pemerintah Nomor
10  Tahun  1983  sebagaimana  diubah  dengan  Peraturan
Pemerintah  Nomor  45  Tahun  1990  Peraturan  Pemerintah
Nomor 45 Tahun 1990, Pegawai Negeri Sipil yang melanggar
kewajiban/ketentuan Pasal 3 ayayat (1) dan Pasal 4 ayat (1)
dijatuhi  salah  satu  hukuman  disiplin  berat  berdasarkan
ketentuan peraturan disiplin Pegawai Negeri Sipil;
4)bahwa berdasarkan Pasal 41 Peraturan Pemerintah Nomor
94  Tahun  2021,  pegawai  negeri  sipil  yang  melanggar
Peraturan Pemerintah Nomor 10 Tahun 1983 sebagaimana
telah diubah dengan Peraturan Pemerintah Nomor 45 Tahun

Kepaniteraan Mahkamah Agung Republik Indonesia berusaha untuk selalu mencantumkan informasi paling kini dan akurat sebagai bentuk komitmen Mahkamah Agung untuk pelayanan publik, transparansi dan akuntabilitas
pelaksanaan fungsi peradilan. Namun dalam hal-hal tertentu masih dimungkinkan terjadi permasalahan teknis terkait dengan akurasi dan keterkinian informasi yang kami sajikan, hal mana akan terus kami perbaiki dari waktu kewaktu.
Dalam hal Anda menemukan inakurasi informasi yang termuat pada situs ini atau informasi yang seharusnya ada, namun belum tersedia, maka harap segera hubungi Kepaniteraan Mahkamah Agung RI melalui :
1990  dijatuhi  salah  satu  jenis  hukuman  disiplin  berat
berdasarkan Peraturan Pemerintah Nomor 94 Tahun 2021;
5)bahwa  untuk  menegakkan  disiplin,  perlu  menjatubkan
hukuman disiplin yang setimpal dengan pelanggaran disiplin
yang dilakukannya.
Dalam  mengambil  Keputusan  sebelum  menjatuhkan  Hukuman
Disiplin,  Tergugat  telah  menjalankan  kewajiban-kewajiban  yang
disebutkan pada Pasal 42 ayat (1) PerBKN 6/2022;
p.Tergugat selanjutnya menerbitkan Keputusan Menteri Pendidikan
Kebudayaan,  Riset  dan  Teknologi  Republik  Indonesia  Nomor:
93731/RHS/M/08/2024,  tertanggal  4  Oktober  2024  Tentang
Pembebasan Dari Jabatannya Menjadi Jabatan Pelaksana selama
12 (dua belas) bulan, atas nama dr. IVAN ROVIAN M.Kp. (Objek
Sengketa 1);
q.Terhadap penerbitan Objek Sengketa 1, Penggugat melalui kuasa
hukumnya menyampaikan keberatan tertanggal 16 Oktober 2024;
r.Atas  keberatan dari Penggugat, Tergugat menerbitkan Keputusan
Menteri Pendidikan  Tinggi, Sains dan Teknologi Republik Indonesia
Nomor:  137561/RHS/M/08/2024,  tanggal  25  November  2024
tentang  penguatan  Keputusan  Menteri  Pendidikan  Kebudayaan,
Riset  dan  Teknologi  Republik  Indonesia  Nomor:
93731/RHS/M/08/2024,  tertanggal  4  Oktober  2024  Tentang
Pembebasan Dari Jabatannya Menjadi Jabatan Pelaksana selama
12 (dua belas) bulan, atas nama dr. IVAN ROVIAN M.Kp.  (Objek
Sengketa 2) yang didasari dari pertimbangan sekretaris jendral atas
keberatan  Tergugat  yang  kemudian  ditindaklanjuti  dengan  surat
usulan  Nomor:  115682/RHS/  S/08/2024  perihal  Penguatan
Keputusan Hukuman Disiplin an. dr. Ivan Rovian, M.Kp tertanggal
18 November 2024.
11.Bahwa sebelum dilakukan pemeriksaan, LLDIKTI Wilayah VII telah
melakukan panggilan klarifikasi kepada Tergugat sebagaimana Surat
Nomor  1381/LL7/RHS/KP.04.04/2023  tanggal  15  Agustus  2023

Kepaniteraan Mahkamah Agung Republik Indonesia berusaha untuk selalu mencantumkan informasi paling kini dan akurat sebagai bentuk komitmen Mahkamah Agung untuk pelayanan publik, transparansi dan akuntabilitas
pelaksanaan fungsi peradilan. Namun dalam hal-hal tertentu masih dimungkinkan terjadi permasalahan teknis terkait dengan akurasi dan keterkinian informasi yang kami sajikan, hal mana akan terus kami perbaiki dari waktu kewaktu.
Dalam hal Anda menemukan inakurasi informasi yang termuat pada situs ini atau informasi yang seharusnya ada, namun belum tersedia, maka harap segera hubungi Kepaniteraan Mahkamah Agung RI melalui :
dimana  dari  klarifikasi  tersebut  Penggugat  menyampaikan  bahwa
laporan tersebut tidak benar;
12.Bahwa dari hasil laporan Tim Periksa terhadap Pemeriksaan yang
telah dilakukan terhadap Istri Pengguat maupun Penggugat dengan
hasil  terdapat  Cukup  Bukti  telah  melakukan  pelanggaran  disiplin
dengan bentuk Pelanggaran izin perkawinan dan perceraian sesuai
dengan PP Nomor 10 Tahun 1983 sebagaimana diubah dengan PP
Nomor 45 Tahun 1990 berupa melakukan perbuatan beristri lebih dari
satu orang dan melakukan perceraian tanpa memperoleh izin terlebih
dahulu dari Pejabat, adapun pelanggaran yang dilakukan Penggugat
menurut hasil pemeriksaan Tim Pemeriksa adalah:
“Yang bersangkutan terbukti melakukan perbuatan beristri lebih dari
satu orang dan melakukan perceraian tanpa memperoleh izin terlebih
dahulu dari Pejabat yang melanggar ketentuan:
a.Pasal  3 Huruf  f  PP Nomor 94 Tahun 2021  tentang Disiplin
Pegawai Negeri Sipil;
b.Pasal  3  Ayat  (1)  PP  Nomor  10  Tahun  1983  sebagaimana
diubah dengan PP Nomor 45 Tahun 1990 Tentang Perubahan
Atas Peraturan Pemerintah Nomor 10 Tahun 1983 tentang Izin
Perkawinan Dan Perceraian Bagi Pegawai Negeri Sipil;
c.Pasal  4  Ayat  (1)  PP  Nomor  10  Tahun  1983  sebagaimana
diubah dengan PP Nomor 45 Tahun 1990 Tentang Perubahan
Atas Peraturan Pemerintah Nomor 10 Tahun 1983 tentang Izin
Perkawinan Dan Perceraian Bagi Pegawai Negeri Sipil;
d.Pasal 41 PP Nomor 94 Tahun 2021 tentang Disiplin Pegawai
Negeri Sipil yang terkait dengan ketentuan izin perkawinan dan
perceraian PNS;
13.Bahwa berkaitan dengan dalil Gugatan Penggugat yang menyatakan
laporan  yang  dilakukan  oleh  Istri  Penggugat  atas  adanya  dugaan
pernikahan siri oleh Penggugat kepada Wanita lain tidak dibuktikan
terlebih dahulu dengan laporan polisi adalah dalil yang mengada-ada
dan tidak berdasarkan hukum. PNS sebagaimana warga negara yang

Kepaniteraan Mahkamah Agung Republik Indonesia berusaha untuk selalu mencantumkan informasi paling kini dan akurat sebagai bentuk komitmen Mahkamah Agung untuk pelayanan publik, transparansi dan akuntabilitas
pelaksanaan fungsi peradilan. Namun dalam hal-hal tertentu masih dimungkinkan terjadi permasalahan teknis terkait dengan akurasi dan keterkinian informasi yang kami sajikan, hal mana akan terus kami perbaiki dari waktu kewaktu.
Dalam hal Anda menemukan inakurasi informasi yang termuat pada situs ini atau informasi yang seharusnya ada, namun belum tersedia, maka harap segera hubungi Kepaniteraan Mahkamah Agung RI melalui :
lain, sama kedudukannya di muka hukum. Jika ia terlibat dalam kasus
pidana  maka  ia  harus  diproses  sebagaimana  mestinya.  Tanpa
mengurangi ketentuan dalam peraturan perundang-undangan pidana,
seorang  PNS  juga  harus  diproses  berdasarkan  peraturan
kepegawaian. Larangan perselingkuhan bagi ASN telah diatur dalam
Peraturan Pemerintah Nomor 10 Tahun 1983 jo Peraturan Pemerintah
Nomor 45 Tahun 1990 tentang Izin Perkawinan dan Perceraian bagi
PNS. Dari hasil pemeriksaan tim  Pemeriksa,  terdapat  Cukup  Bukti
telah melakukan pelanggaran disiplin dengan bentuk Pelanggaran izin
perkawinan dan perceraian sesuai dengan PP Nomor 10 Tahun 1983
sebagaimana  diubah  dengan  PP  Nomor  45  Tahun  1990  berupa
melakukan perbuatan beristri lebih dari satu orang. Adapun terhadap
tidak adanya laporan polisi sebagaimana didalilkan Penggugat adalah
tidak  menjadi  alasan  pemeriksaan  yang  dilakukan  Tergugat  tidak
dapat  dilakukan  mengingat  Penggugat  sebagai  ASN  melekat
kewajiban  untuk  mematuhi  aturan-aturan  mengenai  kepegawaian
yang berlaku mengikat baginya. Hal demikian kemudian telah senada
pula dengan ketentuan Pasal 45 ayat (1) PerBKN 6/2022 yang pada
pokoknya  menyatakan “ PNS yang  diduga  melakukan Pelanggaran
Disiplin  dan  perbuatan  yang  dilakukan  terindikasi  melanggar
ketentuan  peraturan  perundang-undangan  pidana,  tetap  dapat
dilakukan  pemanggilan,  pemeriksaan,  dan  penjatuhan  Hukuman
Disiplin sesuai dengan ketentuan Peraturan Badan ini”
OBJEK  SENGKETA  TIDAK  BERTENTANGAN  DENGAN  ASAS-ASAS
UMUM PEMERINTAHAN YANG BAIK
14.Bahwa  terhadap  tuduhan  Penggugat  yang  menyatakan  Surat
Keputusan  Tergugat  bertentangan  dengan  Asas-Asas  Umum
Pemerintahan yang Baik (AAUPB), merupakan tuduhan yang tidak
berdasarkan  fakta  dan  hukum  yang  sebenarnya,  tuduhan  tersebut
jelas Tergugat tolak dengan tegas karena tuduhan Penggugat hanya
merupakan  asumsi  sepihak,  dimana  tindakan  dan  Tergugat  dalam
menerbitkan  objek  gugatan  a  quo telah  sesuai  dengan  Asas-asas

Kepaniteraan Mahkamah Agung Republik Indonesia berusaha untuk selalu mencantumkan informasi paling kini dan akurat sebagai bentuk komitmen Mahkamah Agung untuk pelayanan publik, transparansi dan akuntabilitas
pelaksanaan fungsi peradilan. Namun dalam hal-hal tertentu masih dimungkinkan terjadi permasalahan teknis terkait dengan akurasi dan keterkinian informasi yang kami sajikan, hal mana akan terus kami perbaiki dari waktu kewaktu.
Dalam hal Anda menemukan inakurasi informasi yang termuat pada situs ini atau informasi yang seharusnya ada, namun belum tersedia, maka harap segera hubungi Kepaniteraan Mahkamah Agung RI melalui :
Umum Pemerintahan Yang Baik sebagaimana dimaksud dalam Pasal
10  Undang-Undang–Undang  Republik  Indonesia  Nomor  30  Tahun
2014 Tentang Administrasi Pemerintahan, yang meliputi:
a.“asas  kepastian  hukum”  adalah  asas  dalam  negara  hukum
yang  mengutamakan  landasan  ketentuan  peraturan
perundang-undangan,  kepatutan,  keajegan,  dan  keadilan
dalam setiap kebijakan penyelenggaraan pemerintahan
b.asas kemanfaatan” adalah manfaat yang harus diperhatikan
secara seimbang antara:
(1)kepentingan  individu  yang  satu  dengan  kepentingan
individu yang lain;
(2)kepentingan individu dengan masyarakat;
(3)kepentingan Warga Masyarakat dan masyarakat asing;
(4)kepentingan  kelompok  masyarakat  yang  satu  dan
kepentingan kelompok masyarakat yang lain;
(5)kepentingan pemerintah dengan Warga Masyarakat;
(6)kepentingan  generasi  yang  sekarang  dan  kepentingan
generasi mendatang;
(7)kepentingan manusia dan ekosistemnya;
(8)kepentingan pria dan wanita
c.“asas ketidakberpihakan” adalah asas yang mewajibkan Badan
dan/atau Pejabat Pemerintahan dalam menetapkan dan/atau
melakukan  Keputusan  dan/atau  Tindakan  dengan
mempertimbangkan  kepentingan  para  pihak  secara
keseluruhan dan tidak diskriminatif
d.“asas kecermatan” adalah asas yang mengandung arti bahwa
suatu Keputusan dan/atau Tindakan harus didasarkan pada
informasi  dan  dokumen  yang  lengkap  untuk  mendukung
legalitas penetapan dan/atau pelaksanaan Keputusan dan/atau
Tindakan  sehingga  Keputusan  dan/atau  Tindakan  yang

Kepaniteraan Mahkamah Agung Republik Indonesia berusaha untuk selalu mencantumkan informasi paling kini dan akurat sebagai bentuk komitmen Mahkamah Agung untuk pelayanan publik, transparansi dan akuntabilitas
pelaksanaan fungsi peradilan. Namun dalam hal-hal tertentu masih dimungkinkan terjadi permasalahan teknis terkait dengan akurasi dan keterkinian informasi yang kami sajikan, hal mana akan terus kami perbaiki dari waktu kewaktu.
Dalam hal Anda menemukan inakurasi informasi yang termuat pada situs ini atau informasi yang seharusnya ada, namun belum tersedia, maka harap segera hubungi Kepaniteraan Mahkamah Agung RI melalui :
bersangkutan dipersiapkan dengan cermat sebelum Keputusan
dan/atau Tindakan tersebut ditetapkan dan/atau dilakukan;
e.“asas tidak menyalahgunakan kewenangan” adalah asas yang
mewajibkan setiap Badan dan/atau Pejabat Pemerintahan tidak
menggunakan kewenangannya untuk kepentingan pribadi atau
kepentingan  yang  lain  dan  tidak  sesuai  dengan  tujuan
pemberian  kewenangan  tersebut,  tidak  melampaui,  tidak
menyalahgunakan,  dan/atau  tidak  mencampuradukkan
kewenangan;
f.“asas  keterbukaan”  adalah  asas  yang  melayani  masyarakat
untuk  mendapatkan  akses  dan  memperoleh  informasi  yang
benar,  jujur,  dan  tidak  diskriminatif  dalam  penyelenggaraan
pemerintahan dengan tetap memperhatikan perlindungan atas
hak asasi pribadi, golongan, dan rahasia negara;
g.“asas kepentingan umum” adalah asas yang mendahulukan
kesejahteraan  dan  kemanfaatan  umum  dengan  cara  yang
aspiratif, akomodatif, selektif, dan tidak diskriminatif;
h.“asas  pelayanan  yang  baik”  adalah  asas  yang  memberikan
pelayanan yang tepat waktu, prosedur dan biaya yang jelas,
sesuai  dengan standar pelayanan,  dan ketentuan peraturan
perundangundangan
15.Berdasarkan  ketentuan  tersebut  di  atas  maka  dengan  jelas
menerangkan bahwa keberatan Penggugat mengenai keberatan atas
terbitnya Objek Gugatan a quo yang bertentangan dengan Asas-asas
Umum Pemerintahan Yang Baik sebagaimana dimaksud dalam Pasal
10  Undang-Undang–Undang  Republik  Indonesia  Nomor  30  Tahun
2014 Tentang Administrasi Pemerintahan, patutlah di tolak, dengan
alasan hukum sebagai berikut:
a.Objek Gugatan telah sesuai dengan “asas kepastian hukum”
adalah  asas  dalam  negara  hukum  yang  mengutamakan
landasan  ketentuan  peraturan  perundang-undangan,

Kepaniteraan Mahkamah Agung Republik Indonesia berusaha untuk selalu mencantumkan informasi paling kini dan akurat sebagai bentuk komitmen Mahkamah Agung untuk pelayanan publik, transparansi dan akuntabilitas
pelaksanaan fungsi peradilan. Namun dalam hal-hal tertentu masih dimungkinkan terjadi permasalahan teknis terkait dengan akurasi dan keterkinian informasi yang kami sajikan, hal mana akan terus kami perbaiki dari waktu kewaktu.
Dalam hal Anda menemukan inakurasi informasi yang termuat pada situs ini atau informasi yang seharusnya ada, namun belum tersedia, maka harap segera hubungi Kepaniteraan Mahkamah Agung RI melalui :
kepatutan,  keajegan,  dan  keadilan  dalam  setiap  kebijakan
penyelenggaraan pemerintahan
b.Objek Gugatan telah sesuai dengan “asas kecermatan” adalah
asas yang mengandung arti bahwa suatu Keputusan dan/atau
Tindakan harus didasarkan pada informasi dan dokumen yang
lengkap  untuk  mendukung  legalitas  penetapan  dan/atau
pelaksanaan  Keputusan  dan/atau  Tindakan  sehingga
Keputusan dan/atau Tindakan yang bersangkutan dipersiapkan
dengan cermat sebelum Keputusan dan/atau Tindakan tersebut
ditetapkan dan/atau dilakukan
16.Bahwa Penggugat dalam Gugatannya tidak menjelaskan dengan baik
dan  jelas  asas-asas  mana  yang  dilanggar  Tergugat  dalam
menerbitkan  Objek  Gugatan,  Penggugat  hanya  menguraikan
penjelasan AAUPB tanpa menjelaskan hubungannya dengan tindakan
Tergugat dalam menerbitkan Objek Gugatan berkaitan dengan asas
mana  yang  dilanggar  oleh  Tergugat.  Atas  dasar  tersebut,  karena
Penggugat  tidak  menguraikan  serta  tidak  dapat  membuktikan  dalil
Penggugat yang menyatakan Tergugat telah melanggar Asas-Asas
Umum  Pemerintahan  yang  baik,  maka  Gugatan  Penggugat  yang
demikian haruslah dikesampingkan dan ditolak;
BANTAHAN TERHADAP DALIL PENGGUGAT
17.Bahwa  terhadap  dalil  Penggugat  pada  bagian  “Kepentingan
Penggugat  Yang  Dirugikan”  pada  halaman  10  sampai  dengan
halaman 13 gugatannya yang pada pokoknya menyatakan dengan
ditetapkannya Objek Gugatan, berakibat sebagai berikut:
a.Penggugat kehilangan jabatannya;
b.Penggugat kehilangan fasilitas dan tunjangan sebagai Kepala
Bagian Umum LLDIKTI;
c.Penggugat mendapatkan perlakukan diksriminasi dan tidak adil
dari Tergugat; dan

Kepaniteraan Mahkamah Agung Republik Indonesia berusaha untuk selalu mencantumkan informasi paling kini dan akurat sebagai bentuk komitmen Mahkamah Agung untuk pelayanan publik, transparansi dan akuntabilitas
pelaksanaan fungsi peradilan. Namun dalam hal-hal tertentu masih dimungkinkan terjadi permasalahan teknis terkait dengan akurasi dan keterkinian informasi yang kami sajikan, hal mana akan terus kami perbaiki dari waktu kewaktu.
Dalam hal Anda menemukan inakurasi informasi yang termuat pada situs ini atau informasi yang seharusnya ada, namun belum tersedia, maka harap segera hubungi Kepaniteraan Mahkamah Agung RI melalui :
d.Penggugat mengalami gangguan psikologis dari tekanan atau
pandangan bawahannya serta mendapatkan pertanyaan yang
menyudutkan penggugat dari keluarganya atau anak-anaknya.
18.Bahwa dalil Penggugat tersebut adalah dalil yang tidak masuk akal
dan berdasar hukum, karena hingga saat ini status Penggugat masih
sebagai  Pegawai  Negeri  Sipil.  Selain  itu,  tunjangan  dan  Fasilitas
sebagaimana Pasal 21 ayat (2) huruf c Undang-Undang Nomor 20
Tahun  2023  tentang  Aparatur  Sipil  Negara  (UU  ASN)  yang  pada
menyatakan  tunjangan  dan  fasilitas  merupakan  komponen
penghargaan  dan  pengakuan  Pegawai  ASN  yang  melekat  baik
terhadap  jabatan tertentu  maupun  individu.  Hilangnya fasilitas dan
tunjangan  sebagai  kepala  bagian  umum  LLDIKTI  sebagaimana
didalilkan Penggugat adalah telah sesuai dengan jabatan Penggugat
Sekarang,  yaitu  sebagai  Penelaah  Teknis  Kebijakan  pada  Bagian
Umum sesuai dengan Keputusan Menteri Pendidikan, Kebudayaan,
Riset,  dan Teknologi Nomor 99146/M/06/2024 tanggal 31 Oktober
2024  tentang  Pemberhentian  dari  Jabatan  Administrator  dan
Pengangkatan  dalam  Jabatan  Pelaksana  di  Lingkungan  Lembaga
Layanan Pendidikan Tinggi Wilayah VII. Berkaitan dengan perlakuan
diskriminasi maupun tidak adil, maupun gangguan dan tekanan yang
disebut oleh Penggugat adalah dalil yang tidak beralasan, Tergugat
tidak  pernah  melakukan  diksriminasi  mengingat  Penyelenggaraan
kebijakan dan manajemen ASN salah satunya berdasarkan pada asas
nondiskriminatif, hal demikian dijelaskan pula dalam penjelasan Pasal
2  UU  ASN  penyelenggaraan  Manajemen  ASN  tidak  membedakan
latar belakang suku, ras, warna kulit, agama, asal-usul, jenis kelamin,
status pernikahan, umur, atau berkebutuhan khusus;
19.Bahwa dalil Penggugat pada angka 1 halaman 13 sampai dengan
angka 7 halaman 17 adalah benar, dimana Penggugat menyampaikan
bahwa Penggugat adalah Pegawai Negeri Sipil sehingga tunduk pada
seluruh  peraturan  Perundang-undangan  di  bidang  aparatur  sipil
negara,  dan  karena  kedudukan  Penggugat  sebagai  PNS  tersebut,

Kepaniteraan Mahkamah Agung Republik Indonesia berusaha untuk selalu mencantumkan informasi paling kini dan akurat sebagai bentuk komitmen Mahkamah Agung untuk pelayanan publik, transparansi dan akuntabilitas
pelaksanaan fungsi peradilan. Namun dalam hal-hal tertentu masih dimungkinkan terjadi permasalahan teknis terkait dengan akurasi dan keterkinian informasi yang kami sajikan, hal mana akan terus kami perbaiki dari waktu kewaktu.
Dalam hal Anda menemukan inakurasi informasi yang termuat pada situs ini atau informasi yang seharusnya ada, namun belum tersedia, maka harap segera hubungi Kepaniteraan Mahkamah Agung RI melalui :
maka  Tergugat  mempunyai  wewenang  untuk  menerbitkan  objek
sengketa;
20.Bahwa dalil Penggugat pada angka 8 halaman 17 sampai dengan
angka 14 halaman 20 gugatannya adalah dalil yang tidak berdasarkan
pada  hukum.  Penggugat  mendalilkan  tindakan  Tergugat  dalam
mengeluarkan  Objek  Gugatan  melanggar  hak  asasi  Penggugat.
Sebagaimana  telah  diuraikan  sebelumnya,  Tergugat  dalam
menerbitkan  Objek  Gugatan  adalah  telah  melalui  prosedur  dan
berdasarkan ketentuan yang berlaku;
21.Bahwa dalil penggugat angka 15 halaman 20 gugatannya adalah dalil
yang  tidak  mendasar.  Penggugat  telah  menyampaikan  Keputusan
Tergugat baik Objek Sengketa 1 maupun Objek Sengketa 2 kepada
Penggugat  melalui  atasan  langsung  Penggugat.  Selain  itu,  dalil
Penggugat  yang  menyatakan  akibat  bantahan  yang  diajukan  tidak
pernah ada jawaban atau tanggapan sehingga Penggugat tidak dapat
melakukan  aktivitas  pekerjaan  normal  adalah  dalil  yang  tidak
beralasan. Saat ini Penggugat masih berstatus sebagai PNS dengan
jabatan/kedudukan Penelaah Teknis Kebijakan pada Bagian Umum,
Penggugat memiliki tugas dan tanggung jawab; 
22.Berdasarkan uraian tersebut, terlihat jelas dalil gugatan Penggugat
adalah tidak beralasan dan berdasarkan hukum, oleh karenanya dalil
Penggugat tersebut harus dikesampingkan;
23.Bahwa terhadap dallil gugatan Penggugat angka 3 halaman 20 adalah
dalil yang mengada-ada, baik Objek Gugatan yang dikeluarkan oleh
Tergugat  tidak  memberikan  sanksi  berupa  pemecatan  kepada
Penggugat,  hingga  saat  ini  Pemohon  masih  berstatus  sebagai
Pegawai Negeri Sipil dimana Penggugat masih mendapatkan hak-
haknya sesuai dengan jabatan dan/atau golongan;
24.Bahwa dalil Penggugat angka 4 halaman 21 sampai dengan angka 10
halaman  23  hanyalah  pengulangan  dalil  yang  telah  diuraikan
sebelumnya  oleh  Penggugat  sebagaimana  angka  8  halaman  17
hingga  angka  15  halaman  20.  Tiba-tiba  berdasarkan  pengulangan

Kepaniteraan Mahkamah Agung Republik Indonesia berusaha untuk selalu mencantumkan informasi paling kini dan akurat sebagai bentuk komitmen Mahkamah Agung untuk pelayanan publik, transparansi dan akuntabilitas
pelaksanaan fungsi peradilan. Namun dalam hal-hal tertentu masih dimungkinkan terjadi permasalahan teknis terkait dengan akurasi dan keterkinian informasi yang kami sajikan, hal mana akan terus kami perbaiki dari waktu kewaktu.
Dalam hal Anda menemukan inakurasi informasi yang termuat pada situs ini atau informasi yang seharusnya ada, namun belum tersedia, maka harap segera hubungi Kepaniteraan Mahkamah Agung RI melalui :
dalil yang tidak jelas tersebut, Penggugat menyatakan dirinya tidak
terbukti melanggar Pasal 3 ayat (1) jo Pasal 4 ayat (1) Peraturan
pemerintah No 45 Tahun 1990 Perubahan atas Peraturan Pemerintah
No  10  Tahun  1983  tentang  Izin  Perkawinan  dan  Perceraian  bagi
pegawai  negeri  sipil.  Alasan-alasan  yang  disampaikan  Penggugat
tersebut adalah alasan yang tidak mendasar mengingat hal demikian
bertentangan dengan fakta-fakta yang ditemukan oleh Tim Pemeriksa
sewaktu melakukan pemeriksaan atas laporan terhadap Penggugat;
25.Bahwa terhadap dalil Penggugat angka 14 halaman 25 gugatannya,
dalil  tersebut  adalah  dalil  yang  tidak  jelas  dan  tidak  berdasarkan
hukum, Penggugat mendalilkan bahwa Objek Sengketa 1 adalah surat
peringatan  yang  diterbitkan  Tergugat  kepada  Penggugat.  Objek
Sengketa 1 merupakan Hukuman Disiplin yang diberikan kepada PNS
yang melakukan pelanggaran disiplin sebagaimana ketentuan Pasal
86  ayat  1  UU  5  tahun  2014  tentang  Aparatur  Sipil  Negara,  yaitu
Hukuman disiplin Berat yang secara khusus diatur dalam Pasal 8 ayat
(4)  perBKN  6/2022  berupa  pembebasan  dari  jabatannya  menjadi
Jabatan  Pelaksana  selama  12  (dua  belas)  bulan  yang  diberikan.
Hukuman  Disiplin  tersebut  bukan  merupakan  peringatan  yang
diberikan Tergugat kepada Penggugat. Adapun sebagaimana Pasal
41  PerBKN  6/202,  Hukuman  Disiplin  bersifat  pembinaan  yang
dilakukan  untuk  memperbaiki  dan  mendidik  PNS  yang  melakukan
Pelanggaran  Disiplin,  agar  yang  bersangkutan  menyesal  dan
berusaha tidak mengulangi serta memperbaiki diri pada masa yang
akan datang. Artinya dengan menjalani hukuman disiplin inilah waktu
bagi  Penggugat  untuk  dapat  memperbaiki  diri  dan  berusaha  tidak
mengulangi  kesalahan  pelanggaran  serupa  maupun  pelanggaran
lainnya;
26.Bahwa  tindakan  Tergugat  dalam  menerbitkan  Objek  Gugatan  baik
terhadap prosedur maupun substansinya adalah telah sesuai dengan
ketentuan peraturan perundang-undangan khususnya peraturan yang
mengatur  tentang  Disiplin  PNS,  dimana  oleh  karena  tingkatan

Kepaniteraan Mahkamah Agung Republik Indonesia berusaha untuk selalu mencantumkan informasi paling kini dan akurat sebagai bentuk komitmen Mahkamah Agung untuk pelayanan publik, transparansi dan akuntabilitas
pelaksanaan fungsi peradilan. Namun dalam hal-hal tertentu masih dimungkinkan terjadi permasalahan teknis terkait dengan akurasi dan keterkinian informasi yang kami sajikan, hal mana akan terus kami perbaiki dari waktu kewaktu.
Dalam hal Anda menemukan inakurasi informasi yang termuat pada situs ini atau informasi yang seharusnya ada, namun belum tersedia, maka harap segera hubungi Kepaniteraan Mahkamah Agung RI melalui :
hukuman  disiplin  yang  di  ancamkan  Penggugat  adalah  Hukuman
Disiplin Berat, maka prosedur pemeriksaan harus berdasarkan pasal
29 ayat (2) sampai dengan ayat (5) Peraturan Pemerintah Republik
Indonesia Nomor 94 Tahun 2021 Tentang Disiplin Pegawai Negeri
Sipil yang menyebutkan:
2)  (Pelanggaran  terhadap  kewajiban  dan/atau  larangan  dengan
Hukuman Disiplin berat sebagaimana dimaksud dalam Pasal 11
dan Pasal 14 dilakukan pemeriksaan oleh Tim pemeriksa,
3) Tim pemeriksa sebagaimana dimaksud pada ayat (1) dan ayat (2)
terdiri  dari  atasan  langsung,  unsur  pengawasan,  dan  unsur
kepegawaian.
4) Dalam hal tertentu Tim pemeriksa sebagaimana dimaksud pada
ayat (3) dapat melibatkan pejabat lain yang ditunjuk.
  5)  Tim pemeriksa sebagaimana dimaksud pada ayat (3) dibentuk
oleh  Pejabat  Pembina  Kepegawaian  atau  pejabat  lain  yang
ditunjuk
27.Berdasarkan ketentuan tersebut di atas maka prosedur pemeriksaan
dan rekomendasi penjatuhan hukuman disiplin terhadap Penggugat
sampai  dengan  terbitnya  Objek  Gugatan,  termasuk  substansi  dari
Surat Keputusan Tergugat telah sesuai dengan ketentuan peraturan
perundang-undangan  khususnya  peraturan  yang  mengatur  tentang
Disiplin PNS;
28.Bahwa berdasarkan uraian kronologis dan fakta hukum yang terurai di
atas,  kiranya  sudah  cukup  menjawab  bagaimana  kondisi  yang
sebenarnya terkait dengan masalah yang dijadikan alasan di dalam
gugatan  a quo, sebagaimana Penggugat sampaikan didalam Surat
Gugatannya tanggal tanggal 24 Oktober 2023, dengan demikian maka
prosedur  pemeriksaan,  rekomendasi  penjatuhan  hukuman  disiplin
kepada  Penggugat  sampai  dengan  terbitnya  objek  gugatan  a  quo
telah  sesuai  dengan  ketentuan  peraturan  perundang-undangan
khususnya peraturan yang mengatur tentan Disiplin PNS;

Kepaniteraan Mahkamah Agung Republik Indonesia berusaha untuk selalu mencantumkan informasi paling kini dan akurat sebagai bentuk komitmen Mahkamah Agung untuk pelayanan publik, transparansi dan akuntabilitas
pelaksanaan fungsi peradilan. Namun dalam hal-hal tertentu masih dimungkinkan terjadi permasalahan teknis terkait dengan akurasi dan keterkinian informasi yang kami sajikan, hal mana akan terus kami perbaiki dari waktu kewaktu.
Dalam hal Anda menemukan inakurasi informasi yang termuat pada situs ini atau informasi yang seharusnya ada, namun belum tersedia, maka harap segera hubungi Kepaniteraan Mahkamah Agung RI melalui :
TERHADAP PENUNDAAN
29.Bahwa terhadap dalil Penggugat mengenai Penundaan Pelaksanaan
Objek Sengketa, Tergugat dengan ini Menolak dengan tegas, seluruh
dalil  Penggugat  pada  bagian  ini  karena  bertentangan  dengan
Ketentuan  Penundaan  sebagaimana  Pasal  67  Undang-Undang
Republik  Indonesia  Nomor  5  Tahun  1986  tentang  Peradilan  Tata
Usaha Negara sebagaimana telah diubah, terakhir dengan Undang-
Undang Republik Indonesia Nomor 51 tahun 2009 tentang Perubahan
Kedua atas Undang-Undang Nomor 5 Tahun 1986 tentang Peradilan
Tata Usaha Negara menyebutkan:
Pasal 67
(1)Gugatan tidak menunda atau menghalangi dilaksanakannya
Keputusan Badan atau Pejabat Tata Usaha Negara serta
indakan  Badan  atau  Pejabat  Tata  Usaha  Negara  yang
digugat.
(2)Penggugat  dapat  mengajukan  permohonan  agar
pelaksanaan  Keputusan  Tata  Usaha  Negara  itu  ditunda
selama pemeriksaan sengketa Tata Usaha Negara sedang
berjalan, sampai ada putusan Pengadilan yang memperoleh
kekuatan hukum tetap.
(3)Permohonan sebagaimana dimaksud dalam ayat (2) dapat
iajukan sekaligus dalam gugatan dan dapat diputus terlebih
dahulu dari pokok sengketanya.
(4)Permohonan penundaan sebagaimana dimaksud dalam ayat
(2):
a.dapat dikabulkan hanya apabila terdapat keadaan yang
sangat  mendesak  yang  mengakibatkan  kepentingan
penggugat sangat dirugikan jika Keputusan Tata Usaha
Negara yang digugat itu tetap dilaksanakan;

Kepaniteraan Mahkamah Agung Republik Indonesia berusaha untuk selalu mencantumkan informasi paling kini dan akurat sebagai bentuk komitmen Mahkamah Agung untuk pelayanan publik, transparansi dan akuntabilitas
pelaksanaan fungsi peradilan. Namun dalam hal-hal tertentu masih dimungkinkan terjadi permasalahan teknis terkait dengan akurasi dan keterkinian informasi yang kami sajikan, hal mana akan terus kami perbaiki dari waktu kewaktu.
Dalam hal Anda menemukan inakurasi informasi yang termuat pada situs ini atau informasi yang seharusnya ada, namun belum tersedia, maka harap segera hubungi Kepaniteraan Mahkamah Agung RI melalui :
b.tidak dapat dikabulkan apabila kepentingan umum dalam
rangka  pembangunan  mengharuskan  dilaksanakannya
keputusan tersebut.
30.Berbeda dengan Hukum Acara Perdata maka dalam Hukum Acara
Tata Usaha Negara Badan atau Pejabat Tata Usaha egara itu selalu
berkedudukan sebagai pihak yang mempertahankan keputusan yang
telah dikeluarkannya terhadap tuduhan penggugat bahwa keputusan
yang digugat itu melawan hukum;
31.Akan  tetapi  selama  hal  itu  belum  diputus  oleh  Pengadilan,  maka
Keputusan Tata Usaha Negara itu harus dianggap menurut hukum.
Dan  proses  di  muka  Pengadilan  Tata  Usaha  Negara  memang
dimaksudkan untuk menguji apakah dugaan bahwa Keputusan Tata
Usaha Negara yang digugat itu melawan hukum beralasan atau tidak.
Itulah  dasar  hukum  acara  Tata  Usaha  Negara  yang  bertolak  dari
anggapan bahwa Keputusan Tata Usaha Negara itu selalu menurut
hukum;
32.Dari  segi  perlindungan  hukum,  maka  Hukum  Acara  Tata  Usaha
Negara yang merupakan sarana hukum untuk dalam keadaan konkret
meniadakan  anggapan  tersebut.  Oleh  karena  itu,  pada  asasnya
selama  hal  tersebut  belum  diputuskan  oleh  Pengadilan,  maka
Keputusan  Tata  Usaha  Negara  yang  digugat  itu  tetap  ianggap
menurut  hukum,  dapat  dilaksanakan.  Akan  tetapi  dalam  keadaan
tertentu,  penggugat  dapat  mengajukan  permohonan  agar  selama
proses  berjalan,  Keputusan  Tata  Usaha  Negara  yang  digugat  itu
diperintahkan  ditunda  pelaksanaannya.  Pengadilan  akan
mengabulkan permohonan penundaan pelaksanaan Keputusan Tata
Usaha Negara tersebut hanya apabila :
a.terdapat keadaan yang sangat mendesak, yaitu jika kerugian
yang  akan  diderita  penggugat  akan  sangat  tidak  seimbang
dibanding  dengan  manfaat  bagi  kepentingan  yang  akan
ilindungi  oleh  pelaksanaan  Keputusan  Tata  Usaha  Negara
tersebut; atau

Kepaniteraan Mahkamah Agung Republik Indonesia berusaha untuk selalu mencantumkan informasi paling kini dan akurat sebagai bentuk komitmen Mahkamah Agung untuk pelayanan publik, transparansi dan akuntabilitas
pelaksanaan fungsi peradilan. Namun dalam hal-hal tertentu masih dimungkinkan terjadi permasalahan teknis terkait dengan akurasi dan keterkinian informasi yang kami sajikan, hal mana akan terus kami perbaiki dari waktu kewaktu.
Dalam hal Anda menemukan inakurasi informasi yang termuat pada situs ini atau informasi yang seharusnya ada, namun belum tersedia, maka harap segera hubungi Kepaniteraan Mahkamah Agung RI melalui :
b.pelaksanaan Keputusan Tata Usaha Negara yang digugat itu
tidak ada sangkut pautnya dengan kepentingan umum dalam
rangka pembangunan.
33.Berdasarkan  ketentuan  tersebut  di  atas  maka  Tergugat  menolak
dengan  tegas  terhadap  permohonan  penundaan  yang  di  ajukan
Penggugat karena tidak ada satu alasan pun yang terpenuhi, yaitu
baik  adanya  keadaan  yang  sangat  mendesak  serta  Keputusan
Tergugat yang dijadikan Objek Gugatan tidak ada sangkut pautnya
dengan kepentingan umum dalam rangka Pembangunan. Oleh karena
itu,  sudah  cukup  beralasan  hukum  Yang  Terhormat  Majelis Hakim
yang  memeriksa  perkara  a  quo  dapat  menolak  Permohonan
Penundaan yang diajukan Penggugat
Berdasarkan seluruh uraian-uraian yang telah disampaikan sebagaimana
tersebut di atas, kiranya tidaklah berlebihan dan sangat beralasan hukum
apabila Tergugat dengan ini memohon agar kiranya Yang Terhormat Majelis
Hakim Pengadilan Tata Usaha Negara Jakarta yang memeriksa perkara a
quo berkenan untuk mengadili dan selanjutnya memutus perkara sebagai
berikut:

# DALAM EKSEPSI

-Menerima eksepsi Tergugat
-Menyatakan Gugatan Penggugat tidak dapat diterima
DALAM PENUNDAAN
-Menolak Permohonan Penundaan Penggugat

# DALAM POKOK PERKARA
:
1.Menolak gugatan Penggugat untuk seluruhnya;
2.Menghukum Penggugat untuk membayar seluruh biaya perkara yang
Timbul dalam perkara ini menurut hukum
Atau
Apabila majelis berpendapat lain, mohon putusan yang seadil-adilnya
(Ex Aequo Et Bono )

Kepaniteraan Mahkamah Agung Republik Indonesia berusaha untuk selalu mencantumkan informasi paling kini dan akurat sebagai bentuk komitmen Mahkamah Agung untuk pelayanan publik, transparansi dan akuntabilitas
pelaksanaan fungsi peradilan. Namun dalam hal-hal tertentu masih dimungkinkan terjadi permasalahan teknis terkait dengan akurasi dan keterkinian informasi yang kami sajikan, hal mana akan terus kami perbaiki dari waktu kewaktu.
Dalam hal Anda menemukan inakurasi informasi yang termuat pada situs ini atau informasi yang seharusnya ada, namun belum tersedia, maka harap segera hubungi Kepaniteraan Mahkamah Agung RI melalui :
Bahwa terhadap Jawaban Tergugat  tersebut, Penggugat   mengajukan
replik pada persidangan tanggal 5 Februari 2025 , dan Tergugat mengajukan
duplik pada persidangan tanggal 26 Februari 2025;
Bahwa  untuk  menguatkan  dalil-dalil  gugatannya,  Penggugat  telah
mengajukan  Bukti  berupa  fotokopi  surat-surat  yang  telah  diberi  meterai
cukup dan telah disesuaikan dengan asli maupun fotokopinya, serta diberi
tanda                      P – 1 sampai dengan P – 13, ya kni sebagai berikut:
-Bukti P-1:Keputusan  Menteri  Pendidikan,  Kebudayaan,  Riset
dan Teknologi Republik Indonesia Nomor 93731/RHS/
M/08/2024  tanggal  4  Oktober  2024  tentang
Pembebasan  dari  Jabatannya  menjadi  Jabatan
Pelaksana  selama  12  (dua  belas)  bulan  (sesuai
dengan asli);
-Bukti P-2:Surat tanggal 16 Oktober 2024 Perihal Bantahan atas
Keputusan Menteri Pendidikan, Riset dan Teknologi
Republik  Indonesia  Nomor:  93731/RHS/M/08/2024
tanggal  4  Oktober  2024  tentang  Pembebasan  dari
Jabatannya  menjadi  Jabatan  Pelaksana  selama  12
(dua belas)  (sesuai dengan fotokopi);
-Bukti P-3:Kartu  Tanda  Penduduk  (KTP)  NIK
3517092603780003 atas nama Ivan Rovian, dr. MKP
(sesuai dengan asli);
-Bukti P-4:Kartu  Keluarga  No.  3517090101070009  atas  nama
Ivan Rovian, dr., MKP (sesuai dengan asli);
-Bukti P-5:Kutipan  Akta  Nikah  Nomor  12/03/II/2003  tanggal  5
Februari  2003  atas  nama  dr.  Ivan  Rovian  (sesuai
dengan asli);
-Bukti P-6:Keputusan  Bupati  Jombang  Nomor:  813/59/415.43/
2009 tanggal 25 Maret 2009 tentang Pengangkatan
Calon Pegawai Negeri Sipil Daerah (sesuai dengan
asli);
-Bukti P-7:Petikan Keputusan Bupati Jombang Nomor: 816/238/
415.42/2010  tanggal  1  Nopember  2010  tentang
Pengangkatan  Calon  Pegawai  Negeri  Sipil  menjadi

Kepaniteraan Mahkamah Agung Republik Indonesia berusaha untuk selalu mencantumkan informasi paling kini dan akurat sebagai bentuk komitmen Mahkamah Agung untuk pelayanan publik, transparansi dan akuntabilitas
pelaksanaan fungsi peradilan. Namun dalam hal-hal tertentu masih dimungkinkan terjadi permasalahan teknis terkait dengan akurasi dan keterkinian informasi yang kami sajikan, hal mana akan terus kami perbaiki dari waktu kewaktu.
Dalam hal Anda menemukan inakurasi informasi yang termuat pada situs ini atau informasi yang seharusnya ada, namun belum tersedia, maka harap segera hubungi Kepaniteraan Mahkamah Agung RI melalui :
Pegawai Negeri Sipil (sesuai dengan asli);
-Bukti P-8:Keputusan  Kepala  Badan  Kepegawaian  Negara
Nomor  0027/KEP/AU/13015/2014  tanggal  27
Nopember 2014 tentang pemindahan/pengalihan jenis
kepegawaiannya menjadi Pegawai Negeri Sipil Pusat
Kementerian  Kesehatan  Republik  Indonesia  atas
nama dr. Ivan Rovian (sesuai dengan asli);
-Bukti P-9:Keputusan  Kepala  Badan  Kepegawaian  Negara
Nomor  00117/KEP/AU/12001/2015  tanggal  25
Nopember  2015  tentang  pemindahan  menjadi
Pegawai Negeri Sipil Pusat pada Kementerian Riset,
Teknologi dan Pendidikan Tinggi atas nama dr. Ivan
Rovian (sesuai dengan asli);
-Bukti P-10:Berita  Acara  Pengangkatan  Sumpah  tanggal  17
Desember 2015 sebagai Kepala Seksi Perencanaan
Teknis Sarana dan Prasarana Pendidikan Tinggi, pada
Direktorat Sarana dan Prasarana, Direktorat Jenderal
Sumber  Daya  Ilmu  Pengetahuan,  Teknologi  dan
Pendidikan Tinggi Kementerian Riset, Teknologi dan
Pendidikan Tinggi atas nama dr. Ivan Rovian, M.Kp
(sesuai dengan asli);
-Bukti P-11:Dokumentasi  saat  menghadiri  Undangan  Walimah
Staf  Khusus  Gubernur  Jawa  Timur  (sesuai  dengan
fotokopi);
-Bukti P-12:Dokumentasi  saat  menjalankan  ibadah  umrah
bersama  keluarga  besar  dr.  Ivan  Rovian  dan  istri
(sesuai dengan fotokopi);
-Bukti P-13:Dokumentasi  foto  bersama  keluarga  besar  saat
menghadiri wisuda S-3 untuk meraih gelar Doktor di
Universitas Airlangga Surabaya, Jawa Timur (sesuai
dengan fotokopi);
Bahwa  untuk  menguatkan  dalil-dalil  bantahannya,  Tergugat  telah
mengajukan  Bukti  berupa  fotokopi  surat-surat  yang  telah  diberi  meterai
cukup dan telah disesuaikan dengan asli maupun fotokopinya, serta diberi
tanda                 T – 1 sampai dengan T – 31, yakni sebagai berikut: 

Kepaniteraan Mahkamah Agung Republik Indonesia berusaha untuk selalu mencantumkan informasi paling kini dan akurat sebagai bentuk komitmen Mahkamah Agung untuk pelayanan publik, transparansi dan akuntabilitas
pelaksanaan fungsi peradilan. Namun dalam hal-hal tertentu masih dimungkinkan terjadi permasalahan teknis terkait dengan akurasi dan keterkinian informasi yang kami sajikan, hal mana akan terus kami perbaiki dari waktu kewaktu.
Dalam hal Anda menemukan inakurasi informasi yang termuat pada situs ini atau informasi yang seharusnya ada, namun belum tersedia, maka harap segera hubungi Kepaniteraan Mahkamah Agung RI melalui :
-Bukti T-1:Keputusan  Menteri  Pendidikan,  Kebudayaan,  Riset
dan Teknologi Republik Indonesia Nomor 93731/RHS/
M/08/2024  tanggal  4  Oktober  2024  tentang
Pembebasan  dari  Jabatannya  menjadi  Jabatan
Pelaksana selama 12 (dua belas) bulan,  atas nama
dr. IVAN ROVIAN, M.Kp.  (sesuai dengan asli);
-Bukti T-2:Keputusan  Menteri  Pendidikan,  Kebudayaan,  Riset
dan Teknologi Republik Indonesia Nomor 93731/RHS/
M/08/2024  tanggal  4  Okober  2024  tentang
Pembebasan  dari  Jabatannya  menjadi  Jabatan
Pelaksana selama 12 (dua belas) bulan,  atas nama
dr. IVAN ROVIAN, M.Kp.  (sesuai dengan asli);
-Bukti T-3:Laporan  Perbuatan  Zinah  tanggal  5  Agustus  2023
(sesuai dengan asli dan lampiran fotokopi);
-Bukti T-4:Surat  Kepala  Biro  Sumber  Daya  Manusia  Nomor:
50768/RHS/B/08/2023  tanggal  12  September  2023
hal Laporan Perbuatan Zina (fotokopi dari fotokopi);
-Bukti T-5:Surat  Kepala  Lembaga  Layanan  Pendidikan  Tinggi
Wilayah VII Nomor: 2254/LL7/RHS/2023 tanggal 25
September  2023  Hal  Laporan  Pelanggaran  Disiplin
Pegawai (sesuai dengan asli);
-Bukti T-6:Surat  Nomor  62016/RHS/B/08/2023  tanggal  20
Oktober  2023,  Hal  Laporan  Pelanggaran  Disiplin
Pegawai  (sesuai dengan asli);
-Bukti T-7:Surat  Kepala  Lembaga  Layanan  Pendidikan  Tinggi
Wilayah  VII  Nomor:  2427/KP/LL7/2023  tanggal  25
Oktober  2023  Hal  Usulan  Pembenukan  Tim
Pemeriksa (sesuai dengan asli);
-Bukti T-8:Surat  Nomor  68279/RHS/B/08/2023  tanggal  7
Desember  2023,  Hal  Permohonan  Tim  Pemeriksa
(fotokopi dari fotokopi);
-Bukti T-9:Surat  Nomor:  1700/G1/RHS/KP.04.06/2024  tanggal
15 Februari 2024, Hal Usul Auditor untuk menjadi Tim
Pemeriksa (sesuai dengan asli);
-Bukti T-10:Surat Nomor: 16086/RHS/B/08/2024 tanggal 4 Maret

Kepaniteraan Mahkamah Agung Republik Indonesia berusaha untuk selalu mencantumkan informasi paling kini dan akurat sebagai bentuk komitmen Mahkamah Agung untuk pelayanan publik, transparansi dan akuntabilitas
pelaksanaan fungsi peradilan. Namun dalam hal-hal tertentu masih dimungkinkan terjadi permasalahan teknis terkait dengan akurasi dan keterkinian informasi yang kami sajikan, hal mana akan terus kami perbaiki dari waktu kewaktu.
Dalam hal Anda menemukan inakurasi informasi yang termuat pada situs ini atau informasi yang seharusnya ada, namun belum tersedia, maka harap segera hubungi Kepaniteraan Mahkamah Agung RI melalui :
2024, Hal Pembentukan Tim Pemeriksa (fotokopi dari
fotokopi);
-Bukti T-11:Surat  Panggilan  I  Nomor:  085/LL7/KP/RHS/2024
tanggal  15  Maret  2024  ditujukan  kepada  dr.  Ivan
Rovian, M.Kp (sesuai dengan asli);
-Bukti T-12:Surat  Panggilan  I  Nomor:  086/LL7/KP/RHS/2024
tanggal  15  Maret  2024  ditujukan  kepada  Tri  Asih
Imro’ati, dr., SpPD., K-GEH., FINASIM (sesuai dengan
asli);
-Bukti T-13:Surat  Panggilan  I  Nomor:  087/LL7/KP/RHS/2024
tanggal 15 Maret 2024 ditujukan kepada Katmini binti
Katmin (sesuai dengan asli);
-Bukti T-14:Surat dari dr. Ivan Rovian, M.Kp tertanggal 22 Maret
2024 (fotokopi dari fotokopi);
-Bukti T-15:Surat  Panggilan  II  Nomor:  98/LL7/KP.04.04/2024
tanggal  22  Maret  2024  ditujukan  kepada  dr.  Ivan
Rovian, M.Kp (sesuai dengan asli);
-Bukti T-16:Surat  Panggilan  II  Nomor:  97/LL7/KP.04.04/2024
tanggal 22 Maret 2024 ditujukan kepada Katmini binti
Katmin (sesuai dengan asli);
-Bukti T-17:Berita Acara Pemeriksaan tanggal 15 Agustus 2023
(sesuai dengan asli);
-Bukti T-18:Berita  Acara  Pemeriksaan  tanggal  1  April  2024
(sesuai dengan fotokopi);
-Bukti T-19:Laporan Hasil Pemeriksaan sifatnya rahasia tanggal
13 Agustus 2024 (sesuai dengan asli);
-Bukti T-20:Surat Kepala Layanan Pendidikan Tinggi Wilayah VII
Nomor:  316/LL7/KP.04.05/2024  tanggal  16  Agustus
2024,  Hal  Usulan  Penjatuhan  Hukuman  Disiplin
(sesuai dengan asli dan lampiran fotokopi);
-Bukti T-21:Pertimbangan  Hukum  tentang  Dugaan  Pelanggaran
Disiplin PNS atas nama dr. Ivan Rovian, M.Kp. (sesuai
dengan asli);
-Bukti T-22:Surat  Sekretaris  Jenderal  Kementerian  Pendidikan,
Kebudayaan,  Riset  dan  Teknologi  Nomor:
92912/RHS/ S/08/2024 tanggal 26 September 2024,

Kepaniteraan Mahkamah Agung Republik Indonesia berusaha untuk selalu mencantumkan informasi paling kini dan akurat sebagai bentuk komitmen Mahkamah Agung untuk pelayanan publik, transparansi dan akuntabilitas
pelaksanaan fungsi peradilan. Namun dalam hal-hal tertentu masih dimungkinkan terjadi permasalahan teknis terkait dengan akurasi dan keterkinian informasi yang kami sajikan, hal mana akan terus kami perbaiki dari waktu kewaktu.
Dalam hal Anda menemukan inakurasi informasi yang termuat pada situs ini atau informasi yang seharusnya ada, namun belum tersedia, maka harap segera hubungi Kepaniteraan Mahkamah Agung RI melalui :
Hal Usul berupa pembebasan dari jabatannya menjadi
jabatan pelaksana selama 12 (dua belas) bulan dr.
Ivan Rovian, M.Kp. (sesuai dengan asli);
-Bukti T-23:Surat tanggal 16 Oktober 2024 perihal Bantahan atas
Keputusan Menteri Pendidikan, Riset dan Teknologi
Republik  Indonesia  Nomor:  93731/RHS/M/08/2024,
tanggal  4  Oktober  2024  tentang  Pembebasan  dari
jabatannya  menjadi  jabatan  pelaksana  selama  12
(dua belas) bulan (fotokopi dari fotokopi);
-Bukti T-24:Surat  tanggal  23  Oktober  2024  perihal
Menindaklanjuti  Surat  Bantahan  atas  Keputusan
Menteri  Pendidikan,  Riset  dan  Teknologi  Republik
Indonesia  Nomor:  93731/RHS/M/08/2024  (sesuai
dengan fotokopi);
-Bukti T-25:Surat  Nomor:  010/SP-AR&P/X/2024  tanggal  31
Oktober  2024  perihal  Bantahan/Keberatan  atas
Keputusan Menteri Pendidikan, Riset dan Teknologi
Republik  Indonesia  Nomor  93731/RHS/M/08/2024
(fotokopi dari fotokopi);
-Bukti T-26:Surat  Nomor  :  010/SP-AR&P/X/2024  tanggal  4
November  2024  perihal  Bantahan/Keberatan  atas
Keputusan Menteri Pendidikan, Riset dan Teknologi
Republik  Indonesia  Nomor  93731/RHS/M/08/2024
(sesuai dengan asli);
-Bukti T-27:Pertimbangan  Sekretaris  Jenderal  Atas  Keberatan
Keputusan  Menteri  Pendidikan,  Kebudayaan,  Riset
dan Teknologi Nomor 93731/RHS/M/08/2024 tanggal
4 Oktober 2024 tentang Pembebasan dari Jabatannya
menjadi  Jabatan  Pelaksana  selama  12  (dua  belas)
bulan  yang  diajukan  oleh  dr.  Ivan  Rovian,  M.Kp.
(sesuai dengan asli);
-Bukti T-28:Surat  Plt.  Sekretaris  Jenderal  Kementerian
Pendidikan  Tinggi,  Sains  dan  Teknologi  Nomor:
115682/RHS/S/ 08/2024 tanggal 18 November 2024

Kepaniteraan Mahkamah Agung Republik Indonesia berusaha untuk selalu mencantumkan informasi paling kini dan akurat sebagai bentuk komitmen Mahkamah Agung untuk pelayanan publik, transparansi dan akuntabilitas
pelaksanaan fungsi peradilan. Namun dalam hal-hal tertentu masih dimungkinkan terjadi permasalahan teknis terkait dengan akurasi dan keterkinian informasi yang kami sajikan, hal mana akan terus kami perbaiki dari waktu kewaktu.
Dalam hal Anda menemukan inakurasi informasi yang termuat pada situs ini atau informasi yang seharusnya ada, namun belum tersedia, maka harap segera hubungi Kepaniteraan Mahkamah Agung RI melalui :
Hal  Penguatan  Keputusan  Hukuman  Disiplin  atas
nama dr. Ivan Rovian, M.Kp. (sesuai dengan asli);
-Bukti T-29:Tanda Terima Surat  Keputusan Menteri Pendidikan,
Kebudayaan, Riset dan Teknologi Nomor 93731/RHS/
M/08/2024  tanggal  4  Oktober  2024  tentang
Pembebasan  dari  Jabatannya  menjadi  Pelaksana
selama 12 (dua belas) bulan (fotokopi dari fotokopi);
-Bukti T-30:Tanda  Terima  Surat  Keputusan  Menteri  Pendidikan
Tinggi,  Sains  dan  Teknologi  Nomor  13756/RHS/M/
08/2024 tanggal 25 November 2024 Penguatan SK
Menteri  Mendikbudristek  Nomor  93731/RHS/M/08/
2024 tentang Pembebasan dari Jabatannya menjadi
Jabatan Pelaksana selama 12 bulan (sesuai dengan
fotokopi) ;
-Bukti T-31:Peraturan  Badan  Kepegawaian  Negara  Nomor  6
Tahun  2022  tentang  Peraturan  Pelaksanaan
Peraturan Pemerintah Nomor 94 Tahun 2021 tentang
Disiplin Pegawai Negeri (sesuai dengan fotokopi); 
Bahwa pada persidangan perkara ini Penggugat tidak mengajukan
saksi  maupun  ahli  meskipun  telah  diberikan  kesempatan  untuk  itu,
sedangkan Tergugat mengajukan 2 (dua) orang saksi dan 1 (satu) orang ahli
di bawah sumpah sebagai berikut ;
KETERANGAN SAKSI :
1.ETIS ANNA SAFITRI, S.SOS., MIP, Kewarganegaraan Indonesia, Tempat
Tanggal  Lahir:  Sidoarjo  27  Januari  1993,  Jenis  Kelamin:  Perempuan,
Alamat: Tempel Sukorejo I/117 RT/RW. 002/006. Kelurahan Wonorejo,
Kecamatan Tegalsari, Kota Surabaya, Provinsi Jawa Timur, Agama: Islam,
Pekerjaan:  Pegawai  Negeri  Sipil.  Yang  pada  pokoknya  memberikan
keterangan sebagai berikut :
-Bahwa  sepengetahuan  saksi  gugatan  yang  diakukan  Penggugat ,
terkait penjatuhan disiplin berat sebagai pelaksana selama 12 (dua
belas) bulan;
-Bahwa saya bertugas di Kantor Lembaga Layanan Pendidikan Tinggi
Wilayah VII dengan jabatan sebagai penyelia administrasi kebijakan;

Kepaniteraan Mahkamah Agung Republik Indonesia berusaha untuk selalu mencantumkan informasi paling kini dan akurat sebagai bentuk komitmen Mahkamah Agung untuk pelayanan publik, transparansi dan akuntabilitas
pelaksanaan fungsi peradilan. Namun dalam hal-hal tertentu masih dimungkinkan terjadi permasalahan teknis terkait dengan akurasi dan keterkinian informasi yang kami sajikan, hal mana akan terus kami perbaiki dari waktu kewaktu.
Dalam hal Anda menemukan inakurasi informasi yang termuat pada situs ini atau informasi yang seharusnya ada, namun belum tersedia, maka harap segera hubungi Kepaniteraan Mahkamah Agung RI melalui :
-Bahwa seingat saksi mengenal Penggugat sejak 1 November 2024,
karena Penggugat adalah mantan atasan saya;
-Bahwa  sepengetahuan  saksi  penjatuhan  hukuman  disiplin  yang
diberikan kepada Penggugat karena adanya laporan dari istri tahun
2023,  yaitu  laporan  terkait  perzinahan  kemudian  kami  melakukan
pemanggilan  secara  informal,  yang  memanggil  adalah  Pimpinan
sedangkan saya sebagai penanggung jawab kepegawaian;
-Bahwa  sepengetahuan  saksi  jabatan  Penggugat  adalah  Kepala
Bagian  Umum  pada  Kantor  Lembaga  Layanan  Pendidikan  Tinggi
Wilayah VII;
-Bahwa  seingat  saksi  yang  mengirim  surat  panggilan  kepada
Penggugat;
-Bahwa  sepengetahuan  saksi  pemeriksaan  terhadap  Penggugat
dilakukan dua kali, pertama di Surabaya dan satunya di Ciledug;
-Bahwa  sepengetahuan  saksi,  istri  Penggugat  mengirimkan  pesan
melalui whatsapp;
-Bahwa sepengetahuan saksi, Penggugat tidak ada rasa penyesalan;
-Bahwa sepengetahuan saksi Katmini tidak ada pemberitahuan kabar
atas ketidakhadirannya dalam pemeriksaan;
-Bahwa  sepengetahuan  saksi,  Penggugat  tidak  hadir  pada  saat
pemanggilan pertama dan tidak mau diperiksa;
-Bahwa saksi mengetahui tentang Surat Keputusan penguatan dan
terhadap surat keputusan tersebut Penggugat tidak ada keberatan;
-Bahwa sepengetahuan saksi,  Penggugat sehari-hari hanya mengisi
absensi  saja,  waku  itu  pernah  kami  panggil  menanyakan,  lalu
Penggugat  menjawab  kalau  beliau  sedang  sibuk  mengajukan
gugatan di PTUN;
-Bahwa sepengetahuan saksi, Penggugat masih berstatus ASN;
-Bahwa  sepengetahuan  saksi,  umrah  dan  haji  upaya  istri  untuk
mempererat kembali hubungan dengan suami;
-Bahwa sepengetahuan saksi, Katmini bertugas di Universitas Strada;

Kepaniteraan Mahkamah Agung Republik Indonesia berusaha untuk selalu mencantumkan informasi paling kini dan akurat sebagai bentuk komitmen Mahkamah Agung untuk pelayanan publik, transparansi dan akuntabilitas
pelaksanaan fungsi peradilan. Namun dalam hal-hal tertentu masih dimungkinkan terjadi permasalahan teknis terkait dengan akurasi dan keterkinian informasi yang kami sajikan, hal mana akan terus kami perbaiki dari waktu kewaktu.
Dalam hal Anda menemukan inakurasi informasi yang termuat pada situs ini atau informasi yang seharusnya ada, namun belum tersedia, maka harap segera hubungi Kepaniteraan Mahkamah Agung RI melalui :
-Bahwa  sepengetahuan  saksi,  kantor  sudah  sering  berupaya
mengakurkan kembali Penggugat dengan istrinya;
-Bahwa sepengetahuan saksi, kepada Penggugat, Istri Penggugat dan
Katmini pernah dilakukan pemanggilan sebanyak dua kali;
-Bahwa sepengetahuan saksi, Katmini tidak pernah hadir meskipun
telah dipanggil sebanyak dua kali;
-Bahwa sepengetahuan saksi, panggilan pertama istri dan  dokter Ivan
Rovian hadir namun tidak berkenan untuk diperiksa;
-Bahwa  sepengetahuan  saksi,  tidak  pernah  ada  surat  perceraian
Penggugat yang dikeluarkan oleh Kantor;
-Bahwa  sepengetahuan  saksi,  laporan  yang  dilakukan  oleh  Istri
Penggugat menyatakan surat perceraiannya tidak ada, hanya pesan
chat dan video Penggugat dengan Katmini;
-Bahwa  sepengetahuan  saksi,  surat  Keputusan  Penguatan  bulan
Desember;
-Bahwa sepengetahuan saksi, Surat Keputusan Penguatan terlebih
dahulu  baru  kemudian  gugatan,  karena  Penggugat  ambil  bulan
Januari SK tersebut dikarekan sibuk ada gugatan di PTUN;
-Bahwa  sepengetahuan  saksi,  tidak  pernah  memeriksa  Penggugat
karena pangkat saya dibawah Penggugat;
-Bahwa  sepengetahuan  saksi,  Penggugat  nikah  siri  berdasarkan
laporan istri;
2.Dr. H. JOKO PRASETYO, S.Kp., Kewarganegaraan Indonesia, Tempat
Tanggal Lahir: Sidoarjo 7 Agustus 1973, Jenis Kelamin: Laki-Laki, Alamat:
Wangkal RT/RW. 012/006, Kelurahan Wangkal, Kecamatan Krembung,
Kabupaten  Sidoarjo,  Provinsi  Jawa  Timur,  Agama:  Islam,  Pekerjaan:
Dosen. Yang pada pokoknya memberikan keterangan sebagai berikut:
-Bahwa  sepengetahuan  saksi,  gugatan  yang  diajukan  Penggugat
mengenai jabatan Penggugat;
-Bahwa sepengetahuan saksi, Penggugat dibebaskan dari jabatannya
karena  masalah  etika  yaitu  hubungan  dengan  teman  kami  dari
Universitas Strada;

Kepaniteraan Mahkamah Agung Republik Indonesia berusaha untuk selalu mencantumkan informasi paling kini dan akurat sebagai bentuk komitmen Mahkamah Agung untuk pelayanan publik, transparansi dan akuntabilitas
pelaksanaan fungsi peradilan. Namun dalam hal-hal tertentu masih dimungkinkan terjadi permasalahan teknis terkait dengan akurasi dan keterkinian informasi yang kami sajikan, hal mana akan terus kami perbaiki dari waktu kewaktu.
Dalam hal Anda menemukan inakurasi informasi yang termuat pada situs ini atau informasi yang seharusnya ada, namun belum tersedia, maka harap segera hubungi Kepaniteraan Mahkamah Agung RI melalui :
-Bahwa sepengetahuan saksi awal mula perselingkuhan Penggugat
adalah awalnya kami Dosen Strada mengundang Penggugat untuk
menghadiri pembukaan perkuliahan dan ada teman Dosen, dan saya
dekat dengan Penggugat, kemudian Penggugat bertanya tentang ada
tidak yang bisa membantu bimbingan disertasinya;
-Bahwa sepengetahuan saksi, selalu ada kemudahan jabatan bagi
Katmini;
-Bahwa  sepengetahuan  saksi  saat  ini  Katmini  sudah  keluar,
sebelumnya jabatan Kepala Prodi, lalu dibantu Penggugat dari Rektor
menjadi Rektor Kepala;
-Bahwa sepengetahuan saksi, Penggugat membantu Katmini dengan
cara Universitas Strada ada Dewan Doktor salah satunya Katmini,
permintaan Penggugat kepada Rektor untuk jabatan Katmini;
-Bahwa sepengetahuan saksi, kita melihat kedekatan mereka sudah
sangat  intens,  bahkan  ada  mahasiswa  pernah  dikenalkan  ke
Penggugat sebagai suaminya, dan Katmini sedang hamil. Lalu dari
Rektorat  meminta  data-data  keluarganya  tapi  tidak  diberikan,
kemudian Katmini mengundurkan diri;
-Bahwa sepengetahuan saksi ketika Katmini hamil dalam keadaan
tidak bersuami;
-Bahwa Saksi bertugas sebagai Dosen Keperawatan di Universitas
Strada;
-Bahwa saksi mengetahui hukuman disiplin yang diberikan kepada
Penggugat dari Ibu Kepala Lembaga;
-Bahwa saksi tidak hadir pada saat pemeriksaan Penggugat ileh Tim
Pemeriksa;
KETERANGAN AHLI :
ACHMAD SETIYANTO, S.H., Kewarganegaraan Indonesia, Tempat Tanggal
Lahir: Jakarta 10 November 1981, Jenis Kelamin: Laki-Laki, Alamat: Jalan
Tambak  II  Blok  D1  No.  25,  RT/RW.  005/005,  Kelurahan  Pegangsaan,
Kecamatan  Menteng,  Jakarta  Pusat,  Agama:  Islam,  Pekerjaan:  Pegawai
Negeri Sipil, pada pokoknya memberikan keterangan sebagai berikut:

Kepaniteraan Mahkamah Agung Republik Indonesia berusaha untuk selalu mencantumkan informasi paling kini dan akurat sebagai bentuk komitmen Mahkamah Agung untuk pelayanan publik, transparansi dan akuntabilitas
pelaksanaan fungsi peradilan. Namun dalam hal-hal tertentu masih dimungkinkan terjadi permasalahan teknis terkait dengan akurasi dan keterkinian informasi yang kami sajikan, hal mana akan terus kami perbaiki dari waktu kewaktu.
Dalam hal Anda menemukan inakurasi informasi yang termuat pada situs ini atau informasi yang seharusnya ada, namun belum tersedia, maka harap segera hubungi Kepaniteraan Mahkamah Agung RI melalui :
-Bahwa  hukuman  yang  diberikan  oleh   pejabat  yang  berwenang
menghukum dalam hal dugaan pelanggaran disiplin yang mungkin
telah terbukti dan dijatuhkan kepada pegawai tersebut;
-Bahwa  sebelum  pejabat  Pembina  kepegawaian/pejabat  yang
berwenang menghukum menjatuhkan hukuman disiplin, maka setiap
pejabat akan mendalami apakah aduan/informasi yang bersangkutan,
kemudian disiapkan surat panggilan, dilakukan panggilan, dilakukan
pemeriksaan,  dibuatkan  BAP,  dibuatkan  juga  LHAP  apabila
diperlukan, kemudian apabila PPK berkenan menjatuhkan hukuman
disiplin  dijatuhkan  hukuman  disiplin,  kemudian  setelah  itu  ada
penyampaian hukuman disiplin;
-Bahwa  kedudukan  Menteri  undang-undang  dibidang  kepegawaian
setidaknya ada dua yang melekat pertama sebagai pejabat Pembina
kepegawaian oleh Undang-Undang Nomor 20 Tahun 2023 bahwa
kewenangan Menteri selaku pejabat Pembina kepegawaian adalah
mengangkat,  memindahkan  dan  memberhentikan  pegawai  ASN,
selain itu kewenangan Menteri melakukan pembinaan manajemen
ASN bagi setiap pegawai di lingkungannya, yang kedua kewenangan
Menteri diatur juga dalam PP No. 94 Tahun 2021 Menteri menjadi
salah  satu pejabat  yang berwenang  menterjemahkan  dari  pejabat
yang  melakukan  pembinaan  pegawai  ASN  salah  satunya  adalah
penjatuhan  hukuman  disiplin  bagi  pegawai  ASN  yang  terbukti
melakukan pelanggaran disiplin;
-Bahwa didalam pasal 8 PP No. 94 Tahun 2021 dikenal tingkat dan
jenis hukuman disiplin, untuk tingkat hukuman disiplin berat menurut
pasal tersebut dibedakan jenisnya menjadi tiga, yaitu ada penurunan
jabatan setingkat lebih rendah, ada pembebasan menjadi pelaksana
masing-masing 1 tahun/12 bulan dan hukuman disiplin jenis ketiga
dari  jenis  hukuman  disiplin  berat  adalah  pemberhentian  dengan
hormat tidak atas permintaan sendiri, untuk ketentuan dari pasal 41
PP No. 94 Tahun 2021 tersebut itu kemudian memberikan ancaman
sanksi bagi PNS khususnya yang melanggar ketentuan dari PP No.

Kepaniteraan Mahkamah Agung Republik Indonesia berusaha untuk selalu mencantumkan informasi paling kini dan akurat sebagai bentuk komitmen Mahkamah Agung untuk pelayanan publik, transparansi dan akuntabilitas
pelaksanaan fungsi peradilan. Namun dalam hal-hal tertentu masih dimungkinkan terjadi permasalahan teknis terkait dengan akurasi dan keterkinian informasi yang kami sajikan, hal mana akan terus kami perbaiki dari waktu kewaktu.
Dalam hal Anda menemukan inakurasi informasi yang termuat pada situs ini atau informasi yang seharusnya ada, namun belum tersedia, maka harap segera hubungi Kepaniteraan Mahkamah Agung RI melalui :
10 Tahun 1983 maupun PP No. 45 Tahun 1990 dimana mereka yang
terbukti melanggar PP No. 10 Tahun 1983 atau PP No. 45 Tahun
1990  diancam dengan  dijatuhi  salah  satu hukuman  disiplin  berat,
apakah  dijatuhi  hukuman  berat  level  1,  penurunan  jabatan  satu
tingkat selama 12 bulan, apakah dijatuhi hukuman disiplin berat level
2 berupa pembebasan jabatan menjadi sebagai pelaksana selama 12
bulan  atau  juga  pejabat  yang  berwenang  menghukum  bisa
menjatuhkan hukuman disiplin berat level 3 berupa pemberhentian
dengan hormat tidak atas permintaan sendiri;
-Bahwa setiap pejabat yang berwenang menghukum tentunya ketika
akan menjatuhkan hukuman disiplin mempertimbangkan antara jenis
pelanggaran  disiplinnya,  berat  ringannya  hukuman  disiplin,
pelanggaran  disiplin  yang  dilakukan  dengan  dampak  yang
ditimbulkan, sehingga setelah mendapat pertimbangan dari berbagai
hal  khususnya  misalkan    adanya  pemeriksaan  pemeriksa,
pertimbangan  hukuman  disiplin  nanti  kemudian  pejabat  yang
berwenang  menghukum  akan  menjatuhkan  salah  satu  hukuman
disiplin berat sebagaimana amanah dari pasal 41 tadi;
-Bahwa  Tim  pemeriksa  dibentuk  oleh  Menteri  atau  pejabat  yang
ditunjuk  oleh  Menteri,  dalam  menentukan  keanggotaan  atau  tiga
unsur  yang  ada  pada  anggota  tim  pemeriksa,  baik  unsur
kepegawaian, unsur pengawasan, maupun atasan langsung tentunya
ketika akan dilakukan pemeriksaan tim pemeriksa ini harus memiliki
kedudukan  atau  jabatan  paling  tidak  atau  serendah-rendahnya
setingkat dengan PNS yang akan diperiksa, oleh sebab itu apabila
dalam  pemeriksaan  PPK  atau  Menteri  harus  menunjuk  pejabat
tersebut, kalau memiliki kedudukan dibawah dari PNS yang diperiksa
ini akan menimbulkan ketidaksesuaian atau ketidaktepatan dari sisi
prosedurnya;
-Bahwa  arahan  dari  pasal  41  PP  PP  No.  94  Tahun  2021  kalau
memang tim pemeriksa dapat membuktikan terjadinya pelanggaran
disiplin maka laporan hasil pemeriksaan menjadi hasil rekomendasi

Kepaniteraan Mahkamah Agung Republik Indonesia berusaha untuk selalu mencantumkan informasi paling kini dan akurat sebagai bentuk komitmen Mahkamah Agung untuk pelayanan publik, transparansi dan akuntabilitas
pelaksanaan fungsi peradilan. Namun dalam hal-hal tertentu masih dimungkinkan terjadi permasalahan teknis terkait dengan akurasi dan keterkinian informasi yang kami sajikan, hal mana akan terus kami perbaiki dari waktu kewaktu.
Dalam hal Anda menemukan inakurasi informasi yang termuat pada situs ini atau informasi yang seharusnya ada, namun belum tersedia, maka harap segera hubungi Kepaniteraan Mahkamah Agung RI melalui :
bagi  Menteri  /  PPK  memutus  /  memberikan  penjatuhan  hukuman
disiplin yang setimpal dengan jenis pelanggaran sebagaimana yang
tadi diungkap dalam BAP / rekomendasi;
-Bahwa peringatan tidak dikenal dalam penjatuhan hukuman disiplin
yang memang ketentuan pasal-pasal itu di cluster diancam dengan
hukuman disiplin berat, tetapi mungkin kita ketahui bersama kalau
sebetulnya  tingkat  ringan  itu  ada  salah  satu  bentuknya  hukuman
disiplin teguran/teguran lisan dan tertulis, oleh sebab itu saya melihat
bercampur, jadi kalau misalkan ketentuan pasalnya hukuman disiplin
berat, misalkan pelanggaran terhadap tidak boleh menerima hadiah
yang  berkaitan  dengan  jabatan,  maka  PPK/Menteri  tidak  perlu
memberikan peringatan terlebih dahulu, kalau aparat /im pemeriksan
yang dibentuknya berhasil membuktikan penerimaan terkait dengan
jabatannya, maka bisa dijatuhkan salah satu hukuman disiplin berat
tanpa didahului oleh peringatan;
-Bahwa  kalau  berbicara  penanganan  polisi  berarti  aturan  yang
dimainkan adalah aturan pidana, jadi misalkan Tergugat menyatakan
adanya  perselingkuhan,  sebetulnya  ketika  kita  sebaga  ASN,
khususnya  PNS  selain  terikat  pada  KUHP juga  terikat  juga  pada
aturan  kepegawaian,  misalkan  ada  17  kewajiban  yang  wajib
dilaksanakan  dan  ada  14  larangan  yang  wajib  tidak
dilakukan/dihindari, oleh sebab itu ketika Presiden melalui PP No. 94
Tahun  2021  telah  memberikan  delegasi  kepada  pejabat  yang
berwenang menghukum untuk membina PNS di lingkungannya, maka
baik dengan informasi dari para penegak hukum atau tanpa melalui
informasi  dari  aparat  penegak  hukum,  pejabat  adminsitrasi  bisa
melakukan  pendalaman,  bisa  melakukan  pemanggilan,  melakukan
pemeriksaan dan kemudian ketika terbukti melakukan pelanggaran
terhadap  kewajiban/larangan  tadi  dapat  dijatuhi  hukuman  disiplin
sesuai ketentuan perundang-undangan;
-Bahwa  PP  No.  10  dan  PP  No.  45  Tahun  1990  secara  filosofis
menginginkan kedudukan kita kalau kedudukan sebagai PNS menjadi

Kepaniteraan Mahkamah Agung Republik Indonesia berusaha untuk selalu mencantumkan informasi paling kini dan akurat sebagai bentuk komitmen Mahkamah Agung untuk pelayanan publik, transparansi dan akuntabilitas
pelaksanaan fungsi peradilan. Namun dalam hal-hal tertentu masih dimungkinkan terjadi permasalahan teknis terkait dengan akurasi dan keterkinian informasi yang kami sajikan, hal mana akan terus kami perbaiki dari waktu kewaktu.
Dalam hal Anda menemukan inakurasi informasi yang termuat pada situs ini atau informasi yang seharusnya ada, namun belum tersedia, maka harap segera hubungi Kepaniteraan Mahkamah Agung RI melalui :
teladan, bagaimana kehidupannya serasi, sejahtera, harmonis ketika
dengan pasangan yang sah dalam hal ini suami/istrinya, oleh sebab
itu  ketika  seorang PNS  akan menikah  ada  fasilitas  namanya cuti
alasan penting, sehingga akan diketahui oleh atasan langsungnya
dan  ketika  selesai  menikah  yang  bersangkutan  wajib  melaporkan
pernikahannya, ketika akan bercerai wajib mendapat izin termasuk
ketika seorang pegawai yang sudah menikah tetapi ingin beristri lebih
dari satu, maka pegawai ini menurut PP No. 10/PP No. 45  terikat
aturan  sebelum  beristri  lebih  dari  satu  dalam  pasal  4  nya  wajib
mendapat  izin  terlebih  dahulu  dari  pejabat  pimpinan  tertinggi  di
instansinya dalam hal ini berarti harus mendapat izin dari Menteri
sebelum beristri dari satu;
-Bahwa PNS diharapkan menjadi teladan oleh atasan PP ini menjadi
teladan,  jadi  sebelum  dia  beristri,  dia  harus  mendapat  ijin  dari
Menteri,  Misalkan  prosesnya  sudah  terjadi,  beristri  yang  kedua
atasan  langsung/pejabat  dibawah  Menteri  dapat  laporan  dari  istri
pertama/seseorang yang merasa dirugikan atas perbuatan pegawai
ASN  berisri  lebih  dari  satu,  lalu  atas  laporan  tersebut  atasan
langsungnya langsung mengingat pasal 41 dari PP No.94 dimana
dinyatakan mereka terancam melakukan pelanggaran dari PP No.
10/PP No. 45 itu berpotensi akan mengurangi hukuman disiplin berat,
maka  atasan  langsung  harus  segera  melaporkan   secara  hirarki,
sehingga PPK/pejabat yang ditunjuk akan membentuk tim pemeriksa
dugaan pelanggaran disiplin terhadap PP No. 10/PP No. 45 tersebut;
-Bahwa pelanggaran disiplin itu tidak hapus kalau memang itu terjadi
misalkan  kondisi  seorang  yang  seharusnya  mendapakan  izin  dari
pejaba/menteri  tetapi  tidak  mendapatkan  izin,  kemudian  dalam
rangka mengjaga keutuhan rumah tangga, pihak yang melaporkan
kemudian berdamai,  ini  tidak menghilangkan  perkara  pelanggaran
disiplinnya,  jadi  kalau  atasan  langsung/pimpinan  instansi  telah
terlanjur mengetahui maka Erika pada PP No. 94, atasan langsung
yang membiarkan terjadinya pelanggaran disiplin itu dijatuhi hukuman

Kepaniteraan Mahkamah Agung Republik Indonesia berusaha untuk selalu mencantumkan informasi paling kini dan akurat sebagai bentuk komitmen Mahkamah Agung untuk pelayanan publik, transparansi dan akuntabilitas
pelaksanaan fungsi peradilan. Namun dalam hal-hal tertentu masih dimungkinkan terjadi permasalahan teknis terkait dengan akurasi dan keterkinian informasi yang kami sajikan, hal mana akan terus kami perbaiki dari waktu kewaktu.
Dalam hal Anda menemukan inakurasi informasi yang termuat pada situs ini atau informasi yang seharusnya ada, namun belum tersedia, maka harap segera hubungi Kepaniteraan Mahkamah Agung RI melalui :
disiplin  yang  lebih  berat  oleh  dari  atasan  langsung,
daluarsa/hapusnya  pelanggaran  terjadi  kalau  yang  bersangkutan
meninggal;
-Bahwa  pelanggaran  disiplin  ini  bukan  delik  aduan,  maka  atasan
langsung terikat kalau ada pembiaran terhadap pelanggaran disiplin,
kalau suatu saat diaudit, apabila datangnya dari atas maka atasan
langsung  bisa  dijattuhi  hukuman  disiplin  yang  lebih  berat  dari
seharusnya yang dijatuhi hukuman disiplin, jadi ada semacam buah
simalakama bagi atasan langsung, yang kedua memang pembuktian
pelanggaran  administrative  dari  sisi  hukum  acaranya  tidak  sama
dengan KUHAP, contoh seseorang tidak masuk kerja demi hukum,
demi keadilan yang bersangkutan sebaiknya mebuktikan bahwa tidak
bersalah, karena tidak masuk bukan merupakan perjanjian yang sah,
maka pegawai yang akan dijatuhi hukuaman disiplin harus dipanggil,
harus diperiksa, ketika tidak hadir pada pemanggilan pemeriksaan
pertama masih diberikan kesempaan pemanggilan yang kedua, tetapi
dalam  pembuktian  proses  penjatuhan  hukuman  disiplin  ini  ketika
atasan  langsung/tim  pemeriksa  dan  panggilan  yang  kedua,  yang
terperiksa  tidak  hadir,  maka  dipanggilan  yyang  kedua  ini  atasan
langsung/tim  pemeriksa  tetap  kalau  hukuman  disiplin  iu  bukan
kewenangan im pemeriksa tetap memuat LHP dan ketidakhadiran
yang diperiksa ini sama saja dianggap/periksa;
-Bahwa dalam administraif teguran salah satu jenis sanksi hukuman
disiplin  ringan  ini  bisa  dilalui  bagi  jenis  hukuman  disiplin  tertentu
misalkan ada atasan langsung tidak mengembangkan karir bawahan
akan dilihat dampaknya unit kerja atau tidak, kalau hanya berdampak
unit  kerja  ancaman  hukuman  disiplin  ringan,  akan  tetapi  apabila
dampaknya  pada  instansi  maka  hukuman  disiplin  sedang,  kalau
dampaknya kepada negera maka hukuman disiplin berat. Terhadap
pelanggaran disiplin lainnya ada pasal 41 PP No. 94 dimana ada
ancaman bagi mereka PNS ada yang melanggar PP No. 10/PP No.
45 kalau terbukti salah satu dapat dijatuhi hukuman berat, sehingga

Kepaniteraan Mahkamah Agung Republik Indonesia berusaha untuk selalu mencantumkan informasi paling kini dan akurat sebagai bentuk komitmen Mahkamah Agung untuk pelayanan publik, transparansi dan akuntabilitas
pelaksanaan fungsi peradilan. Namun dalam hal-hal tertentu masih dimungkinkan terjadi permasalahan teknis terkait dengan akurasi dan keterkinian informasi yang kami sajikan, hal mana akan terus kami perbaiki dari waktu kewaktu.
Dalam hal Anda menemukan inakurasi informasi yang termuat pada situs ini atau informasi yang seharusnya ada, namun belum tersedia, maka harap segera hubungi Kepaniteraan Mahkamah Agung RI melalui :
ini  tidak  turun  kebawah  menjadi  hukuman  disiplin  ringan,  tetapi
pejabat  yang  berwenang  menghukum  sudah  melalui  mekanisme
yang  ada,  kemudian  terbukti  pelanggaran  disiplinnya  maka  akan
dijatuhi  salah satu hukuman disiplin berat dari jenis-jenis hukuman
disiplin berat yang ada baik level 1, level 2 maupun level 3;
Bahwa Tergugat, telah mengajukan kesimpulannya pada persidangan
secara  elektronik  tanggal  23  April  2025,  sedangkan  Penggugat  tidak
mengajukan kesimpulan sampai batas waktu yang sudah ditetapkan. Untuk
mempersingkat  uraian  Putusan,  maka  isi  selengkapnya  dari  Kesimpulan
tersebut  sebagaimana  termuat  dalam  Berita  Acara  Persidangan  yang
merupakan bagian tidak terpisahkan dengan Putusan ini ;
Bahwa  dengan memperhatikan segala  sesuatu  yang  terjadi  dalam
persidangan  selama  pemeriksaan  perkara  ini  berlangsung  sebagaimana
telah tercatat dalam Berita Acara Pemeriksaan Persiapan dan Berita Acara
Persidangan dianggap telah termuat dan merupakan satu kesatuan dalam
perkara ini;
Bahwa akhirnya para pihak menyatakan tidak mengajukan sesuatu
lagi dalam perkara ini dan selanjutnya mohon putusan;
PERTIMBANGAN HUKUM
Menimbang,  bahwa  maksud  dan  tujuan  Gugatan  Penggugat  telah
diuraikan dalam duduk perkara di atas ;
Menimbang, bahwa yang menjadi objek sengketa dalam perkara ini
adalah :
1.Keputusan Menteri Pendidikan, Kebudayaan, Riset, dan Teknologi
Republik  Indonesia  Nomor  :  93731/RHS/M/08/2024,  tertanggal  4
Oktober  2024  Tentang  Pembebasan  Dari  Jabatannya  Menjadi
Jabatan Pelaksana selama 12 (dua belas) bulan, atas nama dr.
IVAN  ROVIAN  M.Kp,  untuk  selanjutnya  disebut  sebagai  objek
sengketa 1 (vide bukti P-1 = T-1) ;
2.Keputusan Menteri Pendidikan Tinggi, Sains dan Teknologi Republik
Indonesia No. 137561/RHS/M/08/2024 tanggal 25 November 2024.
tentang  Penguatan  Keputusan  Menteri  Pendidikan  Kebudayaan,

Kepaniteraan Mahkamah Agung Republik Indonesia berusaha untuk selalu mencantumkan informasi paling kini dan akurat sebagai bentuk komitmen Mahkamah Agung untuk pelayanan publik, transparansi dan akuntabilitas
pelaksanaan fungsi peradilan. Namun dalam hal-hal tertentu masih dimungkinkan terjadi permasalahan teknis terkait dengan akurasi dan keterkinian informasi yang kami sajikan, hal mana akan terus kami perbaiki dari waktu kewaktu.
Dalam hal Anda menemukan inakurasi informasi yang termuat pada situs ini atau informasi yang seharusnya ada, namun belum tersedia, maka harap segera hubungi Kepaniteraan Mahkamah Agung RI melalui :
Riset dan Teknologi Republik Indonesia Nomor : 93731/RHS/M/08/
2024,  tanggal  4  Oktober  2024  Tentang  Pembebasan  Dari
Jabatannya  Menjadi  Jabatan  Pelaksana  selama  12  (dua  belas)
bulan,  atas  nama  dr.  IVAN  ROVIAN  M.Kp.,  untuk  selanjutnya
disebut sebagai objek sengketa 2 ( vide bukti T-2) ;
Menimbang,  bahwa  Tergugat  telah  mengajukan  Jawaban  yang  di
dalamnya  memuat  Eksepsi  dan  jawaban  atas  pokok  perkara,  namun
demikian  Majelis  Hakim  akan  terlebih  dahulu  mempertimbangkan
keberadaan objek sengketa 1 dan objek sengketa 2 dalam perkara a quo ;
Menimbang,  bahwa  ketentuan  Pasal  1  angka  9  Undang-Undang
Nomor  51  Tahun  2009  tentang  Perubahan  Ketiga  Atas  Undang-Undang
Nomor 5 Tahun 1986 tentang Peradilan Tata Usaha Negara mengatur:
Keputusan Tata Usaha Negara adalah suatu penetapan tertulis yang
dikeluarkan oleh badan atau pejabat tata usaha negara yang berisi
tindakan  hukum  tata  usaha  negara  yang  berdasarkan  peraturan
perundang-undangan yang berlaku, yang bersifat konkret, individual,
dan final, yang menimbulkan akibat hukum bagi seseorang atau badan
hukum perdata;
Menimbang, bahwa berdasarkan ketentuan di atas, dapat disimpulkan
bahwa  suatu  keputusan  dapat  dikatakan  keputusan  tata  usaha  negara
apabila memenuhi unsur :
-Penetapan tertulis ;
-Dikeluarkan oleh badan atau pejabat tata usaha negara ;
-Berisi tindakan hukum ;
-Berdasarkan peraturan perundang-undangan yang berlaku ;
-Bersifat konkrit, individual, dan final ;
-Menimbulkan akibat hukum ;
Menimbang,  bahwa  dalam  Penjelasan  Pasal  1  angka  (3)  Undang
Undang  nomor  5  tahun  1986  tentang  Peradilan  Tata  Usaha  Negara
disebutkan  bersifat  final  artinya  sudah  definitif  dan  karenanya  dapat
menimbulkan akibat hukum;

Kepaniteraan Mahkamah Agung Republik Indonesia berusaha untuk selalu mencantumkan informasi paling kini dan akurat sebagai bentuk komitmen Mahkamah Agung untuk pelayanan publik, transparansi dan akuntabilitas
pelaksanaan fungsi peradilan. Namun dalam hal-hal tertentu masih dimungkinkan terjadi permasalahan teknis terkait dengan akurasi dan keterkinian informasi yang kami sajikan, hal mana akan terus kami perbaiki dari waktu kewaktu.
Dalam hal Anda menemukan inakurasi informasi yang termuat pada situs ini atau informasi yang seharusnya ada, namun belum tersedia, maka harap segera hubungi Kepaniteraan Mahkamah Agung RI melalui :
Menimbang, bahwa menurut pendapat Indroharto dalam buku Usaha
Memahami Undang-Undang Peradilan Tata Usaha Negara, Buku I halaman
173 dan 174, dalam praktek akan kita jumpai dua kelompok keputusan yang
tidak memiliki watak melahirkan akibat hukum secara definitif yaitu kelompok
keputusan yang memang belum menimbulkan akibat hukum dan keputusan-
keputusan  yang  tidak  dapat  dikatakan  sebagai  keputusan  yang  berdiri
sendiri.  Dapat  terjadi  memang  ada  penetapan  tertulis  kedua  yang
dikeluarkan  setelah  penetapan  tertulis  yang  definitif  sebelumnya.  Hal  ini
terjadi apabila Badan atau Jabatan TUN setelah mengeluarkan penetapan
tertulis yang pertama itu mengadakan peninjauan kembali dengan dasar-
dasar  pertimbangan  baru  terhadap  penetapan  tertulis  yang  sebelumnya
dikeluarkan tersebut. Pertimbangan kembali tersebut biasanya dapat dilihat
pada  penetapan  tertulis  yang  bersangkutan  karena  disitu  disebut  secara
jelas dengan menunjuk kepada keputusan tata usaha negara sebelumnya; 
Menimbang, bahwa dalam Pasal 6 ayat (1) dan ayat (2) Peraturan
Pemerintah Nomor 79 Tahun 2021 tentang Upaya Administratif dan Badan
Pertimbangan Aparatur Sipil Negara ditentukan sebagai berikut :
1)PPK  dapat  memperkuat,  memperingan,  memperberat,  mengubah,
mencabut, atau membatalkan keputusan yang diajukan Keberatan. 
2)Keputusan  penguatan,  peringanan,  pemberatan,  perubahan,
pencabutan, atau pembatalan sebagaimana dimaksud pada ayat (1)
ditetapkan dengan Keputusan PPK ;
Menimbang,  bahwa  setelah  mencermati  objek  sengketa  2  yaitu
Keputusan  Menteri  Pendidikan  Tinggi,  Sains  dan  Teknologi  Republik
Indonesia  Nomor  137561/RHS/M/08/2024  tanggal  25  November  2024
tentang Penguatan Keputusan Menteri Pendidikan Kebudayaan, Riset dan
Teknologi  Republik  Indonesia  Nomor  :  93731/RHS/M/08/2024,  tanggal  4
Oktober  2024  Tentang  Pembebasan  Dari  Jabatannya  Menjadi  Jabatan
Pelaksana selama 12 (dua belas) bulan, atas nama dr. IVAN ROVIAN M.Kp.
dapat diketahui dasar dikeluarkannya keputusan tersebut yaitu adanya surat
keberatan tanggal 16 Oktober 2024 yang diajukan oleh Penggugat ;

Kepaniteraan Mahkamah Agung Republik Indonesia berusaha untuk selalu mencantumkan informasi paling kini dan akurat sebagai bentuk komitmen Mahkamah Agung untuk pelayanan publik, transparansi dan akuntabilitas
pelaksanaan fungsi peradilan. Namun dalam hal-hal tertentu masih dimungkinkan terjadi permasalahan teknis terkait dengan akurasi dan keterkinian informasi yang kami sajikan, hal mana akan terus kami perbaiki dari waktu kewaktu.
Dalam hal Anda menemukan inakurasi informasi yang termuat pada situs ini atau informasi yang seharusnya ada, namun belum tersedia, maka harap segera hubungi Kepaniteraan Mahkamah Agung RI melalui :
Menimbang, bahwa apabila objek sengketa 2 dihubungkan dengan
ketentuan Pasal 6 ayat (1) dan ayat (2) Peraturan Pemerintah Nomor 79
Tahun 2021 tentang Upaya Administratif dan Badan Pertimbangan Aparatur
Sipil Negara, Majelis Hakim berpendapat objek sengketa 2 tidak bersifat final
karena tidak mengandung perubahan, pengurangan, maupun penambahan
hak dan kewajiban hukum baru, sehingga sifatnya sekadar pengulangan
atau penegasan administratif yang tidak memiliki akibat hukum baru kepada
Penggugat  melainkan  merupakan  keputusan  yang  diterbitkan  untuk
menguatkan  kembali  isi  objek  sengketa  1  sehubungan  dengan  adanya
keberatan yang diajukan Penggugat ;
Menimbang, bahwa berdasarkan pertimbangan di atas, Majelis Hakim
berpendapat  dalam  perkara  a  quo cukuplah  objek  sengketa  1  yang
didudukkan  sebagai  objek  sengketa  sedangkan  objek  sengketa  2  tidak
memenuhi salah satu unsur keputusan tata usaha negara yaitu bersifat final
dan menimbulkan akibat hukum ;
Menimbang,  bahwa  selanjutnya  oleh  karena  Tergugat  telah
mengajukan  eksepsi  maka  Majelis  Hakim  akan  mempertimbangkannya
sebagai berikut :
EKSEPSI
Menimbang,  Tergugat  mengajukan  eksepsi  yang  pada  pokoknya
sebagai berikut :
a.Eksepsi tentang Gugatan Penggugat Prematur;
b.Eksepsi tentang Gugatan Penggugat Tidak Jelas ( Obscuur Libel);
Menimbang, bahwa oleh karena Tergugat mengajukan eksepsi, maka
sebelum pertimbangan hukum atas pokok perkaranya, Majelis Hakim akan
mempertimbangkan terlebih dahulu eksepsi yang diajukan Tergugat sebagai
berikut ;
a. Eksepsi tentang Gugatan Penggugat Prematur ;
Menimbang, bahwa Tergugat mendalilkan yang pada pokoknya bahwa
Gugatan  yang  diajukan  Penggugat  masih  prematur,  karena  Penggugat
belum menempuh Upaya Administratif atas terbitnya objek sengketa 2;
Menimbang, bahwa Penggugat melalui Repliknya telah mengajukan

Kepaniteraan Mahkamah Agung Republik Indonesia berusaha untuk selalu mencantumkan informasi paling kini dan akurat sebagai bentuk komitmen Mahkamah Agung untuk pelayanan publik, transparansi dan akuntabilitas
pelaksanaan fungsi peradilan. Namun dalam hal-hal tertentu masih dimungkinkan terjadi permasalahan teknis terkait dengan akurasi dan keterkinian informasi yang kami sajikan, hal mana akan terus kami perbaiki dari waktu kewaktu.
Dalam hal Anda menemukan inakurasi informasi yang termuat pada situs ini atau informasi yang seharusnya ada, namun belum tersedia, maka harap segera hubungi Kepaniteraan Mahkamah Agung RI melalui :
bantahan dengan mendalilkan yang pada pokoknya bahwa pada 17 Oktober
2024, Penggugat telah melakukan Upaya Administratif Keberatan kepada
Tergugat  atas  objek  sengketa  1  yaitu  Keputusan  Menteri  Pendidikan
Kebudayaan,  Riset  dan  Teknologi  Republik  Indonesia  Nomor  :
93731/RHS/M/ 08/2024, tertanggal 4 Oktober 2024 Tentang Pembebasan
Dari Jabatannya Menjadi Jabatan Pelaksana selama 12 (dua belas) bulan,
atas nama dr. IVAN ROVIAN M.Kp., selanjutnya Penggugat  mendalilkan
belum  pernah  me ndapatkan  surat  sebagaimana  objek  sengketa  2  yaitu
Keputusan  Menteri  Pendidikan  Tinggi,  Sains  dan  Teknologi  Republik
Indonesia No. 137561/RHS/ M/08/2024 tanggal 25 November 2024. tentang
Penguatan Keputusan Menteri Pendidikan Kebudayaan, Riset dan Teknologi
Republik Indonesia Nomor : 93731/RHS/M/08/2024, tanggal 4 Oktober 2024
Tentang Pembebasan Dari Jabatannya Menjadi Jabatan Pelaksana selama
12 (dua belas) bulan,  atas  nama  dr.  IVAN  ROVIAN  M.Kp.,  dikarenakan
Penggugat baru mengetahui adanya objek sengketa 2 pada tahap sidang
pemeriksaan  persiapan  pada  Pengadilan  Tata  Usaha  Negara  Jakarta
tertanggal 09 Desember 2024, sehingga Gugatan Penggugat bukan suatu
gugatan prematur; 
Menimbang,  bahwa  terhadap  perbedaan  pendapat  sebagaimana
disebutkan  di  atas,  Majelis  Hakim  akan  mempertimbangkannya  sebagai
berikut;
Menimbang, bahwa ketentuan Pasal 48 Undang-Undang Nomor 5
Tahun 1986 Tentang Peradilan Tata Usaha Negara berbunyi:
(1)Dalam  hal  suatu  Badan  atau  pejabat  tata  usaha  negara  diberi
wewenang oleh atau berdasarkan peraturan perundang-undangan
untuk  menyelesaikan  secara  administratif  sengketa  Tata  Usaha
Negara tertentu, maka sengketa Tata Usaha Negara tersebut harus
diselesaikan melalui upaya administratif yang tersedia;
(2)Pengadilan  baru  berwenang  memeriksa,  memutus,  dan
menyelesaikan sengketa  Tata  Usaha  Negara  sebagaimana
dimaksud  dalam  ayat  (1)  jika  seluruh  Upaya  administratif  yang
bersangkutan telah digunakan;

Kepaniteraan Mahkamah Agung Republik Indonesia berusaha untuk selalu mencantumkan informasi paling kini dan akurat sebagai bentuk komitmen Mahkamah Agung untuk pelayanan publik, transparansi dan akuntabilitas
pelaksanaan fungsi peradilan. Namun dalam hal-hal tertentu masih dimungkinkan terjadi permasalahan teknis terkait dengan akurasi dan keterkinian informasi yang kami sajikan, hal mana akan terus kami perbaiki dari waktu kewaktu.
Dalam hal Anda menemukan inakurasi informasi yang termuat pada situs ini atau informasi yang seharusnya ada, namun belum tersedia, maka harap segera hubungi Kepaniteraan Mahkamah Agung RI melalui :
Menimbang, bahwa selaras dengan ketentuan di atas, Pasal 2 ayat
(1) dan Pasal 3 Peraturan Mahkamah Agung Republik Indonesia Nomor 6
Tahun  2018  Tentang  Pedoman  Penyelesaian  Sengketa  Administrasi
Pemerintahan Setelah  Menempuh Upaya  Administratif,  telah  memberikan
acuan hukum yang pada pokoknya menyatakan bahwa Upaya Administratif
wajib ditempuh terlebih dahulu sebelum pengajuan gugatan ke Pengadilan
Tata Usaha Negara ;
Menimbang, bahwa selanjutnya ketentuan Pasal 77 ayat (1) Undang-
Undang  Nomor  30  Tahun  2014  tentang  Administrasi  Pemerintahan  telah
mengatur bahwa suatu keputusan hanya dapat diajukan upaya administratif
keberatan  dalam  jangka  waktu  21  (dua  puluh  satu)  hari  kerja  sejak
diumumkannya keputusan tersebut oleh Badan/Pejabat Tata Usaha Negara.
Lebih lanjut dalam ketentuan Pasal 77 ayat (4) Undang-Undang Nomor 30
Tahun  2014  tentang  Administrasi  Pemerintahan  mengatur  bahwa  Badan/
Pejabat  Tata  Usaha  Negara  diberikan  kewenangan  untuk  menyelesaikan
upaya administratif keberatan dalam jangka waktu 10 (sepuluh) hari kerja;
Menimbang, bahwa dalam ketentuan Peraturan Pemerintah Nomor 79
Tahun 2021 tentang Upaya Administratif dan Badan Pertimbangan Aparatur
Sipil Negara, disebutkan sebagai berikut :
Pasal 2 
1)Pegawai  ASN  yang  tidak  puas  terhadap  Keputusan  PPK  atau
Keputusan Pejabat dapat mengajukan Upaya Administratif. 
2)Upaya Administratif sebagaimana dimaksud pada ayat (1) terdiri atas
Keberatan dan Banding Administratif.
Pasal 3
1)Pegawai ASN dapat mengajukan Keberatan atas :
a.Keputusan  PPK  selain  pemberhentian  sebagai  PNS  atau
selain pemutusan hubungan perjanjian kerja sebagai PPPK;
dan 
b.Keputusan Pejabat.
2)Keberatan  sebagaimana  dimaksud  pada  ayat  (1) huruf  a diajukan
kepada PPK.

Kepaniteraan Mahkamah Agung Republik Indonesia berusaha untuk selalu mencantumkan informasi paling kini dan akurat sebagai bentuk komitmen Mahkamah Agung untuk pelayanan publik, transparansi dan akuntabilitas
pelaksanaan fungsi peradilan. Namun dalam hal-hal tertentu masih dimungkinkan terjadi permasalahan teknis terkait dengan akurasi dan keterkinian informasi yang kami sajikan, hal mana akan terus kami perbaiki dari waktu kewaktu.
Dalam hal Anda menemukan inakurasi informasi yang termuat pada situs ini atau informasi yang seharusnya ada, namun belum tersedia, maka harap segera hubungi Kepaniteraan Mahkamah Agung RI melalui :
3)Keberatan  sebagaimana  dimaksud  pada  ayat  (1) huruf  b diajukan
kepada atasan Pejabat ;
Pasal 5 
1)PPK wajib mengambil keputusan atas Keberatan yang diajukan oleh
Pegawai ASN dalam jangka waktu 21 (dua puluh satu) hari kerja
terhitung mulai tanggal PPK menerima Keberatan. 
2)PPK dapat memanggil dan/atau meminta keterangan dari Pegawai
ASN yang mengajukan Keberatan dan/atau pihak lain, jika diperlukan.
3)Apabila dalam jangka waktu lebih dari 21 (dua puluh satu) hari kerja
PPK tidak mengambil keputusan, Pegawai ASN dapat mengajukan
upaya hukum kepada Pengadilan Tata Usaha Negara.
Menimbang, bahwa dari ketentuan hukum di atas dapat disimpulkan
bahwa  keputusan  Pejabat  Pembina  Kepegawaian  (PPK)  selain
pemberhentian sebagai PNS atau selain pemutusan hubungan perjanjian
kerja  sebagai  PPPK  dapat  diajukan  keberatan  ke  PPK  dan  keputusan
pejabat dapat diajukan keberatan kepada atasan Pejabat dan apabila dalam
jangka waktu lebih dari 21 (dua puluh satu) hari kerja PPK tidak mengambil
keputusan, pegawai dapat mengajukan upaya hukum melalui Pengadilan
Tata Usaha Negara;
Menimbang,  bahwa  berdasarkan  bukti-bukti  yang  diajukan  di
persidangan, diketahui bahwa objek sengketa 1 diterbitkan pada tanggal 4
Oktober  2025  dan  Penggugat  mengajukan  upaya  administratif  keberatan
terhadap objek sengketa melalui Surat tertanggal 16 Oktober 2024 perihal :
Bantahan  atas  Keputusan  Menteri  Pendidikan  Kebudayaan,  Riset  dan
Teknologi Republik Indonesia Nomor: 93731/RHS/M/08/2024, tertanggal 4
Oktober  2024  Tentang  Pembebasan  Dari  Jabatannya  Menjadi  Jabatan
Pelaksana selama 12 (dua belas) ( vide bukti P-2 = bukti T-23);
Menimbang,  bahwa  keberatan  yang  diajukan  Penggugat  tersebut
telah  ditanggapi  oleh  Tergugat  melalui  Keputusan  Menteri  Pendidikan,
Kebudayaan, Riset dan Teknologi Republik Indonesia Nomor 93731/RHS/
M/08/2024 tanggal 4 Okober 2024 tentang Pembebasan dari Jabatannya
menjadi Jabatan Pelaksana selama 12 (dua belas) bulan ( vide bukti T-3) dan

Kepaniteraan Mahkamah Agung Republik Indonesia berusaha untuk selalu mencantumkan informasi paling kini dan akurat sebagai bentuk komitmen Mahkamah Agung untuk pelayanan publik, transparansi dan akuntabilitas
pelaksanaan fungsi peradilan. Namun dalam hal-hal tertentu masih dimungkinkan terjadi permasalahan teknis terkait dengan akurasi dan keterkinian informasi yang kami sajikan, hal mana akan terus kami perbaiki dari waktu kewaktu.
Dalam hal Anda menemukan inakurasi informasi yang termuat pada situs ini atau informasi yang seharusnya ada, namun belum tersedia, maka harap segera hubungi Kepaniteraan Mahkamah Agung RI melalui :
gugatan diajukan ke Pengadilan Tata Usaha Negara Jakarta pada tanggal 20
November 2024;
Menimbang, bahwa selanjutnya terkait dalil eksepsi Tergugat yang
menyatakan  gugatan  yang  diajukan  Penggugat  masih  prematur  karena
Penggugat  belum  menempuh  upaya  administratif  atas  terbitnya  objek
sengketa 2, Majelis Hakim berpendapat oleh karena telah dipertimbangkan
bahwa  objek  sengketa  telah  dikeluarkan  dalam  perkara  ini  karena  tidak
memenuhi unsur final, maka eksepsi Tergugat tersebut menjadi tidak relevan
lagi untuk dipertimbangkan ;
Menimbang,  bahwa  berdasarkan  seluruh  pertimbangan  di  atas,
Majelis  Hakim  berpendapat  bahwa  Eksepsi  Tergugat  mengenai  Gugatan
Penggugat Prematur tidak beralasan menurut hukum dan oleh karenanya
harus dinyatakan tidak diterima ;
b. Eksepsi mengenai Gugatan Penggugat Tidak Jelas ( Obscuur Libel)
Menimbang,  bahwa  Tergugat  m endalilkan  yang  pada  pokoknya
bahwa terdapat redundansi dalam dalil-dalil yang disampaikan Penggugat,
selain itu Penggugat juga tidak jelas dalam menguraikan dasar hukum yang
dijadikan alasan pengajuan gugatan sehingga tidak mampu menjelaskan
adanya  korelasi  antara  Posita  dengan  Petitum  gugatan  yang  mem buat
gugatan a quo menjadi tidak jelas dan kabur;
Menimbang, bahwa tolak ukur untuk mengatakan suatu gugatan tidak
jelas  (obscuur libel) adalah merujuk ketentuan Pasal 56 ayat (1) Undang-
Undang Nomor 5 Tahun 1986 Tentang Peradilan Tata Usaha Negara yang
berbunyi: 
“Gugatan harus memuat:
a.nama,  kewarganegaraan,  tempat  tinggal,  dan  pekerjaan
penggugat, atau kuasanya;
b.nama jabatan dan tempat kedudukan tergugat;
c.dasar  gugatan  dan  hal  yang  diminta  untuk  diputuskan  oleh
Pengadilan”;
Menimbang,  bahwa  terhadap  gugatan  Penggugat  telah  dilakukan
perbaikan dalam hal syarat formal gugatan pada pemeriksaan persiapan,
dan hal mana gugatan tersebut berisi identitas para pihak, dasar gugatan

Kepaniteraan Mahkamah Agung Republik Indonesia berusaha untuk selalu mencantumkan informasi paling kini dan akurat sebagai bentuk komitmen Mahkamah Agung untuk pelayanan publik, transparansi dan akuntabilitas
pelaksanaan fungsi peradilan. Namun dalam hal-hal tertentu masih dimungkinkan terjadi permasalahan teknis terkait dengan akurasi dan keterkinian informasi yang kami sajikan, hal mana akan terus kami perbaiki dari waktu kewaktu.
Dalam hal Anda menemukan inakurasi informasi yang termuat pada situs ini atau informasi yang seharusnya ada, namun belum tersedia, maka harap segera hubungi Kepaniteraan Mahkamah Agung RI melalui :
dan  petitumnya  secara  jelas,  oleh  karenanya  gugatan  Penggugat  telah
memenuhi aspek formalitas gugatan, sedangkan mengenai dalil Tergugat
yang menyatakan Penggugat menggunakan dasar hukum dalam gugatannya
karena  masih  menggunakan  peraturan  perundang-undangan  yang  sudah
tidak berlaku, hal tersebut bukan merupakan substansial syarat formalitas
gugatan, sehingga Eksepsi Tergugat mengenai Gugatan Penggugat Tidak
Jelas (Obscuur Libel), haruslah dinyatakan tidak diterima;
Menimbang,  bahwa  oleh  karena  seluruh  eksepsi  yang  diajukan
Tergugat dinyatakan  tidak  diterima dan  juga  tidak  terdapat  bukti  yang
menunjukkan fakta hukum adanya formalitas Gugatan Penggugat yang tidak
terpenuhi,  maka  selanjutnya  Majelis  Hakim  akan  mempertimbangkan
mengenai pokok sengketanya , sebagai berikut:
POKOK PERKARA
Menimbang,  bahwa  di  dalam  gugatannya,  Penggugat  memohon
kepada Pengadilan untuk menyatakan batal atau tidak sah objek sengketa;
Menimbang, bahwa berdasarkan ketentuan Pasal 52 ayat (1) dan (2)
Undang-Undang  Republik  Indonesia  Nomor  30  Tahun  2014  tentang
Administrasi Pemerintahan dinyatakan bahwa:
(1) Syarat sahnya Keputusan meliputi:
      a. ditetapkan oleh pejabat yang berwenang;
      b. dibuat sesuai prosedur; dan;
      c. substansi yang sesuai dengan objek Keputusan; 
(2) Sahnya  Keputusan  sebagaimana  dimaksud  pada  ayat  (1)
didasarkan  pada  ketentuan  peraturan  perundang-undangan  dan
AUPB ;
Menimbang,  bahwa  oleh  karenanya  suatu  Keputusan  Tata  Usaha
Negara dinilai bertentangan dengan peraturan perundang-undangan yang
berlaku  apabila  keputusan  yang  bersangkutan  bertentangan  dengan
peraturan perundang-undangan yang bersifat prosedural, substansial atau
ditetapkan oleh pejabat yang tidak berwenang, dimana jika dari salah satu
aspek  tidak  terpenuhi  maka  sudah  cukup  beralasan  hukum  bagi  Majelis
Hakim untuk menyatakan batal atau tidak sah Keputusan Tata Usaha Negara
yang menjadi objek sengketa ;

Kepaniteraan Mahkamah Agung Republik Indonesia berusaha untuk selalu mencantumkan informasi paling kini dan akurat sebagai bentuk komitmen Mahkamah Agung untuk pelayanan publik, transparansi dan akuntabilitas
pelaksanaan fungsi peradilan. Namun dalam hal-hal tertentu masih dimungkinkan terjadi permasalahan teknis terkait dengan akurasi dan keterkinian informasi yang kami sajikan, hal mana akan terus kami perbaiki dari waktu kewaktu.
Dalam hal Anda menemukan inakurasi informasi yang termuat pada situs ini atau informasi yang seharusnya ada, namun belum tersedia, maka harap segera hubungi Kepaniteraan Mahkamah Agung RI melalui :
Menimbang, bahwa sebelum mempertimbangkan segi prosedur dan
substansi penerbitan objek sengketa 1, Majelis Hakim terlebih dahulu akan
mempertimbangkan aspek kewenangan Tergugat dalam menerbitkan objek
sengketa a quo :
Menimbang,  bahwa  salah  satu  prinsip  negara  hukum  adalah
wetmatigheid  van  bestuur  atau  pemerintahan  berdasarkan  peraturan
perundang-undangan,  oleh  karenanya  setiap  tindakan  hukum  pemerintah
harus  didasarkan  pada  kewenangan  yang  diberikan  oleh  peraturan
perundang-undangan yang berlaku ;
Menimbang, bahwa dalam Pasal 8 ayat (1) dan (2) Undang-Undang
Republik  Indonesia  Nomor  30  Tahun  2014  Tentang  Administrasi
Pemerintahan disebutkan bahwa:
1.Setiap  Keputusan  dan/atau  Tindakan  harus  ditetapkan  dan/atau
dilakukan  oleh  Badan  dan/atau  Pejabat  Pemerintahan  yang
berwenang;
2.Badan  dan/atau  Pejabat  Pemerintahan  dalam  menggunakan
Wewenang wajib berdasarkan:
  a. peraturan perundang-undangan, dan;
  b. AUPB; 
Menimbang,  bahwa  ketentuan  Pasal  1  angka  12  Undang-Undang
Nomor  51  Tahun  2009  tentang  Perubahan  Kedua  Atas  Undang-Undang
Nomor 5 Tahun 1986 tentang Peradilan Tata Usaha Negara, menyatakan
bahwa:
“Tergugat  adalah  Badan  atau  Pejabat  Tata  Usaha  Negara  yang
mengeluarkan keputusan berdasarkan wewenang yang ada padanya
atau yang dilimpahkan kepadanya yang digugat oleh orang atau badan
hukum perdata”;
Menimbang, bahwa objek sengketa ( vide bukti P-1 = bukti T-1) berupa
sanksi pembebasan dari jabatannya menjadi jabatan pelaksana selama 12
(dua  belas)  bulan  kepada  Penggugat  dapat  dikatagorikan  sebagai  jenis
hukuman disiplin berat sebagaimana dimaksud dalam ketentuan Pasal 8
ayat (4) huruf b Peraturan Pemerintah Nomor 94 Tahun 2021 tentang Disiplin
Pegawai Negeri Sipil;

Kepaniteraan Mahkamah Agung Republik Indonesia berusaha untuk selalu mencantumkan informasi paling kini dan akurat sebagai bentuk komitmen Mahkamah Agung untuk pelayanan publik, transparansi dan akuntabilitas
pelaksanaan fungsi peradilan. Namun dalam hal-hal tertentu masih dimungkinkan terjadi permasalahan teknis terkait dengan akurasi dan keterkinian informasi yang kami sajikan, hal mana akan terus kami perbaiki dari waktu kewaktu.
Dalam hal Anda menemukan inakurasi informasi yang termuat pada situs ini atau informasi yang seharusnya ada, namun belum tersedia, maka harap segera hubungi Kepaniteraan Mahkamah Agung RI melalui :
Menimbang, bahwa ketentuan Pasal 16 jo Pasal 18 ayat (2) huruf c
Peraturan  Pemerintah  Nomor  94  Tahun  2021  tentang  Disiplin  Pegawai
Negeri Sipil menyatakan bahwa pejabat yang berwenang untuk menetapkan
penjatuhan hukuman disiplin sebagaimana dimaksud dalam ketentuan Pasal
8 ayat (4) huruf b Peraturan Pemerintah Nomor 94 Tahun 2021 tentang
Disiplin Pegawai Negeri Sipil adalah Pejabat Pembina Kepegawaian;
Menimbang, bahwa dalam ketentuan Pasal 1 ayat (1) Undang-Undang
Nomor 20 Tahun 2023 tentang Aparatur Sipil Negara jo. ketentuan Pasal 1
ayat  (2)  Peraturan  Pemerintah  Nomor  94  Tahun  2021  tentang  Disiplin
Pegawai  Negeri  Sipil,  yang  dimaksud  dengan  Pejabat  Pembina
Kepegawaian adalah pejabat yang mempunyai kewenangan pengangkatan,
pemindahan,  dan  pemberhentian  Pegawai  Aparatur  Sipil  Negara  dan
pembinaan Manajemen Aparatur Sipil Negara di instansi pemerintah sesuai
dengan ketentuan peraturan perundang-undangan;
Menimbang,  bahwa  selanjutnya  dalam  ketentuan  Pasal  1  ayat  (3)
Peraturan Pemerintah Nomor 63 Tahun 2009  Tentang  Perubahan Atas
Peraturan  Pemerintah  Nomor  9  Tahun  2003  Tentang  Wewenang
Pengangkatan,  Pemindahan,  Dan  Pemberhentian  Pegawai  Negeri  Sipil,
menyatakan bahwa:
“Pejabat Pembina Kepegawaian Pusat adalah Menteri, Jaksa Agung,
Pimpinan Kesekretariatan Lembaga Kepresidenan, Kepala Kepolisian
Negara  Republik  Indonesia,  Pimpinan  Lembaga  Pemerintahan
Nonkementerian,  Kepala  Pelaksana  Harian  Badan  Koordinasi
Keamanan  Laut,  Kepala  Pusat  Pelaporan  dan  Analisis  Transaksi
Keuangan  serta  Pimpinan  Kesekretariatan  Lembaga  Negara  dan
Lembaga lainnya yang dipimpin oleh Pejabat Struktural eselon I dan
bukan  merupakan  bagian  dari  Kementerian  Negara/Lembaga
Pemerintah Nonkementerian”;
Menimbang,  bahwa  Penggugat  merupakan  Pegawai  Negeri  Sipil
dengan jabatan terakhir sebagai Kepala Bagian Umum Lembaga Layanan
Pendidikan Tinggi Wilayah VII berdasarkan salinan sah Keputusan Menteri
Pendidikan, Kebudayaan, Riset, dan Teknologi Republik Indonesia Nomor

Kepaniteraan Mahkamah Agung Republik Indonesia berusaha untuk selalu mencantumkan informasi paling kini dan akurat sebagai bentuk komitmen Mahkamah Agung untuk pelayanan publik, transparansi dan akuntabilitas
pelaksanaan fungsi peradilan. Namun dalam hal-hal tertentu masih dimungkinkan terjadi permasalahan teknis terkait dengan akurasi dan keterkinian informasi yang kami sajikan, hal mana akan terus kami perbaiki dari waktu kewaktu.
Dalam hal Anda menemukan inakurasi informasi yang termuat pada situs ini atau informasi yang seharusnya ada, namun belum tersedia, maka harap segera hubungi Kepaniteraan Mahkamah Agung RI melalui :
10958/S/07/2023 tertanggal 15 Februari 2023 ( vide bukti T-3);
Menimbang, bahwa selanjutnya berdasarkan ketentuan Pasal 11 ayat
(2)  Peraturan  Menteri  Pendidikan,  Kebudayaan,  Riset  dan  Teknologi
Republik Indonesia Nomor 35 Tahun 2021 Tentang Organisasi Dan Tata
Kerja Lembaga Layanan Pendidikan Tinggi, menyatakan bahwa:
“(2) Kepala bagian umum merupakan  jabatan administrator  atau
jabatan struktural eselon III.a. ”
Menimbang,  bahwa  berdasarkan  uraian  di  atas,  Penggugat  dapat
digolongkan  dalam  Pejabat  Administrator  dan  objek  sengketa  diketahui
ditandatangani  oleh  Tergugat  sehingga  penerbitan  objek  sengketa  yang
memberikan sanksi pembebasan dari jabatannya menjadi jabatan pelaksana
selama 12 (dua belas) bulan kepada Penggugat merupakan kewenangan
atribusi  Tergugat  sebagai  Pejabat  Pembina  Kepegawaian  Pusat
sebagaimana dimaksud dalam ketentuan Pasal 16 jo. Pasal 18 ayat (2) huruf
c Peraturan Pemerintah Nomor 94 Tahun 2021 tentang Disiplin Pegawai
Negeri Sipil;
Menimbang,  bahwa  oleh  karena  Tergugat  berwenang  menerbitkan
objek sengketa 1 maka selanjutnya Majelis Hakim akan mempertimbangkan
aspek prosedur dan substansi penerbitan objek sengketa a quo;
Menimbang, bahwa berdasarkan dalil-dalil dalam jawab-jinawab, serta
alat bukti dan keterangan saksi yang diajukan para pihak, diperoleh fakta
hukum sebagai berikut :
1.Bahwa  proses  pemeriksaan  terhadap  Penggugat  diawali  dengan
adanya pengaduan  yang  disampaikan oleh Tri Asih  Imro’ati,  dr.,
SpPD.K-GEH.FINASIM  melalui  Surat  Laporan  Perbuatan  Zinah
tertanggal  5  Agustus  2023  yang  disampaikan  kepada  Kepala
Lembaga Layanan Dikti Wilayah VII ( vide bukti T-3);
2.Bahwa  telah  dilakukan  pemeriksaan  pendahuluan  kepada
Penggugat (vide bukti T-4 dan T-5);
3.Bahwa telah diusulkan dan dilakukan pembentukan Tim Pemeriksa
Laporan Pelanggaran Disiplin atas nama dr. Ivan Rovian, M.KP, in
casu  Penggugat  sebagaimana  Keputusan  Menteri  Pendidikan,

Kepaniteraan Mahkamah Agung Republik Indonesia berusaha untuk selalu mencantumkan informasi paling kini dan akurat sebagai bentuk komitmen Mahkamah Agung untuk pelayanan publik, transparansi dan akuntabilitas
pelaksanaan fungsi peradilan. Namun dalam hal-hal tertentu masih dimungkinkan terjadi permasalahan teknis terkait dengan akurasi dan keterkinian informasi yang kami sajikan, hal mana akan terus kami perbaiki dari waktu kewaktu.
Dalam hal Anda menemukan inakurasi informasi yang termuat pada situs ini atau informasi yang seharusnya ada, namun belum tersedia, maka harap segera hubungi Kepaniteraan Mahkamah Agung RI melalui :
Kebudayaan,  Riset,  dan  Teknologi  Republik  Indonesia  Nomor  :
15695/RHS/M/08/2024 Tanggal 4 Maret 2024 tentang Pembentukan
Tim Pemeriksa (vide bukti T-8, T-9, dan T-10);
4.Bahwa Tim Pemeriksa melalui Surat Panggilan I tertanggal 15 Maret
2024 memanggil dr. Ivan Rovian, M.KP, in casu Penggugat, Tri Asih
Imro’ati, dr., SpPD.K-GEH.FINASIM, dan Katmini binti Katmin untuk
hadir  pada  tanggal  22  Maret  2024  sehubungan  dengan  dugaan
pelanggaran  Pasal  3  ayat  (1)  dan  Pasal  4  ayat  (1)  Peraturan
Pemerintah  Nomor  10  Tahun  1983  sebagaimana  telah  diubah
dengan  Peraturan  Pemerintah  Nomor  45  Tahun  1990  tentang
Perubahan  atas  Peraturan  Pemerintah  Nomor  10  Tahun  1983
tentang Izin Perkawinan dan Perceraian Bagi Pegawai Negeri Sipil
dan Pasal 3 huruf e dan Pasal 3 huruf  f Peraturan Pemerintah
Nomor 94 Tahun 2021 tentang Disiplin Pegawai Negeri Sipil ( vide
bukti T-11, T-12, T-13);
5.Bahwa telah dilaksanakan acara permintaan keterangan terhadap
Tri Asih Imro’ati, dr., SpPD.K-GEH.FINASIM sehubungan dengan
dugaan pelanggaran Pasal 3 ayat (1) dan Pasal 4 ayat (1) Peraturan
Pemerintah  Nomor  10  Tahun  1983  sebagaimana  telah  diubah
dengan  Peraturan  Pemerintah  Nomor  45  Tahun  1990  tentang
Perubahan  atas  Peraturan  Pemerintah  Nomor  10  Tahun  1983
tentang Izin Perkawinan dan Perceraian Bagi Pegawai Negeri Sipil
dan Pasal 3 huruf e dan Pasal 3 huruf  f Peraturan Pemerintah
Nomor  94  Tahun  2021  tentang  Disiplin  Pegawai  Negeri  Sipil
berdasarkan Berita Acara Pemeriksaan tertanggal 22 Maret 2024
(vide bukti T-17);
6.Bahwa  Tim  Pemeriksa  melalui  Surat  Panggilan  II  tertanggal  22
Maret 2024 memanggil dr. Ivan Rovian, M.KP,  in casu  Penggugat
dan  Katmini binti  Katmin untuk hadir  pada  tanggal  1 April  2024
sehubungan  dengan  dugaan  pelanggaran  Pasal  3  ayat  (1)  dan
Pasal  4  ayat  (1)  Peraturan   Pemerintah  Nomor  10  Tahun  1983
sebagaimana telah diubah dengan Peraturan Pemerintah Nomor 45

Kepaniteraan Mahkamah Agung Republik Indonesia berusaha untuk selalu mencantumkan informasi paling kini dan akurat sebagai bentuk komitmen Mahkamah Agung untuk pelayanan publik, transparansi dan akuntabilitas
pelaksanaan fungsi peradilan. Namun dalam hal-hal tertentu masih dimungkinkan terjadi permasalahan teknis terkait dengan akurasi dan keterkinian informasi yang kami sajikan, hal mana akan terus kami perbaiki dari waktu kewaktu.
Dalam hal Anda menemukan inakurasi informasi yang termuat pada situs ini atau informasi yang seharusnya ada, namun belum tersedia, maka harap segera hubungi Kepaniteraan Mahkamah Agung RI melalui :
Tahun 1990 tentang Perubahan atas Peraturan Pemerintah Nomor
10  Tahun  1983  tentang  Izin  Perkawinan  dan  Perceraian  Bagi
Pegawai  Negeri  Sipil  dan  Pasal  3  huruf  e  dan  Pasal  3  huruf  f
Peraturan  Pemerintah  Nomor  94  Tahun  2021  tentang  Disiplin
Pegawai Negeri Sipil ( vide bukti T-15, T-16);
7.Bahwa  telah  dilaksanakan  acara  pemeriksaan  terhadap  dr.  Ivan
Rovian,  M.KP,  in  casu  Penggugat  sehubungan  dengan  dugaan
pelanggaran  Pasal  3  ayat  (1)  dan  Pasal  4  ayat  (1)  Peraturan
Pemerintah  Nomor  10  Tahun  1983  sebagaimana  telah  diubah
dengan  Peraturan  Pemerintah  Nomor  45  Tahun  1990  tentang
Perubahan  atas  Peraturan  Pemerintah  Nomor  10  Tahun  1983
tentang Izin Perkawinan dan Perceraian Bagi Pegawai Negeri Sipil
dan Pasal 3 huruf e dan Pasal 3 huruf  f Peraturan Pemerintah
Nomor  94  Tahun  2021  tentang  Disiplin  Pegawai  Negeri  Sipil
berdasarkan Berita Acara Pemeriksaan tertanggal 1 April 2024 ( vide
bukti T-18);
8.Bahwa  berdasarkan  pemeriksaan  yang  telah  dilakukan,  Kepala
Lembaga Layanan Pendidikan Tinggi Wilayah VII sebagai atasan
langsung dr. Ivan Rovian,  M.KP,  in casu  Penggugat melaporkan
hasil pemeriksaan kepada Menteri Pendidikan, Kebudayaan, Riset,
dan Teknologi Republik Indonesia,  in casu  Tergugat tertanggal 13
Agustus  2024  yang  pada  intinya  menyatakan  bahwa  dr.  Ivan
Rovian,  M.KP,  in  casu  Penggugat  terbukti  melakukan  perbuatan
beristri  lebih  dari  satu  orang  dan  melakukan  perceraian  tanpa
memperoleh  izin  terlebih  dahulu  dari  Pejabat  yang  melanggar
ketentuan sebagai berikut:
-Pasal 3 huruf f Peraturan Pemerintah Nomor 94 Tahun 2021
tentang Disiplin Pegawai Negeri Sipil;
-Pasal 3 ayat (1) Peraturan Pemerintah Nomor 10 Tahun 1983
sebagaimana  telah  diubah  dengan  Peraturan  Pemerintah
Nomor  45  Tahun  1990  tentang  Perubahan  atas  Peraturan

Kepaniteraan Mahkamah Agung Republik Indonesia berusaha untuk selalu mencantumkan informasi paling kini dan akurat sebagai bentuk komitmen Mahkamah Agung untuk pelayanan publik, transparansi dan akuntabilitas
pelaksanaan fungsi peradilan. Namun dalam hal-hal tertentu masih dimungkinkan terjadi permasalahan teknis terkait dengan akurasi dan keterkinian informasi yang kami sajikan, hal mana akan terus kami perbaiki dari waktu kewaktu.
Dalam hal Anda menemukan inakurasi informasi yang termuat pada situs ini atau informasi yang seharusnya ada, namun belum tersedia, maka harap segera hubungi Kepaniteraan Mahkamah Agung RI melalui :
Pemerintah Nomor 10 Tahun 1983 tentang Izin Perkawinan
dan Perceraian Bagi Pegawai Negeri Sipil;
-Pasal 4 ayat (1) Peraturan Pemerintah Nomor 10 Tahun 1983
sebagaimana  telah  diubah  dengan  Peraturan  Pemerintah
Nomor  45  Tahun  1990  tentang  Perubahan  atas  Peraturan
Pemerintah Nomor 10 Tahun 1983 tentang Izin Perkawinan
dan Perceraian Bagi Pegawai Negeri Sipil;
-Pasal 41 Peraturan Pemerintah Nomor 94 Tahun 2021 tentang
Disiplin Pegawai Negeri Sipil yang terkait dengan ketentuuan
izin perkawinan dan perceraian PNS;
Sehingga direkomendasikan untuk dijatuhi hukuman disiplin tingkat
berat  berupa  pembebasan  dari  jabatannya  menjadi  pelaksana
selama 12 (dua belas) bulan ( vide bukti T-19);
9.Bahwa  menindaklanjuti  laporan  tersebut,  Sekretaris  Jenderal
Kementerian  Pendidikan,  Kebudayaan,  Riset,  dan  Teknologi
Republik  Indonesia  menyurati  Menteri  Kementerian  Pendidikan,
Kebudayaan, Riset, dan Teknologi Republik Indonesia melalui Surat
Nomor 92912/RHS/S/08/2024 tanggal 26 September 2024 perihal
usul  berupa  pembebasan  dari  jabatannya  menjadi  jabatan
pelaksana selama 12 (dua belas) bulan dr. Ivan Rovian, M.Kp. ( vide
bukti T-22);
10.Bahwa  kemudian  Tergugat  menerbitkan  Keputusan  Menteri
Pendidikan, Kebudayaan, Riset, dan Teknologi Republik Indonesia
Nomor : 93731/ RHS/M/08/2024, tertanggal 4 Oktober 2024 Tentang
Pembebasan Dari Jabatannya Menjadi Jabatan Pelaksana selama
12 (dua belas) bulan, atas nama dr. IVAN ROVIAN M.Kp. ( vide bukti
P-1=T-1);
11.Bahwa  Penggugat  melalui  kuasa  hukumnya  mengirimkan  surat
tertanggal  16  Oktober  2024  perihal  Bantahan  atas  Keputusan
Menteri  Pendidikan,  Kebudayaan,  Riset,  dan  Teknologi  Republik
Indonesia  Nomor  :  93731/RHS/M/08/2024,  tertanggal  4  Oktober
2024  Tentang  Pembebasan  Dari  Jabatannya  Menjadi  Jabatan

Kepaniteraan Mahkamah Agung Republik Indonesia berusaha untuk selalu mencantumkan informasi paling kini dan akurat sebagai bentuk komitmen Mahkamah Agung untuk pelayanan publik, transparansi dan akuntabilitas
pelaksanaan fungsi peradilan. Namun dalam hal-hal tertentu masih dimungkinkan terjadi permasalahan teknis terkait dengan akurasi dan keterkinian informasi yang kami sajikan, hal mana akan terus kami perbaiki dari waktu kewaktu.
Dalam hal Anda menemukan inakurasi informasi yang termuat pada situs ini atau informasi yang seharusnya ada, namun belum tersedia, maka harap segera hubungi Kepaniteraan Mahkamah Agung RI melalui :
Pelaksana selama 12 (dua belas) kepada Kementerian Pendidikan,
Kebudayaan, Riset, dan Teknologi Republik Indonesia ( vide bukti P-
2 = T-23);
12.Bahwa  kemudian  Tergugat  menerbitkan  Keputusan  Menteri
Pendidikan  Tinggi,  Sains  dan  Teknologi  Republik  Indonesia  No.
137561/RHS/M/08/2024,  tanggal  25  November  2024  tentang
Penguatan Keputusan Menteri Pendidikan Kebudayaan, Riset dan
Teknologi  Republik  Indonesia  Nomor  :  93731/RHS/M/08/2024,
tanggal  4  Oktober  2024  Tentang  Pembebasan  Dari  Jabatannya
Menjadi  Jabatan  Pelaksana  selama  12  (dua  belas)  bulan,  atas
nama dr. IVAN ROVIAN M.Kp. ( vide bukti T-2);
Menimbang,  bahwa  terkait  prosedur  penerbitan  objek  sengketa  1,
Majelis Hakim akan mempertimbangkannya sebagai berikut ;
Menimbang, bahwa objek sengketa a quo merupakan keputusan yang
memberikan  sanksi  pembebasan  dari  jabatannya  yang  semula  menjabat
Kepala Bagian Umum menjadi jabatan pelaksana selama 12 (dua belas)
bulan kepada Penggugat sehubungan dengan perbuatan Penggugat yang
melanggar  ketentuan  Pasal  4  ayat  (1)  dan  Pasal  3  ayat  (1)  Peraturan
Pemerintah  Nomor  10  Tahun  1983  tentang  sebagaimana  telah  diubah
dengan Peraturan Pemerintah Nomor 45 Tahun 1990 tentang Perubahan
atas Peraturan Pemerintah Nomor 10 Tahun 1983 tentang Izin Perkawinan
dan Perceraian Bagi Pegawai Negeri Sipil ( vide bukti P-1 = bukti T-1) ;
Menimbang,  bahwa  tata  cara  pemeriksaan,  penjatuhan,  dan
penyampaian keputusan hukuman disiplin berat diatur secara rinci dalam
Peraturan  Pemerintah  Nomor  94  Tahun  2021  tentang  Disiplin  Pegawai
Negeri Sipil, yaitu sebagai berikut:
Pasal 26 ayat (1) dan ayat (2):
(1)PNS yang diduga melakukan Pelanggaran Disiplin dipanggil secara
tertulis oleh atasan langsung untuk dilakukan pemeriksaan;
(2)Jarak  waktu  antara  tanggal  surat  panggilan  dengan  tanggal
pemeriksaan paling lambat 7 (tujuh) hari kerja;
Pasal 27:

Kepaniteraan Mahkamah Agung Republik Indonesia berusaha untuk selalu mencantumkan informasi paling kini dan akurat sebagai bentuk komitmen Mahkamah Agung untuk pelayanan publik, transparansi dan akuntabilitas
pelaksanaan fungsi peradilan. Namun dalam hal-hal tertentu masih dimungkinkan terjadi permasalahan teknis terkait dengan akurasi dan keterkinian informasi yang kami sajikan, hal mana akan terus kami perbaiki dari waktu kewaktu.
Dalam hal Anda menemukan inakurasi informasi yang termuat pada situs ini atau informasi yang seharusnya ada, namun belum tersedia, maka harap segera hubungi Kepaniteraan Mahkamah Agung RI melalui :
(1)Atasan langsung wajib memeriksa PNS yang diduga melakukan
Pelanggaran Disiplin sebelum PNS dijatuhi Hukuman Disiplin;
(2)Pemeriksaan  sebagaimana  dimaksud  pada  ayat  (1)  dilakukan
secara tertutup melalui tatap muka langsung maupun secara virtual
dan hasilnya dituangkan dalam bentuk berita acara pemeriksaan;
(3)Dalam hal hasil pemeriksaan sebagaimana dimaksud pada ayat (2)
menyatakan  kewenangan  menjatuhkan  Hukuman  Disiplin
merupakan kewenangan atasan langsung, maka atasan langsung
tersebut wajib menjatuhkan Hukuman Disiplin;
(4)Dalam hal sesuai hasil pemeriksaan sebagaimana dimaksud pada
ayat  (2)  menyatakan  kewenangan  penjatuhan  Hukuman  Disiplin
merupakan kewenangan pejabat yang lebih tinggi, maka atasan
langsung  wajib  melaporkan  berita  acara  pemeriksaan  dan  hasil
pemeriksaan secara hierarki;
Pasal 29 ayat (2) dan ayat (3):
(2)Pelanggaran  terhadap  kewajiban  dan/atau  larangan  dengan
Hukuman Disiplin berat sebagaimana dimaksud dalam Pasal 11
dan Pasal 14 dilakukan pemeriksaan oleh tim pemeriksa;
(3)Tim pemeriksa sebagaimana dimaksud pada ayat (1) dan ayat (2)
terdiri  dari  atasan  langsung,  unsur  pengawasan,  dan  unsur
kepegawaian;
Pasal 32 ayat (1):
(1)Berita acara pemeriksaan sebagaimana dimaksud dalam Pasal 27
ayat (2) harus ditandatangani oleh pejabat yang memeriksa dan
PNS yang diperiksa secara langsung maupun secara virtual;
Pasal 33 ayat (1):
(1)Berdasarkan  hasil  pemeriksaan  sebagaimana  dimaksud  dalam
Pasal  27  dan  Pasal  28  Pejabat  yang  Berwenang  Menghukum
menjatuhkan Hukuman Disiplin;
Menimbang,  bahwa  berdasarkan  fakta-fakta  hukum  yang  telah
dibuktikan di persidangan  dan  dikorelasikan dengan ketentuan  hukum di

Kepaniteraan Mahkamah Agung Republik Indonesia berusaha untuk selalu mencantumkan informasi paling kini dan akurat sebagai bentuk komitmen Mahkamah Agung untuk pelayanan publik, transparansi dan akuntabilitas
pelaksanaan fungsi peradilan. Namun dalam hal-hal tertentu masih dimungkinkan terjadi permasalahan teknis terkait dengan akurasi dan keterkinian informasi yang kami sajikan, hal mana akan terus kami perbaiki dari waktu kewaktu.
Dalam hal Anda menemukan inakurasi informasi yang termuat pada situs ini atau informasi yang seharusnya ada, namun belum tersedia, maka harap segera hubungi Kepaniteraan Mahkamah Agung RI melalui :
atas,  Majelis  Hakim  berpendapat  bahwa  sebelum  menerbitkan  objek
sengketa                a quo, Tergugat telah menempuh serangkaian prosedur
sebagaimana diatur  dalam Peraturan Pemerintah  Nomor  94 Tahun  2021
tentang Disiplin Pegawai Negeri Sipil dimulai dari adanya laporan dari istri
Penggugat (vide  bukti T-3) yang kemudian ditindaklanjuti oleh Kepala Biro
Sumber Daya Manusia dan Kepala Lembaga Layanan Pendidikan Tinggi
Wilayah VII (vide bukti T-4 dan T-5). Selanjutnya Tergugat telah membentuk
Tim Pemeriksa berdasarkan Keputusan Menteri Pendidikan, Kebudayaan,
Riset,  dan  Teknologi  Republik  Indonesia  Nomor  :  15695/RHS/M/08/2024
Tanggal 4 Maret 2024 tentang Pembentukan Tim Pemeriksa ( vide bukti T-8,
T-9, dan T-10) yang kemudian melakukan pemanggilan kepada Penggugat
(vide bukti T-11 dan T-15), melaksanakan pemeriksaan terhadap Penggugat
(vide  bukti  T-18),  serta  melaporkan  hasil  pemeriksaan  kepada  Menteri
Pendidikan, Kebudayaan, Riset, dan Teknologi Republik Indonesia, in casu
Tergugat (vide bukti T-19). Berdasarkan rangkaian proses tersebut, Tergugat
pada akhirnya menjatuhkan sanksi disiplin berat kepada Penggugat berupa
pembebasan  dari  jabatannya  menjadi  jabatan  pelaksana  karena  terbukti
melanggar  ketentuan   Pasal  4  ayat  (1)  dan  Pasal  3 ayat  (1)  Peraturan
Pemerintah  Nomor  10  Tahun  1983  sebagaimana  telah  diubah  dengan
Peraturan  Pemerintah  Nomor  45  Tahun  1990  tentang  Perubahan  atas
Peraturan Pemerintah Nomor 10 Tahun 1983 tentang Izin Perkawinan dan
Perceraian Bagi Pegawai Negeri Sipil ;
Menimbang, bahwa berdasarkan uraian pertimbangan di atas, Majelis
Hakim berpendapat penerbitan objek sengketa telah sesuai dengan prosedur
hukum yang berlaku ;
Menimbang,  bahwa  selanjutnya  Majelis  Hakim  akan
mempertimbangkan penerbitan objek sengketa dari segi substansi ; 
Menimbang,  bahwa  yang  menjadi  perbedaan  interpretasi  hukum
antara  Penggugat  dengan  Tergugat  adalah  mengenai  permasalahan
penjatuhan sanksi hukuman disiplin berat berupa pembebasan jabatannya
menjadi jabatan pelaksana selama 12 (dua belas) bulan kepada Penggugat
yang didasarkan pada ketentuan Pasal 4 ayat  (1) dan Pasal 3 ayat (1)

Kepaniteraan Mahkamah Agung Republik Indonesia berusaha untuk selalu mencantumkan informasi paling kini dan akurat sebagai bentuk komitmen Mahkamah Agung untuk pelayanan publik, transparansi dan akuntabilitas
pelaksanaan fungsi peradilan. Namun dalam hal-hal tertentu masih dimungkinkan terjadi permasalahan teknis terkait dengan akurasi dan keterkinian informasi yang kami sajikan, hal mana akan terus kami perbaiki dari waktu kewaktu.
Dalam hal Anda menemukan inakurasi informasi yang termuat pada situs ini atau informasi yang seharusnya ada, namun belum tersedia, maka harap segera hubungi Kepaniteraan Mahkamah Agung RI melalui :
Peraturan Pemerintah Nomor 10 Tahun 1983 tentang sebagaimana telah
diubah  dengan  Peraturan  Pemerintah  Nomor  45  Tahun  1990  tentang
Perubahan atas Peraturan Pemerintah Nomor 10 Tahun 1983 tentang Izin
Perkawinan dan Perceraian Bagi Pegawai Negeri Sipil, yang pada pokoknya
menyatakan Penggugat telah melakukan pelanggaran berat terhadap izin
perkawinan dan perceraian bagi Pegawai Negeri Sipil ( vide bukti P-1 = bukti
T-1);
Menimbang,  bahwa  setelah  mencermati  objek  sengketa  diketahui
bahwa terbitnya objek sengketa a quo didasarkan karena alasan Penggugat
telah melanggar ketentuan Pasal 4 ayat (1) dan Pasal 3 ayat (1) Peraturan
Pemerintah  Nomor  10  Tahun  1983  sebagaimana  telah  diubah  dengan
Peraturan  Pemerintah  Nomor  45  Tahun  1990  tentang  Perubahan  atas
Peraturan Pemerintah Nomor 10 Tahun 1983 tentang Izin Perkawinan dan
Perceraian Bagi Pegawai Negeri Sipil, yaitu :
Pasal 3 ayat (1):
(1)Pegawai  Negeri  Sipil  yang  akan  melakukan  perceraian  wajib
memperoleh izin atau surat keterangan lebih dahulu dari Pejabat;
Pasal 4 ayat (1):
(1)Pegawai Negeri Sipil pria yang akan beristri lebih dari seorang,
wajib memperoleh izin lebih dahulu dari Pejabat;
Menimbang,  bahwa  selanjutnya  ketentuan  Pasal  41  Peraturan
Pemerintah Nomor 94 Tahun 2021 tentang Disiplin Pegawai Negeri Sipil,
menyatakan sebagai berikut:
PNS  yang  melanggar  ketentuan  Peraturan  Pemerintah  Nomor  10
Tahun  1983 tentang  Izin Perkawinan dan Perceraian bagi Pegawai
Negeri Sipil (Lembaran Negara Republik Indonesia Tahun 1983 Nomor
13,  Tambahan  Lembaran  Negara  Republik  Indonesia  Nomor  3250)
sebagaimana telah diubah dengan Peraturan Pemerintah Nomor 45
Tahun 1990 tentang Perubahan atas Peraturan Pemerintah Nomor 10
Tahun  1983 tentang  Izin Perkawinan dan Perceraian bagi Pegawai
Negeri Sipil (Lembaran Negara Republik Indonesia Tahun 1990 Nomor
61,  Tambahan Lembaran  Negara Republik Indonesia Nomor 3424),

Kepaniteraan Mahkamah Agung Republik Indonesia berusaha untuk selalu mencantumkan informasi paling kini dan akurat sebagai bentuk komitmen Mahkamah Agung untuk pelayanan publik, transparansi dan akuntabilitas
pelaksanaan fungsi peradilan. Namun dalam hal-hal tertentu masih dimungkinkan terjadi permasalahan teknis terkait dengan akurasi dan keterkinian informasi yang kami sajikan, hal mana akan terus kami perbaiki dari waktu kewaktu.
Dalam hal Anda menemukan inakurasi informasi yang termuat pada situs ini atau informasi yang seharusnya ada, namun belum tersedia, maka harap segera hubungi Kepaniteraan Mahkamah Agung RI melalui :
dijatuhi salah satu jenis Hukuman Disiplin berat berdasarkan Peraturan
Pemerintah Ini;
Menimbang, bahwa ketentuan Pasal 8 ayat (4) Peraturan Pemerintah
Nomor 94 Tahun 2021 tentang Disiplin Pegawai Negeri Sipil menentukan
bahwa  jenis  hukuman  disiplin  berat  terdiri  atas:  (a)  penurunan  jabatan
setingkat lebiih rendah selama 12 (dua belas) bulan; (b) pembebasan dari
jabatannya menjadi jabatan pelaksana selama 12 (dua belas) bulan ; dan
(c)  pemberhentian  dengan  hormat  tidak  atas  permintaan  sendiri  sebagai
Pegawai Negeri Sipil;
Menimbang,  bahwa  penjatuhan  hukuman  disiplin  berat  kepada
Penggugat dilakukan berdasarkan pengaduan yang disampaikan oleh Tri
Asih  Imro’ati,  dr.,  SpPD.K-GEH.FINASIM  (istri  Penggugat)  melalui  Surat
Laporan  Perbuatan  Zinah  tertanggal  5  Agustus  2023  yang  disampaikan
kepada Kepala Lembaga Layanan Dikti Wilayah VII ( vide  bukti T-3), yang
kemudian  ditindaklanjuti  oleh  atasan  Penggugat  melalui  pemeriksaan
pendahuluan (vide bukti T-5);
Menimbang,  bahwa  laporan  tersebut  menjadi  dasar  dilakukannya
pemeriksaan kepada Penggugat oleh Tim Pemeriksa yang dibentuk oleh
Tergugat sebagaimana Keputusan Menteri Pendidikan, Kebudayaan, Riset,
dan Teknologi Republik Indonesia Nomor : 15695/RHS/M/08/2024 Tanggal 4
Maret 2024 tentang Pembentukan Tim Pemeriksa ( vide  bukti T-10), yang
kemudian dilakukan pemeriksaan terhadap Penggugat sebagaimana Berita
Acara  Pemeriksaan  tertanggal  1  April  2024  ( vide  bukti  T-18),  sehingga
direkomendasikan  untuk  dijatuhi  hukuman  disiplin  tingkat  berat  berupa
pembebasan dari jabatannya menjadi jabatan pelaksana selama 12 (dua
belas) bulan (vide bukti T-19);
Menimbang, bahwa oleh karena penjatuhan hukuman didasarkan atas
pelanggaran Pasal 4 ayat (1) dan Pasal 3 ayat (1) Peraturan Pemerintah
Nomor 10 Tahun 1983 tentang sebagaimana telah diubah dengan Peraturan
Pemerintah  Nomor  45  Tahun  1990  tentang  Perubahan  atas  Peraturan
Pemerintah Nomor 10 Tahun 1983 tentang Izin Perkawinan dan Perceraian
Bagi Pegawai Negeri Sipil, maka yang harus dibuktikan secara substansi
adalah :

Kepaniteraan Mahkamah Agung Republik Indonesia berusaha untuk selalu mencantumkan informasi paling kini dan akurat sebagai bentuk komitmen Mahkamah Agung untuk pelayanan publik, transparansi dan akuntabilitas
pelaksanaan fungsi peradilan. Namun dalam hal-hal tertentu masih dimungkinkan terjadi permasalahan teknis terkait dengan akurasi dan keterkinian informasi yang kami sajikan, hal mana akan terus kami perbaiki dari waktu kewaktu.
Dalam hal Anda menemukan inakurasi informasi yang termuat pada situs ini atau informasi yang seharusnya ada, namun belum tersedia, maka harap segera hubungi Kepaniteraan Mahkamah Agung RI melalui :
1.Apakah benar Penggugat sebagai Pegawai Negeri Sipil telah melakukan
perceraian  dan  telah  memperoleh  izin  atau  surat  keterangan  lebih
dahulu dari Pejabat;
2.Apakah  Penggugat  telah  beristri  lebih  dari  seorang  dan  telah
memperoleh izin lebih dahulu dari Pejabat;
Menimbang, bahwa dari bukti T-3 dan bukti T-17 diketahui bahwa istri
Penggugat (Tri Asih Imro’ati) telah membuat laporan perbuatan zinah yang
dilakukan oleh Penggugat dengan Katmini bin Katmin disertai dengan bukti
chat dan beberapa bukti lainnya ; 
Menimbang,  bahwa  Penggugat  dan  istrinya  selaku  pelapor  telah
diperiksa  oleh  Tim  Pemeriksa  yang  dibentuk  oleh  Tergugat  sedangkan
Katmini binti Katmin tidak hadir dalam pemeriksaan meskipun telah 2 (dua)
kali  dipanggil  oleh  Tim  Pemeriksa.  Bahwa  dalam  pemeriksaan  tersebut
Penggugat tidak mengakui telah melakukan pernikahan siri dengan Katmini
binti Katmin (vide bukti T-13, T-16, dan T-18 ) ;
Menimbang, bahwa selama proses persidangan Tergugat tidak dapat
menunjukkan alat bukti lainnya yang dapat meyakinkan Majelis Hakim bahwa
Penggugat  benar  telah  melakukan  pernikahan  kedua/beristri  lebih  dari
seorang dan telah melakukan perceraian tanpa memperoleh izin atau surat
keterangan lebih dahulu dari Pejabat;
Menimbang, bahwa berdasarkan uraian pertimbangan di atas, Majelis
Hakim berpendapat unsur pelanggaran yang dituduhkan kepada Penggugat
belum  terbukti  secara  sah  dan  meyakinkan.  Bahwa  penerapan  sanksi
administratif  yang  tidak  didukung  oleh  bukti  yang  sah  dan  meyakinkan
berpotensi menimbulkan ketidakadilan, baik bagi Penggugat maupun pihak-
pihak yang terkait lainnya, termasuk istri sah yang juga berhak mendapatkan
perlindungan hukum yang sesuai dengan peraturan perundang-undangan
dan prinsip kepastian hukum serta kehati-hatian ;
Menimbang, bahwa prinsip kehati-hatian ( prudence) dan asas  due
process of law menghendaki agar setiap keputusan tata usaha negara yang
berdampak pada hak dan status seseorang harus didasarkan pada proses
pembuktian yang cermat, menyeluruh, dan adil;

Kepaniteraan Mahkamah Agung Republik Indonesia berusaha untuk selalu mencantumkan informasi paling kini dan akurat sebagai bentuk komitmen Mahkamah Agung untuk pelayanan publik, transparansi dan akuntabilitas
pelaksanaan fungsi peradilan. Namun dalam hal-hal tertentu masih dimungkinkan terjadi permasalahan teknis terkait dengan akurasi dan keterkinian informasi yang kami sajikan, hal mana akan terus kami perbaiki dari waktu kewaktu.
Dalam hal Anda menemukan inakurasi informasi yang termuat pada situs ini atau informasi yang seharusnya ada, namun belum tersedia, maka harap segera hubungi Kepaniteraan Mahkamah Agung RI melalui :
Menimbang, bahwa berdasarkan uraian pertimbangan di atas, Majelis
Hakim berpendapat penerbitan objek sengketa 1 secara substansi terdapat
cacat yuridis karena bertentangan dengan ketentuan Pasal 4 ayat (1) dan
Pasal  3  ayat  (1)  Peraturan  Pemerintah  Nomor  10  Tahun  1983  tentang
sebagaimana telah diubah dengan Peraturan Pemerintah Nomor 45 Tahun
1990 tentang Perubahan atas Peraturan Pemerintah Nomor 10 Tahun 1983
tentang Izin Perkawinan dan Perceraian Bagi Pegawai Negeri Sipil;
Menimbang, bahwa seperti telah dipertimbangkan di atas bahwa objek
sengketa 2 tidak dapat dikatagorikan sebagai keputusan tata usaha negara
karena tidak bersifat final sehingga tidak dipertimbangkan lebih lanjut dan
oleh karena terdapat cacat yuridis dalam penerbitan objek sengketa 1 berupa
Keputusan Menteri Pendidikan, Kebudayaan, Riset, dan Teknologi Republik
Indonesia  Nomor  :  93731/RHS/M/08/2024,  tertanggal  4  Oktober  2024
Tentang Pembebasan Dari Jabatannya Menjadi Jabatan Pelaksana selama
12 (dua  belas) bulan, atas  nama dr.  IVAN ROVIAN  M.Kp.,  maka  cukup
beralasan hukum untuk mengabulkan gugatan Penggugat untuk sebagian;
Menimbang, bahwa oleh karena gugatan Penggugat dikabulkan untuk
sebagian,  maka  Tergugat  diwajibkan  untuk  mencabut  Keputusan  Menteri
Pendidikan, Kebudayaan, Riset, dan Teknologi Republik Indonesia Nomor :
93731/RHS/M/08/2024,  tertanggal  4  Oktober  2024  Tentang  Pembebasan
Dari Jabatannya Menjadi Jabatan Pelaksana selama 12 (dua belas) bulan,
atas  nama  dr.  IVAN  ROVIAN  M.Kp.  dan  merehabilitasi  hak-hak  atau
kedudukan hukum Penggugat sebagaimana semula atau yang setara;
Menimbang,  bahwa  terkait  dengan  permohonan  penundaan  objek
sengketa  a  quo  sebagaimana  dimohonkan  oleh  Penggugat  dalam
gugatannya, Majelis Hakim berpendapat tidak terdapat keadaan yang sangat
mendesak  yang mengakibatkan kepentingan  Penggugat  sangat dirugikan
jika  keputusan  tata  usaha  negara  objek  sengketa  tetap  dilaksanakan
sebagaimana ketentuan Pasal 67 ayat (4) huruf a Undang-Undang Nomor 5
Tahun 1986 Tentang Peradilan Tata Usaha Negara, sehingga permohonan
penundaan  pelaksanaan  objek  sengketa  dari  Penggugat  haruslah
dinyatakan ditolak;

Kepaniteraan Mahkamah Agung Republik Indonesia berusaha untuk selalu mencantumkan informasi paling kini dan akurat sebagai bentuk komitmen Mahkamah Agung untuk pelayanan publik, transparansi dan akuntabilitas
pelaksanaan fungsi peradilan. Namun dalam hal-hal tertentu masih dimungkinkan terjadi permasalahan teknis terkait dengan akurasi dan keterkinian informasi yang kami sajikan, hal mana akan terus kami perbaiki dari waktu kewaktu.
Dalam hal Anda menemukan inakurasi informasi yang termuat pada situs ini atau informasi yang seharusnya ada, namun belum tersedia, maka harap segera hubungi Kepaniteraan Mahkamah Agung RI melalui :
Menimbang,  bahwa  sesuai  ketentuan  Pasal  110  dan  Pasal  112
Undang-Undang  Nomor  5  Tahun  1986  Tentang  Peradilan  Tata  Usaha
Negara, Tergugat sebagai pihak yang kalah dihukum untuk membayar biaya
perkara sejumlah yang tercantum dalam Amar Putusan ini ;
Menimbang,  bahwa  dalam  mempertimbangkan  bukti-bukti  yang
diajukan  pihak-pihak  yang  berperkara,  sampai  menjatuhkan  Putusan  ini,
Pengadilan mempedomani ketentuan Pasal 100 dan Pasal 107 Undang-
Undang Nomor 5 Tahun 1986 Tentang Peradilan Tata Usaha Negara, dan
setelah memper-timbangkan seluruh bukti yang diajukan Para Pihak yang
berperkara, hanya bukti-bukti yang relevan dengan esensi permasalahan
hukum antara Para Pihak yang dijadikan dasar dalam memutus perkara  a
quo, sedangkan terhadap bukti-bukti yang selebihnya dipertimbangkan tidak
dijadikan  dasar dalam memutus perkara  ini, tetapi tetap  terlampir  dalam
berkas perkara yang merupakan bagian tidak terpisahkan dengan Putusan
ini;
Menimbang,  bahwa  berdasarkan  ketentuan  Pasal  26  Peraturan
Mahkamah  Agung  Republik  Indonesia  Nomor  7  Tahun  2022  tentang
Perubahan Peraturan Mahkamah Agung Republik Indonesia Nomor 1 Tahun
2019 tentang Administrasi Perkara Dan Persidangan di Peradilan Secara
Elektronik dengan diucapkannya Putusan secara elektronik, maka secara
hukum telah dilaksanakan penyampaian Salinan Putusan Elektronik kepada
Para Pihak melalui Sistem Informasi Pengadilan dan secara hukum dianggap
telah dihadiri oleh Para Pihak dan dilakukan sidang terbuka untuk umum;
Mengingat, Undang-Undang Nomor 5 Tahun 1986 Tentang Peradilan
Tata Usaha Negara  junctis Undang-Undang Nomor 9 Tahun 2004 Tentang
Perubahan Atas Undang-Undang Nomor 5 Tahun 1986 Tentang Peradilan
Tata  Usaha  Negara,  Undang-Undang  Nomor  51  Tahun  2009  Tentang
Perubahan  Kedua  Atas  Undang-Undang  Nomor  5  Tahun  1986  Tentang
Peradilan Tata Usaha Negara, dan peraturan perundang-undangan lainnya
yang berkaitan dengan sengketa ini;
MENGADILI: 

Kepaniteraan Mahkamah Agung Republik Indonesia berusaha untuk selalu mencantumkan informasi paling kini dan akurat sebagai bentuk komitmen Mahkamah Agung untuk pelayanan publik, transparansi dan akuntabilitas
pelaksanaan fungsi peradilan. Namun dalam hal-hal tertentu masih dimungkinkan terjadi permasalahan teknis terkait dengan akurasi dan keterkinian informasi yang kami sajikan, hal mana akan terus kami perbaiki dari waktu kewaktu.
Dalam hal Anda menemukan inakurasi informasi yang termuat pada situs ini atau informasi yang seharusnya ada, namun belum tersedia, maka harap segera hubungi Kepaniteraan Mahkamah Agung RI melalui :
## I. Penundaan:
Menolak permohonan penundaan pelaksanaan objek sengketa yang
diajukan Penggugat ;
## II. Eksepsi:
-Menyatakan Eksepsi Tergugat tidak diterima;
## III. Pokok Perkara:
1.Mengabulkan Gugatan Penggugat untuk sebagian;
2.Menyatakan  batal  Keputusan  Menteri  Pendidikan,  Kebudayaan,
Riset, dan Teknologi Republik Indonesia Nomor : 93731/RHS/M/08/
2024,  tanggal  4  Oktober  2024,  Tentang  Pembebasan  Dari
Jabatannya  Menjadi  Jabatan  Pelaksana  selama  12  (dua  belas)
bulan, atas nama dr. IVAN ROVIAN, M.Kp. ;
3.Mewajibkan  Tergugat  untuk  mencabut  Keputusan  Menteri
Pendidikan, Kebudayaan, Riset, dan Teknologi Republik Indonesia
Nomor : 93731/RHS/M/08/ 2024, tanggal 4 Oktober 2024, Tentang
Pembebasan Dari Jabatannya Menjadi Jabatan Pelaksana selama
12 (dua belas) bulan, atas nama dr. IVAN ROVIAN, M.Kp.  ;  
4.Mewajibkan Tergugat untuk merehabilitasi hak-hak atau kedudukan
hukum Penggugat sebagaimana semula atau yang setara;
5.Menolak gugatan Penggugat untuk selebihnya ;
6.Menghukum  Tergugat  untuk  membayar  biaya  perkara  sejumlah
Rp299.000,- (Dua ratus sembilan puluh sembilan ribu rupiah) ;
Demikian  diputus kan  dalam  musyawarah  Majelis  Hakim  Pengadilan
Tata Usaha Negara Jakarta pada hari Jumat, tanggal 2 Mei 2025, oleh Kami
MOHAMMAD  HERRY INDRAWAN  P.,  S.Sos.,  S.H.,  M.H.,  selaku  Hakim
Ketua  Majelis,  LUCYA  PERMATA  SARI,  S.H.,  M.Hum.  dan  FEBRINA
PERMADI,  S.H.,  M.H.,  masing-masing  selaku  Hakim  Anggota.  Putusan
tersebut  diucapkan  dalam  sidang  terbuka  untuk  umum  secara  elektronik
dengan disampaikan kepada Para Pihak dan sekaligus dipublikasikan untuk
umum melalui Sisitem Informasi Pengadilan, pada hari Rabu, tanggal 7 Mei
2025 oleh Majelis Hakim tersebut di atas, dengan dibantu oleh YULIANTI,
S.H.,  M.H.  sebagai  Panitera  Pengganti  Pengadilan  Tata  Usaha  Negara

Kepaniteraan Mahkamah Agung Republik Indonesia berusaha untuk selalu mencantumkan informasi paling kini dan akurat sebagai bentuk komitmen Mahkamah Agung untuk pelayanan publik, transparansi dan akuntabilitas
pelaksanaan fungsi peradilan. Namun dalam hal-hal tertentu masih dimungkinkan terjadi permasalahan teknis terkait dengan akurasi dan keterkinian informasi yang kami sajikan, hal mana akan terus kami perbaiki dari waktu kewaktu.
Dalam hal Anda menemukan inakurasi informasi yang termuat pada situs ini atau informasi yang seharusnya ada, namun belum tersedia, maka harap segera hubungi Kepaniteraan Mahkamah Agung RI melalui :
Jakarta, dengan dihadiri secara elektronik di Sistim Informasi Pengadilan
oleh Kuasa Hukum Penggugat dan Kuasa Tergugat ;
Hakim-Hakim Anggota
ttd
Lucya Permata Sari, S.H., M.HumHakim Ketua Majelis
ttd
M. Herry Indrawan P., S.Sos., S.H., M.H.
ttd
Febrina Permadi, S.H., M.H.
Panitera Pengganti
ttd
Yulianti, S.H., M.H.

Kepaniteraan Mahkamah Agung Republik Indonesia berusaha untuk selalu mencantumkan informasi paling kini dan akurat sebagai bentuk komitmen Mahkamah Agung untuk pelayanan publik, transparansi dan akuntabilitas
pelaksanaan fungsi peradilan. Namun dalam hal-hal tertentu masih dimungkinkan terjadi permasalahan teknis terkait dengan akurasi dan keterkinian informasi yang kami sajikan, hal mana akan terus kami perbaiki dari waktu kewaktu.
Dalam hal Anda menemukan inakurasi informasi yang termuat pada situs ini atau informasi yang seharusnya ada, namun belum tersedia, maka harap segera hubungi Kepaniteraan Mahkamah Agung RI melalui :
R      incian Biaya Perkara:  
-Pendaftaran : Rp    30.000,00
-ATK: Rp   145.000,00
-Panggilan-Panggilan : Rp    28.000,00
-Lain-lain (fotokopi) : Rp    76.000,00
-Meterai : Rp    10.000,00
-Redaksi                                            : Rp      10.000,00 +  
Jumlah : Rp  299.000,00
 (Dua ratus sembilan puluh sembilan ribu rupiah )

Kepaniteraan Mahkamah Agung Republik Indonesia berusaha untuk selalu mencantumkan informasi paling kini dan akurat sebagai bentuk komitmen Mahkamah Agung untuk pelayanan publik, transparansi dan akuntabilitas
pelaksanaan fungsi peradilan. Namun dalam hal-hal tertentu masih dimungkinkan terjadi permasalahan teknis terkait dengan akurasi dan keterkinian informasi yang kami sajikan, hal mana akan terus kami perbaiki dari waktu kewaktu.
Dalam hal Anda menemukan inakurasi informasi yang termuat pada situs ini atau informasi yang seharusnya ada, namun belum tersedia, maka harap segera hubungi Kepaniteraan Mahkamah Agung RI melalui :
