Direktori Putusan P U T U S A N
NOMOR: 116/G/2016 /PTUN.MKS.

“DEMI KEADILAN BERDASARKAN KETUHANAN YANG MAHA ESA”

Pengadilan Tata Usaha Negara Makassar yang memeriksa,
memutus, dan menyelesaikan Sengketa Tata Usaha Negara pada tingkat
pertama dengan acara biasa, telah menjatuhkan Putusan sebagai berikut
di bawah ini, dalam sengketa antara: -------------------------------------------------
RAHMANSYAH , S.Pd .; kewarganegaraan Indonesia ; tempat tinggal
di Jalan Pasar Lama , Rt. 001/RW. 003, Kelurahan
Segeri, Kecamatan Segeri, Kabupaten Pang kajene dan
Kepulauan; pekerjaan Pegawai Negeri Sipil; ------------------
berdasarkan Surat Kuasa Khusus , tanggal 27 Maret
2017, dalam hal ini diwakili Kuasa Hukumnya : -------- ------
HASANUDDIN RADJA, S.H.; kewarganegaraan Indo -
nesia; pekerjaan Advok at/Pengacara dan Konsultan
Hukum pada Kantor Advokad “Hasanuddin Radja, S .H.”
& Rekan; berkantor di Jalan Badak Utara Nomor 6 ,
Kelurahan Mamajang Luar, Kecamatan Mamajang, K ota
Makassar ;----------------------------------------------------- ----------
selanjutnya disebut PENGGUGAT ;----------------------- -------

MELAWAN

BUPATI PANGKAJENE DAN KEPULAUAN, tempat kedudukan di
Jalan Sultan Hasanuddin , Kabupaten Pangkajene dan
Kepulauan ;---------- ------------------- ------------------------------ --
berdasarkan Surat Kuasa Khusus Nomor : 183.14/04 /
HUKUM , tanggal 11 Januari 2017 , dalam hal ini diwakili
oleh Kuasanya bernama: -------------------------- ----------------
Direktori Putusan 1. DRS. H. EFFENDI KASMIN ; kewarganegaraan
Indonesia; pekerjaan Pegawai Negeri Sipil; jabatan
Plt. Sekretaris Daerah Kabupaten Pangkajene dan
Kepulauan; ------------- ---------------------- ---------------------
2. DRS . ANDI YATHRIB PARE ; kewarganegaraan
Indonesia; pekerjaan Pegawai Negeri Sipil; jabatan
Plt. Kepala Badan Kepegawaian Pendidikan dan
Pelatihan Kabupaten Pangkajene dan Kepulauan; -----
3. IRDAS , S.H ., M.SI .; kewarganegaraan Indonesia;
pekerjaan Pegawai Negeri Sipil; jabatan Kepala
Bagian Hukum dan Perundang -undangan ,
Sekreta riat Daerah Kabupaten Pangkajene dan
Kepulauan; --------------------------------------------------------
4. SAHARUDDIN GANI , S.H., M.H. ; kewarganegaraan
Indonesia; pekerjaan Pegawai Negeri Sipil;
jabatan Sekretaris Inspektorat Kabupaten
Pangkajene dan Kepulauan; ------------- --------------------
5. DRS. ANSHARULLAH ; kewarganegaraan Indonesia;
pekerjaan Pegawai Negeri Sipil; jabatan Inspektur
Pembantu Wilayah III Inspektorat Kabupaten
Pangkajene dan Kepulauan; ---------------------------------
6. RUSTAN ABU , S.SOS. kewarganegaraan Indonesia ;
pekerjaan Pegawai Negeri Sipil; jabatan Kepala
Bidang Pembinaan Kesejah teraan dan Pensiun
Badan Kepegawaian Pendidikan dan Pelatihan
Kabupaten Pangkajene dan Kepulauan ;------- -----------
7. NURUL HAQ, S.PI., M.SI. ; kewarganegaraan Indo-
nesia; pekerjaan Pegawai Negeri Sipil; jabatan
Kepala Bidan g Pendidikan Sekolah Dasar Dinas
Pendidikan Kabupaten Pangkajene dan Kepulauan; -
Direktori Putusan 8. ISRAWATI, S.H.; kewarganegaraan Indonesia; pe-
kerjaan Pegawai Negeri Sipil; jabatan Kepala Sub
Bagian Bantuan Hukum dan HAM , Bagian Hukum
Sekretaris Daerah Kabupaten Pangkajene dan
Kepulauan; ------------------------------------- -------------------
9. LUKI WAHYU MARTANTO , S.H.; kewarganegaraan
Indonesia; pekerjaan Pegawai Negeri Sipil; jabatan
Kepala Sub Bagian Tindak Lanjut Bagian Hukum
Sekretaris Daerah Kabupaten Pangkajene dan
Kepulauan; ------------------------------------------------ --------
10. SURIANI , S.H.; kewarganegaraan Indonesia; pe-
kerjaan Pegawai Negeri Sipil; jabatan Kepala Sub
Pembinaan Pegawai Badan Kepegawaian
Pendidikan dan Pelatihan Kabupaten Pangkajene
dan Kepulauan; ------------------------------------- -------------
semuanya memilih tempat kedudukan di Kantor Bupati
Pangkajene dan Kepulauan , Jalan Sultan Hasanuddin ;---
selanjutnya disebut TERGUGAT ;------------------------------ --

Pengadilan Tata Usaha Negara Makassar tersebut: --------- ---------------
Telah membaca : -------------------------------------------- -------------------------
1. Penetapan Ketua Pengadilan Tata Usaha Negara Makassar Nomor:
116/PEN-DIS/2016/PTUN.MKS , tanggal 11 Januari 2017 , ten tang
Dismissal ;----------------------------------------------------------------------- --------
2. Putusan Pengadilan Tata Usaha Negara Makassar Nomor:
116/PLW/2016/PTUN.MKS, tanggal 20 Maret 2017; ------------------------
3. Penetapan Plh. Ketua Pengadilan Tata Usaha Negara Makassar
Nomor: 116/PEN/20 16/PTUN.MKS , tanggal 23 Maret 2017 , tentang
Penunjukan Majelis Hakim; --------------------------------------------------------
Direktori Putusan 4. Penetapan Hakim Ketua Majelis Pengadilan Tata Usaha Makassar
Nomor: 116/PEN-PP/2016/PTUN.MK S, tanggal 23 Maret 2017 ,
tentang Hari Pemeriksaan Persiapan; -------------------------------------------
5. Penetapan Hakim Ketua Majelis Pengadilan Tata Usaha Negara
Makassar Nomor: 116/PEN.HS/2016/PTUN.MK S, tanggal 13 April
2017 , tentang Hari Sidang Terbuka untuk Umum; ---------------------------
6. Berkas Perkara Nomor: 116/G/2016/PTUN.MK S beserta seluruh
lampiran yang terdapat di dalamnya; ------------------------------------------ --

TENTANG DUDUK SENGKETA

Menimbang, bahwa Penggugat dengan gugatannya, tanggal 27
Desember 2016, didaftarkan di Kepaniteraan Pengadilan Tata Usaha
Negara Maka ssar, dengan Register Nomor: 116/G/2016/PTUN.MKS.,
tanggal 30 Desember 2016 , diperbaiki terakhir pada tanggal 13 April 2017 ,
yang isinya menerangkan sebagai berikut; ------------------------- ---------------- --
Yang menjadi Objek Gugatan dalam perkara Tata Usaha Negara ini
adalah :----------------------------------------------------------------------------------
I. “Keputusan Bupati Pangkajene dan Kepulauan Nomor:
821.29/499/BKDD/2016, tanggal 03 Oktober 2016 , tentang
Mutasi dan Pemb erian Tugas Tambahan Bagi Guru Sebagai
Kepala Sekolah dan Pengawas Sekolah Dilingkungan
Pemerintah Kabupaten Pangkajene dan Kepulauan,” beserta
daftar lampiran Keputusan Bupati Kabupaten Pangkajene dan
Kepulauan Nomor: 821.29/499/BKDD/2016, tanggal 03 Okto ber
2016 , Tentang Mutasi dan Pemberian Tugas Tambahan Bagi
Guru Sebagai Kepal a Sekolah dan Pengawas Sekolah d i
Lingkungan Pemerintah Kabupaten Pangkajene dan Kepulauan,”
khususnya nomor urut 27, atas nama Rahmansyah ,
S.Pd./NIP.19680312 198803 1 008 ;------- ---------- -----------------------
Direktori Putusan II. Bahwa Keputusan Bupati Pangkajene dan Kepulauan Nomor:
821.29/499/BKDD/2016, tanggal 03 Oktober 2016 , tentang
Mutasi dan Pemberian Tugas Tambahan Bagi Guru Sebagai
Kepala Sekolah dan Pengawas sekolah di Lingkungan
Pemerint ah Kabupaten Pangkajene dan Kepulauan , oleh sebab
itu, gugatan sengketa Peradilan Tata Usaha Negara yang
diajukan masih dalam tenggang waktu untuk mengajukan
gugatan Peradilan Tata Usaha Negara sesuai ketentuan dalam
Pasal 55 Undang -Undang No. 5 tahun 198 6 jo. Undang -Undang
Nomor 9 tahun 2004 tentang Perubahan atas UU No. 5 tahun
1986 tentang Peradilan Tata Usaha Negara; ---------- ------------------
III. Bahwa dengan dikeluarkannya Keputusan Bupati Pangkajene
dan Kepulauan Nomor: 821.29/499/BKDD/2016, tanggal 03
Oktober 2016 , oleh Tergugat, kepentingan Penggugat sangat
dirugikan, selain pangkat dan g olongan Penggugat sangat tidak
sebanding sebagai staf UPTD Pendidikan, juga jarak tempat
tugas s angat jauh dari tempat tinggal P enggugat, sementara
tunjangan fungsi onal kh usus, serta tunjangan s ertifikasi yang
diperoleh dari perjuangan melelahkan melalui diklat beserta
ujian –ujiannya , sudah tidak ada lagi. Hal ini sangat tidak
mencerminkan azas pada P asal 2 huruf c, h, j, dan m Undang -
Undang Nomor 5 Tahun 2014; -------------------------------------- --------
IV. Adapun duduk pokok perkara dalam Gugatan Tata Usaha
Negara ini adalah sebagai berikut: ------------------------------------ -----
1. Bahwa Surat Keputusan Bupati Pangkajene dan Kepulauan
Nomor: 821.29/499/BKDD/2016, tanggal 03 Oktober 2016 ,
yang dikeluarkan oleh Tergugat semata -mata didasarkan
Direktori Putusan atas alasan yang tidak jelas dan bersifat s epihak tanpa
mempertimbangkan Azas -azas Pemerintahan yang B aik,
sebagaimana yang diatur dan ditentukan oleh Undang -
Undang RI Nomor 5 T ahun 2014 dalam paragraf 7 tentang
Mutasi, da lam P asal 73 ayat (2) yaitu : “Mutasi PNS dalam
satu instansi pusat atau i nstansi daerah sebagaimana
dimaksud pada ayat (1) dilakukan oleh pejabat Pembina
Kepegawaian ”. Dalam Pasal 73 ayat (7) yaitu : “Mutasi PNS
dilakukan dengan memperhatikan prinsip larangan konflik
kepentingan” ; ---------------------------------------------------- -----------
2. Bahwa dengan dikeluarkannya Surat Keputusan Bupati
Pangkajene dan Kepulauan Nomor: 821.29/499/BKDD/2016,
tanggal 03 Oktobe r 2016 , oleh Tergugat, kepentingan
Penggugat sangat dirugikan serta diperlakukan tidak adil dan
sewenang -wenang , karena T ergugat menggunakan
wewenang yang dimilikinya untuk tujuan yang berbeda dari
yang ditetapkan oleh peraturan perundang -undangan ;-------- -
3. Bahwa Penggugat sebagai PNS selama 29 tahun, saat ini
dengan Pangkat Pembina Tk.I, Golongan IV/b, memulai
kariernya sebagai PNS g uru SD dengan bekal ijazah SPG,
kemudian melanjutkan pendidikan D.II PG SD, dan S.1
Pendidikan (dengan gelar S.Pd.), serta p endidikan terakhir
S.2 (dengan gelar M.Pd.), dianggap c ukup berprestasi dan,
memiliki kompetensi dan kualifikasi, serta k inerja yang baik
dibidang Pendidikan, seharusnya mendapatkan apresiasi,
perha tian dan penghargaan dalam hal promosi j abatan .
Tetapi sebaliknya Tergugat malah memutasi Penggugat
Direktori Putusan dengan jabatan yang lebih rendah serta tidak relevan dengan
kompetensi dan kualifikasi yang dimiliki oleh Tergugat. Hal ini
sangat bertentangan d engan Undang -Undang RI Nomor 5
Tahun 2014 Paragraf 3 Pangkat dan J abatan Pasal 68 ayat
(1, 2, dan 4), yaitu: ------------------------------------------- -------------
Ayat (1) : “PNS diangkat dalam pangkat dan jabatan tertentu
pada Instansi Pemerintah”; --------------------------------- -------------
Ayat (2) : “Pengangkatan P NS dalam jabatan tertentu
sebagaimana dimaksud pada ayat (1) ditentukan
berdasarkan perbandingan objektif antara kompetensi,
kualifikasi, dan persyaratan yang dibutuhkan oleh jabatan
dengan kompetensi, kualifikasi, dan persyaratan yang dimiliki
oleh pegawa i”;------- -------------------------------------------------------
Ayat (4) : “PNS dapat berpindah antar dan antara Jabatan
Pimpinan Tinggi, Jabatan Administrasi, dan Jabatan
Fungsional di Instansi Pusat dan Instansi Daerah
berdasarkan kualifikasi, ko mpetensi, dan penilaian kinerja” ;---
4. Bahwa dengan melihat perjalanan dan pengembangan k arier
Penggugat, sejak diangkat CPNS sampai menjadi Pengawas
SD, mengawali kariernya sebagai guru SD dengan dasar
pendidikan SPG hingga meraih pendidikan S.2, dan d ari
pangkat Pengatur Muda, Golongan II/a , sampai saat ini
sudah berpangkat Pembina Tingkat I, Golongan IV/b, juga
banyak terlibat dalam mengurusi organisasi, kesemuanya itu
tidaklah dapat diraih tanpa kompetensi , kinerja yang baik,
dan i ntegritas yang tinggi, serta moralitas . Olehnya itu
tindakan yang dilakukan oleh Tergugat dengan memutasi
Direktori Putusan Penggugat dari j abatan Pengawas SD Kecamatan Segeri
Kab. Pangkep menjadi staf UPTD Pendidikan Kecamatan
Balocci Kab. Pangkep, sangat tidak sesuai dengan Undang -
Undan g RI Nomor 5 Tahun 2014, Paragraf 4 Pengembangan
Karier Pasal 69 ayat (1, 2, 3, dan 4) sebagai berikut: ------------
Ayat (1) : ”Pengembangan karier PNS dilakukan berdasar -
kan kualifikasi, kompetensi, pe nilaian kinerja, dan kebutuhan
instansi Pemerintah” ;---------------------------------- --------------------
Ayat (2) : “Pengembangan karier PNS sebagaimana
dimaksud pada ayat (1) dilakukan dengan mempertim -
bangkan integritas dan moralitas”; ----------------------------------- -
Ayat (3) : “Kompet ensi sebagaimana dimaksud ayat (1) huruf
a, b, dan c meliputi: ------------------------------------ ------------------
a. kompetensi teknis yang diukur dari tingkat dan
spesialisasi pendidikan, pelatihan teknis fungsional, dan
pengalaman bekerja secara teknis; ------- ---------------------
b. kompetensi manajerial yang diukur dari tingkat
pendidikan, pelatihan struktural atau manajemen, dan
pengalaman kepemimpinan; dan; --------- ----------- ---------
c. kompetensi sosial kultural yang diukur dari pengala -
man kerja berkaitan dengan masyarakat majemuk dalam
hal agama, suku, dan budaya sehingga memiliki
wawasan kebangsaan; ----------------------------------------------
Ayat (4) : “Integritas sebagaimana dimaks ud pada ayat (2)
diukur dari kejujuran, kepatuhan terhadap ketentuan
peraturan perundang -undangan, kemampuan bekerja
sama, dan pengabdian kepada masyarakat, bangsa dan
Negara”; ----------- ------------------------------- ---------------- ---------- ------
Direktori Putusan 5. Bahwa Penggugat diangkat dalam j abatan Pengawas SD
Kecamatan Segeri , Kabupaten Pangkep , pada Februari 2012
dengan Pangkat Pembina IV/a, menyelesaikan Pendidikan
S.2 pada Desember 2013, dan mendapatkan kenaikan
Pangkat menjadi Pembina Tk.I, IV/b, pada 1 April 2015, serta
tidak pernah melakukan perbuatan melanggar hukum. Oleh
karena itu, Keputusan Bupati Pangkajene dan Kepulauan
Nomor: 821.29/499/BKDD/2016, tanggal 03 Oktober 2016,
yang memberhentikan Penggugat dari j abatan Pengawas SD
Kecama tan Segeri , Kab. Pangkep , menjadi Staf UPTD
Pendidikan Kecamatan Balocci , Kab. Pangkep, sangat tidak
sesuai serta bertentangan dengan Peraturan Menteri Negara
Pendayagunaan Aparatur Negara dan Reformasi Birokrasi
Nomor 21 Tahun 2010 Bab XI Bagian Ketiga
“Pemberhentian” Pasal 36 huruf a dan b, yaitu :-------------------
”Pengawas Sekolah diberhentikan dari jabatannya apabila : ---
a. Dijatuhi hukuman disiplin tingkat sedang atau tingkat
berat berupa penurunan pangkat setingkat lebih rendah
selam a 3 (tiga) tahun atau pemindahan dalam rangka
penurunan jabatan set ingkat lebih rendah”; dan; ----------
b. dalam jangka waktu 1 (satu) tahun sejak dibebaskan
sementara dari jabatannya sebagaimana dimaksud
dalam Pasal 34 ayat (1) dan ayat (2) tidak dapat
mengumpulkan angka kredit yang ditentukan; ----------------
Sebagaimana Pasal 34 :------------------------------ --------------------
Ayat (1) : “Pengawas Sekolah Muda, Pangkat Penata,
Go-longan ruang Illlc, sampai dengan Pengawas Sekolah
utama, pangkat Pembina Utama Madya, golongan
Direktori Putusan ruang IV/d dibebaskan sementara dari jabatannya apabila
dalam jangka waktu 5 (lima) tahun sejak menduduki
jenjang jabatan/pangkat terakhir tidak dapat mengumpulkan
angka kredit yang ditentukan untuk kenaikan pangkat
setingkat lebih tinggi”; -------------------- --------------------------------
Ayat (2) : “Pengawas Sekolah Utama, pangkat Pembina
Utama, golongan ruang IV/e, dibebaskan sementara dari
jabatannya apabila setiap tahun sejak menduduki jabatan
pangkatnya tidak dapat mengumpulkan paling kurang
25 (dua puluh lima) angka kredit dari kegiatan tugas pokok”;
6. Bahwa tindakan dan perbuatan pelanggaran yang dilakukan
oleh Tergugat adalah sesuai dengan P asal 53 ayat (2) huruf
a Undan g-Undang RI Nomor 5 tahun 1986 tentang Peradilan
Tata Usaha Negara yang diperbaharui dengan Undang -
Undang RI Nomor 9 Tahun 2004, tentang Perubahan atas
Undang -Undang RI Nomor 5 Tahun 1986, tentang Peradilan
tata Usaha Negara Pasal 53 ayat (1), yaitu: -------------- ----------
“Seseorang atau Badan Hukum Perdata yang merasa
kepentingannya dirugikan o leh suatu keputusan Tata Usaha
Negara dapat mengajukan gugatan tertulis kepada
Pengadilan yang berwenang yang berisi tuntutan agar
keputusan Tata Usaha Negara yang disengketakan itu
dinyatakan batal atau t idak sah dengan atau tanpa disertai
tuntutan ganti rugi dan /atau rehabilitasi”; ---------------- ------------
Dalam P asal 53 ayat (2) huruf a, yaitu :-------------------------- ---
“Keputusan Tata Usaha Negara yang digugat itu
bertentangan dengan Peraturan Perundang -Undangan yang
berlaku”; ----------------- -----------------------------------------------------
Direktori Putusan Dengan demikian maka secara hukum Keputusan Tergugat
tersebut dinyatakan batal atau tidak sah;--------------- -------------
V. Berdasarkan uraian -uraian yang telah dikemukakan di atas,
Penggugat m emohon kepad a Ketua Pengadilan Tata Usaha
Negara Makassar cq. Majelis Hakim yang memeriksa dan
mengadili Perkara ini memberikan :--------------- -----------------------
Putusan dengan amar putusan sebagai berikut : -----------------------
1. Mengabulkan gugatan P enggugat untuk s eluruhnya ; -----------
2. Menyatakan batal atau tidak sah Keputusan Bupati
Pangkajene dan Kepulauan Nomor: 821.29/499/BKDD/2016,
tanggal 03 Oktober 2016 , tentang Mutasi dan Pemberian
Tugas Tambahan Bagi Guru Sebagai Kepala Sekolah dan
Pengawas Sekolah di Lingkungan Pemerintah Kabupaten
pangkajene dan Kepulauan, beserta daftar lampiran
Keputusan Bupati Pangkajene dan Kepulauan Nomor:
821.29/499/BKDD/2016, t anggal 03 Oktober 2016,
khususnya Nomor Urut 27, atas nama Rahmansyah ,
S.Pd./NIP. 19680312 198803 1 008; ---------------------------- -----
3. Mewajibkan kepada T ergugat untuk mencabut Keputusan
Bupati Pangkajene dan Kepulauan Nomor: 821.29/499/
BKDD/ 2016 , tanggal 03 Oktober 2016 , tentang Mutasi dan
Pemberian Tugas Tambahan Bagi Guru Sebag ai Kepala
Sekolah dan Pengawas S ekolah di Lingkungan Pemerintah
Kabupaten Pangkajene dan Kepulauan, beserta daftar
lampiran Keputusan Bupati Pangkajene dan Kepulauan
Nomo r: 821.29/ 499/BKDD/2016, tanggal 03 Oktober 2016,
khususnya Nomor Urut 27, atas nama Rahmansyah ,
S.Pd./NIP. 19680312 198803 1 008 ;------------- --------------------
Direktori Putusan 4. Mewajibkan kepada Tergugat mengembalikan k edudukan
Penggugat sebagai Pengawas SD Kecama tan Segeri
Kabupaten P angkajene dan Kepulauan; --------------------- --------
5. Mewajibkan kepada Tergugat untuk memberikan hak -hak
Penggugat sebagaimana sebelum terbitnya Surat
Keputusan Bupati Pangkajene dan Kepulauan Nomor:
821.29/499/BKDD/2016, ta nggal 03 Oktober 2016, tentang
Mutasi dan Pemberian Tugas Tambahan Bagi Guru Sebagai
Kepala Sekolah dan Pengawas sekolah di Lingkungan
Pemerintah Kabupaten Pangkajene dan Kepulauan,
khususnya Nomor Urut 27, atas nama Rahmansyah , S.Pd./
NIP. 19680312 1988 03 1 008; ----------------------------------------- -
6. Menghukum Tergugat untuk membayar biaya perkara; ---------

Menimbang, bahwa atas gugatan Penggugat tersebut, Tergugat
mengajukan jawaban , tanggal 26 April 2017, diajukan pada persidangan
tanggal 27 April 2017 , yang isinya menerangkan sebagai berikut : -------- ----
1. Bahwa Tergugat menyatakan dengan tegas menolak dan
membantah seluruh apa yang dikemukahkan oleh Penggugat
dalam gugatanya, kecuali apa yang diakui secara tegas dan
terperinci serta tidak mer ugikan kepentingan hukum Tergugat ; ---
2. Bahwa penerbitan Keputusan Bupati Pangkajeme dan Kepulauan
Nomor: 821.29/583/BKDD/2016 telah sesuai huk um dan
berdasar hukum karena diterbitkan ol eh pejaba t yang
berwewenamg sebagaimana P asal 73 ayat (2) Undang -undang
Nomor 5 Tahun 2014 tentang Aparatur Sipil Negara, yakni
“Mutasi PNS dalam satu instansi pusat atau daerah dilakukan
oleh pejabat Pembina K epegawaian ” dalam hal ini Bupati
Pangkajene dan Kepulauan; -------------------- -----------------------------
Direktori Putusan Sedangkan prinsip larangan konflik kepentingan sebagaimana
dikemukakan Penggugat dalam dalilnya pada poin 1 sangat tidak
relavan, sebab sebagaima na disebutkan dalam penjelasan P asal
73 ayat (7) yang dimaksud dengan prinsip larangan konflik
kepentingan hanya berlaku untuk PNS yang memeliki hubungan
tali perkawinan dan hubungan darah secara langsung dalam satu
unit kerja ;---------------------------------- ----------------------------------------
3. Bahwa Penggugat keliru atau salah dalam memahami
menyangkut tujuan diterb itkannya Keputusan Bupati Pangkajen e
dan Kepulauan Nomor: 821.29/583/BKDD/2016 sebagaimana
dikemukakan dalam dalilnya pada poin 2 , penerbitan Keputusan
Bupati Pangkajeme dan Kepulauan Nomor: 821.29/583/BKDD/
2016 semata mata merupakan Keputusan Bupati sela ku Pejabat
Pembina Kepegawaian dalam rangka penyegaran organisasi
yang berorentasi pada kebutuhan instansi pemerintah yang
sangat lazim dilakukan dalam organisasi pemerintahan ;-------------
4. Bahwa apa yang dikemukahkan Penggugat dalam dalilnya pada
poin 3, poin 4 , dan poin 5 adalah sangat tidak beralasan,
seharusnya Penggugat menyadari bahwa sebagai seorang abdi
Negara, selayaknya melaksanakan tugas kedinasan yang
dipercayakan kepadanya dengan penuh pengabdian, kesadaran ,
dan tanggung jawab serta senantiasa mengutamakan
kepentingan Negara/Daerah dari pada kepentingan pribadi
sebagaiaman telah diucapakan pada saat pengucapan
sumpa//janji PNS; --------------------- ------------------------------------------
Selanjunya dalam Undang –Undang Nomor 5 Tahun 2014 tentang
Aparatur Sipil Negara pada P asal 23 secara tegas disebutkan:
Direktori Putusan “Pegawai Aparatur Sipil Negara wajib antara lain: huruf h:
“bersedia ditempatkan diseluruh wilayah Negara Kesatuan
Republik Indonesia”; ------------------ ------------------------------------------
Dengan demikian Penggugat selaku abdi Negara seharusnya
menyadari sepenuhnya akan kewajiban untuk melaksanakan
tugas kedinasan dengan penuh pengabdian, kejujuran,
kesadaran , dan tanggung jawab d imana pun dia ditugaskan serta
melaksanakan kebijakan yang dirumuskan oleh pejabat
pemerintah yang berwewenang. Hal ini merupakan kewajiban
bagi setiap Pegawai Apatur Sipil Negara yang tercantum dalam
Pasal 23 huruf (c) dan huruf (e) Undang -Undang Nomor 5 Tahun
2014 tetang Aparatur Sipil Negara; -------------------------------- --------
Berdasarkan uraian hukum Tergugat di atas, maka Tergugat
memohon kepada Ketua Pengadilan Tata Usaha Negara Makassar
cq. Majelis Hakim yang memeriksa dan mengadili perkara Ta ta
Usaha Negara ini kiranya memutuskan dengan keputusan sebag ai
berikut: ------------------------------------------------------------- ----------------------
1. Menolak gugatan yang diajukan oleh Penggugat untuk
seluruhnya; ------------------------------------- -----------------------------------
2. Menyatakan Keputusan Bupati Pangkajeme dan Kepulauan
Nomor :821.29/583/BKDD/2016 adalah sah; --------- -------------------
3. Menyatakan bahwa gugatan yang diajukan oleh Penggugat
tersebut adalah gugatan yang tidak berdasar hukum; ---------- -----
4. Membebankan biaya perkara kepada Penggugat ;---------------------

Menimbang, bahwa atas jawaban Tergugat , Penggugat mengajukan
replik secara lisan yang pada pokoknya tetap pada gugatan semula, dan
Tergugat pun mengajukan duplik secara lisan yang menyatakan tetap
pada jawaban semula ;------------------------- ------------------------------------- -------
Direktori Putusan Menimbang, bahwa untuk menguatkan dalil -dalil gugatannya,
Penggugat mengajukan bukti surat berupa fotokopi yang diberi tanda P-1
sampai dengan P -28, yang perinciannya sebagai berikut ; --------------- -------
1. Bukti P -1 : Fotokopi sesuai dengan asli, Salinan Resmi
Putusan/Penetapan Perkara Nomor : 116/Pen -Dis/
2016/ PTUN.Mks antara Penggugat Rahmansyah,
S.Pd., Melawan Bupati Pangk ep, tanggal 11
Januari 2017;-------------------------- ---------------------------
2. Bukti P-2 : Fotokopi sesuai dengan asli, Surat dari Rahmansyah
dan kawan -kawan kepada Bupati Pangkajene dan
Kepulauan , tanggal 22 Desember 2016, Perihal:
Keberatan atas SK Bupati No. 821.29/499/
BKDD/2016 , tanggal 03 Oktober 2016, dan SK Bupati
No. 821.29/583/BKDD/2016 , tanggal 07 Nopember
2016 ;----------- -------- ---------------------------------------------
3. Butti P-3 : Fotokopi sesuai dengan asli, Tanda T erima /Resi dari
Kantor Pos , tanggal 2 4-12- 2016 ;--------------------- ------
4. Bukti P -4 : Fotokopi sesuai dengan asli, Petikan Keputusan
Bupati Pangkajene dan Kepulauan Nomor: 821.29/
499/BKDD/2016, tanggal 03 Oktober 2016 , atas
nama Rahmansyah, S.Pd. ;---------------------- -------------
5. Bukti P-5 : Fotokopi sesuai dengan asli, Surat dari Rahmansyah
dan kawan -kawan kepada Gubernur Sulawesi
Selatan, tanggal 04 Januari 2016 , Perihal:
Keberatan atas Surat Keputusan Bupati Pangkajene
dan Kepula uan Nomor: 821.29/499/BKDD/2016 ;-------
6. Bukti P -6 : Fotokopi sesuai dengan asli, Bio Data yang dibuat
oleh Rahmansyah, S.Pd., M.Pd., tanggal 03 Oktober
2016 ;-------------------------------------------- --------------------
Direktori Putusan 7. Bukti P -7 : Fotokopi sesuai dengan asli, Putusan Nomor : 116/
PLW/2016/PTUN.MKS , tanggal 20 Maret 2017 ;------
8. Bukti P -8 : Fotokopi sesuai dengan asli, Surat Tanda Tamat
Pendidikan dan Pelatihan , No. 1089/F443/PP -76/
2009 , tanggal 21 Juni 20 09, atas nama Rahmansyah,
S.Pd. ;------------ -------------------- ------------- ------------------
9. Bukti P -9 : Fotokopi sesuai dengan asli, Sertifikat Pendidik ,
Nomor: 1241102700713 , tanggal 30 November 2011 ,
atas nama Rahmansyah ;-------------------- ---------- --------
10. Bukti P -10 : Fotokopi sesuai dengan asli, Surat Tanda Tamat
Pendidikan dan Pelataihan (STTP) , Nomor:
1955/J4 3/PP.81/2012 , tanggal 04 Juli 2012 , atas
nama Rahmansyah, S.Pd. ;-------------------------------- ---
11. Bukti P -11 : Fotokopi sesuai dengan asli, Surat Keterangan No.
3787/J.16.3/TU/2012, tanggal 05 September 2012 ,
atas nama Rahmansyah, S.Pd.; -----------------------------
12. Bukti P -12 : Fotokopi sesuai dengan asli , Sertifikat Nomor:
1893/J20.2/DL.350/2013, tanggal 12 Agustus 2013,
atas nama Rahmansyah, S.Pd. ;-----------------------------
13. Bukti P -13 : Fotokopi sesuai dengan asli, Sertifikat , tanggal 2 -4
Desember 2013 , nama atas Rahmansyah, S.Pd. ;-----
14. Bukti P -14 : Fotokopi sesuai dengan asli, Sertifikat Nomor: 898/
2456/DISDIK/2016 , tanggal 03 Agustus 2016 , atas
nama Rahmansyah, S.Pd., M.Pd. ;-------------------------
15. Bukti P -15 : Fotokopi sesuai dengan asli, Sertifikat Nomor: 4861/
J20.2/PP.0194/2016, tanggal 22 September 2016,
atas nama Rahmansyah, S.Pd., M.Pd. ;---------- ---------
Direktori Putusan 16. Bukti P -16 : Fotokopi sesuai dengan asli, Piagam Tanda
Kehormatan , Satyalancana Karya Satya 20 Tahun ,
dari Presiden Rebublik Indonesia kepada
Rahmansyah, S.Pd., tanggal 30 Juli 2009 ;--------------
17. Bukti P -17 : Fotokopi sesuai dengan asli, Piagam Penghargaan
Bupati Pangkajene Dan Kepulauan Nomor: /XI/
KKBL/2014 , tangga l 22 November 20 14, atas nama
Rahmansyah, S.Pd., M.Pd. ;--------- --------------- ----------
18. Bukti P -18 : Fotokopi sesuai dengan asli, Piagam Penghargaan
diberikan kepada Rahmansyah, S.Pd ., tanggal 25
November 2016 ;---------------------- ------- --------------------
19. Bukti P -19 : Fotokopi sesuai dengan asli, Sertifikat Penghargaan
dari Menteri Pendidikan dan Kebudayaan , tanggal 26
Juli 2016 , atas nama Rahmansyah, S.Pd. ;-------- -------
20. Bukti P-20 : Fotokopi sesuai dengan asli , Keputusan Bupati
Pangkajene dan Kepulauan Nomor: 120/I/Tahun
2014 , tentang Pengangkatan Sekretaris d an Staf
Sekretariat Panitia Pemilihan Kecamatan s e-
Kabupaten Pa ngkajene dan Kepulauan pada
Pemi lihan Umum Anggota Dewan Perwakilan Rakyat,
Dewan Perwakila n Daerah, Dewan Perwakilan
Rakyat Daerah Tahun 2014 serta Pemelihan Umum
Presiden dan Wakil Presiden Tahun 2014, tanggal 30
Januari 2014 ;------------------------------------------------ ----
21. Bukti P-21 : Fotokopi sesuai dengan asli, Keputusan Pengurus
Kabupaten PGRI Pangkajene dan Kepulauan Nomor:
036/Kep/PGRI -Kab/PKP/II/2015 , tentang Susunan
dan Personalia Pengurus Kecamatan PGRI Segeri
Masa Bakti 2014 -2019, tanggal 20 Pebruari 2015 ;----
Direktori Putusan 22. Bukti P --22 : Fotokopi sesuai dengan asli, Keputusan Gerakan
Pramuka Kwartir Cabang Pangkajene dan Kepulauan
Nomor: 05 Tahun 2014 , tanggal 10 Mei 2014 , tentang
Majelis Pembimbing Ranting dan Pengurus Kwartir
Ranting Segeri Gerakan Pramuka Pangkep Masa
Bakti 2014 -2017 ;------------ ---------------------------- ---------
23. Bukti P-23 : Fotokopi sesuai dengan asli, Surat Keputusan
Pengurus Palang Merah Indonesia Kabupaten
Pangkejene dan Kepulauan Nomor: 081/ORG/5.5.3/
VII/2012 , tanggal 01 Juli 2012 , tentang Pengesahan
Pengurus Palang Merah Indonesia Ranting/
Kecamatan Masa Bakti 2012 -2014 ;------------------------
24. Bukti P -24 : Fotokopi sesuai dengan asli, Keputusan Pemerintah
Kecamatan Segeri Kabupaten Pangkep Nomor:
02/KS/IV/2010, tanggal 30 April 2010 , tentang
Susunan Pengurus Masji d Besar AL - Multazam
Kecamatan Segeri Kabupaten Pangkep Priode 2010 -
2015 ;--------- -------------------------------------- -----------------
25. Bukti P -25 : Fotokopi sesuai dengan asli , Keputusan Pemerintah
Kecamatan Segeri Kabupaten Pangkep Nomor: 10/
KS/IV/2016 , tanggal 30 April 2016 , Tentang Susunan
Pengurus Masjid Besar AL - Multazam Kecamatan
Segeri Kabu paten Pangkep Priode 2016 -2021; --------
26. Bukti P -26 : Fotokopi sesuai dengan asli , Petikan Keputusan
Gubernur Sulawesi Selatan Nomor: PD.823.4 -134,
tanggal 25 -06- 2015, PNS Nomor U rut. 39, atas nama
Rahmansyah, S.Pd., M.Pd. ;----------------------------------
Direktori Putusan 27. Bukti P-27 : Fotokopi sesuai dengan asli , Penilaian Prestasi
Pegawai Negeri Sipil atas nama Rahmansyah, S.Pd.,
M.Pd., tanggal 31 Desember 2015 ;------------------------
28. Bukti P-28 : Fotokopi sesuai dengan asli , Petikan Keputusan
Bupati Pangkajene dan Kepulauan Nomor: 821.29/
233/BKDD/2012, tanggal 23 Pebruari 2012 , atas
nama Rahmansyah, S.Pd. ;------------- ----------------------

Menimbang, bahwa untuk menguatkan dalil -dalil bantahannya,
Tergugat mengajukan bukti surat berupa fotokopi yang diberi tanda T -1
sampai dengan T-5, yang perinciannya sebagai berikut; ------------ -----------

1. Bukti T -1 : Fotokopi sesuai dengan asli, Sura t Nomor:
420/2695.KP/Disdik, Perihal: Usul Mutasi dan
Pemberian Tugas Tambahan bagi Guru sebagai
Kepala Sekolah dan Pengawas Sekolah Lingkungan
Dinas Pendidikan Kab. Pangkep , tanggal 25 Agustus
2016, ditujukan Kepada Bupati Pangkajene dan
Kepulauan ;----------- -----------------------------------------------
2. Bukti T -2 : Fotokopi sesuai dengan asli, Surat Nomor: 11/
Baperjakat/IX/2016 , tanggal 20 September 2016,
Perihal: Pertimbangan Baperjakat, ditujukan Kepada
Bupati Pangkep ;-------------------------------- -----------------
3. Bukti T -3 : Fotokopi sesuai dengan asli, Keputusan Bupati
Pangkajene dan Kepulauan Nomor: 821.29/499/
BKDD/2016, tanggal 03 Oktober 2016 , Tentang Mutas i
dan Pemberian Tugas Tambahan b agi Guru sebagai
Kepala Sekolah dan Pengawas Sekolah di Lingkungan
Pemerintahan Kabupaten Pangkajene dan Kepu -
lauan ;---------------------------------- --------------- --------------- -
Direktori Putusan 4. Bukti T -4 : Fotokopi sesuai dengan asli, Petikan Keputusan Bupati
Pangkajene dan Kepulauan Nomor: 821.29/499/BKDD/
2016, tanggal 03 Oktober 2016 , atas nama
Rahmansyah ;-------------- ------------------- ------------------------
5. Bukti T -5 : Fotokopi sesuai dengan asli, Daftar Lampiran
Keputusan Bupati Pangkajene dan Kepulauan Nomor:
821.29/499/BKDD/ 2016, tanggal 03 Oktober 2016 ,
tentang: Mutasi dan Pemberian Tugas Tambahan b agi
Guru sebagai Kepala Sekolah dan Pengawas Sekolah di
Lingkungan Pemerintahan Kabupaten Pangkajene dan
Kepulauan ;----------------------------------- -------------------------

Menimbang, bahwa Penggugat dan Tergugat tidak mengajukan
saksi, meskipun telah diberi kesempatan oleh Majelis Hakim; --------- ------- --
Menimbang, bahwa selanjutnya Penggugat dan Tergugat
mengajukan kesimpulan pada persidangan tanggal 07 Juni 2017; ------- ---
Menimbang, bahwa akhirnya para pihak dalam perkara ini
menyatakan tidak men gajukan sesuatu lagi dan mohon p utusan; -------------
Menimbang, bahwa segala sesuatu yang terjadi di pemeriksaan
persiapan maupun di persidangan dalam perkara ini, selengkapnya
tercatat dalam Berita Acara Pemeriksaan Persiapan maupun Berita Acara
Persidangan dan menjadi satu kesatuan dengan Putusan ini; ------------------

TENTANG PERTIMBANGAN HUKUM

Menimbang, bahwa maksud dan tujuan gugatan Penggugat ialah
sebagaimana telah diuraikan dalam bagian „Tentang Duduk Sengketa‟
Putusan ini; ------------------------------------------------------------------------------------
Direktori Putusan Menimbang, bahwa Tergugat mengajukan jawaban tertulis yang
telah diu raikan dalam bagian „Tentang Duduk Sengke ta‟ Putusan ini; --------
Menimbang, bahwa Penggugat mengajukan replik lisan yang
menyatakan pada pokoknya bertetap pada gugatannya semula, dan
Tergugat pun mengajukan duplik lisan yang menyatakan pada pokoknya
bertetap pada jawabannya semula; -----------------------------------------------------
Menimbang, bahwa Penggugat dan Tergugat telah mengajukan
bukti -bukti sebagaimana telah diuraikan dalam bagian „Tentang Duduk
Sengketa‟ Putusan ini yang selengkapnya terlampir dan tercatat dalam
Berita Acara Persidangan yang merupakan bagian tidak terpisahkan dari
Putusan ini; --------------------------------------------- ---------------------------------------
Menimbang, bahwa objek dalam sengketa ini ialah Keputusan Ta ta
Usaha Negara (KTUN) yang berupa: -------------------------------- ------- -----------
“Keputusan Bupati Pangkajene dan Kepulauan Nomor: 821.29/
499/BKDD/2016, tanggal 03 Oktober 2016, tentang Mutasi dan
Pemberian Tugas Tambahan Bagi Guru sebagai Kepala Se kolah dan
Pengawas Sekolah di Lingkungan Pemerintah Kabupaten Pang -
kajene dan Kepulauan, beserta Daftar Lampiran Keputusan Bupati
Pangkajene dan Kepulauan Nomor: 821.29/499/ BKDD/2016, Khusus
Nomor Urut 27, atas nama Rahmansyah, S.Pd. (vide Bukti T -3,
selanjutnya disebut objek sengketa); ------------- ------------------------- ------
Menimbang, bahwa Undang -Undang Republik Indonesia Nomor 5
Tahun 1986 tentang Peradilan Tata Usaha Negara sebagaimana telah
dirubah dengan Undang -Undang Republik Indonesia Nomor 9 Tahun 2004
dan Undang -Undang Republik Indonesia Nomor 51 Tahun 2009, dalam hal
ini, selanjutnya disebut UU Peradilan Tata Usaha Negara; --------------------- -
Menimbang, bahwa Tergugat tidak mengajukan eksepsi , dan setelah
Majelis Hakim mencermati bukti -bukti yang diajukan para pihak , tidak
diperoleh fakta hukum yang berkaitan dengan formalitas gugatan yang
dapat berakibat hukum kepada tidak diterimanya gugatan Penggugat ;-----
Direktori Putusan Menimbang, bahwa dengan demikian, selanjutnya Majelis Hakim
akan mempertimbangkan pokok sengketanya; --------------------------------------
Menimbang, bahwa Penggugat mendalilkan yang pada pokoknya
objek sengketa diterbitkan Tergugat tanpa alasan yang jelas, tidak
didasarkan kepada pola pengembangan karier pegawai nege ri sipil yang
bersi fat objektif , tanpa memperhatikan kompetensi maupun penilaian
kinerja, tanpa adanya hukuman disiplin, sehingga objek sengketa a quo
bertentangan dengan Pasal 68 ayat (1), ayat (2), ayat (4), Pasal 69 ayat
(1), ayat (2), ayat (3), ayat (4), dan Pasal 73 ayat (7) Undang -Undang
Republik Indonesia Nomor 5 Tahun 2014 tentang Aparatur Sipil Negara,
serta Pasal 36 huruf a dan b Peraturan Menteri Pendayagunaan Aparatur
Negara dan Reformasi Birokrasi Nomor 21 Tahun 2010; ---------- ---------------
Menimbang, bahwa Tergugat mendalilkan yang pada pokoknya objek
sengketa diterbitkan telah sesuai huk um dan berdasar hukum,
dilaksanakan dalam rangka penyegaran organisasi yang berore intasi pada
kebutuhan instansi pemerintah, dan Penggugat selaku abdi n egara
seharusnya meny adari sepenuhnya akan kewajiban untuk melaksanakan
tugas kedinasan dengan penuh pengabdian, kejujuran, kesadaran , dan
tanggung jawab dimana pun dia ditugaskan serta melaksanakan kebijakan
yang dirumuskan ol eh pejabat pemerintah yang ber wenang ;------------- ------
Menimbang, bahwa berdasarkan dalil -dalil gugatan Penggugat, dalil -
dalil jawaban Tergugat, dan bukti -bukti yang diajuka n di persidangan,
diperoleh inti permasalahan hukum dalam sengketa ini ialah mengenai
alasan yang mendasari tindakan hukum Tergugat untuk memberhentikan
Penggugat dari jabatan pengawas sekolah dasar (SD) di Kecamatan
Sege ri, Kabupaten Pangkajene dan K epulauan, dan kemudian
memutasikannya menjadi staf UPTD Pendidikan di Kecamatan Balocci ,
Kabupaten Pangkajene dan Kepulauan ;-------------------------- ------- -------------
Direktori Putusan Menimbang, bahwa pertimbangan atas inti permasalahan hukum
tersebut di atas, akan diawali pertimbangan mengenai kewenangan
Tergugat dalam menerbitkan objek sengketa a quo , sebagai berikut di
bawah ini; --------------------------------------------------------------------------------------
Menimbang, bahwa berdasarkan Pasal 53 huruf e Undang -Undang
Republik Indonesia Nomor 5 Tahun 2014 tentang Aparatur Sipil Negara
(UU ASN), Pres iden selaku pemegang kekuasaan tertinggi pembinaan
ASN dapat mendelegasikan kewenangan menetapkan pengangkatan,
pemindahan, dan pemberhentian pejabat selain pejabat pimpinan tinggi
utama dan madya, dan pejabat keahlian utama kepada bupati/walikota di
kabup aten/kota; ------------------------------------------------------------------------------
Menimbang, bahwa Pasal 73 ayat (2) UU ASN menentukan yang
pada pokoknya mutasi PNS dalam satu Instansi Pusat atau Instansi
Daerah dilakukan oleh Pejabat Pembina Kepega waian ;------------------------- -
Menimbang, bahwa Pasal 14 ayat (1) huruf d Peraturan Pemerintah
Republik Indonesia Nomor 9 Tahun 2003 tentang Wewenang
Pengangkatan, Pemindahan, dan Pemberhentian Pegawai Negeri Sipil
(PP No. 9 Tahun 2003) , menentukan yang pada pokoknya bahwa Pejabat
Pembina Kepegawaian Daerah Kabupaten/Kota berwenang untuk
mengangkat , memindahkan , dan memberhentikan Pegawai Negeri Sipil
dalam dan dari jabatan struktural eselon III ke bawah dan jabatan
fungsional yang jenja ngnya setingkat dengan jabatan struktural eselon II
ke bawah di lingkungan Pemerintah Daerah Kabupaten/Kota; ------------------
Menimbang, bahwa berdasarkan Pasal 2 Peraturan Menteri
Pendayagunaan Aparatur Negara dan Reformasi Birokrasi Nomor 21
Tahun 2010 tentang Pejabat Fungsional Pengawas Sekolah dan Angka
Kreditnya (Permenpan RB No. 21 Tahun 2010), Pengawas Sekolah
Direktori Putusan merupakan jabatan fungsional yang termasuk rumpun pendidikan lainnya,
dan Pasal 33 Permenpan RB No. 21 Tahun 2010 menentukan: “Pejabat
yang berwenang membebaskan sementara, mengangkat kembali, dan
memberhentikan PNS dalam dan dari jabatan fungsional Pengawas
Sekolah adalah pejabat yang berwenang sesuai peraturan perundang -
undangan ”;-------------------------------------------------------------- --------------------- -
Menimbang, bahwa berdasarkan ketentuan -ketentuan sebagaimana
diuraikan di atas, maka Bupati/Walikota memiliki kewenangan untuk
mengangkat , memindahkan , dan memberhentikan Pengawas Sekolah
yang jenjangnya setingkat dengan jabatan struktural eselon II ke bawah di
lingkungan Pemerintah Daerah Kabupaten/Kota ;------------------ -----------------
Menimbang, bahwa objek sengketa a quo berupa tindakan hukum
Tergugat , dalam kapasitasnya sebagai Pejabat P embina Kepegawaian di
Kabupaten Pangkajene dan Kepulauan, untuk memberhentikan Penggugat
dari jabatan fungsional Pengawas SD di Kecamatan Segeri , Kabupaten
Pangkajene dan Kepulauan, kemu dian memindahkan Penggugat menjadi
staf UPTD Pendidikan di Kecamatan Balocci , Kabupaten Pangkajene da n
Kepulauan; ------------------------------------------------------------------------------------
Menimbang, bahwa dengan demikian, Majelis Hakim berpendapat
Tergugat memiliki kewenangan untuk menerbitkan objek sengketa a quo
sesuai ketentuan Pasal 53 huruf e dan Pasal 73 ayat (2) UU ASN jis. Pasal
14 ayat (1) huruf d PP No. 9 Tahun 2003 dan Pasal 33 Permenpan RB No.
21 Tahun 2010; ------------------------------------------------------------------------------
Menimbang, bahwa be rkaitan dengan pelaksanaan kewenangan
Tergugat sebagaimana tersebut di atas, Pasal 8 ayat (2) Undang -Undang
Republik Indonesia Nomor 30 Tahun 2014 (UU AP) mengamanatkan:
“Badan dan/atau Pejabat Pemerintahan dalam menggunakan wewenang
wajib berdasarkan: a. peraturan perundang -undangan; dan b. AUPB ”;-------
Direktori Putusan Menimbang, bahwa dengan merujuk Pasal 55 ayat (1) UU ASN,
tindakan hukum Tergugat dalam menerbitkan objek sengketa termasuk
kegiatan dalam manajemen PNS, yang mana Tergugat telah
memberhentikan Penggugat dari jabatan fungsional pengawas SD di
Kecamatan Segeri , Kabupaten Pangkajene dan Kepulauan, selanjutnya
meminda hkan Penggugat menjadi staf UPTD Pendidikan di Kecamatan
Balocci , Kabupaten Pangkajene dan K epulauan; ---------------- -------------------
Menimbang, bahwa prinsip manajemen PNS dalam hal perpindahan
antar dan antara jabatan , telah diatur dalam Pasal 68 ayat (4) UU ASN
yang berbunyi: “ PNS dapat berpindah antar dan antara Jabatan Tinggi,
Jabatan Administrasi, dan Jabatan Fungsional di Instansi Pusat dan
Instansi Daerah berdasarkan kualifikasi, kompetensi, dan penilaian
kinerja ”;--------------------- ------------------------------------------------------- -------------
Menimbang, bahwa ada pun mengen ai pemberhentian pejabat
fungsional pengawas sekolah diatur Pasal 36 Permenpan RB No. 21
Tahun 2010 yang berbunyi: ------------------------------------------------ ---------------
“Pengawas Sekolah diberhentikan dari jabatannya apabila: -------------

a. Dij atuhi hukuman disiplin tingkat sedang atau tingkat berat berupa
penurunan pangkat setingkat lebih rendah selama 3 (tiga) tahun
atau pemindahan dalam rangka penurunan jabatan setingkat lebih
rendah; dan ------------------------------------------------------- ------------------
b. dalam jangka waktu 1 (satu) tahun sejak dibebaskan sementara
dari jabatannya sebagaimana dimaksud dalam Pasal 34 ayat (1)
dan ayat (2) tidak dapat mengumpulkan angka kredit yang
ditentukan. -------------------------------------------- ------------------------------

Menimbang, bahwa dengan demikian pelaksanaan kewenangan
Tergugat dalam menerbitkan objek sengketa a quo , mesti didasarkan
kepada kualifikasi, kompetensi, dan penilaian kinerja Penggugat, sesuai
ketentuan Pasal 68 ayat (4) UU ASN, dan dasar pemberhentian jabatan
pengawas sekolah sebagaimana ditentu kan Pasal 36 Permenpan RB No.
21 Tahun 2010; ------------- -----------------------------------------------------------------
Direktori Putusan Menimbang, bahwa melalui pemeriksaan di persidangan diperoleh
fakta -fakta sebagai berikut: ---------------------------------------------------------------
1. bahwa Penggu gat diangkat dari guru men jadi p engawas sekolah
berdasarkan Keputusan Bupati Pangkajene dan Kepulauan
Nomor: 821.29/ 233/BKDD/2012, tanggal 23 Pebruari 2012 (vide
Bukti P -28);-----------------------------------------------------------------------
2. bahwa berdasarkan Surat Keterangan , No. 3787/J.16.3/TU/2012,
tanggal 05 September 2012 (vide Bukti P -11), diketahui
Penggugat pernah mengikuti pendidikan dan pelatihan supervisi
pengawas sekolah; -------------------------------------------------------------
3. bahwa Penggugat pern ah mengikuti pendidikan pelatihan
pembekalan KTSP , tahun 2009 ( vide Bukti P -8); pendidikan dan
pelatihan District Core Tema (DCT) program bermutu , tahun
2012 ( vide Bukti P -10); kegiatan capacity building pemetaan mutu
pendidikan , tahun 2013 ( vide Bukti P-12); pelatihan pembelajaran
pakem , tahun 2013 ( vide Bukti P -13); sosialisasi pendidikan
inklusif ( vide Bukti P-14); dan workshop pengembangan sekolah
model , tahun 2016 ( vide Bukti P -15);-------------------------------- ------
4. bahwa Penggugat mendapat kenaikan pangkat menjadi Pembina
Tk. I G olongan Ruang IV/b, dalam jabatan Pengawas Sekolah
Madya, berdasarkan Keputusan Gubernur Sulawesi Selatan
Nomor: PD.823.4 -134, tanggal 25 -06- 2015 (vide Bukti P -26);-----
5. bahwa berdasarkan Penilaian Prestasi Pegawai Negeri Sipil,
tanggal 31 Desember 2015 (vide Bukti P -27), diketahui penilaian
kinerja Penggugat ialah baik; ------------------------------------------------
6. bahwa pemberhentian Penggugat dari pengawas sekolah SD di
Kecamatan Segeri untuk dipindah menjadi staf UPTD Pendidikan
di Kecamatan Balocci , didasarkan Surat Dinas Pendidikan
Direktori Putusan Pangkajene dan Kepulauan kepada Tergugat, Nomor: 420/2695.
KP/Disdik , tanggal 25 Agustus 2 016, Perihal: Usul Mutasi dan
Pemberian Tugas Tambahan bagi Gur u sebagai Kepala Sekolah
dan Pengawas Sekolah Lingkungan Dinas Pendidikan Kab.
Pangkep , Daftar Lampiran No. 209, dari (vide Bukti T -1);------------
7. bahwa berdasarkan Surat Nomor: 11/Baperjakat/IX/2016 , tanggal
20 September 2016, Perihal: Pertimbangan Baperjakat (vide
Bukti T -2), usulan Dinas Pendidikan Kabupaten Pangkajene dan
Kepulauan sebagaimana dimaksud Bukti T -1 telah dibahas dan
dipertimbangkan oleh Baperjakat; ----------------------------------------- -
8. bahwa kemudian terbit objek sengketa ( vide Bukti T -3);------------- -

Menimbang, bahwa berdasarkan Bukti P -8, Bukti P -10, Bukti P -11,
Bukti P -12, Bukti P -13, Bukti P -14, dan Bukti P -15, diperoleh fakta hukum
mengenai Penggugat telah menempuh pendidikan dan pelatihan maupun
kegiatan untuk mendukun g pemenuhan dan peningkatan kompetensi
sebagai pengawas sekolah ;------------------------------------- -------------------------
Menimbang, bahwa Bukti P -26 merupakan fakta hukum kenaikan
pangkat Penggugat menjadi Pembina Tk. I Gol. IV/b, dan Bukti P -27
meru pakan fakta hukum mengenai penilaian yang baik atas kinerja
Penggugat sebagai pengawas sekolah , sehingga berdasarkan Bukti P -26
dan Bukti P -27 diketahui fakta hukum mengenai prestasi kerja Penggugat
untuk pelaksanaan tugas -tugas sebagai pengawas sekolah cu kup baik; -----
Menimbang, bahwa dalam usulan mutasi sebagaimana Bukti T -1
maupun pertimbangan Baperjakat sebagaimana Bukti T -2, tidak terdapat
catatan /penjelasan khusus mengenai alasan -alasan diusulkannya pem -
berhentian Penggugat dari pengawas SD di Kecamatan Segeri untuk
dipindah kan menjadi staf UPTD Pendidikan di Kecamatan Balocci , selain
Direktori Putusan alasan yang bersifat umum yaitu untuk penyegaran guna penambahan
wawasan dan pengalaman bagi kepala sekolah dan pengawas s ekolah di
lingkungan Dinas Pendidikan Kabupaten Pangkajene dan Kepulauan ;------
Menimbang, bahwa selama pemeriksaan di persidangan tidak
diperoleh bukti yang menunjukkan adanya fakta hukum mengenai: -----------
- kinerja Penggugat yang buruk sebagai penga was sekolah; ----------
- penjatuhan hukum an disiplin kepada Penggugat, baik tingkat
ringan, sedang, atau pun berat; ------------------------- ----------------------
- pembebasan sementara Penggugat dari pengawas sekolah,
karena tidak memenuhi pengumpulan angka kredit yang
ditentukan peraturan perundang -undangan ;---------- ---------------------
Menimbang, bahwa berdasarkan uraian fakta -fakta hukum tersebut
di atas, maka terbukti tindakan hukum Tergugat dalam menerbitkan objek
sengketa a quo , tanpa didasark an informasi dan data/dokumen mengenai:
penilaian kompetensi dan kinerja Penggugat, Penggugat tidak pernah
dijatuhi hukuman disiplin sedang atau pun berat, dan Penggugat tidak
pernah diberhentikan sementara dari pengawas SD karena tidak
memenuhi angka kred it yang ditentukan peraturan perundang -undangan; -
Menimbang, bahwa oleh karena itu , tindakan hukum Tergugat dalam
menerbitkan objek sengketa a quo telah bertentangan dengan peraturan
perundang -undangan, khususnya Pasal 68 ayat (4) UU ASN dan Pasal 36
Perm enpan RB No. 21 Tahun 2010; --------------------------------- -------------------
Menimbang, bahwa uraian pertimbangan hukum tersebut di atas pun
membu ktikan tindakan Tergugat dalam menerbitkan objek sengketa a quo ,
disamping tidak mengindahkan peraturan perundang -undangan, juga tidak
didasarkan kepada informasi dan dokumen yang lengkap untuk
mendukung legalitas pengambilan keputusan, oleh karenanya tindakan
Direktori Putusan hukum Tergugat tersebut telah melanggar azas kepastian huk um dan azas
kecermatan dalam Azas -Azas Umum Pemerintahan Y ang Baik (AUPB)
sebagaimana ketentuan Pasal 10 huruf a dan d UU AP; -------- ---------------- -
Menimbang, bahwa alasan Tergugat menerbitkan objek sengketa a
quo dalam rangka penyegaran guna penambahan wawasan dan
pengalaman bagi kepala sekolah dan pengawas sekolah di lingkungan
Dinas Pendidikan Kabupaten Pangkajene dan Kepulauan, tidak dapat
mengesampingkan kewajiban Tergugat untuk berpegang kepada dasar
peraturan perundang -undangan dan Azas -azas Umum Pemerintahan yang
Baik (AUPB) sebagaimana amanat Pasal 8 ayat (2) UU AP; --------------------
Menimbang, bahwa berdasarkan seluruh uraian pertimbangan hukum
di atas, Majelis Hakim berkesimpulan penerbitan objek sengketa a quo
oleh Tergugat memiliki kesalahan ( cacat yuridis ) dari aspek prosedur, oleh
karenanya sesuai ketentuan Pasal 71 ayat (1) huruf a UU AP jo. Pasal 53
ayat (2) UU Peradilan Tata Usaha Negara, Majelis Hakim berkeyakinan
bahwa gugatan Penggugat agar Pengadilan menyatakan objek sengket a a
quo batal, haruslah dikabulkan; --------- ------------------------------------------------
Menimbang, bahwa oleh karena objek sengketa a quo dinyatakan
batal, maka gugatan Penggugat agar Pengadilan mewajibkan Tergugat
untuk mencabut objek sengketa a quo , haruslah d ikabulkan; -------------------
Menimbang, bahwa sesuai ketentuan Pasal 23 huruf h UU ASN yang
mewajibkan Pegawai ASN harus siap ditempatkan di seluruh wilayah
Negara Kesatuan Republik Indonesia, dalam hal ini, Penggugat pun harus
siap ditempatkan di seluruh wilayah Kabupaten Pangkajene dan
Kepulauan, oleh karenanya gugatan P enggugat agar mewajibkan
Tergugat mengembalikan Penggugat sebagai pengawas SD di Kecamatan
Segeri , haruslah dikabulkan sepanjang kewajiban Tergugat untuk
Direktori Putusan mengemba likan Penggugat kepada jabatan fungsional pengawas sekolah
dasar , sedangkan untuk tempat tugasnya merupakan kebijaksanaan
(doelmatigheid ) Tergugat; --------------------------------------------- --------------------
Menimbang, bahwa oleh karena pembatalan obje k sengketa a quo
didasarkan adanya kesalahan (cacat) prosedur sebagaimana ketentuan
Pasal 71 ayat (1) huruf a UU AP, maka sesuai ketentuan Pasal 71 ayat (2)
UU AP, akibat hukum objek sengketa a quo ialah tidak mengikat sejak
saat dibatalkan atau tetap sah sampai adanya pembatalan dan berakhir
setelah ada pembatalan, sehingga gugatan Penggugat agar Pengadilan
mewajibkan Tergugat untuk memberikan hak -hak Penggugat
sebagaimana sebelum terbitnya objek s engketa a quo , mestilah
dinyatakan ditolak; ---------------------------------------------------------------------------
Menimbang, bahwa dengan demikian gugatan Penggugat
dikabulkan untuk sebagian, maka sesuai ketentuan Pasal 110 UU
Peradilan Tata Usaha Ne gara, Tergugat dihukum untuk membayar biaya
perkara sejumlah yang tercantum dalam amar Putusan ini; ----------------------
Menimbang, bahwa dengan mempedomani ketentuan Pasal 100 jo.
Pasal 107 UU Peradilan Tata Usaha Negara , Majelis Hakim dalam
memutus sen gketa a quo hanya mempertimbangkan bukti -bukti yang
relevan dengan persoalan/masalah hukum dalam sengketa antara
Penggugat dan Tergugat, sedangkan terhadap bukti -bukti yang selebihnya
dipertimbangkan untuk tidak dijadikan dasar dalam memutus sengketa a
quo, namun tetap terlampir dalam berkas perkara yang merupakan bagian
tidak terpisahkan dari Putusan ini; --------------------------- --------------------------
Mengingat, UU Peradilan Tata Usaha Negara dan peraturan
perundang -undangan lainnya yang berkaitan d engan sengketa ini; ----------
Direktori Putusan MENGADILI

1. Mengabulkan gugatan Penggugat untuk sebagian ;---------------------
2. Menyatakan batal Keputusan Tata Usaha Negara yang berupa: -----
“Keputusan Bupati Pangkajene dan Kepulauan Nomor: 821.29/
499/BKDD/2016, tanggal 03 Oktober 2016, tentang Mutasi dan
Pemberian Tugas Tambahan Bagi Guru sebagai Kepala Sekolah
dan Pengawas Sekolah di Lingkungan Pemerintah Kabupaten
Pangkajene dan Kepulauan, beserta Daftar Lampiran Keputusan
Bupati Pangkajene dan Kepulauan Nomor: 821.29/499/BKDD/2016,
Khusus Nomor Urut 27, atas nam a Rahmansyah, S.Pd. ”;---------------
3. Mewajibkan Tergugat untuk mencabut Keputusan Tata Usaha
Negara berupa: ----------------------------------------------------------------------
“Keputusan Bupati Pangkajene dan Kepulauan Nomor: 821.29/
499/BKDD/2016, tangg al 03 Oktober 2016, tentang Mutasi dan
Pemberian Tugas Tambahan Bagi Guru sebagai Kepala Sekolah
dan Pengawas Sekolah di Lingkungan Pemerintah Kabupaten
Pangkajene dan Kepulauan, beserta Daftar Lampiran Keputusan
Bupati Pangkajene dan Kepulauan Nomor: 821. 29/499/BKDD/2016,
Khusus Nomor Urut 27, atas nama Rahmansyah, S.Pd. ”;---------------
4. Mewajibkan Tergugat untuk mengembalikan kedudukan Penggugat
sebagai pengawas sekolah dasar ;------------------------------------- --------
5. Menolak gugatan Penggugat untuk se lain dan selebihnya; -------------
6. Menghukum Tergugat untuk membayar biaya perkara sejumlah
Rp. 378.000, - (Tiga Ratus Tujuh Puluh Depalan Ribu Rupiah );--------
Direktori Putusan Demikianlah diputuskan dalam rapat permusyawaratan Majelis
Hakim Pengadilan Tata Usaha Negara Makassar pada hari Kamis ,
tanggal 15 Juni 2017, oleh JOKO SETIONO, S.H., M.H. selaku Hakim
Ketua Majelis, ELWIS PARDAMEAN SITIO , S.H. dan DIKDIK SOMANTRI,
S.H., S.I.P., M.H. masing -masing selaku Hakim Anggota. Putusan tersebu t
diucapkan dalam sidang yang terbuka untuk umum pada hari Senin ,
tanggal 19 Juni 2017, oleh Majelis Hakim tersebut dengan dibantu oleh
JASMAN , S.H. selaku Panitera Pengganti Pengadilan Tata Usaha Negara
Makassar, dengan dihadiri Kuasa Hukum Penggugat dan Kuasa Tergugat ;
HAKIM -HAKIM ANGGOTA HAKIM KETUA MAJELIS

Ttd.

ELWIS PARDAMEAN SITIO , S.H.

Ttd.

JOKO SETIONO, S.H., M.H.

Ttd.

DIKDIK SOMANTRI, S.H., S.I.P., M.H.

PANITERA PENGGANTI,

Ttd.

J A S M A N , S.H.
Rincian Biaya Perkara Nomor: 116/G/2016/PTUN.MKS :
1. Pendaftaran : Rp. 30.000, -
2. Biaya Proses : Rp. 50.000, -
3. Biaya Panggilan Sidang : Rp. 287.000 ,-
4. Meterai : Rp. 6 .000, -
5. Redaksi : Rp. 5.000 ,-
Jumlah : Rp. 378.000 ,- (Tiga Ratus Tujuh Puluh
Delapan Ribu Rupiah );
Disclaimer
Kepaniteraan Mahkamah Agung Republik Indonesia berusaha untuk selalu mencantumkan informasi paling kini dan akurat sebagai bentuk komitmen Mahkamah Agung untuk pelayanan publik, transparansi dan akuntabilitas
pelaksanaan fungsi peradilan. Namun dalam hal-hal tertentu masih dimungkinkan terjadi permasalahan teknis terkait dengan akurasi dan keterkinian informasi yang kami sajikan, hal mana akan terus kami perbaiki dari waktu kewaktu.
Dalam hal Anda menemukan inakurasi informasi yang termuat pada situs ini atau informasi yang seharusnya ada, namun belum tersedia, maka harap segera hubungi Kepaniteraan Mahkamah Agung RI melalui :
Email : kepaniteraan@mahkamahagung.go.id Telp : 021-384 3348 (ext.318) Halaman 32