# Bukti No. 1
- **Tanggal:** 01-08-2009
- **Ringkasan Fakta:** KMK 1105/KM.1/UP.11/2009, pengangkatan pertama sebagai Pranata Komputer TMT 1 Agustus 2009. Persyaratan pendidikan saat itu SLTA/D-I. Dasar *verkregen recht*.
Inti: Keputusan Menteri Keuangan yang membuktikan pengangkatan sah pertama Penggugat dalam Jabatan Fungsional Pranata Komputer terhitung mulai 1 Agustus 2009.
# Bukti No. 2
- **Tanggal:** 30-03-2022
- **Ringkasan Fakta:** KMK 321.1/KM.1/UP.11/2022, kenaikan jenjang menjadi Pranata Komputer Mahir. Kenaikan di bawah rezim Permenpan RB 32/2020 tanpa dipersoalkan kualifikasinya.
Inti: Keputusan Menteri Keuangan mengenai penetapan kenaikan jenjang jabatan fungsional Penggugat menjadi Pranata Komputer Mahir pada Maret 2022.
# Bukti No. 3
- **Tanggal:** 15-05-2024
- **Ringkasan Fakta:** Surat Keterangan Plt. Kapusdiklat KU BPPK No. KET-137/PP.7/2024: Penggugat memenuhi persyaratan minimal keikutsertaan sebagai Pranata Komputer. Terbit sebelum tenggat 26 Mei 2025 (rantai pengakuan #1).
## Informasi Dokumen
| Keterangan | Isi |
||--|
| Nomor | KET-137/PP.7/2024 |
| Tanggal | 15 Mei 2024 |
| Jenis Dokumen | Surat Keterangan |
## Instansi
**KEMENTERIAN KEUANGAN REPUBLIK INDONESIA**  
**BADAN PENDIDIKAN DAN PELATIHAN KEUANGAN**  
**PUSAT PENDIDIKAN DAN PELATIHAN KEUANGAN UMUM**
Jalan Pancoran Timur II Nomor 1, Pancoran, Jakarta Selatan 12780  
Telepon: (021) 79192438, 79192436  
Faksimile: (021) 7996109  
Situs: www.bppk.kemenkeu.go.id
## Pihak yang Menerangkan
| Uraian | Keterangan |
|||
| Nama | Wahyu Kusuma Romadhoni |
| NIP | 197407201994021001 |
| Pangkat/Golongan | Pembina Utama Muda (IV/c) |
| Jabatan | Plt. Kepala Pusdiklat Keuangan Umum |
## Pihak yang Diterangkan
| Uraian | Keterangan |
|||
| Nama | Ninin Sapto Hargiyanto |
| NIP | 198607202007011001 |
| Pangkat/Golongan | Penata Muda (III/a) |
| Jabatan | Pranata Komputer Mahir |
| Pendidikan | D1 Kebendaharaan Negara |
## Keterangan
Yang bersangkutan memenuhi keikutsertaan pada diklat pranata komputer kategori keterampilan, dengan menyatakan sebagai berikut:
1. Memiliki latar belakang pendidikan **Teknologi Informasi (TI)** yang dibuktikan dengan ijazah terlampir dan/atau telah berkecimpung di ranah TI minimal **5 tahun terakhir**.
2. Memiliki pengalaman mengajar minimal **2 tahun terakhir**.
## Penutup
Atas perhatian dan kerja sama Saudara, kami ucapkan terima kasih.
## Penandatangan
Jakarta, **15 Mei 2024**
**Plt. Kepala Pusat Pendidikan dan Pelatihan Keuangan Umum**
Ditandatangani secara elektronik
**Wahyu Kusuma Romadhoni**
# Bukti No. 4
- **Tanggal:** 29-10-2024
- **Ringkasan Fakta:** Sertifikat Kompeten Pelatihan Fungsional Prakom No. 0024/PRAKOM-TERAMPIL/106/BPS/III/2024 dari BPPK + Instansi Pembina (BPS). Pengakuan kompetensi sebagai Prakom Keterampilan.
Inti: Sertifikat yang membuktikan Penggugat dinyatakan secara sah "Kompeten" melalui Pelatihan Fungsional Pranata Komputer di BPPK pada Oktober 2024.
# Bukti No. 5
- **Tanggal:** 12-02-2025
- **Ringkasan Fakta:** Printout pernyataan Kepala BKN di bkn.go.id (12 Feb 2025): ASN yang sudah melaksanakan tugas/izin belajar tetapi terlampau waktunya tidak perlu perpanjangan, tetap diakui.
## “Bagi yang sudah lulus, silakan diurus. Kemudian bagi yang sudah melaksanakan Tugas Belajar atau Izin Belajar tetapi terlampau waktunya, tidak perlu perpanjangan, tetap kita akui. Ini berlaku juga untuk lulusan perguruan tinggi dengan akreditasi C, karena tidak semua Perguruan Tinggi di daerah memiliki akreditasi B atau bahkan akreditasi A”
# Bukti No. 6
- **Tanggal:** 16-05-2025
- **Ringkasan Fakta:** ND-472/PP.7/2025 dari Kapusdiklat Keuangan Umum kepada Sekretaris BPPK: pengajuan izin belajar mandiri a.n. Penggugat.
## Identitas Dokumen
| Keterangan | Isi |
||--|
| Nomor | ND-472/PP.7/2025 |
| Tanggal | 16 Mei 2025 |
| Sifat | Biasa |
| Lampiran | - |
| Hal | Pengajuan Permohonan Izin Belajar Mandiri a.n. Ninin Sapto Hargiyanto |
| Dari | Kepala Pusat Pendidikan dan Pelatihan Keuangan Umum |
| Kepada | Sekretaris Badan Pendidikan dan Pelatihan Keuangan |
## Instansi
**KEMENTERIAN KEUANGAN REPUBLIK INDONESIA**  
**BADAN PENDIDIKAN DAN PELATIHAN KEUANGAN**  
**PUSAT PENDIDIKAN DAN PELATIHAN KEUANGAN UMUM**
Jalan Pancoran Timur II Nomor 1, Pancoran, Jakarta Selatan 12780  
Telepon: (021) 79192438, 79192436  
Faksimile: (021) 7996109  
Situs: www.bppk.kemenkeu.go.id
## Isi Nota Dinas
Sehubungan dengan Pengajuan Permohonan Izin Belajar Mandiri di Luar Kedinasan, berikut data pegawai yang diajukan:
| Uraian | Keterangan |
|||
| Nama / NIP | Ninin Sapto Hargiyanto / 198607202007011001 |
| Pangkat / Golongan | Penata Muda (III/a) |
| Jabatan | Pranata Komputer Mahir |
| Program Studi | S1 – Sistem Informasi (Akreditasi: B) |
| Universitas | Universitas Siber Asia |
Berdasarkan Nota Dinas Sekretaris Badan Pendidikan dan Pelatihan Keuangan Nomor **ND-27/PP.1/2025** tanggal **6 Januari 2025** perihal **Permohonan Penyampaian Rencana Melanjutkan Pendidikan Mandiri Para Pegawai di Lingkungan BPPK T.A. 2025**, dengan ini disampaikan permohonan penerbitan surat tugas belajar mandiri bagi pegawai tersebut.
Selain itu, dalam rangka menjaga komitmen sebagai unit kerja berpredikat **Wilayah Birokrasi Bersih dan Melayani (WBBM)**, Pusdiklat Keuangan Umum siap memberikan pelayanan dengan nilai **BAHAGIA**:
- **B**ersih
- **A**kuntabel
- **H**armonis
- **G**esit
- **I**novatif
- **A**daptif
Atas perhatian dan kerja sama Saudara, kami ucapkan terima kasih.
## Penandatangan
Ditandatangani secara elektronik oleh:
**Ganti Lis Ariyadi**
## Tembusan
- Ninin Sapto Hargiyanto
# Bukti No. 7
- **Tanggal:** 10-06-2025
- **Ringkasan Fakta:** Surat Tugas Belajar Mandiri No. ST-497/PP.1/2025 ( 1 Sep 2025 – 31 Agt 2028)
## Informasi Dokumen 
| Keterangan | Isi |
||--|
| Nomor | ST-497/PP.1/2025 |
| Tanggal | 10 Juni 2025 |
| Jenis Dokumen | Surat Tugas Belajar Mandiri Tidak Diberhentikan |
## Instansi
**KEMENTERIAN KEUANGAN REPUBLIK INDONESIA**  
**BADAN PENDIDIKAN DAN PELATIHAN KEUANGAN**  
**SEKRETARIAT BADAN PENDIDIKAN DAN PELATIHAN KEUANGAN**
Gedung Arimurti Lantai 3  
Jalan Purnawarman Nomor 99, Kebayoran Baru, Jakarta Selatan 12110  
Telepon: (021) 7394666, 7204131  
Faksimile: (021) 7261775  
Situs: www.bppk.kemenkeu.go.id
## Pegawai yang Ditugaskan
| Uraian | Keterangan |
|||
| Nama | Ninin Sapto Hargiyanto |
| NIP | 19860720 200701 1 001 |
| Golongan | Penata Muda / III/a |
| Jabatan | Pranata Komputer Mahir |
| Unit Asal | Pusat Pendidikan dan Pelatihan Keuangan Umum |
## Penugasan Tugas Belajar Mandiri
| Uraian | Keterangan |
|||
| Program Studi | S1 - Sistem Informasi (Akreditasi: B) |
| Perguruan Tinggi | Universitas Siber Asia, Jakarta |
| Tanggal Mulai Tugas | 01 September 2025 |
| Tanggal Akhir Tugas | 31 Agustus 2028 |
## Ketentuan
### 1. Status Kepegawaian
Selama melaksanakan Tugas Belajar Mandiri, pegawai berstatus sebagai pegawai aktif yang memiliki hak dan kewajiban pegawai sesuai dengan tugas dan fungsi dalam jabatannya.
### 2. Kewajiban Selama Menjalani Tugas Belajar Mandiri
Pegawai wajib:
a. Mematuhi segala ketentuan yang berlaku baik sebagai Pegawai Negeri Sipil maupun sebagai mahasiswa.
b. Menjaga kehormatan dan nilai-nilai Kementerian Keuangan serta Aparatur Sipil Negara.
c. Menyampaikan laporan perkembangan studi setiap periode akademik/periode pelaporan kinerja.
d. Melakukan pemutakhiran data dan mengimplementasikan kebijakan manajemen kinerja sesuai dengan ketentuan yang berlaku.
e. Menyelesaikan administrasi pengisian laporan perpajakan dan harta kekayaan penyelenggara negara sesuai ketentuan yang berlaku.
f. Melaksanakan seluruh kewajiban sebagai pegawai aktif sesuai dengan ketentuan yang berlaku.
### 3. Setelah Selesai Studi
Setelah selesai menjalankan Tugas Belajar Mandiri, pegawai wajib menyampaikan laporan selesai studi.
## Penutup
Demikian Surat Tugas Belajar Mandiri ini dibuat untuk dilaksanakan sebaik-baiknya dengan penuh tanggung jawab.
## Penandatangan
Jakarta, **10 Juni 2025**
**Sekretaris Badan**
Ditandatangani secara elektronik
**Bambang Juli Istanto**
## Tembusan
- Kepala Pusat Pendidikan dan Pelatihan Keuangan Umum
# Bukti No. 8
- **Tanggal:** 19 s.d. 20-06-2025
- **Ringkasan Fakta:** KMK 117/MK/SJ.5/2025 + Nota Dinas penugasan/mutasi sebagai Pranata Komputer di BaTii Kemenkeu. Penetapan jabatan SETELAH tenggat 26 Mei 2025.
Inti: Dokumen nota dinas penugasan dan mutasi internal yang membuktikan bahwa Penggugat secara sah dipindahtugaskan dan diakui menduduki jabatannya pada Juni 2025.
# Bukti No. 9
- **Tanggal:** 23-06-2025
- **Ringkasan Fakta:** KEP-2/TI/2025 dari Kepala BaTii: Penggugat "cakap dan memenuhi syarat" menduduki jabatan Pranata Komputer. Pengakuan tertulis unit kerja setelah tenggat.
Inti: Keputusan Kepala BaTii Kemenkeu Nomor KEP-2/TI/2025 yang memuat pengakuan tertulis bahwa Penggugat secara legal "cakap dan memenuhi syarat" dalam jabatan tersebut.
# Bukti No. 10
- **Tanggal:** Triwulan III-2025
- **Ringkasan Fakta:** Evaluasi Kinerja Pegawai Tw III 2025: predikat "Sangat Baik", capaian "Istimewa". Menggugurkan basis Pasal 43 huruf a Permenpan RB 1/2023.
Inti: Dokumen Evaluasi Kinerja Pegawai periode Triwulan III Tahun 2025 yang membuktikan Penggugat mendapat predikat kinerja "Sangat Baik" dan capaian "Istimewa".
# Bukti No. 11
- **Tanggal:** 18-09 s.d. 15-12-2025
- **Ringkasan Fakta:** Salinan utuh chat Penggugat–Ikhwan A. Rachman (Kasub AJF BaTii): urgensi aturan JF, rencana SK mutasi+pemberhentian, pengurangan TGR, perpindahan BPPK/DJA. **Sumber frasa "pasti bulan ini" (Replik 49)**, 30 Okt 2025 pukul 14.06.
- **Ikhwan A. Rachman**: bro [1]\
- **18/9/2025 15.45 | Ikhwan A. Rachman**: ngobrol skrg sama aku yok [1]\
- **18/9/2025 15.45 | Ikhwan A. Rachman**: di karkop aja [1]\
- **18/9/2025 15.45 | Hargi**: piye [1]\
- **18/9/2025 15.45 | Ikhwan A. Rachman**: urgent [1]\
- **18/9/2025 15.45 | Hargi**: otw [1]\
- **18/9/2025 15.45 | Hargi**: nggoeo laptop ra? [1]\
- **18/9/2025 15.45 | Hargi**: sisan mulih yo [1]\
- **18/9/2025 15.47 | Ikhwan A. Rachman**: ra sah laptop [1]\
- **18/9/2025 15.47 | Ikhwan A. Rachman**: saiki ya [1]\
- **18/9/2025 15.51 | Hargi**: ok [1]\
- **26/9/2025 19.18 | Ikhwan A. Rachman**: Km wisuda bulan apa rencananya om [1]\
- **26/9/2025 19.18 | Ikhwan A. Rachman**: Agustus/oktober? Ak lupa [2]\
- **26/9/2025 22.07 | Hargi**: September 2026 [2]\
- **9/10/2025 14.34 | Ikhwan A. Rachman**: om. tolong ditanyakan secepatnya ke ahli hukum ya, ak kasih waktu sampai minggu depan. [2]\
- **9/10/2025 14.34 | Ikhwan A. Rachman**: biar g berlama" ya [2]\
- **9/10/2025 14.35 | Ikhwan A. Rachman**: kalo km cek di case WI di bppk, itu sama terkait dengan persyaratan jabatan [2]\
- **9/10/2025 15.21 | Hargi**: siap ndan [2]\
- **16/10/2025 17.03 | Ikhwan A. Rachman**: Otw [2]\
- **16/10/2025 17.03 | Ikhwan A. Rachman**: Nembe bar [2]\
- **16/10/2025 17.04 | Hargi**: Ok siap. Aman msh di kantor [3]\
- **16/10/2025 17.11 | Ikhwan A. Rachman**: Wes nek lt 2 [3]\
- **16/10/2025 17.14 | Hargi**: Otw [3]\
- **16/10/2025 17.31 | Ikhwan A. Rachman**: https://www.bkn.go.id/layanan/pembinaan-jf/#pengangkatan [3]\
- **30/10/2025 12.31 | Ikhwan A. Rachman**: Om [3]\
- **30/10/2025 12.31 | Ikhwan A. Rachman**: Wfh/wfo? [3]\
- **30/10/2025 12.35 | Hargi**: Udh keluar? [3]\
- **30/10/2025 12.35 | Ikhwan A. Rachman**: Bar iki tak tlfn ya [3]\
- **30/10/2025 12.36 | Ikhwan A. Rachman**: Ak ngopi sek, nembe bar rapat [3]\
- **30/10/2025 12.36 | Hargi**: Sip [3]\
- **30/10/2025 13.45 | Hargi**: Nek mutasi sbg prakom di BPPK bisa gak mas? Di DJA, STAN msh ada prakom [4]\
- **30/10/2025 13.46 | Ikhwan A. Rachman**: dja gak ada [4]\
- **30/10/2025 13.46 | Ikhwan A. Rachman**: yg skrg akan ditarik [4]\
- **30/10/2025 13.46 | Ikhwan A. Rachman**: sbg prakom g bisa [4]\
- **30/10/2025 13.46 | Ikhwan A. Rachman**: stan masih ak bukain (nego sama organta) dan disetujui [4]\
- **30/10/2025 14.02 | Hargi**: nanti ada SK pemberhentian sebagai prakom kan ya mas? [4]\
- **30/10/2025 14.03 | Hargi**: apa langsung SK mutasi tok? [4]\
- **30/10/2025 14.06 | Ikhwan A. Rachman**: mutasi + pemberhentian bareng [4]\
- **30/10/2025 14.06 | Ikhwan A. Rachman**: dan pasti bulan ini [5]\
- **30/10/2025 14.07 | Hargi**: 1 SK berarti ya [5]\
- **30/10/2025 14.08 | Ikhwan A. Rachman**: ya [5]\
- **30/10/2025 14.09 | Ikhwan A. Rachman**: bsk ibunya ada [5]\
- **30/10/2025 14.09 | Ikhwan A. Rachman**: ak temenin ngadep bu yeyen ya [5]\
- **30/10/2025 14.10 | Hargi**: ok [5]\
- **31/10/2025 11.07 | Ikhwan A. Rachman**: wes ngadep durung [5]\
- **31/10/2025 11.07 | Ikhwan A. Rachman**: ayo nek arep ngadep [5]\
- **31/10/2025 11.07 | Ikhwan A. Rachman**: tak kancani [5]\
- **31/10/2025 11.07 | Hargi**: durung [5]\
- **31/10/2025 11.07 | Hargi**: saiki? [5]\
- **31/10/2025 11.08 | Ikhwan A. Rachman**: ayo [6]\
- **31/10/2025 11.09 | Ikhwan A. Rachman**: cek ibune [6]\
- **31/10/2025 11.09 | Ikhwan A. Rachman**: nek kosong, tak munggah [6]\
- **31/10/2025 11.10 | Hargi**: tak cek sek [6]\
- **31/10/2025 11.14 | Ikhwan A. Rachman**: yo [6]\
- **31/10/2025 11.20 | Hargi**: Ijek rapat ibu nya [6]\
- **31/10/2025 11.21 | Ikhwan A. Rachman**: ok. mengko wae nek ngono [6]\
- **31/10/2025 14.52 | Ikhwan A. Rachman**: Sido ngdep rak om [6]\
- **31/10/2025 14.52 | Ikhwan A. Rachman**: Ben ndang bar siji" [6]\
- **31/10/2025 14.52 | Hargi**: ono tamu ibunya [6]\
- **31/10/2025 14.59 | Ikhwan A. Rachman**: Ok [6]\
- **31/10/2025 15.03 | Ikhwan A. Rachman**: Mengko ojo balik sik ya [7]\
- **31/10/2025 15.03 | Ikhwan A. Rachman**: Jam 5 ngadep [7]\
- **31/10/2025 15.03 | Ikhwan A. Rachman**: Ak bar asar ngadep pak ali sik [7]\
- **31/10/2025 15.06 | Hargi**: Siap [7]\
- **31/10/2025 15.06 | Hargi**: Monggo [7]\
- **31/10/2025 17.16 | Hargi**: ibunya udh pulang, mas [7]\
- **31/10/2025 17.16 | Ikhwan A. Rachman**: Yaah [7]\
- **31/10/2025 17.16 | Ikhwan A. Rachman**: Pdhl tak enteni [7]\
- **31/10/2025 17.18 | Hargi**: aku mulih yo [7]\
- **31/10/2025 17.35 | Ikhwan A. Rachman**: Yo [7]\
- **31/10/2025 17.35 | Ikhwan A. Rachman**: Iki ak arep muleh jg [7]\
- **10/11/2025 10.38 | Hargi**: mas, saya ada tawaran dari om Loho, katanya DJA butuh orang IT & siap janjiin grade 10. apa bisa SK diubah ke DJA? [8]\
- **10/11/2025 10.39 | Hargi**: rencana hari ini mau ngadep kabag SDM DJA [8]\
- **10/11/2025 10.42 | Ikhwan A. Rachman**: Nd nya sdh dikirimkan k biro sdm [8]\
- **10/11/2025 10.43 | Hargi**: siap aku ke biro SDM berarti ya [8]\
- **10/11/2025 12.40 | Hargi**: Mas. Boleh minta ND ini [8]\
- **10/12/2025 14.51 | Ikhwan A. Rachman**: bro.. ak dapat pesen dari raninto sdmki [8]\
- **10/12/2025 14.51 | Ikhwan A. Rachman**: ente diminta kontak ke atsung di bppk (okta) ya.. [8]\
- **10/12/2025 14.57 | Hargi**: siap mas, ini malah lagi bareng mas Okta [9]\
- **10/12/2025 14.58 | Ikhwan A. Rachman**: wah, malh josss [9]\
- **15/12/2025 08.45 | Hargi**: Mas, per hari ini saya udah aktif di bppk. Minta tolong pindahin presensi ya. Suwun [9]\
- **15/12/2025 08.46 | Ikhwan A. Rachman**: siap mas [9]\
- **15/12/2025 08.46 | Ikhwan A. Rachman**: ak koordinasikan dengan tempat mas firman [9]\
- **15/12/2025 08.46 | Hargi**: Siap [9]\
- **15/12/2025 08.55 | Ikhwan A. Rachman**: bro [9]\
- **15/12/2025 08.55 | Ikhwan A. Rachman**: per iku an (realisasi), penilaian perilaku udah kelar semua? [9]\
- **15/12/2025 08.55 | Ikhwan A. Rachman**: kalo sdh selesai semua hari ini, dan sdh ga ada yg dikerjakan di pusdatin, baru dipindah [10]\
- **15/12/2025 08.55 | Ikhwan A. Rachman**: tlg konfirmasi ke ane ya ntr [10]\
- **15/12/2025 09.43 | Hargi**: Sudah mas, aman. Udh di ttd bu kapus [10]\
- **15/12/2025 09.51 | Ikhwan A. Rachman**: Ok. Kita proses k biro sdm ya [10]}
# Bukti No. 12
- **Tanggal:** 02-10-2025
- **Ringkasan Fakta:** Hasil pemeriksaan EKG 2 Okt 2025 + diagnosis psikiater (Anxiety, GERD). Kerugian immateriil.
Inti: Bukti rekam medis EKG dan diagnosis psikiater yang menunjukkan Penggugat mengalami kerugian immateriil berupa gangguan kecemasan (Anxiety) dan GERD akibat objek sengketa.
# Bukti No. 13
- **Tanggal:** 08-10-2025 s.d. 21-04-2026
- **Ringkasan Fakta:** Salinan utuh chat Penggugat–Nasru (staf pelaksana BPPK): konsultasi mutasi ke BPPK, informasi grading, koordinasi BaTii–BPPK, permintaan pertemuan Bagian SDM terkait gugatan PTUN.
[8/10/2025 12.46] Hargi: Mohon izin mengganggu mas Nasru. Status prakom saya kan akan diberhentikan. Kondisi ini menyebabkan dampak finansial yang signifikan bagi saya.
Apakah ada kemungkinan bagi saya untuk mengajukan permohonan kembali bertugas di BPPK? Mengingat dulu yg dipindah hanya prakom & pejabat saja.
Atas perhatian dan bantuannya, saya ucapkan terima kasih.
[8/10/2025 12.50] Nasru: Izin mas, ke BPPK sebagai pelaksana maksudnya mas?
[8/10/2025 12.51] Hargi: Iya mas
[8/10/2025 12.59] Nasru: Saya cb sampaikan ke atasan ya mas,
Btw, maaf mas. Jika sama-sama sebagai pelaksana, bedanya apa ya mas di Batii dan BPPK, untuk saya informasikan juga ke atasan
[8/10/2025 13.00] Nasru: Oiya mas, untuk pendidikan yang minimal D3 itu, apa mas hargi sebelummya pernah terinfo?
[8/10/2025 13.19] Hargi: Sudah mas. Cuma ada aturan baru yg boleh SMA. Ini yg bikin saya rancu
[8/10/2025 13.20] Hargi: Ada 2 ex prakom DJA yg senasib sama saya juga minta balik ke DJA
[8/10/2025 13.21] Hargi: Lebih deket rumah (terutama pancoran dan setban)
[8/10/2025 13.21] Nasru: baik mas, saya sampaikan dulu ke atasan ya mas
[8/10/2025 13.23] Hargi: Terima kasih banyak mas
[8/10/2025 14.26] Nasru: izin mas, setelah saya cb tanya2. yang bisa mengakomodir nanti dari kepegawaian di Batii dulu mas, misal nanti sudah ada ND permohonan pindah dari Batii, akan kami cb bantu bicarakan ke yang mengurusi mutasi mas
[8/10/2025 15.05] Hargi: Siap terima kasih mas
[8/10/2025 15.09] Hargi: Mas Nasru mau tanya apa benar dulu BPPK pernah bersurat ke LAN meminta perpanjangan waktu untuk WI yang belum S2 agar bisa misal selama 2/3 tahun untuk menyelesaikan studinya dulu, baru diberhentikan? Terima kasih
[8/10/2025 15.27] Nasru: info yang saya dapat, tidak ada surat permintaan perpanjangan masa pendidikan untuk WI mas
[8/10/2025 15.42] Hargi: siap mas. terima kasih informasinya
[17/10/2025 09.21] Hargi: Izin mas Nasru mau lanjut konsultasi lagi, rekan saya ex prakom DJA yg SMA infonya akan dimutasi ke DJA setelah atau berbarengan keluar SK pemberhentian, kata beliau udh disetujui sama kabag SDM DJA, bahkan dijanjiin cuma turun 2 grade (beliau skrg penyelia sekarang grade 13, nanti di DJA dijanjiin grade 11).
[17/10/2025 09.22] Hargi: Mau bertanya kalo saya D1 bisa dapat grade berapa ya mas kalo mutasi ke BPPK?
[17/10/2025 09.23] Nasru: saya konfirmasi ke PIC grade dulu ya mas
[17/10/2025 09.43] Hargi: siap, terima kasih banyak mas
[17/10/2025 10.17] Nasru: oiya mas, untuk grade, td kami dapat info dari PIC grading, kalau pangkat III.a dan pendidikan terakhir D1 , maksimal gradingnya 8 mas
[17/10/2025 10.17] Nasru: terkait perpindahan, sama seperti yang kami sampaikan sebelumnya ya mas, mas hargi koordinasikan dulu ke bagian SDM nya Batii
[17/10/2025 10.18] Nasru: jika disetujui oleh SDM Batii, nanti ber ND ke BPPK, setelah ada ND akan kami bantu ke pak sesnya mas
[17/10/2025 11.42] Hargi: Siap terima kasih banyak informasinya ya
[17/10/2025 12.26] Nasru: Sami2 mas
[17/10/2025 12.32] Nasru: Btw, apa bisa dimintakan ke temannya yang dari DJA mas, dasar hukum terkait penetapan grade lulusan SMA jadi 11
[17/10/2025 12.33] Nasru: Supaya bisa saya sampaikan ke PIC grading BPPK
[17/10/2025 17.51] Hargi: Siap nanti saya tanyakan mas
[17/10/2025 18.11] Nasru: Terima kasih mas
[21/10/2025 09.07] Nasru: assalaamualaykum mas, maaf apa sudah dapat peraturan yang menjadi dasar hukum penetapan grading ini dari temannya mas?
[21/10/2025 09.08] Nasru: oiya mas, mutasi ke DJA ini maksudnya prosesnya bagaimana ya mas? apa DJA saat ini sudah ber ND ke Batii untuk minta mantan prakomnya, atau bagaimana mas?
[21/10/2025 09.09] Hargi: belum mas, saya khawatir ini cuma asusmsi beliau
[21/10/2025 09.09] Hargi: ini baru informal mas
[21/10/2025 09.12] Nasru: oo, berarti sudah ada kesepakatan informal antara DJA dan Batii untuk pemindahan ini ya mas?
[21/10/2025 09.15] Hargi: iya sudah mas, DJA juga butuh prakom probisnya banyak yg ngeluh teknis IT
[21/10/2025 09.32] Nasru: oiya, mas hargi tp belum minta ke Bagian SDM Batii untuk pindah ke BPPK lagi ya mas?
[21/10/2025 09.33] Hargi: belum mas, rencana hari ini mas.
[21/10/2025 09.35] Nasru: misal nanti grade nya beneran mentok di grade 8 saat balik ke BPPK, apa tidak mengapa mas?
[21/10/2025 12.11] Hargi: Ya gak papa mas.
[21/10/2025 14.10] Nasru: baik mas, semoga ada ketentuan yang memang mengatur agar grade tidak terlalu turun ya mas, jika mas dapat ketentuannya, bisa dikirim ke saya, nanti saya sampaikan ke PIC grading BPPK
[21/10/2025 14.13] Nasru: jika nanti sudah ada info hasil pertemuan dengan bagian SM Batii, tolong saya dikabari ya mas
[21/10/2025 14.13] Nasru: untuk saya laporkan ke atasan
[21/10/2025 14.17] Hargi: siap mas, nanti saya infokan ya, teirma kasih banyak sebelumnya
[21/10/2025 14.17] Nasru: sami2 mas
[22/10/2025 11.18] Hargi: Infonya karena beliau pegawai lama, waktu msh pelaksana ini beliau ada history dpt grade 11 di hris. 
Apa mungkin pas waktu itu blm ada aturan grade based on pendidikan ya
[22/10/2025 11.19] Nasru: dulu belum ada mas
[22/10/2025 11.19] Nasru: mas ingat apa ndak mas, grade terakhir sebagai pelaksana?
[22/10/2025 11.19] Nasru: atau mungkin ada di data hris mas hargi
[22/10/2025 11.20] Hargi: Gak ada mas. Di hris jg gak ada history nya.
[22/10/2025 11.21] Nasru: mas hargi jadi pelaksana berapa tahun mas?
[22/10/2025 11.32] Hargi: September 2009 diangkat prakom mas
[23/10/2025 08.09] Nasru: oiya ,mas, apa sudah jadi koordinasi ke bagian SDM nya Batii? tanggapan mereka bagaimana ya mas?
[23/10/2025 08.11] Hargi: baru informal ke mas Ikhwan kemarin lusa mas
[23/10/2025 08.12] Nasru: baik mas, oiya apa Bagian SDM nya akan ber ND ke kami untuk pemindahan mas hargi ke BPPK?
[23/10/2025 08.13] Hargi: siap mas, nanti saya koordinasikan
[23/10/2025 08.13] Nasru: baik mas, nanti tolong saya dikabari updatenya ya mas? untuk saya laporkan ke atasan
[24/10/2025 09.40] Nasru: oiya mas, hasil koordinasi dengan bagian SDM nya bagaimana mas?
[24/10/2025 12.36] Hargi: Sebentar mas.
[24/10/2025 12.37] Hargi: Kalo formasi jafung arsiparis atau pustakawan apa bisa ya mas?
[24/10/2025 12.38] Hargi: Agar grade nya gak turun drastis, temen saya yg DJA katanya mau dijadiin arsiparis. Mutasi masih prakom DJA, terus alih jabatan arsiparis
[24/10/2025 12.39] Nasru: Nanti saya cek dulu mas
[24/10/2025 12.39] Nasru: Pustakawan minimal D3 mas, Arsiparis nanti saya cek dulu
[24/10/2025 12.39] Hargi: Siap
[24/10/2025 13.10] Nasru: Pustakawan dan Arsiparis minimal D3 semua mas
[24/10/2025 13.10] Hargi: siap terima kasih mas
[10/11/2025 10.55] Hargi: assalamulaikum mas Nasru. izin update info saat ini infonya SK mutasi sbg pelaksana ke BPPK ke biro SDM sdh dikirim BaTii, kebetulan tadi saya ditawarin sesama prakom terdampak yg ke DJA, info beliau kabag SDM DJA butuh org IT & menjanjikan grade 9-10
[10/11/2025 10.56] Hargi: izin apakah saya bisa minta info nanti di BPPK dpt grade berapa?
[10/11/2025 10.57] Hargi: rencana mau ke biro SDM siapa tahu bisa revisi SK agar diganti ke DJA saja. mohon maaf ngrepotin ya mas 🙏
[10/11/2025 11.02] Nasru: Waalaykumussalam warahmatullahi wabarakatuh
[10/11/2025 11.03] Nasru: kalau setahu saya, yang sudah dikirimkan Batii ke Biro SDM itu, ND permohonan pemindahan mas hargi sebagai pelaksana ke BPPK ya mas, apa SK nya mungkin nanti dari Biro SDM ya
[10/11/2025 11.04] Hargi: iya, kemungkinan SK mutasi sedang diproses mas, karna antar UE!, SK dari biro SDM
[10/11/2025 11.04] Hargi: kalo pemberhentian sbg prakom, dari ses BaTii udh cukup
[10/11/2025 11.06] Nasru: kalau grading, setahu PIC Grading di sini, akan ditetapkan dengan grading terakhir sebagai pelaksana mas, tp kami juga belum menemukan SK grading terakhir mas hargi sebagai pelaksana
[10/11/2025 11.07] Hargi: siap mas. Terima kasih informasinya
[21/4 13.44] Nasru: assalaamualaykum mas
[21/4 13.47] Nasru: oiya mas, apa mas ninin berkenan ngobrol sebentar dengan Bagian SDM, terkait pengajuan banding mas Hargi ke PTUN
[21/4 13.48] Nasru: Bu Lina, Kabag SDM pgn ketemu dengan mas Hargi mas,
[21/4 13.49] Nasru: tp ini mas Hargi ketemunya dengan teh Ajeng , karena Bu Lina masih baru ya di BPPK,
[21/4 15.12] Nasru: oiya mas, kalau siang ini ndak bisa. 
mungkin bisa nanti malam via zoom, atau besok pagi
[21/4 15.18] Hargi: baru selesai ngajar mas, habis ashar saya ke Bagian SDM ya mas
[21/4 15.18] Nasru: ya mas
# Bukti No. 14
- **Tanggal:** 16-10-2025
- **Ringkasan Fakta:** Rekaman pertemuan 16 Okt 2025 di BaTii + transkrip. Hadir: Ikhwan (Kasub AJF), Masayu (Kabag SDM), Riyanto Sihaloho, Penggugat. Mekanisme pemberhentian JF, opsi pengurangan TGR, ketidakmampuan membatalkan SK. Bawa audio asli + pemutar + transkrip nazegelen.
Keterangan Suara:\
(Ikhwan / Ikhwan A. Rahman): Kasub AJF BaTii yang menjelaskan aturan\
(Hargi / Ninin Sapto Hargiyanto): Peserta rapat\
(Riyanto Sihaloho): Pegawai (JF Prakom) yang terdampak pemberhentian\
(Masayu): Kabag SDM BaTii (Pimpinan rapat)\
[00:00](Ikhwan): Kata-kata, kata-kata pertama... Kalau ada kata-kata pertama, itu pengangkatan pertama.\
[00:03](Ikhwan): Enggak, pengangkatan, coba definisi pengangkatan. Definisi, ini pengangkatan, pengangkatan itu ada pengangkatan pertama, itu adalah yang dari CPNS. Pengangkatan itu dari macam-macam. Pengangkatan pertama itu, term yang digunakan untuk CPNS. Kalau dari pelaksana itu namanya, atau dari pelaksana atau dari jabatan fungsional lainnya, itu namanya perpindahan jabatan. Bukan pengangkatan pertama.\
[00:16](Ikhwan): Yang dicabut itu pengangkatan PNS dalam JF. Jadi orang yang mau diangkat...\
[00:19](Ikhwan): Nggak ada kata-kata PNS, pengangkatan dalam JF. Coba buka di situ pasal 12. Definisi pengangkatan dalam JF itu apa? Pasal 12. Kamu kalau ngomong pengangkatan pertama, kita di Kementerian Keuangan enggak pernah pakai pengangkatan pertama. Pengangkatan pertama itu dari CPNS langsung dia jadi JF. Begitu dia jadi PNS, dia langsung jadi JF. Kamu kalau enggak percaya, buka peraturan, buka situsnya BKN. Nih tak kirimin link-nya. Ini ada jelas penjelasannya di situ. Kalau pelaksana, itu masuknya perpindahan dari jabatan. Di situ. Nah, ini, ini adalah bagian dari pengangkatan PNS ke dalam JF. Jadi seorang PNS diangkat dalam JF itu ada 4. Satu, pengangkatan pertama. Dua, perpindahan dari jabatan lain. Ini kita nih, pakainya yang PJL. Dari, dari pelaksana ke Prakom, dari eselon 4 ke Prakom, atau ke JF lain, eselon 3 ke JF, itu bisa. Yang ketiga, namanya penyesuaian. Ini kalau dari eselon 4 ke Muda. Tiga ke Madya. Yang terakhir promosi. Promosi itu kalau dari pelaksana ke Muda itu promosi. Dari eselon 4 ke Madya itu promosi. Jadi ada empat, pengangkatan ini.\
[01:10](Ikhwan): Nah, di situ ada pasal pemberhentian. Pasal pemberhentian itu ada, tapi enggak kamu masukin, Dek. Di pasal, Permenpan 1 itu juga ada pasal pemberhentian.\
[01:17](Ikhwan): Coba, cari di pasal 41. Pemberhentian dari JF. Pejabat fungsional, ini berarti orang yang dalam jabatan ya. Diberhentikan dari jabatannya apabila: 1. mengundurkan diri, bla bla bla bla, sampai dengan f. tidak memenuhi persyaratan JF. Semua, kalau kamu cek, semua Permenpan yang mengatur JF, entah JF PK, entah JF Widyaiswara, entah yang lain, itu A sampai F ini ditaruh semuanya. Kamu cek deh, kamu minta SK-nya WI yang kemarin diberhentikan, itu juga karena pendidikan. Kalau pendidikan itu susah, enggak bisa kita nego.\
[02:05](Hargi): Iya, tapi belum ada peraturan di tengah-tengah peraturan itu yang... ada kata-kata disesuaikan dan wajib dicabut itu nggak ada. Kalau di kasus ini ada.\
[02:10](Ikhwan): Ya iyalah, yang pertengahan, misalnya WI diberhentikan, di pertengahan sebelum WI diberhentikan dan jangka waktu itu enggak ada peraturan yang mencabut di tengah-tengahnya.\
[02:14](Hargi): Kalau ini kan ada.\
[02:15](Ikhwan): Ini adalah peraturan yang secara jenderal untuk mencabut angka kredit dan kawan-kawannya, yang waktu itu Dupak. Karena di, karena di sini ada peraturan yang terkait SKP. Gitu loh. Jadi kalau, kalau dia bertentangan, ini nggak bertentangan. Coba lihat pemberhentian dari JF yang di sini sama yang di sana, sama persis. Jadi, kamu itu nggak bisa pakai yang pengangkatan, karena kamu bukan diangkat saat itu. Tapi kamu diangkat di tahun sebelum 2020. Kalau kamu diangkat, boleh tuh, dari SMA. Pasal ini berlaku.\
[02:48](Hargi): Itu kan masuknya ke wajib disesuaikan ya? Maksudnya semua peraturan...\
[02:50](Ikhwan): Loh ini dia nggak wajib karena nggak bertentangan.\
[02:53](Hargi): Bertentangan? Karena sebelumnya ada kata-kata D3, sekarang ada minimal SMA.\
[02:58](Ikhwan): Ya itu kan penafsiranmu. Kalau, kalau di pengangkatan pertama, itu bisa disesuaikan, pengangkatan pertama orang yang mau diangkat, itu bisa disesuaikan, itupun masih ada klausul sesuai dengan kebutuhan di JF Keterampilan itu. Gitu loh, Bro. Jadi, ini kalau aku udah kayak gini berarti udah susah opsinya. Jadi yang bisa kita bantu, Pak, ini mohon maaf nggih, Pak, itu untuk meminimalisir TGR atau menghilangkan TGR. Kalau untuk pemberhentiannya kita enggak bisa bantu. Gitu, karena ini nggak cuman JF Prakom, Pak, di JF di kementerian lain pun sama, di BC juga sama. 3 tahun lagi mau pensiun disuruh ini Pak, disuruh kuliah. Kita itu udah nanya-nanya ke Organta, ke Biro SDM, dan pilihannya memang diberhentikan. Masalahnya kalau nggak diberhentikan sekarang, itu nanti argo TGR-nya bisa jalan terus. Makanya kalau kemarin kita kirim ND itu biar segera diproses, pemberhentiannya kita proses dulu, TGR-nya kita carikan solusi, bisa enggak ini untuk enggak kena TGR. Ini kami barusan dari Organta juga sama, Pak. Maksudnya, untuk bantuin jenengan-jenengan ini, tapi ya nggak cuman ini, maksudnya ada beberapa, ada banyak hal yang didiskusikan tadi. Termasuk kami ke BPS juga. Nah maksud, maksud kami gitu loh Pak. Kalau yang untuk pemberhentiannya udah nggak bisa karena memang nggak sesuai standar, sama standar jabatan, karena temen-temen itu sudah menjabat. Gitu loh, ini bukan pasal yang bertentangan tadi, karena yang bertentangan adalah pengangkatan orang dalam JF. Pertama kali, entah kamu pakai yang pertama, atau penyesuaian, atau promosi, atau PJL, itu namanya pengangkatan JF. Gitu loh.\
[04:22](Ikhwan): Nah, sebenarnya kami itu udah punya beberapa opsi, Pak, untuk Pak Riyanto. Cuman opsi-opsi yang kami coba ini agak susah ya, contohnya gini. Kami juga udah ngomong sama Pak... Pak siapa namanya, Pak Ernawan, sama Bu Yulia, maksudnya tempatin Bapaknya kalau masih pengen di sini, tempatin Bapaknya di tempat-tempat yang ada ya lemburannya atau tambahannya, gitu loh. Karena 14 ke 6 itu kan ya berat. Nah saya nggak tahu kalau di DJA apakah bisa ke 11 atau nggak, nggak tahu saya, tapi kalau jenengan kemarin pengen ke DJA, ya kita bantu untuk usahakan balik, gitu Pak.\
[04:52](Ikhwan): Nah, kami lagi mencoba mengusahakan yang TGR-nya biar nggak kena, kayak jenengan kan kemarin bilang kayak gitu, gitu loh.\
[05:00](Riyanto): Kalau saya sih berpikirnya gini, seolah-olah aku pindah ke BTI ini buat dipecat doang. Kenapa saya bilang begitu? Kenapa saya... terus terang aja peraturan PP 1 2020 juga, saya tidak pernah disampaikan, dan saya tidak terima ya. Enggak, aku juga nggak bisa salahkan di SDM saya atau di mana, makanya saya pernah saya bilang, apakah dari BTI ini ketika narik kita ke sini nggak ada disisir dulu bahwa di sini adalah Prakom yang SMA? Terus datang ke sini numpang dipecat. Nah itu yang saya sangat tragis ya. Terus ya, kalau yang saya baca tadi peraturan itu tadi kan 2023, saya sih nggak mau lihat itu mau pengangkatan apa nggak, tapi di situ kan masih ada keterampilan. Sementara saya pengen persisnya juga pengen tahu, pemecatan kita ini larinya ke... ke PP 20, PP 23, apa yang SKJ 2024? Maksudnya butirnya itu di mana kira-kira gitu ya. Karena kalau menurut saya itu tadi, peraturan 2023 ini kan peraturan terakhir. Maksudnya menyempurnakan yang 2020. Kalau yang 2024 ini kan semacam keputusan ya, keputusan itu lebih rendah dari peraturan, gitu aja sih ya. Nah kalau saya pribadi tadi masalah juga ditempatkan di sini dikasih apa namanya tadi, supaya menutupi, dikasih dinas, kayaknya menurut saya kurang pas gitu ya.\
[06:38](Ikhwan): Ya itu opsi-opsi yang bisa kita ini sih Pak, bantu, kalau, kalau enggak ya enggak apa-apa gitu loh.\
[06:43](Riyanto): Cuman ini kan seolah-olah saya kan seolah jadi kayak terdakwa nih. Kenapa saya bilang itu tadi, saya nggak ada salah apa-apa tiba-tiba diputuskan gitu bahwa saya diberhentikan dari Prakom. Nah ini saya nggak ada... saya pikiran saya tuh, ya itu tadi, bawa ke sini, nah itu kan sebenarnya bukannya disalah ke kita. Apa nggak ada kebijakan yang lain bahwa, contoh umpanya gini, dibuat surat bahwa Riyanto si anu ini, telah mengerjakan... sampai itu tadi ya, mengerjakan pekerjaan pranata komputer. Jadi sampai satu, masalah TGR dulu ya. Nah maksud saya, seolah-olah kita kan dipotong apa, dipotong TGR itu kita seolah-olah melaksanakan pekerjaan pelaksana. Sementara sampai sekarang saya mengerjakan masih dan itu keputusannya itu kan dari pejabat-pejabat di sini yang menandatangani. Bahkan nyuruh saya dinas atau ke mana atau surat tugas ke sana selama saya tinggal di sini, itu kan mereka harusnya salah juga semua gitu. Kenapa saya dikasih TGR balikin lagi uangnya, seolah-olah... maksud saya tuh buatlah bagaimana caranya itu jangan sampai ada TGR itu aja, Pak ya.\
[07:48](Ikhwan): Iya, ini yang kami usahakan.\
[07:50](Riyanto): Terus yang oke ya perjuangan TGR. Terus perjuangan masalah itu tadi yang pranata komputer sampai dipecat, itu kembali kepada tadi yang disampaikan sama Pak Ikhwan ya. Ya maksud saya, keputusannya tuh sebenarnya saling berkait, di SKJ 2024, sementara SKJ 2024 mengacu kepada PP 1 2020. Tidak menyebutkan Menpan RB 2023. Maksudnya, Menpan 2023 diterbitkan, itu kan sebenarnya mengacu untuk penyempurnaan 2024... eh 2020. Dari 2023 itu dibilang 5 tahun ke depan. 5 tahun, maksudnya... menimbangnya 2024 tuh nggak menyebut 2023 sama sekali. Di situ sudah kelihatan SKJ 2024 itu cacat formil. Karena tidak ada kata menimbang 2023. Jadi dibikin berbarengan, atau yang bikin salah, gitu. Sebenarnya peraturan salah itu nggak apa-apa, saya juga salah, nggak kuliah kan. Cuman kalau salah sampai mengakibatkan kerugian, ini yang harusnya kita perbaiki gitu.\
Jadi kalau saya urutin dari peraturan ini tuh Pak ya. Kenapa tadi nggak kuliah? Satu, saya nggak terima tuh Menpan RB nomor 32 2020, ya. Terus yang kedua, karena keluar Menpan RB 2023, nah saya fokus kepada situ. Ah dalam pikiran saya, saya juga tadinya ibarat kuliah nih Bu, tapi saya udah nggak mampu, saya juga sakit-sakit. Udahlah saya sampai di sini aja, toh nanti saya juga udah pensiun. Jadi saya fokus ke situ. Jadi saya nggak berpikiran, kenapa kemarin... ah, bukannya ibarat yaitu bukan salah saya karena kalau saya baca peraturan itu seharusnya saya nggak diberhentikan. Dalam pikiran saya 1 tahun setengah juga saya udah, udah pensiun. Udah, maksud saya, saya ini aja disyukurin. Jadi bukannya di situ saya kayak gimana ya, semacam kayak terdakwa gitu aja Pak. Gitu aja Bu, jadi seolah-olah Ibu ya timbang-timbanglah ibaratnya. Kita itu kan... saya juga, dari grade sekian terus ke sekian, di samping gajinya dipotong, TGR lagi, ya, saya nggak tahu jugalah bagaimana anak-anak saya. Apakah dalam kepegawaian kan ada istilahnya waktu kita juga waktu diklat tentang kepegawaian, bagaimana jangan sampai merugikan pegawai. Saya nggak tahu itunya tapi harus saya cari dulu ya. Tidak boleh merugikan pegawai, gitu Bu ya dari... kalau nggak salah kalau dari peraturan kepegawaian ya, gitu.\
[09:37](Riyanto): Itu Bu, yang buat masukan ya, mohon pertimbangan dari Ibu sama Bapak.\
[09:40](Masayu): Iya Pak. Jadi, em... itu yang akan kami usahakan. Jadi kalau dari pembacaan... dari pembacaan apa namanya... ketentuannya... itu dari seperti yang Mas Ikhwan sampaikan, itu sudah dikonsultasikan dan... ya... memang diberhentikan. Tapi yang akan kami usahakan adalah tidak ada TGR. Tidak ada TGR. Jadi... setidaknya yang kemarin itu ya sudah enggak ada, tidak, tidak perlu ada pengembalian. Meskipun kemarin kami udah sempat mengatakan ada pemberhentian dan ada pengembalian dan sudah dimulai, ya itu kan jadi tanggung jawab kami untuk mengubah itu juga. Itu yang sedang kami usahakan. Dan, em... itu yang akan kami sampaikan juga ke BPS sama Kemenpan RB. Terkait dengan TMT ini apakah bisa kita TMT-kan terdekat saja. Jadi tidak surut ke atau tidak per 1 Juli 2020...\
Ya, kalau... Izin Pak, eh terkait dengan yang... terkait dengan informasi... eh saya tidak membela diri karena saya belum di sini sebelumnya. Eh kami hanya melihat ke data... apa namanya... historical-nya... bahwa temen-temen di Pusintek dulu, pengembangan JF Pusintek dulu, itu sudah menyampaikan informasi itu ke... temen-temen pengelola SDM di DJA. Yang seharusnya berarti itu sudah di-distribute, gitu, sudah semua. Dan bahwa temen-temen lain, ada banyak juga JF lain di... DJP, di... BC, yang kemudian mereka mengejar untuk bisa... kuliah karena... setelah dapat info ada apa, ada ketentuan terkait yang Permenpan 32 itu. Sehingga kenapa kemudian kami... eh melakukan ini karena sebagai pengelola kepegawaian kan juga ada fairness yang harus kami jaga ya Pak ya. Terhadap teman-teman juga yang di unit-unit lain yang mereka berusaha keras ini untuk akhirnya dengan segala cara untuk menyelesaikan atau memenuhi minimal... pendidikan itu. Nah, terkait dengan kok jadi kayak seolah-olah dipindahin ke BTI jadi kayak hanya untuk diberhentikan, nah itu yang memang mal-administrasinya. Jadi, seandainya dulu kemudian... proses pemberhentian itu sudah dilakukan Pak per 1 Juli, Bapak berarti enggak akan ikut ke... BTI, karena yang ikut ke BTI hanya... Prakom.\
[11:15](Riyanto): Jadi, kebetulan kalau saya cerita sedikit ke belakang, di tempat saya dulu... aku kan ada data center sendiri juga dulu di DJA. Jadi ketika saya masuk Prakom itu kan dari inpassing Bu. Nah apabila udah di TI, apa namanya, teknologi informasi sekian tahun bisa inpassing. Dan saya masuk inpassing makanya itu tadi urutannya itu... ketemu namanya apa tuh... Menpan 2023 itu kan, karena saya masuk inpassing itu kan SK-nya tuh 2018... terus dilantik 2019. Nah, sebelum saya masuk Prakom itu, kan dia saya dipanggil sama kepegawaian. "Pak Riyanto bener masuk Prakom? Iya. Tapi ini grade-nya turun loh Pak." Segitunya lah maksud saya, saya turunlah grade-nya itu 2... 2 tahunnya. Ya, harusnya saya, hal yang penting bisa naik pangkat dan juga bisa jadi Prakom, begitu. Nah di situ, 2 tahun saya turun grade, setelah itu baru normal ya, naiklah grade saya karena maksudnya itulah perjuangan Bu. Maksudnya, ketika saya masuk Prakom itu ya merasa senanglah. Jadi saya juga di sana di DJA itu nanganin duktek. Sampai saya pindah ke sini, sebelum pindah juga ke sini saya dipanggil sama teman sama BMN. "Pak Riyanto di sini aja, nanganin ini, siapa? Karena ini active directory mau join domain, mau install segala macam." Sampai saya pun pindah ke sini waktu itu sama Pak Ernawan juga ngomong, "Pak saya kerjaan di sana masih ada ya, tapi nggak mungkin saya tinggal spontan begitu karena mereka juga masih punya kontak saya", kan gitu kan. Nah karena di sana juga walaupun ada teman kita mantan duktek ya, temen-temen yang baru, dibilang, "Oh itu bukan tusi saya". Tapi secara karena saya juga sama pegawai itu saya satu juga ngomong sama atasan, masih ada nggak kerjaan di sana? Ada kerjaan, kadang saya remote, dan sana terakhir itu masih ada PC remote teman-teman itu ada 20-an biji, dan juga server development itu masih ada, tetap saya tangani. Jadi... maksud saya, di situlah Bu, bahwa pekerjaan kalau seumpamanya saya nggak pindah ke sini, masih bisa saya tinggal di sana, dan kebetulan ya maaf nih Bu ya... (rekaman terpotong)}
# Bukti No. 15
- **Tanggal:** 23-10-2025
- **Ringkasan Fakta:** Petikan KMK 188/MK/SJ.5/2025 a.n. Riyanto Sihaloho (ditetapkan 23 Okt, berlaku 1 Nov 2025). Rekan sejawat yang juga diberhentikan namun diperlakukan PROSPEKTIF.
Inti: Bukti SK pembanding atas nama rekan sejawat yang juga diberhentikan namun secara adil diberlakukan secara prospektif (tidak berlaku surut).
# Bukti No. 16
- **Tanggal:** 01-11-2025
- **Ringkasan Fakta:** Petikan KMK 188/MK/SJ.5/2025 a.n. Agus Riyanto (berlaku 1 Nov 2025). Pembanding prospektif kedua.
Inti: Bukti SK pembanding kedua atas rekan sejawat yang juga diberlakukan secara prospektif, sebagai alat bukti adanya pelanggaran asas nondiskriminatif.
# Bukti No. 17
- **Tanggal:** 07-11-2025
- **Ringkasan Fakta:** ST-182/TI.1/2025 dari Sekretaris BaTii (Moch. Ali Hanafiah): penugasan Penggugat mengikuti Training Data Science & Machine Learning 10–14 Nov 2025, tercatat sebagai "Prakom Mahir". Penggugat MASIH diakui/ditugaskan sebagai Prakom Mahir SETELAH tanggal berlaku surut SK pemberhentian (1 Nov 2025).
## KEMENTERIAN KEUANGAN REPUBLIK INDONESIA
## BADAN TEKNOLOGI, INFORMASI, DAN INTELIJEN KEUANGAN
## SEKRETARIAT BADAN TEKNOLOGI, INFORMASI, DAN INTELIJEN
## KEUANGAN
## GEDUNG JB. SUMARLIN LANTAI 1-6, JALAN DR. WAHIDIN RAYA NO. 1, JAKARTA 10710
## SURAT TUGAS
## NOMOR ST-182/TI.1/2025
Dalam rangka meningkatkan kompetensi pegawai terkait pengelolaan dan analisis data,
bersama ini kami menugaskan pejabat/pegawai sebagaimana terlampir untuk mengikuti Training
Data Science and Machine Learning yang akan dilaksanakan pada:
Hari/Tanggal:    Senin s.d. Jumat/10 s.d. 14 November 2025
Waktu:    Pukul 09.00 WIB s.d. selesai
## Tempat:    Swiss Belinn Wahid Hasyim,
Jl. K.H. Wahid Hasyim No.135 - 137, Tanah Abang
Kepada yang bersangkutan agar menyampaikan laporan kepada kami sebelum dan
setelah selesai melaksanakan penugasan dimaksud.
Segala biaya yang timbul akibat dilaksanakan Surat Tugas ini dibebankan pada DIPA
Satuan Kerja Pengelolaan, Pengembangan, dan Pengawasan BUN Tahun Anggaran 2025.
Demikian Surat Tugas ini ditetapkan untuk dilaksanakan dengan sebaik-baiknya dan
penuh tanggung jawab.
## Jakarta, 7 November 2025
## SEKRETARIS BADAN,
Ditandatangani secara elektronik
## MOCH. ALI HANAFIAH
## 2
## LAMPIRAN
## Surat Tugas Sekretaris Badan
Nomor: ST-182/TI.1/2025
## Tanggal: 7 November 2025
Daftar Peserta Training Data Science and Machine Learning
NoNama/NIPPangkat/GolJabatan
## 1.
## Megananda Hervita P. S./
## 198710102010122001
Penata/IIIc
Prakom Muda pada Pusat Data
dan Informasi
## 2.
## Mega Rulliana/
## 198501152010122001
## Penata Muda
Tk.I/IIIb
Prakom Pertama pada Pusat
Data dan Informasi
## 3.
## Ilmi Hayyu Dinna/
## 198710222010122003
## Penata Muda
Tk.I/IIIb
Prakom Pertama pada Pusat
Data dan Informasi
## 4.
## Titik Susilowati/
## 199204112015022006
Penata Muda/IIIa
Prakom Pertama pada Pusat
Data dan Informasi
## 5.
## Ninin Sapto Hargiyanto/
## 198607202007011001
Penata Muda/IIIa
Prakom Mahir pada Pusat Data
dan Informasi
## 6.
## Prapida Dwi Saputra/
## 199107192014021001
Penata Muda/IIIa
Prakom Mahir pada Pusat Data
dan Informasi
## 7.
## Riza Fahlevi/
## 199605012018011006
Penata Muda/IIIa
Pelaksana pada Pusat Data dan
## Informasi
## SEKRETARIS BADAN,
Ditandatangani secara elektronik
## MOCH. ALI HANAFIAH
# Bukti No. 18
- **Tanggal:** 13-11-2025
- **Ringkasan Fakta:** KMK 199/MK/SJ.5/2025: Pemberhentian dari JF Pranata Komputer Mahir + Pemindahan PNS antar Unit JPT Madya. Ditetapkan 13 Nov 2025, berlaku surut sejak 1 Nov 2025.
**Isi dokumen (teks lengkap KTUN):**
MENTERI KEUANGAN
REPUBLIK INDONESIA
SALINAN
KEPUTUSAN MENTERI KEUANGAN REPUBLIK INDONESIA
NOMOR 199 /MK/SJ.5/2025
TENTANG
PEMBERHENTIAN DARI JABATAN FUNGSIONAL PRANATA KOMPUTER MAHIR
DAN PEMINDAHAN PEGAWAI NEGERI SIPIL ANTAR UNIT JABATAN PIMPINAN
TINGGI MADYA DI LINGKUNGAN KEMENTERIAN KEUANGAN
ATAS NAMA SDR. NININ SAPTO HARGIYANTO (NIP 19860720 200701 1 001)
Menimbang
MENTERI KEUANGAN REPUBLIK INDONESIA,
a. bahwa Sdr. Ninin Sapto Hargiyanto (NIP 19860720
200701 1 001) Penata Muda (III/a) Pranata Komputer
Mahir pada Badan Teknologi, Informasi, dan Intelijen
Keuangan tidak memenuhi kualifikasi pendidikan yang
dipersyaratkan untuk menduduki Jabatan Fungsional
Pranata Komputer Mahir sesuai dengan peraturan
perundang-undangan terkait Jabatan Fungsional
Pranata Komputer,
. bahwa Sdr. Ninin Sapto Hargiyanto (NIP 19860720
200701 1 001) Penata Muda (III/a) mengajukan
permohonan mutasi Pelaksana ke lingkungan Badan
Pendidikan dan Pelatihan Keuangan,
. bahwa dengan mempertimbangkan huruf a dan huruf b
di atas, Sekretaris Badan Teknologi, Informasi, dan
Intelijen Keuangan dengan Nota Dinas Nomor ND-
684/TI.1/2025 mengusulkan pemberhentian Sdr. Ninin
Sapto Hargiyanto (NIP 19860720 200701 1 001) Penata
Muda (III/a) dari Jabatan Pranata Komputer Mahir dan
menyetujui permohonan mutasi ke lingkungan Badan
Pendidikan dan Pelatihan Keuangan:
. bahwa berdasarkan pertimbangan sebagaimana
dimaksud dalam huruf a, huruf b, dan huruf c perlu
menetapkan Keputusan Menteri Keuangan tentang
Pemberhentian dari Jabatan Fungsional Pranata
Komputer Mahir dan Pemindahan Pegawai Negeri Sipil
antar Unit Jabatan Pimpinan Tinggi Madya di
Lingkungan Kementerian Keuangan atas nama Sdr.
Ninin Sapto Hargiyanto (NIP 19860720 200701 1 001);
Mengingat
Menetapkan
KESATU
KEDUA
1. Undang-Undang Nomor 20 Tahun 2023 tentang
Aparatur Sipil Negara (Lembaran Negara Republik
Indonesia Tahun 2023 Nomor 141, Tambahan Lembaran
Negara Republik Indonesia Nomor 6897):
2. Peraturan Pemerintah Nomor 11 Tahun 2017 tentang
Manajemen Pegawai Negeri Sipil (Lembaran Negara
Republik Indonesia Tahun 2017 Nomor 63, Tambahan
Lembaran Negara Republik Indonesia Nomor 6037)
sebagaimana telah diubah dengan Peraturan
Pemerintah Nomor 17 Tahun 2020 (Lembaran Negara
Republik Indonesia Tahun 2020 Nomor 68, Tambahan
Lembaran Negara Republik Indonesia Nomor 6477),
3. Peraturan Menteri Pendayagunaan Aparatur Negara dan
Reformasi Birokrasi Nomor 1 Tahun 2023 tentang
Jabatan Fungsional (Berita Negara Republik Indonesia
Tahun 2023 Nomor 54),
4. Peraturan Menteri Keuangan Nomor 224/PMK.01/2020
tentang Manajemen Karier di Lingkungan Kementerian
Keuangan (Berita Negara Republik Indonesia Tahun
2020 Nomor 1656),
5. Keputusan Menteri Keuangan Nomor 74/KMK.01/2012
tentang Penunjukan Para Pejabat di Lingkungan
Kementerian Keuangan yang Diberi Kuasa untuk dan
Atas Nama Menteri Keuangan Menandatangani
Surat/Keputusan Mutasi Kepegawaian dan Lain
Sebagainya di Bidang Kepegawaian sebagaimana telah
diubah dengan Keputusan Menteri Keuangan Nomor
404/KMK.01/2013;
MEMUTUSKAN:
KEPUTUSAN  'MENTERI KEUANGAN TENTANG
PEMBERHENTIAN DARI JABATAN FUNGSIONAL PRANATA
KOMPUTER MAHIR DAN PEMINDAHAN PEGAWAI NEGERI
SIPIL ANTAR UNIT JABATAN PIMPINAN TINGGI MADYA DI
LINGKUNGAN KEMENTERIAN KEUANGAN ATAS NAMA
SDR. NININ SAPTO HARGIYANTO (NIP 19860720 200701 1
001).
Memberhentikan dengan hormat Sdr. Ninin Sapto
Hargiyanto (NIP 19860720 200701 1 001) Penata Muda
(HI/a) dari jabatannya sebagai Pranata Komputer Mahir
terhitung mulai tanggal 1 November 2025 dengan ucapan
terima kasih atas pelaksanaan tugas dan pekerjaannya
selama ini.
Memindahkan Sdr. Ninin Sapto Hargiyanto (NIP 19860720
200701 1 001) Penata Muda (IlI/a) ke dalam jabatan
KETIGA
KEEMPAT
KELIMA
Pelaksana pada Badan Pendidikan dan Pelatihan Keuangan
terhitung mulai tanggal 1 November 2025.
Atasan langsung pada tempat kedudukan baru wajib
melakukan pembekalan terkait tugas, fungsi, target kinerja
serta melakukan pengembangan kompetensi yang
diperlukan dalam pelaksanaan tugas jabatan kepada
Pegawai Negeri Sipil sebagaimana dimaksud dalam Diktum
KEDUA.
Apabila di kemudian hari ternyata terdapat kekeliruan
dalam Keputusan Menteri ini akan diadakan perbaikan
sebagaimana mestinya.
Keputusan Menteri ini mulai berlaku pada tanggal
ditetapkan dan berlaku surut sejak 1 November 2025.
Salinan Keputusan Menteri ini disampaikan kepada:
1. Menteri Keuangan,
2. Kepala Badan Kepegawaian Negara,
3. Sekretaris Badan Teknologi Informasi dan Intelijen
Keuangan, Kementerian Keuangan,
4. Sekretaris Badan Pendidikan dan Pelatihan Keuangan,
Kementerian Keuangan,
5. Kepala Biro Perencanaan dan Keuangan, Kementerian
Keuangan,
6. Kepala Kantor Pelayanan Perbendaharaan Negara
terkait:
7. Kepala Bagian Perencanaan dan Pengadaan Sumber
Daya Manusia, Biro Sumber Daya Manusia,
Kementerian Keuangan,
8. Sdr. Ninin Sapto Hargiyanto (NIP 19860720 200701 1
001).
Ditetapkan di Jakarta
pada tanggal 13 November 2025
a.n. MENTERI KEUANGAN REPUBLIK INDONESIA
KEPALA BIRO SUMBER DAYA MANUSIA,
ttd.
RUKIJO
Salinan sesuai dengan aslinya,
Kepala Bagian Mutasi dan Kepangkatan
# Bukti No. 19
- **Tanggal:** —
- **Ringkasan Fakta:** Tagihan & bukti bayar PNBP via SIMPONI untuk pengembalian tunjangan kinerja November 2025, cicilan 10 × Rp150.000. Kerugian konkret akibat keberlakuan surut (clawback).
Inti: Bukti cetak tanda terima pembayaran dan tagihan PNBP melalui sistem SIMPONI sebagai pengembalian paksa tunjangan kinerja akibat SK yang berlaku surut.
# Bukti No. 20
- **Tanggal:** —
- **Ringkasan Fakta:** Rekening koran: perbandingan penghasilan Agustus 2025 vs Februari 2026 + bukti pemotongan. Kerugian materiil riil dan terukur.
Inti: Rekening koran bank yang membuktikan kerugian materiil secara riil akibat pemotongan jabatan fungsional dan penarikan tunjangan kinerja secara retroaktif.
# Bukti No. 21
- **Tanggal:** 23-12-2025
- **Ringkasan Fakta:** Surat Keberatan Administratif No. 1/Hargi/2025 kepada Pejabat Pembina Kepegawaian (Menteri Keuangan). Upaya administratif wajib sebelum gugatan PTUN.
Inti: Surat resmi pengajuan upaya keberatan administratif oleh Penggugat kepada Pejabat Pembina Kepegawaian (Tergugat) pada tanggal 23 Desember 2025.
# Bukti No. 22
- **Tanggal:** —
- **Ringkasan Fakta:** Tanda terima resmi penyampaian Surat Keberatan Administratif di Kementerian Keuangan. Formalitas upaya administratif.
Inti: Tanda terima resmi yang membuktikan penyampaian fisik surat Keberatan Administratif Penggugat di Kementerian Keuangan secara sah.
# Bukti No. 23
- **Tanggal:** Januari 2026
- **Ringkasan Fakta:** KMK 9/MK/SJ/2026 menolak keberatan administratif Penggugat secara paripurna. Dibaca via sistem Nadine pada 29 Januari 2026.
Inti: Keputusan Penguatan dari Tergugat Nomor 9/MK/SJ/2026 yang menolak keberatan Penggugat secara paripurna.
# Bukti No. 24
- **Tanggal:** 29-01-2026
- **Ringkasan Fakta:** Screenshot Nadine: SK Penolakan Keberatan (KMK 9/MK/SJ/2026) dibaca elektronik 29 Jan 2026. Patokan perhitungan tenggang waktu 90 hari (jo. SEMA 5/2021).
Inti: Tangkapan layar sistem Nadine yang membuktikan SK Penolakan secara elektronik baru dibaca pada 29 Januari 2026, memastikan gugatan masih dalam tenggang waktu yang sah.
# Bukti No. 25
- **Tanggal:** —
- **Ringkasan Fakta:** Screenshot Nadine: nihil dokumen pemberitahuan, pemanggilan, maupun pemeriksaan sebelum penerbitan objek sengketa. Bukti negatif ketiadaan audiensi (Pasal 41 ayat (5) Permenpan RB 1/2023).
Inti: Tangkapan layar sistem aplikasi persuratan Nadine yang membuktikan ketiadaan dokumen pemberitahuan, pemanggilan, maupun pemeriksaan bagi Penggugat.
# Bukti No. 26
- **Tanggal:** 10-02-2026
- **Ringkasan Fakta:** Printout situs BaTii Kemenkeu: pelantikan/sumpah JF 10 Feb 2026. Teduh Afriyoko dilantik Prakom Penyelia; Naufal Gunaningrat & Sarah Jessica Hutapea dilantik Prakom Ahli Pertama — tanpa latar belakang pendidikan TI. Diskriminasi parameter "bidang TI".
Inti: Dalam Pelantikan dan Pengambilan Sumpah/Janji Jabatan Fungsional di Lingkungan BaTii tanggal 10 Februari 2026, Teduh Afriyoko, S.M. dilantik sebagai Pranata Komputer Penyelia, sedangkan Naufal Gunaningrat, S.M. dan Sarah Jessica Hutapea, S.E. dilantik sebagai Pranata Komputer Ahli Pertama.
# Bukti No. 27
Ringkasan Putusan Nomor: 78/G/2015/PTUN-JKT
*   **Penggugat:** H. AGUS SUSANTO, S.H.
*   **Tergugat:** MENTERI AGAMA REPUBLIK INDONESIA
*   **Objek Sengketa:** "Surat Keputusan Menteri Agama RI No.B.II/3/00311, tanggal 16 Januari 2015 tentang Pemberhentian dari Jabatan Auditor atas nama H. AGUS SUSANTO,SH."
*   **Amar Putusan (M E N G A D I L I):**
    1. "Mengabulkan gugatan Penggugat untuk seluruhnya;"
    2. "Menyatakan batal Surat Keputusan Menteri Agama R.I Nomor : B.II/3/00311 tanggal 16 Januari 2015 tentang Pemberhentian Dari Jabatan Auditor atas nama H. AGUS SUSANTO., S.H.;"
    3. "Mewajibkan Tergugat untuk mencabut Surat Keputusan Menteri Agama RI Nomor B.II/3/00311 tanggal 16 Januari 2015 tentang Pemberhentian Dari Jabatan Auditor atas nama H. AGUS SUSANTO., S.H.;"
    4. "Mewajibkan Tergugat untuk merehabilitasi dan mengembalikan hak dan kewajiban Penggugat pada posisi semula sebagai Fungsional Auditor Ahli Madya ;"
    5. "Menghukum Tergugat untuk membayar biaya perkara sebesar Rp .221.000.-(dua ratus dua puluh satu ribu rupiah);"
---
**Kutipan Verbatim Pertimbangan Hakim (Menimbang):**
Berikut adalah bagian verbatim dari pertimbangan hakim yang memuat isu **prosedur yang tidak dilakukan**, **retroaktif (surut)**, **tidak memperhatikan usaha penggugat**, serta **inkonsistensi tergugat**:
**1. Terkait Prosedur yang Tidak Dilakukan (Tiada Peringatan):**
> "Menimbang, bahwa tindakan Inspektorat Jenderal Kementerian Agama menerbitkan surat usulan pemberhentian sementara tertanggal 29 Desember 2014 sebagaimana dalam bukti T-3, untuk menindaklanjuti hasil evaluasi BPKP tertanggal 29 Desember 2014, sangat mengandung kejanggalan, baik dari tanggal penerbitannya yaitu tanggal 29 Desember 2014 yang bersamaan dengan tanggal hasil evaluasi BPKP, **maupun dari prosedurnya yang tidak terlebih dahulu dilakukan peringatan** sebagaimana yang diatur dalam Peraturan Kepala BPKP Nomor PER-709/K/JF/2009."
**2. Terkait Retroaktif (Surut) & Tidak Memperhatikan Usaha Penggugat:**
> "Di samping itu dari hasil evaluasi BPKP dimaksud seharusnya tidaklah kemudian disikapi oleh Tergugat dengan menerbitkan Surat Keputusan Pemberhentian Sementara Nomor B.II/3/71262 tanggal 31 Desember 2014 **yang diberlakukan surut terhitung mulai tangggal 1 Oktober 2013**, yang semata-mata untuk memenuhi temuan dari hasil evaluasi BPKP, **tanpa mempertimbangkan akibat hukum atas hasil pelaksanaan tugas dan hak-hak yang telah Penggugat lakukan dan terima** dalam kurun waktu mulai 1 Oktober 2013 sampai dengan 31 Desember 2014 yaitu tanggal penerbitan surat keputusan tentang Pemberhentian Sementara dimaksud;"
**3. Terkait Inkonsistensi Tergugat (Perbedaan Penyebutan Jabatan pada Objek Sengketa):**
> "Menimbang, bahwa dari dalil gugatan Penggugat dan jawaban Tergugat atas dalil gugatan Penggugat tersebut di atas, Majelis Hakim berpendapat bahwa **Tergugat mengakui adanya perbedaan antara Jabatan Auditor dengan Jabatan Fungsional Auditor Kepegawaian**, hal ini sesuai dengan pengertian dan adanya fakta pengaturan yang berbeda dari kedua jabatan tersebut sebagai uraian dalam pertimbangan di atas. **Oleh karenanya fakta adanya perbedaan antara judul dengan diktum surat keputusan obyek sengketa, dapat menimbulkan maksud yang berbeda** dari tujuan diterbitkannya surat keputusan obyek sengketa yaitu apakah Penggugat diberhentikan dari jabatan Fungsional Auditor ataukan jabatan Fungsional Kepegawaian, sementara itu jabatan Penggugat yang benar adalah jabatan Fungsional Auditor;"
>
> "Menimbang, bahwa adanya fakta perbedaan penyebutan jabatan Penggugat dalam surat keputusan obyek sengketa telah membuktikan bahwa secara substansial surat keputusan obyek sengketa mengandung cacat yuridis;"
# Bukti No. 28
Ringkasan Putusan Nomor: 43/G/2019/PTUN.SMD**
*   **Penggugat:** HANSEN, S.H., M.Si.
*   **Tergugat:** BUPATI KUTAI BARAT.
*   **Objek Sengketa:** "KEPUTUSAN BUPATI KUTAI BARAT Nomor: 800.05.860/K.971/2018. Tanggal 31 Desember 2018 Tentang Pemberhentian Karena Melakukan Tindak Pidana Kejahatan Jabatan Atau Tindak Pidana Kejahatan Yang Ada Hubungannya Dengan Jabatan, atas nama Hansen, SH.,M.Si. NIP: 197203172006041010".
*   **Amar Putusan (M E N G A D I L I):**
    **Dalam Eksepsi:**
    *   "Menyatakan eksepsi Tergugat tidak diterima;"
    **Dalam Pokok Perkara:**
    1. "Mengabulkan gugatan Penggugat untuk seluruhnya;"
    2. "Menyatakan batal Surat Keputusan Bupati Kutai Barat Nomor : 800.05.860/K.971/2018 tanggal 31 Desember 2018 tentang Pemberhentian Karena Melakukan Tindak Pidana Kejahatan Jabatan atau Tindak Pidana Kejahatan yang ada Hubungannya dengan Jabatan atas nama Hansen,SH.,M.Si.NIP.197203172006041010;"
    3. "Memerintahkan kepada Tergugat untuk mencabut Surat Keputusan Bupati Kutai Barat Nomor :800.05.860/K.971/2018 tanggal 31 Desember 2018 tentang Pemberhentian Karena Melakukan Tindak Pidana Kejahatan Jabatan atau Tindak Pidana Kejahatan yang ada Hubungannya dengan Jabatan atas nama Hansen,SH.,M.Si.NIP.197203172006041010;"
    4. "Memerintahkan kepada Tergugat dengan kewajiban untuk merehabilitasi hak-hak dan kedudukan Penggugat sebagai Pegawai Negeri Sipil seperti keadaan semula;"
    5. "Menghukum Tergugat untuk membayar biaya perkara yang timbul dalam sengketa ini sejumlah Rp. 336.000,- (Tiga Ratus Tiga Puluh Enam Ribu Rupiah);"
---
**Kutipan Verbatim Pertimbangan Hakim (Menimbang):**
Berikut adalah bagian verbatim dari pertimbangan hakim yang memuat isu terkait **retroaktif (surut)**, **inkonsistensi tergugat**, serta **prosedur yang tidak dilakukan tergugat**:
**1. Terkait Retroaktif (Surut):**
> "Menimbang, bahwa kemudian setelah dikeluarkannya SKB 3 Menteri (bukti T-7), Tergugat menerbitkan objek sengketa a quo (bukti Bukti No. 1 dan T-1) dan dalam penerbitan objek sengketa disebutkan PP Nomor 11 Tahun 2017 dijadikan salah satu dasar peraturan, sementara putusan pengadilan T-2 di bacakan pada tanggal 2 Mei 2016, artinya SKB 3 Menteri bukti T-7 diterbitkan tanggal 13 September 2018 dan PP Nomor 11 tahun 2017 yang substansinya memberhentikan tidak dengan hormat Penggugat sebagai Pegawai Negeri Sipil **berlaku mundur terhitung tanggal 31 Mei 2018, yang menurut Majelis Hakim tidaklah tepat dalam menghukum seseorang menggunakan dasar hukum yang diterbitkan setelah peristiwa hukum nya telah selesai**;"
**2. Terkait Inkonsistensi Tergugat & Prosedur yang Tidak Dilakukan Tergugat:**
> "Menimbang, bahwa berdasarkan fakta-fakta hukum tersebut diatas, dapat diketahui **Tergugat belum melakukan pemberhentian sementara saat Penggugat pertama kali ditahan** dan bukti Bukti No. 4 dan Bukti No. 6 fakta hukum lain menyatakan bahwa ketika penggugat telah selesai menjalani hukuman penggugat diaktifkan kembali sebagai PNS di lingkungan Kabupaten Kutai Barat;"
> "Menimbang, bahwa dari uraian diatas terbukti ketika penggugat telah selesai menjalani masa hukumannya penggugat kembali aktif sebagai PNS jika hal ini dianalogikan dengan pasal 30 ayat (3) bahwa PNS tidak dapat dijatuhi hukuman disiplin dua kali atau lebih untuk satu pelanggaran disiplin maka penggugat selaku PNS yang dalam fakta hukum pada saat ditahan tidak menerima gaji namun **tidak ditemukan fakta hukum terdapat pemberhentian sementaranya kemudian langsung diberhentikan tidak dengan hormat menurut Majelis Hakim prosedur pemberhentian tidak diproses dengan benar dan oleh karenanya pemberhentian tidak dengan hormat penggugat terbukti telah cacat prosedur**;"
> "Menimbang, bahwa tindakan Tergugat tersebut terbukti bertentangan dengan ketentuan Pasal 88 ayat (2) Undang-Undang Nomor 5 Tahun 2014 tentang Aparatur Sipil Negara, **pemberhentian sementara tidak dilakukan maka Majelis Hakim berpendapat bahwa tindakan Tergugat menerbitkan keputusan objek sengketa a quo tidak memperhatikan prosedur yang sesuai dengan peraturan perundang-undangan**;"
**AMAR (M E N G A D I L I):**
- Dalam Eksepsi: Menyatakan eksepsi Tergugat tidak diterima.
- Dalam Pokok Perkara:
  1. Mengabulkan gugatan Penggugat untuk seluruhnya;
  2. Menyatakan batal SK Bupati Kutai Barat No. 800.05.860/K.971/2018 tanggal 31 Desember 2018 tentang Pemberhentian Karena Melakukan Tindak Pidana Kejahatan Jabatan atau Tindak Pidana Kejahatan yang ada Hubungannya dengan Jabatan a.n. Hansen, S.H., M.Si.;
  3. Memerintahkan Tergugat untuk mencabut SK tersebut;
  4. Memerintahkan Tergugat merehabilitasi hak-hak dan kedudukan Penggugat sebagai PNS seperti keadaan semula;
  5. Menghukum Tergugat membayar biaya perkara Rp336.000,-.
- Diputus 26 November 2019, diucapkan 27 November 2019 (Majelis: Dedi Wisudawan Gamadi [Ketua], Ayi Solehudin, Febrina Permadi).
# Bukti No. 29
Ringkasan Putusan Nomor: 146/G/2019/PTUN-JKT
*   **Penggugat:** Drs. Sapari, Apt., M.Kes.
*   **Tergugat:** Kepala Badan Pengawas Obat dan Makanan Republik Indonesia.
*   **Objek Sengketa:** "Surat Keputusan Kepala Badan Pengawas Obat dan Makanan Republik Indonesia Nomor: 00032/15014/AZ/03/19, tanggal 26 Maret 2019, tentang Pemberian Kenaikan Pangkat Pengabdian, Pemberhentian dan Pemberian Pensiun Pegawai Negeri Sipil Yang Mencapai Batas Usia Pensiun a.n. Drs. Sapari, APT., M.Kes, beserta lampirannya."
*   **Amar Putusan (M E N G A D I L I):**
    1. "Mengabulkan gugatan Penggugat untuk sebagian ;"
    2. "Menyatakan batal Obyek Sengketa, yaitu Keputusan Kepala Badan Pengawas Obat dan Makanan Republik Indonesia Nomor 00032/15014/AZ/03/19 tanggal 26 Maret 2019 tentang Pemberian Kenaikan Pangkat Pengabdian, Pemberhentian dan Pemberian Pensiun PNS Yang Mencapai Batas Usia Pensiun atas nama Drs. Sapari, Apt., M.Kes ;"
    3. "Mewajibkan Tergugat untuk mencabut obyek sengketa, yaitu Keputusan Kepala Badan Pengawas Obat dan Makanan Republik Indonesia Nomor 00032/15014/AZ/03/19 tanggal 26 Maret 2019 tentang Pemberian Kenaikan Pangkat Pengabdian, Pemberhentian dan Pemberian Pensiun PNS Yang Mencapai Batas Usia Pensiun atas nama Drs. Sapari, Apt., M.Kes ;"
    4. "Menolak gugatan Penggugat untuk selebihnya ;"
    5. "Menghukum Tergugat untuk membayar biaya perkara yang timbul dalam sengketa sebesar Rp. 259.000,- (dua ratus lima puluh sembilan ribu rupiah)."
**Kutipan Verbatim Pertimbangan Hakim (Menimbang):**
Berikut adalah bagian verbatim dari pertimbangan hakim yang memuat isu **tidak memperhatikan usaha penggugat**, **inkonsistensi tergugat**, serta **prosedur yang tidak dilakukan (cacat prosedur)**:
> "Menurut Majelis Hakim, tindakan Tergugat yang tetap meminta kelengkapan berkas pensiun kepada Penggugat dan tetap mengusulkan Penggugat ke BKN untuk pensiun padahal sengketa kepegawaiannya belum diputus oleh Majelis Hakim tingkat pertama yang memeriksanya, **adalah tindakan yang telah melanggar asas kecermatan karena Tergugat tidak mempertimbangkan aspek bahwa Penggugat masih sedang berjuang menempuh upaya hukum terhadap status kepegawaiannya**, lebih khusus lagi berkaitan dengan statusnya sebagai JPT yakni sebagai Kepala BPOM Surabaya ;"
> "Tergugat sangatlah menyadari bahwa keabsahan tindakannya menerbitkan pemberhentian Penggugat dari JPT masih sedang diperiksa pengadilan... Sehingga **tindakan Tergugat yang tidak mempertimbangkan keadaan tersebut adalah tindakan yang melanggar asas kecermatan yang mensyaratkan bahwa setiap keputusan harus didasarkan pada dokumen yang lengkap untuk mendukung legalitasnya dan harus dipersiapkan dengan cermat sebelum keputusan diterbitkan.** Karenanya dapat disimpulkan bahwa **tindakan Tergugat yang tidak cermat tersebut mengakibatkan penerbitan obyek sengketa telah cacat prosedur**;"
> "Menimbang, bahwa dengan demikian Tergugat dalam mengeluarkan objek sengketa telah melanggar Undang-Undang Nomor 5 Tahun 2014 tentang Aparatur Sipil Negara, Peraturan Pemerintah Nomor 11 Tahun 2017 tentang Manajemen Pegawai Negeri Sipil, serta Asas-Asas Umum Pemerintahan yang Baik yaitu asas kecermatan, **suatu prinsip yang mementingkan persiapan yang cermat terhadap suatu keputusan administrasi pemerintahan atau terhadap suatu tindakan faktual lainnya**;"
# Bukti No. 30
Ringkasan Putusan Nomor: 82/G/2020/PTUN-JKT
*   **Penggugat:** Dra. EVI NOVIDA GINTING MANIK, MSP.
*   **Tergugat:** PRESIDEN REPUBLIK INDONESIA
*   **Objek Sengketa:** "Keputusan Presiden Republik Indonesia Nomor 34/P.Tahun 2020 tentang Pemberhentian Dengan Tidak Hormat Anggota Komisi Pemilihan Umum Masa Jabatan Tahun 2017-2022 tanggal 23 Maret 2020"
*   **Amar Putusan (M E N G A D I L I):**
    **Dalam Penundaan:**
    1. "Mengabulkan Permohonan Penundaan Pelaksanaan Keputusan Presiden Nomor 34/P.Tahun 2020 tentang Pemberhentian Dengan Tidak Hormat Anggota Komisi Pemilihan Umum Masa Jabatan 2017-2022 tanggal 23 Maret 2020;"
    2. "Memerintahkan atau Mewajibkan Tergugat untuk menunda pelaksanaan Keputusan Presiden Nomor 34/P.Tahun 2020 tentang Pemberhentian Dengan Tidak Hormat Anggota Komisi Pemilihan Umum Masa Jabatan 2017-2022 tanggal 23 Maret 2020 selama proses pemeriksaan sampai dengan adanya Putusan Pengadilan yang berkekuatan hukum tetap;"
    **Eksepsi:**
    - "Menyatakan eksepsi Tergugat tidak diterima;"
    **Pokok Perkara:**
    1. "Mengabulkan gugatan Penggugat untuk seluruhnya;"
    2. "Menyatakan batal Keputusan Presiden Republik Indonesia Nomor 34/P.Tahun 2020 tentang Pemberhentian Dengan Tidak Hormat Anggota Komisi Pemilihan Umum Masa Jabatan Tahun 2017-2022 tanggal 23 Maret 2020;"
    3. "Mewajibkan Tergugat untuk mencabut Keputusan Presiden Republik Indonesia Nomor 34/P.Tahun 2020 tentang Pemberhentian Dengan Tidak Hormat Anggota Komisi Pemilihan Umum Masa Jabatan Tahun 2017-2022 tanggal 23 Maret 2020;"
    4. "Mewajibkan Tergugat untuk merehabilitasi nama baik dan memulihkan kedudukan Penggugat sebagai Anggota Komisi Pemilihan Umum Masa Jabatan 2017 – 2022 seperti semula sebelum diberhentikan;"
    5. "Menghukum Tergugat untuk membayar biaya perkara sejumlah Rp. 332.000,00. (tiga ratus tiga puluh dua ribu rupiah);"
---
**Kutipan Verbatim Pertimbangan Hakim (Menimbang):**
**1. Terkait Tiada Pemeriksaan & Prosedur Panggilan yang Tidak Dilakukan Sebagaimana Mestinya:**
> "Menimbang, bahwa berdasarkan ketentuan-ketentuan di atas dikaitkan dengan fakta-fakta persidangan sebagaimana diuraikan sebelumnya di atas, Pengadilan berpendapat bahwa panggilan pertama tertanggal 7 Nopember 2019 (Bukti Bukti No. 40) kepada 5 (lima) Penyelenggara Pemilu untuk hadir sidang pada tanggal 13 Nopember 2019 (Bukti Bukti No. 40, Bukti Bukti No. 40.1) sehingga pemanggilan hanya 4 (empat) hari kerja, seharusnya 5 (lima) hari kerja.",
>
> "Namun, pada persidangan pertama dan kedua Penggugat tidak hadir. Ketidakhadiran pertama karena menjadi Narasumber untuk KPU Provinsi se-Indonesia... Ketidakhadiran kedua karena Penggugat sedang sakit dan menjalani perawatan di Rumah Sakit MMC Kuningan... Dengan demikian, baik pemanggilan pada persidangan pertama dan kedua, adalah tidak sesuai dengan Pasal 458 ayat (3), ayat (4) dan ayat (5) UU No. 7 Tahun 2017 jo. Pasal 1 angka 42 Peraturan DKPP tentang Pedoman Beracara Kode Etik Penyelenggara Pemilu."
>
> "Ketidakhadiran Penggugat pada sidang DKPP, jika tidak dipertimbangkan alasannya, **otomatis seperti menghilangkan hak dan kesempatan yang bersangkutan untuk mengajukan hak pembelaan diri (right of self defense)**, dalam kondisi seperti ini apabila tetap digelar maka yang terjadi adalah **serupa dengan persidangan in absentia** untuk kasus-kasus extraordinary crimes, sesuatu yang justru semakin kontradiktif dengan hilangnya kepentingan pengadu yang pada persidangan pertama telah menyatakan mencabut pengaduan."
**2. Terkait Inkonsistensi Tergugat/Lembaga Pemutus (DKPP Mengesampingkan Aturannya Sendiri):**
> "Di sisi lain, **DKPP mengesampingkan (put aside) hukum acaranya sendiri**: sehingga dalam keadaan tertentu rapat Pleno Putusan dapat dihadiri paling sedikit 4 (empat) orang anggota DKPP vide Keputusan Ketua DKPP No. 04/SK/K.DKPP/SET-04/I/2020 Tentang Rapat Pleno Pengambilan Keputusan tertanggal 17 Januari 2020 (Bukti T-19) yang **isinya berbeda dan bertentangan dengan Pasal 36 Peraturan DKPP No. 2 Tahun 2019**."
**3. Kesimpulan Pelanggaran Prosedur:**
> "Menimbang, bahwa berdasarkan uraian pertimbangan-pertimbangan di atas, Pengadilan berpendapat bahwa putusan DKPP No. 317/2019 **bertentangan dengan Pasal 24 UU No. 30 Tahun 2014 tentang Administrasi Pemerintahan dan Pasal 458 ayat (3), ayat (4), ayat (5) dan ayat (8) UU No. 7 Tahun 2017 tentang Pemilu maupun dengan Pasal 36 Peraturan DKPP No. 2 Tahun 2019**, terlebih lagi dengan asas-asas umum pemerintahan yang baik, khususnya asas kepastian hukum, asas kecermatan, asas keterbukaan, asas kepentingan umum dan asas pelayanan yang baik;"
# Bukti No. 31
Ringkasan Putusan Nomor: 450/G/2024/PTUN.JKT
*   **Penggugat:** dr. IVAN ROVIAN M.Kp.
*   **Tergugat:** MENTERI PENDIDIKAN, SAINS, DAN TEKNOLOGI REPUBLIK INDONESIA
*   **Objek Sengketa:**
    1. "Keputusan Menteri Pendidikan Kebudayaan, Riset dan Teknologi Republik Indonesia Nomor : 93731/RHS/M/08/2024, tertanggal 4 Oktober 2024 Tentang Pembebasan Dari Jabatannya Menjadi Jabatan Pelaksana selama 12 (dua belas) bulan, atas nama dr. IVAN ROVIAN M.Kp."
    2. "Keputusan Menteri Pendidikan Tinggi, Sains, dan Teknologi Republik Indonesia No. 137561/RHS/M/08/2024 tanggal 25 November 2024. tentang Penguatan Keputusan Menteri Pendidikan Kebudayaan, Riset, dan Teknologi Republik Indonesia Nomor : 93731/RHS/M/08/2024, tanggal 4 Oktober 2024 Tentang Pembebasan Dari Jabatannya Menjadi Jabatan Pelaksana selama 12 (dua belas) bulan, atas nama dr. IVAN ROVIAN M.Kp."
*   **Amar Putusan (M E N G A D I L I):**
    **I. Penundaan:**
    - "Menolak permohonan penundaan pelaksanaan objek sengketa yang diajukan Penggugat ;"
    **II. Eksepsi:**
    - "Menyatakan Eksepsi Tergugat tidak diterima;"
    **III. Pokok Perkara:**
    1. "Mengabulkan Gugatan Penggugat untuk sebagian;"
    2. "Menyatakan batal Keputusan Menteri Pendidikan, Kebudayaan, Riset, dan Teknologi Republik Indonesia Nomor : 93731/RHS/M/08/ 2024, tanggal 4 Oktober 2024, Tentang Pembebasan Dari Jabatannya Menjadi Jabatan Pelaksana selama 12 (dua belas) bulan, atas nama dr. IVAN ROVIAN, M.Kp. ;"
    3. "Mewajibkan Tergugat untuk mencabut Keputusan Menteri Pendidikan, Kebudayaan, Riset, dan Teknologi Republik Indonesia Nomor : 93731/RHS/M/08/ 2024, tanggal 4 Oktober 2024, Tentang Pembebasan Dari Jabatannya Menjadi Jabatan Pelaksana selama 12 (dua belas) bulan, atas nama dr. IVAN ROVIAN, M.Kp. ;"
    4. "Mewajibkan Tergugat untuk merehabilitasi hak-hak atau kedudukan hukum Penggugat sebagaimana semula atau yang setara;"
    5. "Menolak gugatan Penggugat untuk selebihnya ;"
    6. "Menghukum Tergugat untuk membayar biaya perkara sejumlah Rp299.000,- (Dua ratus sembilan puluh sembilan ribu rupiah) ;"
---
**Kutipan Verbatim Pertimbangan Hakim (Menimbang):**
Berikut adalah bagian verbatim dari pertimbangan hakim yang memuat isu terkait **tiada pemeriksaan (kurangnya bukti)** yang mendasari pembatalan objek sengketa:
**1. Terkait Tiada Pemeriksaan / Bukti yang Cukup:**
> "Menimbang, bahwa selama proses persidangan **Tergugat tidak dapat menunjukkan alat bukti lainnya yang dapat meyakinkan Majelis Hakim** bahwa Penggugat benar telah melakukan pernikahan kedua/beristri lebih dari seorang dan telah melakukan perceraian tanpa memperoleh izin atau surat keterangan lebih dahulu dari Pejabat;"
> "Menimbang, bahwa prinsip kehati-hatian (prudence) dan asas due process of law menghendaki agar setiap keputusan tata usaha negara yang berdampak pada hak dan status seseorang **harus didasarkan pada proses pembuktian yang cermat, menyeluruh, dan adil**;"
# Bukti No. 32
- **Tanggal:** —
- **Ringkasan Fakta:** UU 5/1986 jo. UU 9/2004 jo. UU 51/2009 (Peradilan TUN) — Pasal 48, 55, 67. Dasar kewenangan PTUN, tenggang waktu gugatan, dan penundaan pelaksanaan KTUN.
## Pasal 48 Ayat 2 berbunyi Pengadilan baru berwenang memeriksa, memutus, dan menyelesaikan sengketa Tata Usaha Negara apabila seluruh upaya administratif yang bersangkutan telah digunakan secara paripurna.
## Pasal 55 berbunyi Gugatan dapat diajukan hanya dalam tenggang waktu 90 (sembilan puluh) hari terhitung sejak saat diterimanya atau diumumkannya Keputusan Badan atau Pejabat Tata Usaha Negara.
## Pasal 67 Ayat 2 berbunyi Penggugat dapat mengajukan permohonan agar pelaksanaan Keputusan Tata Usaha Negara itu ditunda selama pemeriksaan sengketa Tata Usaha Negara sedang berjalan, sampai ada putusan Pengadilan yang memperoleh kekuatan hukum tetap.
## Pasal 67 Ayat 4 Huruf a berbunyi Dapat dikabulkan hanya apabila terdapat keadaan yang sangat mendesak yang mengakibatkan kepentingan penggugat sangat dirugikan jika Keputusan Tata Usaha Negara yang digugat itu tetap dilaksanakan.
## Pasal 67 Ayat 4 Huruf b berbunyi Tidak dapat dikabulkan apabila kepentingan umum dalam rangka pembangunan mengharuskan dilaksanakannya keputusan tersebut.
# Bukti No. 33
- **Tanggal:** —
- **Ringkasan Fakta:** UU 30/2014 (Administrasi Pemerintahan) — Pasal 7(2)f, 9(1), 10(1), 47, 58(6), 65, 66. Larangan keberlakuan surut KTUN; kewajiban pemberitahuan & pemeriksaan sebelum keputusan membebani.
## Pasal 58 Ayat 6 berbunyi Keputusan tidak dapat berlaku surut, kecuali untuk menghindari kerugian yang lebih besar dan/atau terabaikannya hak Warga Masyarakat.
## Pasal 7 Ayat 2 Huruf f berbunyi Pejabat Pemerintahan wajib memberikan kesempatan kepada Warga Masyarakat untuk didengar pendapatnya sebelum membuat Keputusan dan/atau Tindakan yang membebani.
## Pasal 47 berbunyi kewajiban pemberitahuan paling lama 10 (sepuluh) hari kerja sebelum Keputusan yang menimbulkan pembebanan ditetapkan.
## Pasal 10 Ayat 1 Huruf a berbunyi Asas Kepastian Hukum.
## Pasal 10 Ayat 1 Huruf b berbunyi Asas Kemanfaatan.
## Pasal 10 Ayat 1 Huruf d berbunyi Asas Kecermatan.
## Pasal 9 Ayat 1 berbunyi setiap Wewenang Pejabat Pemerintahan dalam menerbitkan Keputusan didasarkan pada peraturan perundang-undangan.
## Pasal 17
(1) Badan dan/atau Pejabat Pemerintahan dilarang menyalahgunakan Wewenang.
(2) Larangan penyalahgunaan Wewenang sebagaimana dimaksud pada ayat (1) meliputi:
a. larangan melampaui Wewenang;
b. larangan mencampuradukkan Wewenang; dan/atau
c. larangan bertindak sewenang-wenang.
## Pasal 18
(1) Badan dan/atau Pejabat Pemerintahan dikategorikan melampaui Wewenang sebagaimana dimaksud dalam Pasal 17 ayat (2) huruf a apabila Keputusan dan/atau Tindakan yang dilakukan:
a. melampaui masa jabatan atau batas waktu berlakunya Wewenang;
b. melampaui batas wilayah berlakunya Wewenang; dan/atau
c. bertentangan dengan ketentuan peraturan perundang-undangan.
(2) Badan dan/atau Pejabat Pemerintahan dikategorikan mencampuradukkan Wewenang sebagaimana dimaksud dalam Pasal 17 ayat (2) huruf b apabila Keputusan dan atau Tindakan yang dilakukan:
a. di luar cakupan bidang atau materi Wewenang yang diberikan; dan/atau
b. bertentangan dengan tujuan Wewenang yang diberikan.
(3) Badan dan/atau Pejabat Pemerintahan dikategorikan bertindak sewenang-wenang sebagaimana dimaksud dalam Pasal 17 ayat (2) huruf c apabila Keputusan dan atau Tindakan yang dilakukan:
a. tanpa dasar Kewenangan; dan/atau
b. bertentangan dengan Putusan Pengadilan yang berkekuatan hukum tetap.
# Bukti No. 34
- **Tanggal:** —
- **Ringkasan Fakta:** UU 20/2023 (Aparatur Sipil Negara) — Pasal 2 huruf a, g, j, l. Asas kepastian hukum, akuntabilitas, nondiskriminatif, keadilan/kesetaraan.
## Pasal 2 Huruf a berbunyi penyelenggaraan kebijakan dan Manajemen ASN didasarkan pada asas kepastian hukum.
## Pasal 2 Huruf g berbunyi asas akuntabilitas menuntut setiap tindakan Manajemen ASN dapat dipertanggungjawabkan kepada publik
## Pasal 2 Huruf j berbunyi penyelenggaraan kebijakan dan Manajemen ASN didasarkan pada asas nondiskriminatif.
## Pasal 2 Huruf l berbunyi penyelenggaraan kebijakan dan Manajemen ASN didasarkan pada Asas Keadilan dan Kesetaraan.
# Bukti No. 35
- **Tanggal:** —
- **Ringkasan Fakta:** UU 12/2011 (Pembentukan Peraturan Perundang-undangan) — Lampiran II angka 127. Kaidah ketentuan peralihan: menghindari kekosongan hukum, kepastian hukum, perlindungan pihak terdampak.
# Bukti No. 36
- **Tanggal:** —
- **Ringkasan Fakta:** PP 11/2017 jo. PP 17/2020 (Manajemen PNS). Dasar pengangkatan, kenaikan pangkat, manajemen karier PNS. Dikutip di bagian Mengingat Objek Sengketa.
## [Tidak ada pasal spesifik yang dikutip secara verbatim dalam Gugatan, digunakan sebagai dasar kewenangan terkait pendelegasian pemberhentian dan mutasi ASN]
# Bukti No. 37
- **Tanggal:** —
- **Ringkasan Fakta:** PP 38/2016 (Kerugian Negara) — Pasal 1 angka 1, 9, 16, 38. Definisi kerugian negara & mekanisme penggantian; menilai dalil TGR Tergugat.
## Pasal 1 angka 1 "Kerugian Negara/Daerah adalah kekurangan uang, surat berharga, dan barang, yang nyata dan pasti jumlahnya sebagai akibat perbuatan melawan hukum baik sengaja maupun lalai."
## Pasal 9 "Dalam rangka penyelesaian Kerugian Negara/Daerah, PPKN/D sebagaimana dimaksud dalam Pasal 8 ayat (1) atau pejabat yang diberi kewenangan sebagaimana dimaksud dalam Pasal 8 ayat (2), ayat (3), dan ayat (4) membentuk TPKN/TPKD."
## Pasal 16 ayat (1) "Dalam hal laporan hasil pemeriksaan sebagaimana dimaksud dalam Pasal 14 ayat (1) huruf a disetujui oleh PPKN/D sebagaimana dimaksud dalam Pasal 15 ayat (1) huruf a, PPKN/D segera menugaskan TPKN/TPKD untuk melakukan penuntutan penggantian Kerugian Negara/Daerah kepada Pihak yang Merugikan."
## Pasal 38 ayat (1) huruf a "Berdasarkan putusan sebagaimana dimaksud dalam Pasal 35 ayat (2) huruf b, Majelis memberikan pertimbangan kepada PPKN/D untuk melakukan: a. pembebasan penggantian Kerugian Negara/Daerah;"
# Bukti No. 38
- **Tanggal:** —
- **Ringkasan Fakta:** PP 79/2021 (Upaya Administratif & Badan Pertimbangan ASN) — Pasal 3(1), 4(2). Kewajiban keberatan administratif sebelum menggugat ke PTUN.
## Pasal 4 Ayat 2 berbunyi pengajuan Keberatan Administratif diajukan dalam jangka waktu paling lama 14 (empat belas) hari kerja terhitung mulai tanggal keputusan yang diajukan Keberatan diterima oleh Pegawai ASN.
## Pasal 3 Ayat 1 berbunyi Pegawai ASN dapat mengajukan Keberatan atas Keputusan PPK selain pemberhentian sebagai PNS atau selain pemutusan hubungan perjanjian kerja sebagai PPPK.
# Bukti No. 39
- **Tanggal:** —
- **Ringkasan Fakta:** PP 94/2021 (Disiplin PNS). Diakui Tergugat dalam Jawaban sebagai "pedoman".
## Pasal 8 Ayat 4 Huruf b berbunyi pembebasan dari jabatannya menjadi jabatan pelaksana selama 12 (dua belas) bulan.
# Bukti No. 40
- **Tanggal:** —
- **Ringkasan Fakta:** Kepmenpan 66/KEP/M.PAN/7/2003 (JF Pranata Komputer & Angka Kreditnya) — Pasal 22. Syarat pendidikan minimal SLTA/D-I saat pengangkatan Penggugat (2009).
## Pasal 22 Ayat 1 Huruf a berbunyi syarat pendidikan minimal untuk pengangkatan Pranata Komputer kategori keterampilan adalah SLTA atau Diploma I.
# Bukti No. 41
- **Tanggal:** —
- **Ringkasan Fakta:** Permenpan RB 32/2020 (JF Pranata Komputer) — Pasal 59(3). Norma peralihan kewajiban D-III bidang TI dalam 5 tahun; dasar substantif pemberhentian yang didalilkan Tergugat.
## Pasal 59 ayat (2) berbunyi Pranata Komputer kategori terampil yang belum memperoleh ijazah minimal diploma tiga, tetap melaksanakan tugas jabatan sesuai dengan jenjang jabatannya berdasarkan Peraturan Menteri ini.
## Pasal 59 ayat (3) berbunyi Pranata Komputer kategori keterampilan wajib memperoleh ijazah paling rendah D-III di bidang Teknologi Informasi paling lama 5 (lima) tahun sejak Peraturan Menteri ini diundangkan.
## Pasal 59 ayat (4) berbunyi Pejabat Fungsional Pranata Komputer kategori keterampilan yang belum memperoleh ijazah minimal diploma tiga sampai dengan batas waktu sesuai ketentuan sebagaimana dimaksud pada ayat (3), diberhentikan dari jabatan fungsionalnya.
# Bukti No. 42
- **Tanggal:** —
- **Ringkasan Fakta:** Permenpan RB 1/2023 (Jabatan Fungsional) — Pasal 41(1)f, 41(5), 43, 60, 61, 62 huruf b. Kewajiban pemeriksaan sebelum pemberhentian JF; saving clause Pasal 61; pencabutan sebagian ketentuan teknis lama.
## Pasal 41 Ayat 5 berbunyi Pejabat Fungsional sebagaimana dimaksud pada ayat (1) huruf a dan huruf f harus diperiksa terlebih dahulu dan mendapatkan izin dari PyB sebelum ditetapkan pemberhentiannya.
## Pasal 41 Ayat 1 Huruf f berbunyi pemberhentian dari jabatan fungsional apabila tidak memenuhi persyaratan JF.
## Pasal 43 Huruf a berbunyi pemberhentian JF jika predikat kinerja Kurang atau Sangat Kurang.
## Pasal 61 berbunyi Pada saat Peraturan Menteri ini mulai berlaku, semua peraturan perundang-undangan yang merupakan pelaksanaan dari Peraturan Menteri yang mengatur mengenai JF masing-masing dinyatakan masih tetap berlaku sepanjang tidak bertentangan dan belum diubah berdasarkan Peraturan Menteri ini.
## Pasal 60 berbunyi peraturan teknis JF lama wajib disesuaikan dengan seluruh ketentuan dalam Peraturan Menteri ini paling lambat 5 (lima) tahun terhitung sejak diundangkan.
## Pasal 62 Huruf b berbunyi Ketentuan mengenai unsur dan sub unsur kegiatan pengangkatan dalam JF, kenaikan pangkat, dan kenaikan jenjang JF dalam peraturan teknis lama dicabut dan dinyatakan tidak berlaku.
# Bukti No. 43
- **Tanggal:** —
- **Ringkasan Fakta:** Kepmen PANRB SKJ.4/2024 (Standar Kompetensi JF Pranata Komputer) — Diktum IX huruf f, Diktum XI. Berlaku prospektif sejak 14 Mei 2024; rujukan kualifikasi bidang TI.
## DIKTUM Kesembilan Huruf f berbunyi mensyaratkan ijazah Teknologi Informasi untuk Jabatan Fungsional Pranata Komputer.
## DIKTUM Kesebelas berbunyi Keputusan Menteri ini mulai berlaku pada tanggal ditetapkan.
# Bukti No. 44
- **Tanggal:** —
- **Ringkasan Fakta:** Peraturan BPS 7/2023 (Uji Kompetensi Pranata Komputer) — Pasal 11(3)a/(4)a. Persyaratan ijazah TI untuk Penyelia dan jenjang di atasnya; dalil diskriminasi parameter "bidang TI".
## Pasal 11 Ayat 3 Huruf a berbunyi mensyaratkan ijazah Teknologi Informasi.
# Bukti No. 45
- **Tanggal:** —
- **Ringkasan Fakta:** PMK 218/PMK.01/2017 (Tata Cara Penyelesaian TGR Keuangan Negara) — Pasal 23, 38, Lampiran Bab I.B. Mekanisme TGR di Kemenkeu; menilai ancaman TGR lisan terhadap Penggugat.
## Pasal 23 ayat (1) huruf a "Menteri selaku PPKN melakukan penyelesaian Kerugian Negara mengenai: a. kekurangan uang, surat berharga, dan/ atau barang bukan disebabkan perbuatan melanggar hukum a tau lalai Pegawai N egeri Bukan Bendahara sebagaimana dimaksud dalam Pasal 14 ayat ( 1) huruf b;"
## Pasal 38 ayat (1) huruf a "Berdasarkan putusan sebagaimana dimaksud dalam Pasal 35 ayat (2) huruf b, Majelis memberikan pertimbangan kepada Menteri selaku PPKN untuk melakukan: a. pembebasan penggantian Kerugian Negara;"
## Lampiran (Pedoman Tata Cara Tuntutan Ganti Kerugian Negara Terhadap Pegawai Negeri Bukan Bendahara di Lingkungan Kementerian Keuangan) Bab I Huruf B "Bagi Pegawai Negeri Bukan Bendahara di lingkungan Kementerian Keuangan yang melanggar hukum atau melalaikan kewajibannya baik langsung atau tidak langsung merugikan keuangan negara diwajibkan mengganti Kerugian Negara."
# Bukti No. 46
- **Tanggal:** —
- **Ringkasan Fakta:** PMK 224/PMK.01/2020 (Manajemen Karier di Lingkungan Kemenkeu). Dicantumkan di bagian Mengingat Objek Sengketa.
## [Tidak ada pasal spesifik yang dikutip secara verbatim dalam Gugatan, digunakan sebagai dasar manajemen karier dan perlindungan pengembangan pegawai]
# Bukti No. 47
- **Tanggal:** —
- **Ringkasan Fakta:** PMK 34/2024 (Tugas Belajar di Lingkungan Kemenkeu) — Pasal 2(1), 45(1)f, 51(4). Dasar hukum ST-497/PP.1/2025. **Pasal 51(4): perpindahan PT/prodi wajib Surat Tugas Belajar Mandiri baru.**
## Kutipan untuk Mendukung Argumen "Itikad Baik & Transparansi" (Anda telah melapor secara jujur)
[Menurut PMK Nomor 34 Tahun 2024 Pasal 45 ayat (1) huruf f bahwa "menyampaikan Laporan Perkembangan Studi yang disusun sesuai dengan contoh format sebagaimana tercantum dalam Lampiran huruf E yang merupakan bagian tidak terpisahkan dari Peraturan Menteri ini melalui aplikasi otomasi perkantoran (office automation) yang disediakan oleh Kementerian Keuangan, khusus untuk Tugas Belajar Mandiri Diberhentikan Laporan Perkembangan Studi selanjutnya digunakan sebagai salah satu dasar penilaian kinerja;"].
## Kutipan untuk Mendukung Argumen "Kebutuhan Organisasi" (Perpindahan ke D3 untuk memenuhi tuntutan kualifikasi Kemenkeu/Organisasi)
[Menurut PMK Nomor 34 Tahun 2024 Pasal 2 ayat (1) bahwa "Pengelolaan Tugas Belajar bagi PNS di lingkungan Kementerian Keuangan bertujuan untuk standardisasi pengelolaan dan pengembangan kompetensi melalui pendidikan yang menunjang tugas dan fungsi serta kebutuhan organisasi sebagai bagian yang tidak terpisahkan dalam pengelolaan sumber daya manusia berbasis sistem merit."].
## Kutipan Mengenai "Kelemahan Administratif" (Untuk memisahkan antara pelanggaran disiplin fatal vs pelanggaran administratif ringan)
Menurut PMK Nomor 34 Tahun 2024 Pasal 51 ayat (4) bahwa "Bagi PNS Tugas Belajar Mandiri yang mengalami perubahan/perpindahan perguruan tinggi dan/atau program studi, harus mengajukan permohonan untuk diterbitkan Surat Tugas Belajar Mandiri baru sesuai ketentuan Peraturan Menteri ini."].
# Bukti No. 48
- **Tanggal:** —
- **Ringkasan Fakta:** SE Kepala BKN 3/2025 (Pencantuman Gelar ASN). Pencantuman gelar bagi ASN yang sedang menempuh pendidikan; status Penggugat sebagai mahasiswa aktif.
## Poin 2. Maksud dan Tujuan Maksud dan tujuan Surat Edaran ini yaitu: huruf a. Pemerintah memberikan keberpihakan kepada Aparatur Sipil Negara untuk meningkatkan kualitas melalui jalur pendidikan secara berkelanjutan dan menjaga profesionalitas;
## Poin 5. Isi Surat Edaran huruf c. Kepemilikan ijazah sebagaimana dimaksud pada huruf a merupakan ijazah yang diperoleh secara resmi dan sah sesuai dengan ketentuan peraturan perundang-undangan.
## Poin d. Pemilik ijazah bertanggungjawab secara administrasi, perdata, dan pidana atas keabsahan ijazahnya.
# Bukti No. 49
- **Tanggal:** —
- **Ringkasan Fakta:** SEMA 5/2021 (Rumusan Pleno Kamar TUN). Tenggang 90 hari dihitung sejak diterimanya penolakan upaya administratif, bukan sejak KTUN diterima.
## Rumusan Pleno Kamar Tata Usaha Negara berbunyi rentang waktu yang dilalui selama proses upaya administratif tidak dihitung, dan gugatan diajukan dalam tenggang waktu 90 hari sejak diterimanya surat penolakan upaya administratif.