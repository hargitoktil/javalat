 P U T U S A N Nomor 36/G/2025/PTUN.KPG DEMI KEADILAN BERDASARKAN KETUHANAN YANG MAHA ESA PENGADILAN TATA USAHA NEGARA KUPANG memeriksa, memutus, dan menyelesaikan perkara tata usaha negara dalam tingkat pertama dengan acara biasa yang diselenggarakan secara elektronik melalui Sistem Informasi Pengadilan sebagai berikut dalam perkara:
MARTIN CHRISANI LIUFETO, M.Pd., kewarganegaraan Indonesia, tempat tinggal di Jalan Mega Mendung, RT. 007,
RW. 002, Kelurahan Naikolan, Kecamatan Maulafa, Kota Kupang, Provinsi Nusa Tenggara Timur, pekerjaan Dosen;
Dalam hal ini diwakili oleh kuasa hukumnya bernama LESLY ANDERSON LAY,
S.H.
dan kawan-kawan,
semuanya kewarganegaraan Indonesia, Pekerjaan Advokat pada Kantor Lesly Anderson Lay, S.H. & Rekan beralamat di Jalan Alfons Nisnoni Nomor 14, Kelurahan Airnona, Kecamatan Kota Raja,
Kota Kupang, Provinsi Nusa Tenggara Timur, domisili elektronik melkzonberi95@gmail.com, berdasarkan Surat Kuasa Khusus tanggal 14 Oktober 2025;
Penggugat;
Lawan REKTOR INSTITUT AGAMA KRISTEN NEGERI KUPANG,
tempat kedudukan di Jalan Tajoin Tuan, Kelurahan Naimata,
Kecamatan Maulafa, Kota Kupang, Provinsi Nusa Tenggara Timur;
Dalam hal ini diwakili oleh kuasa hukumnya Herry F. F. Battileo,
S.H., M.H., dan Kawan-kawan, semuanya kewarganegaraan Indonesia, Pekerjaan Advokat pada Kantor Herry F. F. Battileo,
S.H., M.H. & Rekan beralamat di Jalan W. J. Lalamentik Nomor
057, Kelurahan Oebufu, Kecamatan Oebobo, Kota Kupang,
Provinsi Nusa Tenggara Timur,
domisili elektronik herrybattileo64@gmail.com, berdasarkan Surat Kuasa Khusus

Nomor 122/B.1.1/L/KAP-HFFB/XI/2025, tanggal 12 November
2025;
Tergugat;
Pengadilan Tata Usaha Negara Kupang tersebut, telah membaca:
1.
Penetapan Ketua Pengadilan Tata Usaha Negara Kupang Nomor
36/PEN-DIS/2025/PTUN.KPG tanggal 21 Oktober 2025 tentang Lolos Dismissal;
2.
Penetapan Ketua Pengadilan Tata Usaha Negara Kupang Nomor
36/PEN-MH/2025/PTUN.KPG tanggal 21 Oktober 2025 tentang Susunan Majelis Hakim;
3.
Surat Panitera Pengadilan Tata Usaha Negara Kupang Nomor
36/PEN-PPJS/2025/PTUN.KPG tanggal 21 Oktober 2025 tentang Penunjukan Panitera Pengganti dan Juru Sita Pengganti;
4.
Penetapan Hakim Ketua Majelis Pengadilan Tata Usaha Negara Kupang Nomor 36/PEN-PP/2025/PTUN.KPG tanggal 21 Oktober
2025 tentang Penetapan Hari Pemeriksaan Persiapan;
5.
Penetapan Hakim Ketua Majelis Pengadilan Tata Usaha Negara Kupang Nomor 36/PEN-HS/2025/PTUN.KPG tanggal 13 November
2025 tentang Penetapan Hari Sidang Pertama dan Jadwal Persidangan (Court Calendar);
6.
Surat Panitera Pengadilan Tata Usaha Negara Kupang Nomor
36/PEN-PPJS/2025/PTUN.KPG tanggal 09 Februari 2026 tentang Penunjukan Panitera Pengganti;
7.
Surat Panitera Pengadilan Tata Usaha Negara Kupang Nomor
36/PEN-PPJS/2025/PTUN.KPG tanggal 18 Februari 2026 tentang Penunjukan Panitera Pengganti;
8.
Berkas perkara dan mendengar keterangan para pihak yang berperkara di persidangan;
DUDUK PERKARA Penggugat telah mengajukan gugatan tanggal 16 Oktober 2025, yang didaftarkan di Kepaniteraan Pengadilan Tata Usaha Negara Kupang pada tanggal
17
Oktober
2025,
dengan Register Perkara Nomor

36/G/2025/PTUN.KPG dan telah diperbaiki tanggal 13 November 2025,
Penggugat mengemukakan pada pokoknya:
I.
Objek Sengketa:
Keputusan Rektor Institut Agama Kristen Negeri Kupang Nomor 497
Tahun 2025 tanggal 30 Juli 2025 tentang Pemberhentian Wakil Rektor II Bidang Administrasi Umum, Perencanaan dan Keuangan,
Institut Agama Kristen Negeri Kupang, atas nama Martin Chrisani Liufeto, M.Pd;
II.
Kewenangan Pengadilan Tata Usaha Negara:
−
Bahwa kewenangan Pengadilan Tata Usaha Negara meliputi kewenangan bersifat absolut dan kewenangan bersifat relatif;
−
Bahwa kewenangan absolut Pengadilan Tata Usaha Negara diatur dalam Pasal 4 Undang-Undang Nomor 5 Tahun 1986
yang menyatakan Peradilan Tata Usaha Negara adalah salah satu pelaksana kekuasaan kehakiman bagi rakyat pencari keadilan terhadap sengketa Tata Usaha Negara;
−
Bahwa Pasal 1 angka 10 Undang-Undang Nomor 51 Tahun
2009 menyebutkan Sengketa Tata Usaha Negara adalah sengketa yang timbul dalam bidang tata usaha negara antara orang atau badan hukum perdata dengan badan atau pejabat tata usaha negara, baik di pusat maupun di daerah,
sebagai akibat dikeluarkannya keputusan tata usaha negara,
termasuk sengketa kepegawaian berdasarkan peraturan perundang-undangan yang berlaku;
−
Bahwa Pasal 1 angka 9 Undang-Undang Nomor 51 Tahun
2009 menyebutkan Keputusan Tata Usaha Negara adalah suatu penetapan tertulis yang dikeluarkan oleh badan atau pejabat tata usaha yang berisi tindakan hukum tata usaha negara yang berdasarkan peraturan perundang-undangan yang berlaku yang bersifat konkrit, individual dan final yang

menimbulkan akibat hukum bagi seseorang atau badan hukum perdata;
−
Bahwa Pasal 87 Undang-Undang Nomor 30 Tahun 2014
tentang Administrasi Pemerintahan menyebutkan Dengan berlakunya Undang-Undang ini, Keputusan Tata Usaha Negara sebagaimana dimaksud dalam Undang-Undang Nomor 5 Tahun 1986 tentang Peradilan Tata Usaha Negara sebagaimana telah diubah dengan Undang-Undang Nomor 9
Tahun 2004 dan Undang-Undang Nomor 51 Tahun 2009
harus dimaknai sebagai: a. Penetapan tertulis yang harus mencakup tindakan faktual, b. Keputusan Badan dan/atau Pejabat Tata Usaha Negara di lingkungan eksekutif, legislatif,
yudikatif, dan penyelenggara negara lainnya, c. Berdasarkan ketentuan perundang-undangan dan AAUPB, d. Bersifat final dalam arti yang lebih luas, e. Keputusan yang berpotensi menimbulkan akibat hukum; dan/atau, f. Keputusan yang berlaku bagi warga masyarakat;
−
Bahwa objek sengketa dikeluarkan Tergugat dalam Jabatan sebagai Rektor pada Institut Agama Kristen Negeri Kupang,
yang menurut Peraturan Pemerintah Nomor 4 Tahun 2014
tentang Penyelenggaraan Pendidikan Tinggi dan Pengelolaan Perguruan Tinggi menyebutkan Rektor pada Universitas dan Institut menyelenggarakan urusan pemerintahan di bidang pendidikan, sehingga dalam konteks hukum administrasi negara dikategorikan sebagai Pejabat Tata Usaha Negara, dan karena itu objek sengketa tersebut bersifat konkrit, individual dan final yang menimbulkan akibat hukum bagi Penggugat yang dapat ditunjukan: Bersifat Konkrit, karena objek sengketa yang dikeluarkan Tergugat tidak abstrak tetapi telah jelas menyebutkan
“memberhentikan Penggugat, Martin Chrisani Liufeto, M.Pd dalam jabatan sebagai Wakil Rektor II Bidang Administrasi

Umum, Perencanaan dan Keuangan, Institut Agama Kristen Negeri Kupang, Bersifat Individual, karena objek sengketa yang dikeluarkan Tergugat tersebut nyata-nyata ditujukan kepada Penggugat dengan menyebutkan secara jelas nama Penggugat Martin Chrisani Liufeto, M.Pd, Bersifat Final,
karena objek sengketa yang dikeluarkan Tergugat tersebut memiliki kekuatan hukum yang mengikat dan tidak memerlukan persetujuan dari instansi atasan atau pihak lain;
−
Bahwa dengan demikian Pengadilan berwenang mengadili sengketa Tata Usaha Negara a quo;
−
Bahwa menyangkut kewenangan absolut Pengadilan Tata Usaha Negara diatur dalam Pasal 47 Undang-Undang Nomor 5 Tahun 1986 yang menyebutkan Pengadilan Tata Usaha Negara bertugas dan berwenang memeriksa,
memutus dan menyelesaikan sengketa Tata Usaha Negara;
Kemudian dalam Pasal 50 Undang-Undang Nomor 5 Tahun
1986 menyebutkan Pengadilan Tata Usaha Negara bertugas dan berwenang memeriksa, memutus, dan menyelesaikan sengketa Tata Usaha Negara di tingkat pertama;
−
Bahwa Pasal 1 angka 11 Undang-Undang Nomor 51 Tahun
2009 menyebutkan gugatan adalah permohonan yang berisi tuntutan terhadap badan atau pejabat tata usaha negara dan diajukan ke Pengadilan untuk mendapatkan putusan; Lalu dalam Pasal 54 ayat (1) Undang-Undang Nomor 5 Tahun
1986 menyebutkan gugatan sengketa Tata Usaha Negara diajukan kepada pengadilan yang berwenang yang daerah hukumnya meliputi tempat kedudukan tergugat;
−
Bahwa Tergugat dalam perkara a quo berkedudukan di Jalan Tajoin Tuan, Kelurahan Naimata, Kecamatan Maulafa, Kota Kupang, Provinsi Nusa Tenggara Timur, merupakan wilayah hukum Pengadilan Tata Usaha Negara Kupang;

−
Bahwa berdasarkan uraian-uraian tersebut maka terhadap objek sengketa dalam perkara a quo telah terpenuhi kewenangan yang bersifat absolut dan kewenangan yang bersifat relatif dan karena itu Pengadilan Tata Usaha Negara Kupang berwenang memeriksa,
menyelesaikan dan memutuskan sengketa Tata Usaha Negara a quo;
III.
Kedudukan dan Kepentingan Hukum Penggugat Yang Dirugikan
−
Bahwa Pasal 53 ayat (1) Undang-Undang Nomor 5 Tahun
1986 menyebutkan seseorang atau badan hukum perdata yang merasa kepentingannya dirugikan oleh suatu keputusan Tata Usaha Negara dapat mengajukan gugatan tertulis kepada Pengadilan yang berwenang yang berisi tuntutan agar keputusan tata usaha negara yang disengketakan itu dinyatakan batal atau tidak sah dengan atau tanpa disertai ganti rugi dan/atau rehabilitasi;
−
Bahwa pada tanggal 25 September 2024 Penggugat diangkat sebagai Wakil Rektor II Bidang Administrasi Umum,
Perencanaan dan Keuangan, Institut Agama Kristen Negeri Kupang berdasarkan Keputusan Tergugat Nomor 201 Tahun
2024 untuk masa waktu 4 (empat) tahun yaitu tahun 2024
s/d tahun 2028;
−
Bahwa Keputusan Tergugat tersebut dalam diktum memutuskan bagian Kesatu dan Kedua menyebutkan
“Mengangkat Penggugat Martin Chrisani Liufeto, M.Pd dalam Jabatan sebagai Wakil Rektor II Bidang Administrasi Umum,
Perencanaan dan Keuangan, Institut Agama Kristen Negeri Kupang” dan pada bagian Ketiga menyebutkan Honorarium per bulan sebesar Rp3.150.000,- (Tiga Juta Seratus Lima Puluh Ribu Rupiah);
−
Bahwa dengan Tergugat mengeluarkan objek sengketa maka Penggugat sangat dirugikan dalam hal ini Penggugat kehilangan pendapatan sehingga Penggugat mengalami

kerugian materiil yaitu tidak menerima tunjangan sejak tanggal 30 Juli 2025;
−
Bahwa selain kerugian materil, Penggugat juga mengalami kerugian imateril

yang mana dengan Tergugat mengeluarkan objek sengketa Penggugat kehilangan kepercayaan dari civitas akademika dan kehilangan kesempatan untuk melamar lagi pada tugas tambahan/jabatan pada Institut Agama Kristen Negeri Kupang;
IV.
Upaya Administratif dan Tenggang Waktu Mengajukan Gugatan:
−
Bahwa Pasal 2 ayat (1) Peraturan Mahkamah Agung Republik Indonesia Nomor 6 Tahun 2018 tentang Pedoman Penyelesaian Sengketa Administrasi Pemerintahan menyebutkan Pengadilan berwenang menerima, memeriksa,
memutus dan menyelesaikan gugatan sengketa administrasi pemerintahan setelah menempuh upaya administratif;
−
Bahwa ketentuan Pasal 64 Undang-Undang Nomor 20
Tahun 2023 tentang Aparatur Sipil Negara pada pokoknya menyebutkan sengketa Pegawai ASN diselesaikan melalui upaya administratif yang terdiri atas keberatan dan banding administratif;
−
Bahwa Pasal 75 ayat (1) dan ayat (2) Undang-Undang Nomor 30 Tahun 2014 tentang Administrasi Pemerintahan pada pokoknya menyebutkan warga masyarakat yang dirugikan terhadap keputusan Pejabat Tata Usaha Negara dapat mengajukan upaya administratif kepada pejabat pemerintahan atau atasan pejabat yang menetapkan dan/atau melakukan keputusan dan/atau tindakan yang terdiri atas keberatan dan banding;
−
Bahwa kemudian dalam Pasal 77 Undang-Undang Nomor 30
Tahun
2014
tentang Administrasi Pemerintahan menyebutkan: (1) Keputusan dapat diajukan keberatan

dalam waktu paling lama 21 (dua puluh satu) hari kerja sejak diumumkan keputusan tersebut oleh Badan dan/atau pejabat pemerintahan, (2) Keberatan sebagaimana dimaksud pada ayat (1) diajukan secara tertulis kepada Badan dan/atau pejabat pemerintahan yang menetapkan Keputusan, (3)
Dalam hal keberatan sebagaimana dimaksud pada ayat (1)
diterima Badan atau Pejabat Pemerintahan wajib menetapkan keputusan sesuai permohonan keberatan, (4)
Badan dan/atau Pejabat Pemerintahan menyelesaikan keberatan paling lama 10 (sepuluh) hari kerja, (5) Dalam hal Badan dan/atau Pejabat Pemerintahan tidak menyelesaikan keberatan dalam jangka waktu sebagaimana dimaksud pada ayat (4), keberatan dianggap dikabulkan, (6) Keberatan yang dianggap dikabulkan, ditindaklanjuti dengan penetapan Keputusan sesuai dengan permohonan keberatan oleh Badan dan/atau Pejabat Pemerintahan, (7) Badan dan/atau Pejabat Pemerintahan wajib menetapkan keputusan sesuai dengan permohonan paling lama 5 (lima) hari kerja setelah berakhirnya tenggang waktu sebagaimana dimaksud pada ayat (4);
−
Bahwa ketentuan Pasal 55 Undang-Undang Nomor 5 Tahun
1986 menyebutkan gugatan dapat diajukan hanya dalam tenggang waktu 90 (sembilan puluh) hari terhitung saat diterimanya atau diumumkannya Keputusan Badan atau Pejabat Tata Usaha Negara;
−
Bahwa selanjutnya dalam Pasal 3 Peraturan Mahkamah Agung Republik Indonesia Nomor 6 Tahun 2018 tentang Pedoman Penyelesaian Sengketa Administrasi Pemerintahan tersebut menegaskan Pengadilan dalam memeriksa, memutus dan menyelesaikan gugatan sengketa administrasi pemerintahan menggunakan peraturan dasar yang mengatur upaya administratif tersebut. Dalam hal

peraturan dasar penerbitan keputusan dan/ atau tindakan tidak mengatur upaya administrasi Pengadilan menggunakan ketentuan yang diatur dalam Undang-Undang Nomor 30
Tahun 2014 tentang Administrasi Pemerintahan;
−
Bahwa ketentuan Pasal 5 ayat (1) Peraturan Mahkamah Agung Republik Indonesia Nomor 6 Tahun 2018 tentang Pedoman Penyelesaian Sengketa Administrasi Pemerintahan menyebutkan “Tenggang waktu pengajuan gugatan di Pengadilan dihitung 90 (sembilan puluh) hari sejak keputusan atas upaya administratif diterima oleh warga masyarakat atau diumumkan oleh badan/atau pejabat administrasi pemerintahan yang menangani penyelesaian upaya administratif”;
−
Bahwa pemberhentian Penggugat bukanlah pemberhentian sebagai Aparatur Sipil Negara; Pemberhentian Penggugat sebagaimana dalam objek sengketa a
quo adalah pemberhentian dalam jabatan selaku Wakil Rektor II Bidang Administrasi Umum, Perencanaan dan Keuangan, Institut Agama Kristen Negeri Kupang, sehingga upaya administratif yang dilakukan tidaklah mengikuti prosedur upaya administratif sesuai Undang-Undang Aparatur Sipil Negara;
−
Bahwa pengangkatan dan pemberhentian Wakil Rektor pada Institut Agama Kristen Negeri Kupang diatur dalam Peraturan Menteri Agama Republik Indonesia Nomor 37 Tahun 2020
tentang Statuta Institut Agama Kristen Negeri Kupang,
dimana dalam Peraturan Menteri Agama Republik Indonesia tersebut tidak mengatur tentang upaya administratif,
sehingga dengan demikian Upaya administratif mengikuti ketentuan yang disebutkan dalam Undan-Undang Undang-
Undang Nomor 30 Tahun 2014 tentang Administrasi Pemerintahan sesuai amanat Pasal 3 Peraturan Mahkamah Agung Republik Indonesia Nomor 6 Tahun 2018 tentang

Pedoman Penyelesaian Sengketa Administrasi Pemerintahan sebagaimana disebutkan pada angka 6;
−
Bahwa objek sengketa dikeluarkan Tergugat pada tanggal 30
Juli 2025 dan diterima Penggugat pada hari itu juga yakni tanggal 30 Juli 2025, lalu pada tanggal 25 Agustus 2025
Penggugat mengajukan keberatan kepada Tergugat dengan berdasarkan ketentuan Pasal 77 ayat (1) Undang-Undang Nomor 30 Tahun 2014;
−
Bahwa terhadap keberatan Penggugat tersebut sampai dengan 10 (sepuluh) hari kerja sesuai ketentuan Pasal 77
ayat (4) Undang-Undang Nomor 30 Tahun 2014, Tergugat tidak memberikan keputusan, sehingga secara hukum dianggap dikabulkan;
−
Bahwa dengan demikian, dihubungkan dengan ketentuan Pasal 5 ayat (1) Peraturan Mahkamah Agung Republik Indonesia Nomor 6 Tahun 2018 sebagaimana tersebut pada angka 7, maka perhitungan tenggang waktu objek sengketa a quo terhitung tanggal 10 September 2025, sehingga gugatan a quo masih dalam tenggang waktu 90 (sembilan puluh)
hari yang diamanatkan dalam ketentuan perundangan-undangan, dan karena itu gugatan Penggugat sangatlah beralasan hukum untuk diterima;
V.
Alasan-Alasan Mengajukan Gugatan:
−
Bahwa Penggugat diangkat sebagai Dosen pada Institut Agama Kristen Negeri Kupang sejak tanggal 29 Februari tahun 2016 berdasarkan Keputusan Ketua Sekolah Tinggi Agama Kristen Negeri Kupang Nomor : Stk.07/IIa/KP.00.3/
613/2016 dengan golongan III/b, lalu terakhir pada tanggal
14 Maret 2024 berdasarkan Keputusan Menteri Agama Republik Indonesia Nomor 46 Tahun 2024 Penggugat mendapatkan kenaikan pangkat menjadi III/D;

−
Bahwa pada tanggal 25 September 2024 Penggugat diangkat sebagai Wakil Rektor II Bidang Administrasi Umum,
Perencanaan dan Keuangan, Institut Agama Kristen Negeri Kupang, berdasarkan Keputusan Tergugat Nomor 201
Tahun 2024 untuk masa jabatan 4 (empat) yaitu tahun 2024
s/d tahun 2028;
−
Bahwa pengangkatan Penggugat sebagai Wakil Rektor II Bidang Administrasi Umum, Perencanaan dan Keuangan,
Institut Agama Kristen Negeri Kupang oleh karena Penggugat mengikuti proses penjaringan yang dilakukan oleh Panitia Penjaringan sebagaimana ketentuan Pasal 29
Peraturan Menteri Agama Republik Indonesia Nomor 37
Tahun 2020 tentang Statuta Institut Agama Kristen Negeri Kupang dan dinyatakan memenuhi syarat sebagai Wakil Rektor sesuai ketentuan Pasal 28 Peraturan Menteri Agama Republik Indonesia Nomor 37 Tahun 2020 tentang Statuta Institut Agama Kristen Negeri Kupang yakni: a. Berstatus Dosen Tetap, b. Beragama Kristen, c. Berusia paling tinggi
60 (enam puluh) tahun, d. Berpendidikan program Doktor atau Magister dengan jabatan fungsional paling rendah Lektor, e. Memahami visi, misi dan tujuan Institut, f. Sehat jasmani dan Rohani yang dibuktikan dengan surat keterangan dari dokter pemerintah, g. Tidak sedang menjalani hukuman disiplin Tingkat sedang atau berat sesuai ketentuan perundang-undangan, h. Tidak sedang menjalani pidana berdasarkan putusan pengadilan yang telah memperoleh kekuatan hukum tetap, i. Mencalonkan atau bersedia dicalonkan menjadi Wakil Rektor secara tertulis, j.
Bersedia bekerjasama dengan Rektor;
−
Bahwa sejak diangkat sebagai Wakil Rektor II Bidang Administrasi Umum, Perencanaan dan Keuangan, Institut Agama Kristen Negeri Kupang Penggugat telah menjalankan

tugas dengan baik dan tidak melakukan pelanggaran disiplin dan tidak pernah dijatuhi hukuman disiplin apapun;
−
Bahwa akan tetapi pada tanggal 30 Juli 2025 secara tiba-
tiba tanpa alasan yang sah dan jelas Tergugat mengeluarkan objek sengketa dan memberhentikan Penggugat sebagai Wakil Rektor II Bidang Administrasi Umum, Perencanaan dan Keuangan, Institut Agama Kristen Negeri Kupang berdasarkan Nota Dinas Tergugat sendiri kepada Kepala Biro Administrasi, Umum Akademik dan Kemahasiswaan Institut Agama Kristen Negeri Kupang Nomor
3839/ikn.01/1/KP.04.2/07/2025 tanggal 23 Juli 2025 Perihal menerbitkan SK Pemberhentian Pejabat, Sehingga apabila dihitung tenggang waktu antara Nota Dinas dan penerbitan objek sengketa oleh Tergugat senyatanya dilakukan secara terburu-buru hanya dalam waktu 7 (tujuh) hari dimana dalam tenggang waktu tersebut Penggugat tidak pernah dipanggil untuk dilakukan pemeriksaan dan atau klarifikasi yang dibuktikan dengan Berita Acara Pemeriksaan dan/atau Berita Acara Klarifikasi; Dengan demikian tidak ada proses/tahapan apapun yang dilakukan oleh Kepala Biro Umum, Akademik dan Kemahasiswaan, Institut Agama Kristen Negeri Kupang dalam menindaklanjuti Nota Dinas Tergugat a quo sesuai tugas dan fungsinya berdasarkan ketentuan Pasal 33 Jo Pasal 34 Peraturan Menteri Agama Republik Indonesia Nomor 24 Tahun 2020 tentang Organisasi dan Tata Kerja Institut Agama Kristen Negeri Kupang, yang menyebutkan :
Pasal
33:
Biro Administrasi Umum, Akademik,
dan Kemahasiswaan sebagaimana dimaksud dalam Pasal 32
mempunyai tugas melaksanakan penyusunan rencana dan program,
administrasi umum,
keuangan,
organisasi,
kepegawaian,
hukum,
administrasi akademik,
kemahasiswaan, pemberdayaan alumni, dan kerjasama.

Pasal
34:
Dalam melaksanakan tugas sebagaimana dimaksud dalam Pasal 33, Biro Administrasi Umum,
Akademik dan Kemahasiswaan menyelenggarakan fungsi:
Penyusunan rencana, program dan anggaran, Pelaksanaan penataan organisasi dan tatalaksana, urusan kepegawaian,
penyusunan Keputusan dan instrumen hukum lain, dan advokasi hukum, Pelaksanaan perbendaharaan, akuntansi dan pelaporan keuangan,
Pelaksanaan administrasi akademik,
kelembagaan,
alumni dan kerjasama,
Pelaksanaan layanan pembinaan minat, bakat, penalaran,
dan kesejahteraan mahasiswa,
Pelaksanaan urusan ketatausahaan, kearsipan, pengelolaan barang milik negara,
dokumentasi,
publikasi,
hubungan masyarakat,
dan kerumahtanggaan; dan Penatausahaan, evaluasi, dan pelaporan Institut;
−
Bahwa pada tanggal
25
Agustus
2025
Penggugat mengajukan keberatan secara tertulis kepada Tergugat atas objek sengketa yang dikeluarkan, tetapi Tergugat tidak menyelesaikan keberatan Penggugat sampai dengan gugatan ini diajukan sehingga berdasarkan ketentuan Pasal
77 ayat (1) Undang-Undang Nomor 30 Tahun 2014,
keberatan tersebut secara hukum dianggap dikabulkan;
−
Bahwa alasan pemberhentian Wakil Rektor secara limitatif diatur dan ditentukan dalam ketentuan Pasal 31 Peraturan Menteri Agama Republik Indonesia Nomor 37 Tahun 2020
tentang Statuta Institut Agama Kristen Negeri Kupang yang menyebutkan Wakil Rektor diberhentikan dari jabatan karena: a. Telah berakhir masa jabatan, b. Mengundurkan diri atas permintaan sendiri, c. Diangkat dalam jabatan yang lain, d. Tidak dapat bekerjasama dengan Rektor, e. Sakit jasmani dan/atau rohani terus menerus, f. Dikenakan sanksi

hukuman disiplin tingkat berat, g. Dipidana penjara, h. Cuti diluar tanggungan negara; dan, i. Meninggal dunia;
−
Bahwa ketentuan Pasal 52 ayat (1) Undang-Undang Nomor
30
Tahun
2014
tentang Administrasi Pemerintahan menentukan syarat sahnya keputusan meliputi a. ditetapkan oleh pejabat yang berwenang, b. Dibuat sesuai prosedur hukum, dan c. Substansi yang sesuai dengan objek keputusan.
Bahwa dari ketentuan tersebut menurut Penggugat, Tergugat dalam mengeluarkan objek sengketa mengandung cacat prosedur dan cacat substansi;
−
Bahwa objek sengketa yang dikeluarkan Tergugat mengandung cacat prosedur karena objek sengketa telah diterbitkan tanpa terlebih dahulu dilakukan pemeriksaan dan/atau klarifikasi yang dibuktikan dengan Berita Acara Pemeriksaan dan atau Berita Acara Klarifikasi oleh Kepala Biro Umum, Akademik dan Kemahasiswaan Institut Agama Kristen Negeri Kupang dalam menindaklanjuti Nota Dinas Tergugat a quo sesuai tugas dan fungsinya berdasarkan ketentuan Pasal 33 Jo Pasal 34 Peraturan Menteri Agama Republik Indonesia Nomor
24
Tahun
2020
tentang Organisasi dan Tata Kerja Institut Agama Kristen Negeri Kupang terhadap Penggugat mengenai ada tidaknya peristiwa dan atau pelanggaran yang dilakukan Penggugat yang mana peristiwa dan atau pelanggaran tersebut memenuhi syarat pemberhentian sebagaimana ketentuan Pasal 31 Peraturan Menteri Agama Republik Indonesia Nomor 37 Tahun 2020 tentang Statuta Institut Agama Kristen Negeri Kupang yaitu Telah berakhir masa jabatan,
Mengundurkan diri atas permintaan sendiri, Diangkat dalam jabatan yang lain, Tidak dapat bekerjasama dengan Rektor,
Sakit jasmani dan/atau rohani terus menerus, Dikenakan

sanksi hukuman disiplin tingkat berat, Dipidana penjara, Cuti diluar tanggungan negara;
−
Bahwa secara substansi alasan dikeluarkan obyek sengketa oleh Tergugat bertentangan dengan alasan-alasan pemberhentian sebagaimana yang ditentukan dalam Pasal
31 Peraturan Menteri Agama Republik Indonesia Nomor 37
Tahun 2020 tentang Statuta Institut Agama Kristen Negeri Kupang sebagaimana tersebut diatas karena objek sengketa dalam konsiderans Mengingatnya diketahui pemberhentian Penggugat hanya berdasarkan Nota Dinas kepada Kepala Biro Administrasi, Umum Akademik dan Kemahasiswaan,
Institut Agama Kristen Negeri Kupang Nomor
3839/ikn.01/1/KP.04.2/07/2025 tanggal 23 Juli 2025 Perihal menerbitkan SK Pemberhentian Pejabat yang dibuat dan dikeluarkan oleh Tergugat sendiri;
−
Bahwa dalam Nota Dinas Tergugat kepada Kepala Biro Administrasi, Umum Akademik dan Kemahasiswaan, Institut Agama Kristen Negeri Kupang Nomor
3839/ikn.01/1/KP.04.2/07/2025
tanggal
23
Juli
2025
menyebutkan alasan pemberhentian atas diri Penggugat adalah sehubungan dengan penataan organisasi dan dalam rangka penyegaran struktur kepemimpinan di lingkungan Institut Agama Kristen Negeri Kupang akan tetapi alasan tersebut bukanlah merupakan alasan pemberhentian sebagaimana ketentuan Pasal 31 Peraturan Menteri Agama Republik Indonesia Nomor 37 Tahun 2020 tentang Statuta Institut Agama Kristen Negeri Kupang;
−
Bahwa dalam Bab II huruf B angka 2 huruf a, point 1,
Keputusan Menteri Agama Republik Indonesia nomor 9
Tahun 2016 tentang Pedoman Tata Naskah Dinas pada Kementerian Agama menyebutkan Nota Dinas adalah merupakan naskah dinas internal pada satuan

organisasi/kerja yang dibuat oleh pejabat dalam melaksanakan tugas guna menyampaikan laporan,
pemberitahuan, pernyataan, permintaan, atau penyampaian pendapat kepada pejabat lain; Nota dinas memuat hal yang bersifat rutin berupa catatan ringkas dan lengkap dan dapat langsung dijawab dengan disposisi oleh pejabat struktural yang dituju. Ketentuan tersebut apabila dihubungkan dengan Nota Dinas a quo bertentangan dengan ketentuan tersebut karena Nota Dinas yang dikeluarkan Tergugat pada tanggal
23 Juli 2025 yang isinya bukan-lah merupakan hal-hal yang bersifat rutin tetapi berkaitan dengan pemberhentian pejabat yaitu secara langsung Memerintahkan kepada Kepala Biro Administrasi, Umum Akademik dan Kemahasiswaan, Institut Agama Kristen Negeri Kupang untuk menerbitkan Surat Keputusan pemberhentian atas diri Penggugat, sehingga tidak dapat dijadikan sebagai dasar penerbitan objek sengketa;
−
Bahwa oleh karena itu objek sengketa yang dikeluarkan Tergugat telah bertentangan dengan Asas-Asas Umum Pemerintahan yang Baik (Algemene Beginzellen Van Behorlijk Beztuur) yakni : a. Asas kepastian hukum, yaitu bahwa Tergugat dalam mengeluarkan objek sengketa tidak didasarkan pada syarat-syarat pemberhentian Wakil Rektor sesuai Peraturan Menteri Agama Republik Indonesia Nomor
37 Tahun 2020 tentang Statuta Institut Agama Kristen Negeri Kupang, b. Asas kecermatan, yaitu bahwa Tergugat dalam mengeluarkan objek sengketa tidak didasarkan pada informasi dan dokumen yang lengkap untuk memastikan legalitas dan keabsahan penetapannya dan/atau tindakan tersebut dipersiapkan dengan tidak cermat yang mana penerbitan obyek sengketa hanya didasarkan pada Nota Dinas Tergugat sendiri yang ditujukan Kepada Kepala Biro

Administrasi, Umum Akademik dan Kemahasiswaan, Institut Agama Kristen Negeri Kupang Nomor
3839/
ikn.01/1/KP.04.2/07/2025 tanggal 23 Juli 2025;
−
Bahwa oleh karena objek sengketa yang diterbitkan Tergugat bertentangan dengan ketentuan perundang-undangan yang berlaku dan bertentangan dengan Asas-Asas Umum Pemerintahan yang Baik (Algemene Beginzellen Van Behorlijk Beztuur) maka objek sengketa tersebut patutlah dinyatakan batal atau tidak sah dengan mewajibkan TERGUGAT untuk mencabut objek sengketa tersebut dan merehabilitasi harkat dan martabat serta mengembalikan kedudukan PENGGUGAT pada jabatan semula sebagai Wakil Rektor II Bidang Administrasi Umum, Perencanaan dan Keuangan, Institut Agama Kristen Negeri Kupang atau yang setingkat dengan jabatan Wakil Rektor tersebut;
VI.
Petitum:
1.
Mengabulkan gugatan Penggugat untuk seluruhnya;
2.
Menyatakan batal atau tidak sah Keputusan Rektor Institut Agama Kristen Negeri Kupang Nomor 497 Tahun 2025
tanggal 30 Juli 2025 tentang Pemberhentian Wakil Rektor II Bidang Administrasi Umum, Perencanaan dan Keuangan,
Institut Agama Kristen Negeri Kupang, atas nama Martin Chrisani Liufeto, M.Pd;
3.
Mewajibkan Tergugat untuk mencabut Keputusan Rektor Institut Agama Kristen Negeri Kupang Nomor 497 Tahun
2025 tanggal 30 Juli 2025 tentang Pemberhentian Wakil Rektor II Bidang Administrasi Umum, Perencanaan dan Keuangan, Institut Agama Kristen Negeri Kupang, atas nama Martin Chrisani Liufeto, M.Pd;
4.
Mewajibkan kepada Tergugat untuk merehabilitasi harkat dan martabat serta mengembalikan kedudukan Penggugat pada jabatan semula sebagai Wakil Rektor II Bidang

Administrasi Umum, Perencanaan dan Keuangan, Institut Agama Kristen Negeri Kupang atau yang setingkat dengan jabatan tersebut sesuai dengan ketentuan perundang-
undangan yang berlaku;
5.
Menghukum Tergugat untuk membayar semua biaya perkara yang timbul dalam sengketa ini;
Tergugat mengajukan jawaban secara tertulis pada tanggal 27
November 2025, pada pokoknya:
−
Bahwa terhadap posita gugatan Penggugat huruf A terkait Objek Sengketa pada halaman 2, semata hanya menyebutkan objek sengketa adalah Keputusan Rektor Institut Agama Kristen Negeri Kupang, Nomor 497 Tahun 2025, tanggal 30 Juli 2025 tentang pemberhentian Wakil Rektor II Bidang Administrasi umum,
Perencanaan dan Keuangan, Institut Agama Kristen Negeri Kupang atas nama Martin Chrisani Liufeto, M.Pd terlihat masih bersifat abstrak karena tidak diikuti dengan uraian latar belakang hukum yang jelas dan terang sehingga Surat Keputusan tersebut patut dijadikan alasan hukum sebagai objek perkara dalam perkara in casu;
−
Bahwa terhadap poin B angka 1 sampai dengan 11 halaman 2
gugatan Penggugat,
semata mengutip Undang-Undang dan beberapa peraturan yang dipandang sebagai hal yang normatif, soal kewenangan absolut maupun relatif. Mengingat hal-hal yang dimuat merupakan sesuatu yang normatif sehingga tidak ditanggapi lebih lanjut;
−
Bahwa terhadap poin C angka 1 sampai dengan 5 pada halaman 4
gugatan Penggugat, terkait kedudukan dan kepentingan hukum Penggugat yang dirugikan, terhadap dalil-dalil tersebut dengan tegas Tergugat menolak dengan alasan sebagai berikut:
−
Bahwa Penggugat dalam dalilnya menggunakan Pasal 53 ayat (1)
Undang-Undang Nomor 5 Tahun 1986 yang merupakan lex generalis, yang pengaturannya bersifat umum, sedangkan Tergugat

dalam pengambilan keputusan dan pengelolaan Perguruan Tinggi/(Institut Agama Kristen Negeri Kupang) terkait pengangkatan dan pemberhentian seseorang dalam jabatan struktural, payung hukum yang digunakan adalah Peraturan Menteri Agama Republik Indonesia Nomor 37 Tahun 2020 tentang Statuta Institut Agama Kristen Negeri Kupang sebagai lex specialis;
−
Bahwa Pengangkatan Penggugat dalam Jabatan Struktural/Eselon Wakil Rektor II Bidang Administrasi umum, Perencanaan dan Keuangan, Institut Agama Kristen Negeri Kupang) merupakan amanah/tugas tambahan, dimana yang bersangkutan berkedudukan sebagai Wakil Rektor II Bidang Administrasi umum, Perencanaan dan Keuangan, yang sifatnya sementara serta dapat diberhentikan oleh Rektor karena kewenangannya sebagaimana diatur dalam Pasal 27 ayat (2) dan Pasal 31 Huruf d, Peraturan Menteri Agama Republik Indonesia Nomor 37 Tahun 2020 tentang Statuta Institut Agama Kristen Negeri Kupang, maka penerbitan Surat Keputusan Rektor Institut Agama Kristen Negeri Kupang Nomor 497 Tahun 2025
tanggal 30 Juli 2025 tentang Pemberhentian Wakil Rektor II Bidang Administrasi umum, Perencanaan dan Keuangan, Institut Agama Kristen Negeri Kupang atas nama Martin Chrisani Liufeto, M.Pd
(Penggugat) tidak dapat dikategorikan sebagai Perbuatan Melawan Hukum;
−
Bahwa oleh karena penerbitan Surat Keputusan Rektor Institut Agama Kristen Negeri Kupang Nomor 497 Tahun 2025 tanggal 30
Juli 2025 tentang Pemberhentian Wakil Rektor II Bidang Administrasi umum, Perencanaan dan Keuangan, Institut Agama Kristen Negeri Kupang atas nama Martin Chrisani Liufeto, M.Pd (Penggugat) adalah keputusan berdasarkan kewenangan dan memiliki payung hukum yang jelas, maka keputusan tersebut tidak dapat dikategorikan sebagai Perbuatan Melawan Hukum dan tidak mengakibatkan adanya kerugian materiil dan immateriil yang diklaim Penggugat

(kehilangan kepercayaan publik, kewibawaan jabatan dan reputasi profesional sebagai pimpinan Perguruan Tinggi);
−
Bahwa dengan adanya surat Keputusan Pemberhentian tersebut maka segala hak dan kewajiban yang melekat pada Penggugat secara hukum berakhir;
−
Bahwa terhadap poin D angka 1 sampai dengan 12 pada gugatan Penggugat halaman 4 sampai dengan 6, rumusan-rumusan yang dituangkan dalam gugatan berkaitan dengan Undang-Undang dan Peraturan lain yang semata-mata sifatnya normatif yang dipaksakan berbenturan dengan peraturan Perguruan Tinggi/Institut Negeri,
sehingga terhadap dalil tersebut, Tergugat menolak dengan tegas dan tetap berpijak pada payung hukum Peraturan Menteri Agama Republik Indonesia Nomor 37 Tahun 2020 tentang Statuta Institut Agama Kristen Negeri Kupang;
−
Bahwa terhadap dalil gugatan Penggugat pada poin E angka 1
sampai dengan 14 pada halaman 7 sampai dengan halaman 11,
Tergugat menjawab dengan alasan-alasan hukum sebagai berikut:
−
Menolak seluruh dalil Penggugat bahwa pemberhentian Penggugat tidak memiliki alasan yang sah dan mengandung cacat prosedur/substansi;
−
Bahwa Keputusan Rektor sudah didasarkan pada evaluasi kinerja yang komprehensif sebagaimana dalam Surat Telaah tentang Pemberhentian Pejabat Pimpinan Nomor:
5111/Ikn/01/1/OT.01.2/08/2025.
Pemberhentian sebagaimana dimaksud telah dilakukan berdasarkan hasil evaluasi secara berjenjang sehingga Penggugat terbukti tidak dapat bekerjasama dengan Rektor dan Penggugat tidak konsisten/tidak mentaati dan menjalankan dengan nyata Surat Pernyataan Kesediaan Bekerja Sama tertanggal 10 September 2024;
−
Bahwa dalam Surat Telaah tentang Pemberhentian Pejabat Pimpinan dimaksud,
Rektor menggunakan kewenangannya berdasarkan Peraturan Menteri Agama Republik Indonesia Nomor

37 Tahun 2020 tentang Statuta Institut Agama Kristen Negeri Kupang sebagaimana pada Pasal 1 ayat (3): Rektor merupakan organ institut yang memimpin penyelenggaraan pendidikan tinggi pada institut,
Pasal 26 ayat (1) huruf d: Rektor mempunyai tugas dan kewajiban mengangkat dan memberhentikan pejabat di bawah rektor sesuai dengan ketentuan peraturan perundang-undangan, Pasal 27 ayat
(2): Wakil Rektor diangkat dan diberhentikan oleh Rektor, Pasal 31
huruf d: Wakil Rektor dapat diberhentikan karena tidak dapat bekerja sama dengan Rektor;
−
Bahwa Penggugat dalam Surat Pernyataannya Kesediaan Bekerja sama tertanggal 10 September 2024 telah menyatakan bersedia mengikuti segala ketentuan sebagaimana berlaku, namun dalam evaluasi berjenjang tersebut ternyata tidak dapat bekerja sama Rektor;
−
Bahwa pemberhentian Penggugat dari jabatannya diperlukan untuk menciptakan kepemimpinan fakultas yang kondusif dan efektif;
−
Bahwa Nota Dinas Nomor: 3839/lkn.01/l/KP.04.2./07/2025 tertanggal
23 Juli 2025 dari Rektor kepada Kepala Biro AUAK adalah bentuk instruksi internal yang sah dari atasan kepada bawahan untuk melaksanakan kewenangan tersebut untuk menerbitkan Surat Keputusan Rektor Institut Agama Kristen Negeri Kupang Nomor 497
Tahun 2025 tanggal 30 Juli 2025 tentang Pemberhentian Wakil Rektor II Bidang Administrasi umum, Perencanaan dan Keuangan,
Institut Agama Kristen Negeri Kupang atas nama Martin Chrisani Liufeto, M.Pd (Penggugat);
−
Bahwa pemberhentian Penggugat telah dibahas bersama Rektor pada Senin 11 Agustus 2025, sebagaimana dalam notulen rapat,
dimana Tergugat menyatakan surat keputusan pemberhentian bersifat final dan Tergugat memiliki kewenangan untuk mengangkat dan memberhentikan Wakil Rektor;
−
Bahwa Keputusan Tergugat telah memenuhi Asas-asas Umum Pemerintahan Yang Baik (AAUPB): Asas Kepastian Hukum:

Berdasarkan Peraturan Menteri Agama Republik Indonesia Nomor
37 Tahun 2020 tentang Statuta Institut Agama Kristen Negeri Kupang. Asas Kecermatan: Dilakukan berdasarkan evaluasi sebagaimana dalam Surat Telaah tentang Pemberhentian Pejabat Pimpinan Nomor:
5111/Ikn/01/1/OT.01.2/08/2025.
Asas Proposionalitas:
Tindakan pemberhentian sebanding dengan dampak negatif yang ditimbulkan dari kinerja dan sikap Penggugat terhadap institusi;
−
Bahwa dengan demikian, Surat Keputusan Rektor Nomor 497 Tahun
2025 tanggal 30 Juli 2025 tentang pemberhentian Wakil Rektor II Bidang Administrasi Umum, Perencanaan dan Keuangan Institut Agama Kristen Negeri Kupang atas nama Martin Chrisani Liufeto,
M.Pd (Penggugat) telah dikeluarkan secara sah dan sesuai kewenangan dan prosedur sehingga gugatan Penggugat harus ditolak;
−
Berdasarkan Jawaban Tergugat diatas maka mohon kiranya Yang Mulia Majelis Hakim yang memeriksa, mengadili serta memutus perkara in casu agar dapat memutus dengan amar sebagai berikut:
1. Menolak gugatan Penggugat seluruhnya, 2. Menyatakan Surat Keputusan Rektor Nomor 497 Tahun 2025 tanggal 30 Juli 2025
tentang pemberhentian Wakil Rektor II Bidang Administrasi Umum,
Perencanaan dan Keuangan Institut Agama Kristen Negeri Kupang atas nama Martin Chrisani Liufeto, M.Pd adalah sah dan berkekuatan hukum, 3. Menghukum Penggugat untuk membayar biaya yang timbul dalam perkara ini;
Penggugat mengajukan replik tertulis pada tanggal 04 Desember
2025 dan terhadap replik Penggugat tersebut, Tergugat mengajukan duplik tertulis pada tanggal 18 Desember 2025;
Penggugat telah mengajukan alat bukti berupa fotokopi surat-surat yang telah diberi materai cukup serta dicocokkan dengan pembandingnya,
masing-masing diberi tanda P-1 s.d. P-16 sebagai berikut:

1.
Bukti P-1
: Keputusan Rektor Institut Agama Kristen Negeri Kupang Nomor 497 Tahun 2025 tanggal 30 Juli 2025
tentang Pemberhentian Wakil Rektor II Bidang Administrasi Umum, Perencanaan dan Keuangan Institut Agama Kristen Negeri Kupang atas nama Martin Chrisani Liufeto, M.Pd. (fotokopi sesuai dengan asli);
2.
Bukti P-2
: Keputusan Rektor Institut Agama Kristen Negeri Kupang Nomor 201 Tahun 2024 tanggal 25 September
2024 tentang Pengangkatan Wakil Rektor II Bidang Administrasi Umum, Perencanaan dan Keuangan Institut Agama Kristen Negeri Kupang atas nama Martin Chrisani Liufeto, M.Pd. (fotokopi sesuai dengan fotokopi dengan stempel basah);
3.
Bukti P-3
: Surat dari Martin Ch. Liufeto, M.Pd., tanggal 25 Agustus
2025 Perihal: Keberatan, yang ditujukan kepada Rektor Institut Agama Kristen Negeri Kupang (IAKN) Kupang
(fotokopi sesuai dengan asli);
4.
Bukti P-4
: Tanda Terima Surat Keberatan, tanggal 25 Agustus
2025 (fotokopi sesuai dengan asli);
5.
Bukti P-5
: Keputusan Ketua Sekolah Tinggi Agama Kristen Negeri Kupang Nomor: Stk.07/2a/KP.00.3/613/2016 tanggal 29
Februari 2016 tentang Pengangkatan Pegawai Negeri Sipil atas nama Martin Chrisani Liufeto, M.Pd. (fotokopi sesuai dengan asli);
6.
Bukti P-6
: Keputusan Menteri Agama Republik Indonesia Nomor:
B-3475/Stk.01/2a/07.1/12/2020 tanggal 29 Desember
2020 tentang Kenaikan Pangkat Pegawai Negeri Sipil atas nama Martin Chrisani Liufeto, M.Pd. (fotokopi sesuai dengan asli);
7.
Bukti P-7
: Keputusan Menteri Agama Nomor: 46 Tahun 2024
tanggal 14 Maret 2024 tentang kenaikan pangkat atas nama Martin Chrisani Liufeto, M.Pd (fotokopi sesuai

dengan asli);
8.
Bukti P-8
: Nota Dinas Nomor:
3839/Ikn.01/I/KP.04.2/07/2025
tanggal 23 Juli 2025, dari Rektor kepada Kepala Biro AUAK, Hal: Menerbitkan SK Pemberhentian Pejabat
(fotokopi sesuai dengan fotokopi);
9.
Bukti P-9
: Peraturan Menteri Agama Republik Indonesia Nomor
37 Tahun 2020 tentang Statuta Institut Agama Kristen Negeri Kupang (fotokopi sesuai dengan fotokopi);
10. Bukti P-10
: Peraturan Menteri Agama Republik Indonesia Nomor
24 Tahun 2020 tentang Organisasi dan Tata Kerja Institut Agama Kristen Negeri Kupang (fotokopi sesuai dengan fotokopi);
11. Bukti P-11
: Piagam Tanda Kehormatan Presiden Republik Indonesia Satyalancana Karya Satya X Tahun atas nama Martin Chrisani Liufeto, M.Pd., tanggal 22 Juli
2025 (fotokopi sesuai dengan asli);
12. Bukti P-12
: Petikan Keputusan Presiden Republik Indonesia Nomor
58/TK/Tahun 2025 tanggal 22 Juli 2025 tentang Penganugerahan Tanda Kehormatan Satyalancana Karya Satya, atas nama Martin Chrisani Liufeto, M.Pd.
(fotokopi sesuai dengan asli);
13. Bukti P-13
: Dokumen sasaran kinerja pegawai pengisian bukti dukung untuk periode tahunan tahun 2024 atas nama ASN Martin Chrisani Liufeto, M.Pd (fotokopi sesuai dengan hasil cetak);
14. Bukti P-14
: Dokumen sasaran kinerja pegawai pengisian bukti dukung untuk periode tahunan tahun 2025 atas nama ASN Martin Chrisani Liufeto, M.Pd (fotokopi sesuai dengan hasil cetak);
15. Bukti P-15
: Keputusan Rektor Institut Agama Kristen Negeri Kupang Nomor 336 Tahun 2024 tanggal 14 November
2024 tentang Panitia, Peserta, Narasumber dan

Moderator Kegiatan Focus Group Discussion (FGD)
Finalisasi RIP dan Penyusunan Program Prioritas Renstra Tahun 2025-2029 Institut Agama Kristen Negeri Kupang Tahun 2024 beserta lampirannya (fotokopi sesuai dengan fotokopi);
16. Bukti P-16
: Keputusan Rektor Institut Agama Kristen Negeri Kupang Nomor 344 Tahun 2024 tanggal 19 November
2024 tentang Tim Penyusunan Renstra di Lingkungan Institut Agama Kristen Negeri Kupang Tahun 2025-2029
beserta lampirannya (fotokopi sesuai dengan fotokopi);
Tergugat telah mengajukan alat bukti berupa fotokopi surat-surat yang telah diberi materai cukup serta telah dicocokkan dengan pembandingnya, masing-masing diberi tanda T-1 s.d. T-22, sebagai berikut:
1.
Bukti T-1
: Fotokopi Kartu Tanda Penduduk Nomor Induk Kependudukan 7326111212750001 atas nama I Made Suardana (fotokopi sesuai dengan fotokopi);
2.
Bukti T-2
: Keputusan Menteri Agama Republik Indonesia Nomor:
031924/MA.KP.07/8/2024
tanggal
7 Agustus
2024
tentang Pemindahan dan Pengangkatan Dr. I Made Suardana, M.Th., NIP 197512122008011014, Pembina,
IV/a, Lektor Kepala pada Institut Agama Kristen Negeri Toraja dalam jabatan tugas tambahan sebagai Rektor Institut Agama Kristen Negeri Kupang masa jabatan tahun 2024 sampai dengan 2028 (fotokopi sesuai dengan stempel basah);
3.
Bukti T-3
: Keputusan Rektor Institut Agama Kristen Negeri Kupang Nomor 201 Tahun 2024 tanggal 25 September 2024
tentang Pengangkatan Wakil Rektor II Bidang Administrasi Umum, Perencanaan dan Keuangan Institut Agama Kristen Negeri Kupang atas nama Martin Chrisani Liufeto,
M.Pd.
(fotokopi sesuai dengan fotokopi);

4.
Bukti T-4
: Hasil tangkapan layar pesan WhatsApp (fotokopi sesuai dengan fotokopi);
5.
Bukti T-5
: Surat Pernyataan Kesediaan Bekerjasama tanggal 10
September 2024 atas nama Martin Chrisani Liufeto,
M.Pd. (fotokopi sesuai dengan asli);
6.
Bukti T-6
: Surat Telaah tentang Pemberhentian Pejabat Pimpinan Nomor: 5111/Ikn/01/1/OT.01.2/08/2025 Perihal: Telaah Pemberhentian Pejabat Pimpinan di Lingkungan IAKN Kupang dari Rektor IAKN Kupang kepada Direktur Jenderal Bimbingan Masyarakat Kristen Kementerian Agama Republik Indonesia, tanpa tanggal (fotokopi sesuai dengan asli);
7.
Bukti T-7
: Nota Dinas Nomor:
3839/Ikn.01/I/KP.04.2/07/2025
tanggal 23 Juli 2025, dari Rektor kepada Kepala Biro AUAK, Hal: Menerbitkan SK Pemberhentian Pejabat
(fotokopi sesuai dengan fotokopi);
8.
Bukti T-8
: Keputusan Rektor Institut Agama Kristen Negeri Kupang Nomor 497 Tahun 2025 tanggal 30 Juli 2025 tentang Pemberhentian Wakil Rektor II Bidang Administrasi Umum, Perencanaan dan Keuangan Institut Agama Kristen Negeri Kupang, atas nama Martin Chrisani Liufeto, M.Pd. (fotokopi sesuai dengan asli);
9.
Bukti T-9
: Hasil tangkapan layar video tanggal 6 Agustus 2025 dari Media Online Zonalinenews (fotokopi sesuai dengan hasil cetak);
10. Bukti T-10
: Notulen Rapat Hari Senin, Tanggal 11 Agustus 2025,
beserta lampirannya (fotokopi sesuai dengan asli);
11. Bukti T-11
: Surat dari Martin Ch. Liufeto, M.Pd., tanggal 25 Agustus
2025 Perihal: Keberatan yang ditujukan kepada Rektor Institut Agama Kristen Negeri Kupang (IAKN) Kupang
(fotokopi sesuai dengan asli);
12. Bukti T-12
: Lembar Disposisi Surat dari Martin Ch. Liufeto, M.Pd.,

tanggal 25 Agustus 2025 Perihal: Keberatan yang ditujukan kepada Rektor Institut Agama Kristen Negeri Kupang (IAKN) Kupang (fotokopi sesuai dengan asli);
13. Bukti T-13
: Peraturan Menteri Agama Republik Indonesia Nomor 37
Tahun 2020 tentang Statuta Institut Agama Kristen Negeri Kupang (fotokopi sesuai dengan fotokopi);
14. Bukti T-14
: Peraturan Menteri Agama Republik Indonesia Nomor 24
Tahun 2020 tentang Organisasi dan Tata Kerja Institut Agama Kristen Negeri Kupang (fotokopi sesuai dengan fotokopi);
15. Bukti T-15
: Surat Rektor Institut Agama Kristen Negeri Kupang Nomor:
P-8090/Ikn.01/I/PP.09/12/2025
tanggal
04
Desember 2025 Hal: Penyampaian Dokumen Analisis Legalitas dan Akreditasi Prodi PPA terkait Pencairan Beasiswa KIP Kuliah, yang ditujukan kepada Ketua Badan Pemeriksa Keuangan Republik Indonesia beserta lampirannya (fotokopi sesuai dengan fotokopi);
16. Bukti T-16
: Lembar Disposisi penerimaan surat dari WR II nomor:
SP-II/Ikn.01/1b/PP.04/07/2025
tanggal 8
Juli
2025
Perihal Surat Pengantar Hasil Verifikasi Program Beasiswa KIP beserta lampirannya (fotokopi sesuai dengan fotokopi);
17. Bukti T-17
: Pengumuman Nomor: 5048/Ikn.01/IIa.2/09/2024 dari Kepala Biro Administrasi Umum, Akademik,
dan Kemahasiswaan atas nama Rektor Institut Agama Kristen Negeri Kupang, tanggal 26 September 2024
tentang Penetapan Nama-Nama Penerima Bantuan Beasiswa Program Indonesia Pintar (PIP) Lama Tahap II Institut Agama Kristen Negeri Kupang Tahun 2024
beserta lampirannya (fotokopi sesuai dengan fotokopi);
18. Bukti T-18
: Surat Kepala Perwakilan Ombudsman Republik Indonesia Provinsi Nusa Tenggara Timur Nomor:

T/0129/LM.48-18/0009.2025/IV/2025 tanggal 24 April
2025 Hal: Permintaan Keterangan, yang ditujukan kepada Rektor Institut Agama Kristen Negeri Kupang
(fotokopi sesuai dengan fotokopi);
19. Bukti T-19
: Surat Kepala Biro Administrasi Umum Akademik dan Keuangan atas nama Rektor Institut Agama Kristen Negeri Kupang Nomor:
B-
6639/Ikn.01/IIa.1/HM.01/10/2025 tanggal 01 Oktober
2025 Perihal: Undangan (fotokopi sesuai dengan fotokopi);
20. Bukti T-20
: Artikel dari Koran Media Selalu Terdepan, dengan judul:
Bahas Persoalan Beasiswa PIP, Ombudsman NTT Minta IAKN Kupang Harus Transparan (fotokopi sesuai dengan hasil cetak);
21. Bukti T-21
: Artikel dari BeritaNasional.ID,
dengan judul:
Ombudsman NTT Apresiasi Respons Cepat IAKN Kupang Tangani Laporan Masyarakat (fotokopi sesuai dengan hasil cetak);
22. Bukti T-22
: Keputusan Rektor Institut Agama Kristen Negeri Kupang Nomor 683 Tahun 2025 tanggal 24 Oktober 2025
tentang Pedoman Pelaksanaan Program Kartu Indonesia Pintar Kuliah Institut Agama Kristen Negeri Kupang (fotokopi sesuai dengan fotokopi);
Tergugat mengajukan bukti elektronik yang telah ditunjukkan secara sah dalam persidangan diberi tanda T.E-1 sebagai berikut:
1.
Bukti T.E-1
: Video pernyataan terkait Surat Keputusan Rektor Institut Agama Kristen Negeri Kupang Nomor 497 Tahun 2025
tanggal 30 Juli 2025 Tentang Pemberhentian Wakil Rektor II Bidang Administrasi Umum, Perencanaan Dan Keuangan Institut Agama Kristen Negeri Kupang atas nama Martin Chrisani Liufeto, M.Pd., (telah ditunjukkan secara sah dalam persidangan);

Penggugat mengajukan 2 (dua) orang saksi yang telah memberikan pendapat atau keterangan di bawah sumpah/janji menurut agama dan kepercayaannya:
Saksi Penggugat:
1.
Roimanson Panjaitan:
−
Bahwa Saksi menerangkan dirinya berstatus sebagai dosen di Institut Agama Kristen Negeri Kupang sejak tahun 2014
dengan mata kuliah yang diampu adalah Metodologi Penelitian;
−
Bahwa saksi dan Penggugat diangkat sebagai Pegawai Negeri Sipil pada tahun yang sama sehingga hubungan kedinasan keduanya telah terjalin sejak awal masa pengabdian;
−
Bahwa selain sebagai dosen, saksi pernah menjabat sebagai Kepala Satuan Pengawas Internal (SPI) berdasarkan Surat Keputusan tertanggal 28 Oktober 2024, namun kemudian diberhentikan bersamaan dengan Penggugat;
−
Bahwa objek sengketa berawal dari Nota Dinas tertanggal 23
Juli 2025 yang diterbitkan oleh Rektor dan ditujukan kepada Biro Administrasi Umum, Akademik, dan Kemahasiswaan
(AUAK)
untuk segera menerbitkan Surat Keputusan pemberhentian;
−
Bahwa penerbitan SK pemberhentian tersebut dilakukan dalam dua tahap, yakni pada tanggal 23 Juli 2025 dan 30
Juli 2025, yang mengenai empat pejabat struktural, termasuk saksi dan Penggugat;
−
Bahwa alasan yang tercantum dalam Nota Dinas tersebut adalah penataan struktur dan langkah evaluasi.
−
Bahwa saksi mengetahui keberadaan Nota Dinas dan SK pemberhentian tersebut setelah menerima soft file melalui pesan WhatsApp dari bagian kepegawaian pada tanggal 22
Juli 2025;

−
Bahwa sepanjang pengetahuan saksi, tidak terdapat pembentukan tim atau mekanisme khusus dalam proses penerbitan Nota Dinas dimaksud, serta tidak diketahuinya adanya proses telaah administratif lanjutan setelah Nota Dinas ditujukan kepada Kepala Biro sebelum SK pemberhentian diterbitkan;
−
Bahwa dalam aspek pengaturan kelembagaan, saksi menerangkan organisasi dan tata kerja IAKN diatur dalam Peraturan Menteri Agama Nomor 24 Tahun 2020, sedangkan ketentuan mengenai statuta diatur dalam Peraturan Menteri Agama Nomor 37 Tahun 2020;
−
Bahwa pada tahun 2025 tidak terdapat peraturan baru yang mencabut atau menggantikan kedua regulasi tersebut;
−
Bahwa SPI berdasarkan regulasi tersebut memiliki fungsi pengawasan pada bidang non-akademik yang meliputi keuangan, kinerja, dan kepatuhan;
−
Bahwa selama menjabat sebagai Kepala SPI, saksi tidak pernah mengeluarkan laporan evaluasi yang menyatakan bahwa kinerja Penggugat tidak baik, serta tidak pernah mengetahui adanya pemeriksaan disiplin, teguran, maupun sanksi administratif terhadap Penggugat pada tahun 2025;
−
Bahwa dalam pengamatan profesional saksi, Penggugat menjalankan tugasnya sebagai Wakil Rektor II dengan baik,
meskipun penilaian tersebut diakui bukan merupakan hasil evaluasi formal berbasis instrumen kinerja tertulis seperti SKP;
−
Bahwa saksi mengetahui proses pengangkatan Penggugat sebagai Wakil Rektor II dilakukan melalui mekanisme seleksi penjaringan perangkat Rektor pada tahun 2024 yang meliputi tahapan administratif, verifikasi, penilaian oleh panitia penjaringan,
dan wawancara oleh Rektor sebelum penetapan. Bahwa salah satu persyaratan dalam proses

penjaringan tersebut adalah adanya surat pernyataan kesediaan bekerja sama dengan Rektor, yang dibuat sebagai syarat seleksi sebelum pelantikan;
−
Bahwa dalam lingkup tugas, Penggugat membidangi urusan keuangan termasuk pengelolaan beasiswa. Bahwa saksi mengetahui adanya isu salah pembayaran beasiswa yang berkembang di masyarakat dan telah dilakukan klarifikasi ke Ombudsman oleh beberapa pihak termasuk saksi dan Penggugat. Pertemuan tersebut bersifat klarifikasi, bukan pemeriksaan,
dan Ombudsman pada pokoknya menyarankan peningkatan transparansi publikasi pengelolaan beasiswa. Bahwa hasil klarifikasi tersebut telah disampaikan secara lisan kepada Rektor;
−
Bahwa saksi mengetahui adanya pembebanan tugas kepada Penggugat untuk menyusun SOP berdasarkan perintah lisan Rektor, serta dalam beberapa rapat revisi anggaran pernah ditanyakan progresnya. Namun demikian, saksi tidak mengetahui secara rinci perkembangan penyusunan SOP tersebut. Bahwa SPI sendiri belum memiliki instrumen baku untuk mengukur efektivitas kerja sama antara Rektor dan Wakil Rektor, karena pedoman internal terkait manajemen risiko, audit, dan tata kelola masih dalam tahap penyusunan dan belum terselesaikan hingga saksi diberhentikan;
−
Bahwa dalam pelaksanaan apel rutin setiap Senin pagi,
Rektor pernah menyampaikan permintaan pertanggungjawaban kinerja secara umum kepada seluruh jajaran pimpinan, namun tidak secara khusus ditujukan kepada Penggugat;
−
Bahwa sebelum penerbitan SK pemberhentian, saksi tidak mengetahui adanya pemanggilan atau pemeriksaan khusus terhadap Penggugat untuk dimintai klarifikasi oleh pimpinan.

−
Bahwa sebagai Kepala SPI, saksi pernah melakukan monitoring terhadap tugas-tugas Wakil Rektor II khususnya terkait laporan beasiswa mahasiswa, dan hasil klarifikasi tersebut dibuatkan laporan serta ditembuskan kepada Rektor. Namun demikian, saksi tidak pernah menyampaikan laporan penilaian kinerja formal yang menyatakan adanya ketidakprofesionalan Penggugat;
−
Bahwa saksi juga mengetahui dalam statuta terdapat alasan pemberhentian perangkat Rektor berupa tidak dapat bekerja sama dengan Rektor, namun saksi tidak mengetahui adanya instrumen penilaian objektif maupun proses evaluasi formal yang secara khusus mendasari penerapan alasan tersebut terhadap Penggugat;
2.
Vinsensius A. Paulo:
−
Bahwa Saksi menerangkan tugas pokok dan fungsinya sebagai penerima dan pencatat surat masuk pada bagian tata usaha di Institut Agama Kristen Negeri Kupang, yang selanjutnya meneruskan surat dimaksud sesuai dengan alur administrasi yang berlaku;
−
Bahwa Saksi bekerja di dalam Gedung IAKN, namun tidak berada dalam satu gedung dengan Rektor sehingga secara fisik terpisah dari ruang kerja Rektor;
−
Bahwa setiap surat masuk terlebih dahulu dicatat dalam buku registrasi pada bagian tata usaha, kemudian diteruskan kepada Kepala Bagian Umum untuk selanjutnya disampaikan kepada staf Rektor, dan Saksi tidak mengetahui lebih lanjut disposisi akhir surat tersebut selain memperoleh konfirmasi bahwa surat telah diteruskan kepada staf Rektor;
−
Bahwa Saksi mengakui pernah menerima surat keberatan dari Penggugat dan atas penerimaan tersebut dilakukan pencatatan dalam buku registrasi surat masuk serta tanda terima tercantum dalam lembar pengantar administrasi;

−
Bahwa Saksi mengetahui perihal surat yang diterima berupa keberatan, namun tidak membaca isi surat tersebut sehingga tidak mengetahui secara spesifik substansi atau pokok keberatan yang diajukan;
−
Bahwa setelah dilakukan konfirmasi terhadap bukti bertanda P-3 dan P-4, Saksi membenarkan bahwa surat sebagaimana tercantum dalam bukti tersebut adalah benar surat yang pernah diterimanya pada bagian tata usaha;
Tergugat juga mengajukan 5 (lima) orang saksi yang telah memberikan keterangan di bawah sumpah/janji menurut agama dan kepercayaannya:
Saksi Tergugat:
1.
Ezra Tari:
−
Bahwa Saksi berprofesi sebagai dosen di Institut Agama Kristen Negeri Kupang sejak tahun 2014 dan selain itu menjabat sebagai Direktur Pascasarjana.
Saksi juga berkedudukan sebagai anggota senat secara ex officio.
Saksi mengenal Penggugat sejak tahun
2014, dan mengetahui bahwa Penggugat menjabat sebagai Wakil Rektor II (WR II) sejak Agustus 2024 sampai dengan Mei
2025;
−
Bahwa terkait dengan pemberhentian Penggugat sebagai WR II, Saksi menerangkan pernah dipanggil oleh Rektor pada bulan April dan Mei 2025 dalam kapasitasnya sebagai Direktur Pascasarjana untuk mengikuti pertemuan evaluasi terhadap perangkat rektor, khususnya kinerja Penggugat selaku WR II. Pemanggilan dilakukan secara lisan melalui staf rektor bernama Amon. Dalam pertemuan tersebut hadir WR I (Marion), Direktur Pascasarjana, dan salah satu dekan,
yakni Dekan Fakultas Seni (Regi Sibutar). Tidak terdapat penyebutan adanya tim evaluasi secara formal;

−
Bahwa pokok pembahasan dalam evaluasi dimaksud berkaitan dengan kinerja Penggugat, khususnya mengenai penyelesaian beasiswa mahasiswa, termasuk persoalan adanya salah transfer dana dan belum tuntasnya realisasi pembayaran beasiswa. Saksi tidak mengetahui secara pasti jumlah mahasiswa terdampak maupun besaran kerugian,
namun menerangkan pernah terjadi aksi demonstrasi di kampus yang diikuti sekitar 9 (sembilan) mahasiswa dan ditujukan kepada Rektor;
−
Bahwa menurut keterangan Saksi, pembahasan evaluasi hanya terfokus pada persoalan beasiswa dan tidak dibahas alasan lain. Saksi juga menyatakan tidak mengetahui adanya laporan mahasiswa secara formal sebelum evaluasi tersebut.
Dalam rapat tidak dibacakan atau dibahas secara eksplisit kesimpulan akhir, namun Saksi menerangkan bahwa terdapat pembahasan mengenai rencana pemberhentian WR II;
−
Bahwa terhadap proses administratif pemberhentian, Saksi tidak mengikuti secara langsung dan tidak mengetahui mekanisme penerbitan Surat Keputusan pemberhentian yang menurut pengetahuannya diterbitkan pada bulan Juli
2025. Saksi juga tidak mengetahui secara rinci apakah terdapat berita acara atau notulensi resmi, serta tidak pernah membaca notulen rapat tersebut;
−
Bahwa dalam aspek normatif kelembagaan,
Saksi mengetahui bahwa pengelolaan perguruan tinggi mengacu pada Statuta dan peraturan yang berlaku, antara lain PMA Nomor 37 Tahun 2020 dan PMA Nomor 24 Tahun 2020, yang mengatur mekanisme pengangkatan Wakil Rektor dan Dekan.
Saksi mengetahui adanya klausul kewajiban bekerjasama dengan Rektor dalam Statuta, namun tidak mengetahui secara spesifik ruang lingkup kerjasama

dimaksud maupun ketentuan rinci mengenai syarat dan tata cara pemberhentian;
−
Bahwa terkait tugas pokok dan fungsi WR II, Saksi menerangkan secara umum meliputi bidang administrasi,
hukum, dan kemahasiswaan. Terdapat SOP organisasi dan tata kerja sebagai pedoman umum, namun tidak terdapat SOP khusus yang secara spesifik mengatur pengukuran kinerja WR II, termasuk SOP pengawasan kinerja;
2.
Hasudungan Sidabutar:
−
Bahwa Saksi menjabat sebagai Kepala Satuan Pengawasan Internal (SPI) di Institut Agama Kristen Negeri Kupang dan menerangkan bahwa dirinya menggantikan pejabat sebelumnya, yakni Roimanson Panjaitan. Saksi mulai menjabat sebagai Kepala SPI sejak Oktober 2025 sampai dengan sekarang;
−
Bahwa menurut keterangan Saksi, secara struktural dan fungsional SPI memiliki tugas pokok dalam dua ranah utama,
yakni fungsi assurance dan fungsi consulting. Dalam fungsi assurance, SPI melaksanakan audit keuangan, audit Barang Milik Negara (BMN), audit kinerja, serta audit kepatuhan,
termasuk kegiatan review dan evaluasi. Adapun dalam fungsi consulting, SPI memastikan penyelenggaraan tata kelola berjalan sesuai peraturan perundang-undangan serta memberikan rekomendasi kepada pimpinan.
Saksi menerangkan bahwa dalam pelaksanaan tugasnya, lingkup pengawasan SPI secara umum berkaitan dengan bidang yang menjadi koordinasi Wakil Rektor II;
−
Bahwa terhadap pemberhentian Penggugat sebagai WR II,
Saksi menyatakan tidak mengetahui proses maupun dasar pemberhentian tersebut, karena pada saat keputusan dimaksud diambil, Saksi masih berstatus sebagai dosen

biasa. Pengetahuan Saksi mengenai pemberhentian tersebut hanya diperoleh dari media;
−
Bahwa selama menjabat sebagai Kepala SPI, Saksi telah melakukan audit keuangan atas anggaran tahun 2025,
namun tidak pernah melakukan audit kinerja terhadap Penggugat. Berdasarkan dokumen yang diperiksa setelah menjabat, pada tahun 2025 tidak terdapat audit kinerja yang dilakukan oleh SPI. Saksi juga menegaskan bahwa apabila SPI hendak melakukan audit, maka terlebih dahulu diajukan surat permohonan kepada pimpinan/rektor dengan mencantumkan indikator-indikator pemeriksaan dalam Program Kerja Pengawasan Tahunan (PKPT);
−
Bahwa Saksi tidak pernah menerima hasil audit kinerja dari Kepala SPI sebelumnya, serta tidak pernah menemukan atau memeriksa dokumen audit terkait realisasi beasiswa.
Dengan demikian, tidak terdapat data audit internal yang dapat dijadikan rujukan formal mengenai evaluasi kinerja Penggugat dalam kapasitasnya sebagai WR II;
−
Bahwa dalam menjelaskan parameter audit,
Saksi menerangkan bahwa pengukuran kinerja dilakukan berdasarkan pengelolaan anggaran, pelaksanaan tridharma perguruan tinggi, serta pelaksanaan tugas tambahan sesuai dengan tugas pokok dan fungsi jabatan. Sementara itu,
aspek kepatuhan diukur dari sejauh mana pelaksanaan tugas telah dilaksanakan sesuai ketentuan yang berlaku;
−
Bahwa terkait permasalahan beasiswa yang sempat menjadi isu di lingkungan kampus, Saksi hanya mengetahui dari pemberitaan media dan tidak memiliki pengetahuan langsung maupun hasil audit internal terkait hal tersebut.
3.
Relin Yosi Huka:
−
Bahwa Saksi menerangkan telah berstatus sebagai dosen sejak tahun 2014 di Institut Agama Kristen Negeri Kupang

dengan bidang pengajaran musik, dan saat ini menjabat sebagai Dekan Fakultas Seni. Saksi mengenal Penggugat sejak tahun 2014 dan mengetahui bahwa Penggugat diangkat sebagai Wakil Rektor II (WR II) sekitar September
2024. Saksi juga mengetahui bahwa Rektor IAKN dijabat oleh I Made Suardana sejak Agustus 2024;
−
Bahwa terkait dengan pemberhentian Penggugat sebagai WR II, Saksi mengetahui adanya surat telaah pejabat pimpinan yang ditujukan kepada Direktur Jenderal Bimbingan Masyarakat Kristen Kementerian Agama. Surat telaah tersebut, menurut keterangan Saksi, memuat aspek kinerja, etika, dan administrasi, dengan substansi antara lain mengenai tidak terselesaikannya pengelolaan beasiswa,
persoalan komunikasi,
serta pertanggungjawaban Penggugat kepada Rektor yang dinilai tidak dilaksanakan dengan baik;
−
Bahwa telaah tersebut disusun oleh tim yang terdiri dari Saksi sendiri, Sance Tameon (Wakil Dekan II Fakultas Sosial), dan Marion Pattinaya (WR I). Penyusunan telaah dilakukan setelah terbitnya Surat Keputusan pemberhentian Penggugat sebagai WR II, dengan maksud sebagai laporan kepada Kementerian Agama. Saksi menerangkan bahwa penyusunan telaah merupakan inisiatif internal IAKN, bukan atas perintah langsung dari Dirjen;
−
Bahwa sebelum penyusunan telaah, terdapat dokumen kronologis pemberhentian yang telah dibuat, dan menurut Saksi, kronologis tersebut menjadi dasar dalam penyusunan telaah. Namun demikian, Saksi tidak mengetahui siapa yang menyusun kronologis tersebut serta tidak memperhatikan apakah dibubuhkan tanda tangan. Saksi juga menerangkan adanya tim ad hoc yang ditunjuk secara lisan oleh Rektor,

tanpa mengetahui apakah penunjukan tersebut didasarkan pada Surat Keputusan formal;
−
Bahwa dalam penyusunan telaah, alasan-alasan yang dicantumkan diperoleh dari penjelasan Rektor, termasuk mengenai persoalan beasiswa dan etika komunikasi. Salah satu peristiwa yang disebutkan adalah dugaan pelanggaran etika oleh Penggugat saat proses akreditasi, berupa pernyataan yang dianggap tidak patut di hadapan asesor.
Saksi tidak menyaksikan secara langsung proses pemeriksaan atas dugaan tersebut dan hanya mengetahui dari penuturan Rektor;
−
Bahwa Saksi menerangkan tidak pernah dipanggil secara khusus oleh Rektor untuk membahas kinerja Penggugat,
selain pengingatan secara umum dalam rapat-rapat. Saksi juga tidak mengetahui adanya surat teguran tertulis,
pernyataan resmi ketidakpuasan,
maupun proses pemeriksaan formal terhadap Penggugat sebelum pemberhentian;
−
Bahwa setelah pemberhentian, Saksi mengetahui adanya aksi demonstrasi sekitar bulan Agustus 2025 serta adanya video pernyataan Penggugat yang menyatakan menerima pemberhentian tersebut, yang diketahui Saksi dari kiriman rekan-rekan;
4.
Drs. Yorhans S. Lopis, M.Si:
−
Bahwa Saksi berstatus sebagai Pegawai Negeri Sipil sejak tahun 2021, sebelumnya bertugas pada Kantor Wilayah Kementerian Agama Nusa Tenggara Timur. Di lingkungan IAKN Kupang, Saksi bertugas pada Biro Administrasi Umum,
Akademik, dan Keuangan dengan fungsi koordinatif di bidang administrasi umum,
keuangan,
akademik,
kepegawaian PNS, serta perencanaan;

−
Bahwa dalam kedudukannya tersebut, Saksi diangkat oleh Menteri Agama Republik Indonesia dan berkedudukan sebagai mitra kerja Rektor selaku pimpinan satuan kerja.
Terkait penerbitan Surat Keputusan (SK) pemberhentian Penggugat sebagai Wakil Rektor II (WR II), Saksi menerangkan menerima nota dinas yang dibuat oleh Rektor dan disampaikan melalui staf. Nota dinas tersebut pada konsideran awal menyebut alasan umum berupa penataan organisasi dan penyegaran struktur;
−
Bahwa setelah menerima nota dinas tersebut, Saksi menindaklanjuti dengan menyusun konsep SK sesuai perintah dalam nota dinas, tanpa melakukan penelaahan terhadap alasan-alasan substantif pemberhentian. Saksi menegaskan tidak memiliki kewenangan untuk menelaah dasar pemberhentian kecuali diminta oleh Rektor, dan dalam hal ini tidak pernah diminta melakukan telaah. Ketika menanyakan apakah SK harus segera diproses, Rektor menjawab agar segera ditindaklanjuti;
−
Bahwa menurut keterangan Saksi,
alasan spesifik pemberhentian tidak tercantum dalam nota dinas dan tidak disampaikan secara langsung pada saat penerbitan SK.
Saksi hanya mengingat adanya penyampaian umum oleh Rektor dalam berbagai kesempatan, termasuk apel dan pertemuan informal,
mengenai keinginan melakukan pergantian kabinet/perangkat rektor dengan alasan adanya pekerjaan yang tertunda serta kebutuhan percepatan kinerja;
−
Bahwa dalam sistem tata naskah dinas di Institut Agama Kristen Negeri Kupang, setiap surat dinas seharusnya dibubuhi paraf koordinasi, termasuk oleh Saksi selaku Kepala Biro, Kepala Bagian Umum, dan WR II. Namun terhadap SK pemberhentian dimaksud, Saksi menerangkan tidak terdapat paraf koordinasi sebagaimana lazimnya. SK

tersebut diantarkan kepada Rektor untuk ditandatangani melalui staf Saksi;
−
Bahwa Saksi tidak mengetahui adanya pemeriksaan atau evaluasi formal terhadap Penggugat sebelum diterbitkannya nota dinas, dan menegaskan tidak pernah ada tim yang melakukan pemeriksaan sebelum penerbitan keputusan pemberhentian. Saksi juga tidak mengetahui adanya surat teguran tertulis maupun sanksi disiplin terhadap Penggugat selama bertugas di Institut Agama Kristen Negeri Kupang;
−
Bahwa terkait aspek pengawasan,
Saksi mengenal Roimanson Panjaitan yang menjabat sebagai Kepala SPI pada tahun 2025, namun tidak pernah mendengar adanya rekomendasi dari SPI terkait pemberhentian Penggugat;
−
Bahwa mengenai substansi beasiswa, Saksi menerangkan bahwa ruang lingkup tugas beasiswa berada dalam ranah WR III, bukan WR II;
−
Bahwa Saksi juga menerangkan bahwa Penggugat pernah memperoleh penghargaan Satyalancana Karya Satya yang diusulkan oleh kampus kepada Biro SDM Kementerian Agama dan diteruskan kepada Staf Kepresidenan, dengan persyaratan antara lain berprestasi dan memiliki kinerja tinggi. Penghargaan tersebut diberikan dalam upacara/apel resmi dan berlaku bagi seluruh PNS, tidak terbatas pada pejabat struktural;
−
Bahwa terkait penataan organisasi, Saksi menjelaskan bahwa penataan tidak identik dengan perubahan struktur organisasi, melainkan lebih pada pembenahan untuk meningkatkan pelayanan. Sepanjang pengetahuan Saksi sejak tahun 2021, pada masa kepemimpinan rektor sebelumnya tidak pernah terdapat pemberhentian dengan dasar penataan organisasi;

−
Bahwa dalam mekanisme penjaringan perangkat rektor,
dibentuk tim penjaringan dan Saksi pernah menjabat sebagai Ketua Tim tersebut.
Namun demikian,
pada saat pemberhentian Penggugat,
tidak terdapat tim yang melakukan pemeriksaan sebelum diterbitkannya nota dinas;
5.
Maryon Daniamaputra Pattinaja:
−
Bahwa Saksi menjabat sebagai Wakil Rektor I (WR I) di Institut Agama Kristen Negeri Kupang sejak Oktober 2024,
dengan tugas pokok dan fungsi di bidang akademik dan kelembagaan. Saksi menerangkan bahwa pada saat Penggugat menjabat sebagai Wakil Rektor II (WR II), ruang lingkup tugas WR II meliputi bidang perencanaan dan keuangan;
−
Bahwa terkait program beasiswa, Saksi menjelaskan beasiswa berada dalam ranah keuangan dan kemahasiswaan sehingga kewenangannya melekat pada WR II;
−
Bahwa WR I tidak selalu dilibatkan dalam urusan tersebut.
Bahwa setiap tahun terdapat kuota beasiswa, namun Saksi tidak mengetahui secara rinci jumlahnya;
−
Bahwa permasalahan beasiswa muncul pada masa kepemimpinan Rektor yang baru setelah pengangkatan pada Agustus
2024,
ketika ditemukan adanya perubahan penerima beasiswa di tengah masa studi;
−
Bahwa secara regulatif mahasiswa yang telah ditetapkan sebagai penerima beasiswa seharusnya tetap menerima hingga akhir masa studi sepanjang memenuhi persyaratan.
Perubahan tersebut berupa penghentian pembayaran terhadap mahasiswa yang sebelumnya telah ditetapkan sebagai penerima, dan bahwa kebijakan tersebut terjadi pada periode pimpinan sebelumnya;

−
Bahwa Rektor yang baru kemudian meminta WR II melakukan telaah guna memulihkan hak mahasiswa, dan bahwa dalam proses tersebut ditemukan kekeliruan administrasi berupa kesalahan transfer akibat tidak diperbaruinya nomor rekening mahasiswa. Bahwa terdapat sekitar 40 mahasiswa yang terdampak, yang setelah klarifikasi dengan pihak bank tersisa sekitar 20 mahasiswa dan hingga tahun 2025 belum terselesaikan. Bahwa para mahasiswa tersebut pada prinsipnya adalah pihak yang berhak menerima beasiswa dengan nominal yang sama, dan bahwa Saksi tidak mengetahui secara langsung siapa yang melakukan kesalahan transfer dimaksud;
−
Bahwa terkait rencana strategis (renstra) periode 2025–
2029, Saksi menerangkan renstra merupakan dokumen perencanaan lima tahunan yang secara substantif berada dalam ranah perencanaan dan menjadi kewenangan WR II.
Bahwa telah dibentuk tim penyusun berdasarkan SK Rektor Nomor 344 Tahun 2024, di mana Saksi sempat menjadi penanggung jawab kurang lebih satu tahun sebelum kemudian dibebastugaskan dan perannya dikembalikan ke ranah perencanaan;
−
Bahwa Saksi tidak mengetahui secara pasti kesalahan konkret Penggugat dalam penyusunan renstra dan bahwa sebagian informasi diperoleh dari penjelasan Rektor;
−
Bahwa hingga pemeriksaan dilakukan, dokumen renstra masih dalam proses penetapan;
−
Bahwa mengenai penyusunan DIPA, Saksi memahami tanggung jawab berada pada bagian perencanaan dan biro keuangan yang berkoordinasi dengan WR II, serta bahwa setiap unit mengusulkan programnya masing-masing. Bahwa Saksi tidak mengetahui secara langsung apakah Penggugat mengajukan DIPA Tahun Anggaran 2025 ke kementerian;

−
Bahwa terkait pembukaan blokir belanja modal Tahun 2024,
terdapat instruksi kepada Penggugat untuk mengajukan permohonan pembukaan blokir kepada pemerintah pusat,
namun menurut pengetahuan Saksi hal tersebut tidak terlaksana;
−
Bahwa berkenaan dengan tugas tambahan berupa pembuatan video promosi institusi pada tahun 2025, instruksi diberikan secara lisan dalam forum rapat tanpa SK tertulis dan tanpa pembiayaan khusus, dan bahwa Penggugat tidak melaksanakan instruksi tersebut;
−
Bahwa dalam kaitannya dengan rencana pembangunan rusunawa,
rencana tersebut pernah dibahas dalam pertemuan bersama Gubernur Nusa Tenggara Timur, namun progresnya tidak terlaksana dan proposal belum dibuat.
Bahwa Saksi tidak mengetahui secara pasti siapa yang bertanggung jawab menyusun proposal tersebut, meskipun secara perencanaan berkaitan dengan kewenangan WR II;
−
Bahwa mengenai pemberhentian Penggugat, Saksi tidak mengetahui secara langsung alasan yuridis yang mendasari penerbitan objek sengketa dan tidak pernah melihat secara langsung SK pemberhentian tersebut, kecuali sekilas dalam grup komunikasi. Bahwa menurut pengetahuan Saksi,
statuta sebagai dasar hukum tertinggi universitas tidak secara eksplisit mengatur mekanisme pemberhentian dari tugas tambahan;
−
Bahwa Saksi mengetahui adanya komunikasi antara Rektor dan Penggugat, termasuk pernyataan agar Penggugat mengundurkan diri apabila tidak dapat bekerja sama, namun tidak mengetahui respons Penggugat. Bahwa Saksi juga tidak mengetahui secara langsung adanya pelanggaran konkret yang dilakukan Penggugat, serta tidak pernah melihat surat peringatan maupun nota dinas terkait;

−
Bahwa Saksi mengetahui Penggugat pernah menerima penghargaan Satya Lencana Karya Satya dari Presiden Republik Indonesia sebagai bentuk pengakuan atas masa bakti sebagai Aparatur Sipil Negara;
Penggugat dan Tergugat telah mengajukan kesimpulannya pada tanggal 18 Februari 2026;
Segala sesuatu dalam Berita Acara Persidangan telah termuat dan merupakan satu kesatuan dalam putusan ini;
Pada akhirnya para pihak mohon putusan pengadilan;
PERTIMBANGAN HUKUM

Menimbang, bahwa maksud dan tujuan gugatan Penggugat telah diuraikan dalam duduk perkara;
Menimbang, bahwa yang menjadi objek sengketa dalam perkara ini adalah Keputusan Rektor Institut Agama Kristen Negeri Kupang Nomor 497
Tahun 2025 tanggal 30 Juli 2025 tentang Pemberhentian Wakil Rektor II Bidang Administrasi Umum, Perencanaan Dan Keuangan Institut Agama Kristen Negeri Kupang atas nama Martin Chrisani Liufeto, M.Pd. (vide bukti P-1 =T-8);
Menimbang, bahwa atas Gugatan Penggugat tersebut, Tergugat telah mengajukan Jawabannya tanggal 27 November 2025 yang diunggah pada Sistem Informasi Pengadilan (e-Court Mahkamah Agung Republik Indonesia) tanggal 27 November 2025, Tergugat dalam jawabannya tidak mengemukakan eksepsi dan secara langsung memasuki pemeriksaan pokok perkara. Oleh karena itu, sebelum Pengadilan melakukan penilaian terhadap pokok perkara dalam sengketa a quo, Pengadilan terlebih dahulu berkewajiban untuk menilai terpenuhinya persyaratan formal pengajuan gugatan di Pengadilan Tata Usaha Negara, yang meliputi: Kewenangan Pengadilan, Kepentingan Penggugat dan Tenggang waktu pengajuan gugatan dan upaya administratif yang ditempuh;
1.
Kewenangan Pengadilan;
Menimbang, bahwa kewenangan Pengadilan Tata Usaha Negara diatur di dalam Pasal 47 juncto Pasal 50 Undang-Undang Negara Republik

Indonesia Nomor 5 Tahun 1986 tentang Peradilan Tata Usaha Negara yang menyebutkan bahwa:
Pasal 47
“Pengadilan bertugas dan berwenang memeriksa,
memutus,
dan menyelesaikan sengketa Tata Usaha Negara.”
Pasal 50
“Pengadilan Tata Usaha Negara bertugas dan berwenang memeriksa,
memutus, dan menyelesaikan sengketa Tata Usaha Negara di tingkat pertama.”
Menimbang, bahwa selanjutnya yang dimaksud dengan Keputusan Tata Usaha Negara di dalam ketentuan Pasal 1 angka 9 Undang-Undang Nomor 51 Tahun 2009 tentang Perubahan Kedua Atas Undang-Undang Nomor 5 Tahun 1986 tentang Peradilan Tata Usaha Negara adalah:
“Keputusan Tata Usaha Negara adalah suatu penetapan tertulis yang dikeluarkan oleh badan atau pejabat tata usaha negara yang berisi tindakan hukum tata usaha negara yang berdasarkan peraturan perundang-undangan yang berlaku, yang bersifat konkret, individual, dan final, yang menimbulkan akibat hukum bagi seseorang atau badan hukum perdata.”
Menimbang, bahwa adapun yang dimaksud dengan sengketa tata usaha negara menurut ketentuan dalam Pasal 1 angka 10 Undang-Undang Nomor 51 Tahun 2009 tentang Perubahan Kedua Atas Undang-Undang Nomor 5 Tahun 1986 tentang Peradilan Tata Usaha Negara adalah:
“Sengketa Tata Usaha Negara adalah sengketa yang timbul dalam bidang tata usaha negara antara orang atau badan hukum perdata dengan badan atau pejabat tata usaha negara, baik di pusat maupun di daerah, sebagai akibat dikeluarkannya keputusan tata usaha negara, termasuk sengketa kepegawaian berdasarkan peraturan perundang-undangan yang berlaku.”
Menimbang, bahwa objek sengketa dalam perkara ini adalah Keputusan Rektor Institut Agama Kristen Negeri Kupang Nomor 497 Tahun

2025 tanggal 30 Juli 2025 Tentang Pemberhentian Wakil Rektor II Bidang Administrasi Umum, Perencanaan Dan Keuangan Institut Agama Kristen Negeri Kupang atas nama Martin Chrisani Liufeto, M.Pd. sebagaimana bukti P-1 =T-8), maka berdasarkan objek sengketa tersebut diperoleh fakta hukum bahwa Objek Sengketa berwujud ketetapan tertulis yang diterbitkan oleh Rektor Institut Agama Kristen Negeri Kupang dalam kapasitasnya selaku Pejabat Tata Usaha Negara, yang berisikan tindakan hukum Tata Usaha Negara berupa penerbitan Keputusan Pemberhentian Wakil Rektor II Bidang Administrasi Umum, Perencanaan dan Keuangan dan bersifat konkret karena secara tegas menyebutkan bahwa objek sengketa diterbitkan atas nama Martin Chrisani Liufeto, M.Pd., serta telah pula bersifat final karena tidak lagi memerlukan persetujuan dari pihak manapun sehingga telah memiliki akibat hukum bagi Penggugat;
Menimbang, bahwa setelah mencermati objek sengketa a quo,
subjek hukum yang bersengketa serta sifat permasalahan hukum yang disengketakan para pihak, Pengadilan berpendapat bahwa sengketa ini telah memenuhi unsur sebagaimana dimaksud Pasal 1 angka 10 Undang-Undang Republik Indonesia Nomor 51 Tahun 2009 tentang Perubahan Kedua Atas Undang-Undang Nomor 5 Tahun 1986 tentang Peradilan Tata Usaha Negara;
Menimbang, bahwa berdasarkan pertimbangan di atas, Pengadilan berpendapat bahwa Pengadilan Tata Usaha Negara Kupang berwenang mengadili sengketa a quo;
2.
Kepentingan Penggugat;
Menimbang, bahwa selanjutnya untuk menentukan ada atau tidaknya kepentingan Penggugat untuk menggugat di Pengadilan Tata Usaha Negara Pengadilan mendasarkan penilaiannya pada ketentuan Pasal 53
ayat (1) Undang-Undang Nomor 9 Tahun 2004 tentang Perubahan Atas Undang-Undang Nomor 5 Tahun 1986 tentang Peradilan Tata Usaha Negara yang menyatakan bahwa:
“Orang atau badan hukum perdata yang merasa kepentingannya dirugikan oleh suatu Keputusan Tata Usaha Negara dapat mengajukan gugatan tertulis

kepada pengadilan yang berwenang yang berisi tuntutan agar Keputusan Tata Usaha Negara yang disengketakan itu dinyatakan batal atau tidak sah,
dengan atau tanpa disertai tuntutan ganti rugi dan/atau direhabilitasi.”
Menimbang, bahwa berdasarkan objek sengketa yang diajukan sebagai bukti surat bertanda P-1, yang bersesuaian dengan bukti T-8,
terungkap bahwa dalam objek sengketa tersebut secara tegas tercantum nama Penggugat yang sebelumnya menjabat sebagai Wakil Rektor II Bidang Administrasi Umum, Perencanaan Dan Keuangan Institut Agama Kristen Negeri Kupang, yang telah diberhentikan dari jabatannya tersebut berdasarkan surat keputusan sebagaimana dimaksud dalam sengketa a quo.
Penerbitan keputusan tersebut secara langsung dan otomatis mengakibatkan Penggugat kehilangan hak-hak jabatannya sebagai Wakil Rektor II Bidang Administrasi Umum, Perencanaan Dan Keuangan Institut Agama Kristen Negeri Kupang. Dengan demikian, Pengadilan berpendapat bahwa Penggugat telah menderita kerugian akibat diterbitkannya objek sengketa, sehingga Penggugat memiliki kepentingan hukum yang nyata dan relevan. Oleh karenanya, gugatan dalam perkara a quo telah memenuhi ketentuan mengenai legal standing untuk mengajukan gugatan sebagaimana dimaksud dalam Pasal 53 ayat (1) Undang-Undang Republik Indonesia Nomor 9 Tahun 2004 tentang Perubahan atas Undang-Undang Nomor 5
Tahun 1986 tentang Peradilan Tata Usaha Negara;
3.
Tenggang waktu pengajuan gugatan dan upaya administratif;
Menimbang,
bahwa mengenai pembatasan tenggang waktu pengajuan gugatan (beroeptermijn), ketentuannya telah diatur secara limitatif dalam peraturan perundang-undangan yang mengatur tentang Peradilan Tata Usaha Negara, yaitu Pasal 55 Undang-Undang Republik Indonesia Nomor 5 tahun 1986 tentang Peradilan Tata Usaha Negara sebagai berikut:
“Gugatan dapat diajukan hanya dalam tenggang waktu sembilan puluh hari terhitung sejak saat diterimanya atau diumumkannya Keputusan Badan atau Pejabat Tata Usaha Negara.”

Menimbang, bahwa setelah mencermati secara saksama objek sengketa a quo, Pengadilan berpendapat bahwa Penggugat merupakan pihak yang secara langsung dituju oleh Keputusan Tata Usaha Negara yang menjadi objek sengketa. Oleh karena itu, perhitungan tenggang waktu pengajuan gugatan bagi pihak yang secara langsung dituju oleh keputusan tata usaha negara yang dianggap merugikan tersebut harus dihitung sejak saat keputusan objek sengketa a quo diterima oleh Penggugat atau sejak saat keputusan tersebut diumumkan secara sah sesuai dengan ketentuan peraturan perundang-undangan;
Menimbang, bahwa terhadap setiap warga masyarakat yang merasa hak atau kepentingan hukumnya dirugikan akibat diterbitkannya suatu Keputusan dan/atau Tindakan Administrasi Pemerintahan, tidak serta merta diberikan akses langsung untuk mengajukan gugatan ke Pengadilan Tata Usaha Negara, melainkan terlebih dahulu diwajibkan menempuh upaya administratif sebagai prasyarat prosedural. Upaya administratif tersebut berlaku baik yang secara tegas ditentukan dalam peraturan dasar yang menjadi landasan kewenangan penerbitan keputusan dimaksud maupun dalam hal peraturan dasarnya tidak mengatur secara eksplisit, dengan tetap berpedoman pada ketentuan Pasal 75 sampai dengan Pasal 78 Undang-
Undang Republik Indonesia Nomor 30 Tahun 2014 tentang Administrasi Pemerintahan serta Pasal 2 dan Pasal 3 Peraturan Mahkamah Agung Republik Indonesia Nomor 6 Tahun 2018 tentang Pedoman Penyelesaian Sengketa Administrasi Pemerintahan Setelah Menempuh Upaya Administratif, yang secara normatif menegaskan bahwa penyelesaian sengketa administrasi pemerintahan harus terlebih dahulu ditempuh melalui mekanisme administratif sebelum menjadi objek pemeriksaan di lingkungan peradilan tata usaha negara;
Menimbang, bahwa berdasarkan dalil-dalil gugatan, jawab-menjawab para pihak, serta hasil pemeriksaan di persidangan yang dikaitkan dengan alat bukti surat, keterangan saksi, dan bukti-bukti lain yang diajukan oleh para pihak, Pengadilan memperoleh dan menetapkan fakta-fakta hukum sebagai berikut:

−
Bahwa yang menjadi dasar penerbitan objek sengketa a quo adalah adanya Nota Dinas Rektor Institut Agama Kristen Negeri Kupang kepada Kepala Biro Administrasi Umum,
Akademik dan Kemahasiswaan Nomor 3839/Ikn.01/1/KP.04.2/07/2025 tanggal 23
Juli 2025 perihal Penerbitan SK Pemberhentian Pejabat (vide bukti P-8 dan T-7);
−
Bahwa objek sengketa a quo terbit pada tanggal 30 Juli 2025
Penggugat mengetahui adanya objek sengketa tanggal 30 Juli 2025
dan menerima objek sengketa a quo pada tanggal 30 Juli 2025;
Menimbang, bahwa terhadap dalil Penggugat yang menyatakan baru mengetahui keberadaan dan substansi objek sengketa pada tanggal 30 Juli
2025, Pengadilan terlebih dahulu menilai aspek tempus dan kepastian waktu diketahuinya keputusan tata usaha negara tersebut sebagai titik awal penghitungan tenggang waktu pengajuan upaya administratif maupun gugatan ke Pengadilan;
Menimbang, bahwa berdasarkan fakta hukum yang terungkap di persidangan, Penggugat setelah mengetahui diterbitkannya objek sengketa a quo pada tanggal 30 Juli 2025, telah mengajukan upaya keberatan administratif melalui Surat Keberatan tertanggal 25 Agustus 2025 yang ditujukan kepada pejabat yang menerbitkan keputusan dimaksud, dan surat tersebut terbukti telah diterima oleh Vinsensius A. Paulo selaku Aparatur Sipil Negara pada Institut Agama Kristen Negeri Kupang (vide Bukti P-4 = T-11).
Dari fakta tersebut menunjukkan upaya administrasi berupa keberatan Penggugat kepada Tergugat masih dalam tenggang waktu 21 hari kerja sesuai ketentuan Pasal 77 ayat (1) Undang-Undang Republik Indonesia Nomor 30 Tahun 2014 tentang Administrasi Pemerintahan;
Menimbang, bahwa selanjutnya berdasarkan ketentuan Pasal 77
ayat (1) Undang-Undang Republik Indonesia Nomor 30 Tahun 2014 tentang Administrasi Pemerintahan, Tergugat diberikan waktu paling lama 10 hari kerja untuk menanggapi keberatan tersebut, namun demikian hingga diajukannya gugatan a quo secara e-Court di Pengadilan Tata Usaha Negara

Kupang pada tanggal 17 Oktober 2025, tidak pernah ada hasil tanggapan dari Tergugat atas surat keberatan Penggugat tersebut;
Menimbang, bahwa berdasarkan uraian pertimbangan di atas,
apabila dihitung sejak batas terakhir Tergugat seharusnya menanggapi keberatan tersebut dengan fakta gugatan diajukan pada tanggal 17 Oktober
2025, Pengadilan berpendapat bahwa gugatan Penggugat masih diajukan dalam tenggang waktu 90 (sembilan puluh) hari sebagaimana diatur dalam ketentuan Pasal 55 Undang-Undang Negara Republik Indonesia Nomor 5
Tahun 1986 tentang Peradilan Tata Usaha Negara;
Menimbang, bahwa berdasarkan keseluruhan uraian pertimbangan hukum tersebut di atas, Pengadilan berpendapat bahwa pengajuan gugatan oleh Penggugat ke Pengadilan Tata Usaha Negara telah memenuhi seluruh persyaratan formal pengajuan gugatan. Oleh karena itu, Pengadilan selanjutnya akan beralih untuk mempertimbangkan pokok sengketa dalam perkara a quo, sebagai berikut:
Pokok Perkara:

Menimbang, bahwa di dalam gugatannya, Penggugat memohon kepada Pengadilan untuk menyatakan batal atau tidak sah objek sengketa;
Menimbang, bahwa berlandaskan asas dominus litis, Majelis Hakim dalam memeriksa dan memutus sengketa a quo berpedoman pada ketentuan Pasal 107 Undang-Undang Nomor 5 Tahun 1986 tentang Peradilan Tata Usaha Negara,
yang pada pokoknya memberikan kewenangan kepada Hakim Tata Usaha Negara untuk menggali, mengikuti,
dan memahami nilai-nilai hukum serta fakta yang berkembang dalam persidangan secara aktif, tanpa terikat secara mutlak pada dalil, alat bukti,
maupun konstruksi hukum yang diajukan oleh para pihak. Dengan demikian,
Majelis Hakim memiliki kebebasan yudisial untuk menemukan dan menegakkan kebenaran materiil (materiële waarheid) demi tercapainya keadilan substantif dalam penyelesaian sengketa administrasi pemerintahan.
Menimbang, bahwa maksud dan tujuan Penggugat mengajukan gugatan adalah untuk memperoleh putusan yang menyatakan batal atau tidak sahnya objek sengketa a quo oleh karenanya, untuk menilai terpenuhi

atau tidaknya petitum dimaksud, Pengadilan akan menguji keabsahan penerbitan objek sengketa a quo berdasarkan parameter normatif sebagaimana ditentukan dalam Pasal 53 ayat (2) huruf a dan/atau huruf b Undang-Undang Republik Indonesia Nomor 9 Tahun 2004 tentang Perubahan atas Undang-Undang Nomor 5 Tahun 1986 juncto Pasal 70 ayat
(1) dan Pasal 71 ayat (1) Undang-Undang Republik Indonesia Nomor 30
Tahun 2014 tentang Administrasi Pemerintahan, yang pada prinsipnya mengatur bahwa suatu Keputusan Tata Usaha Negara dapat dinyatakan batal atau tidak sah apabila bertentangan dengan peraturan perundang-
undangan dan/atau asas-asas umum pemerintahan yang baik, serta apabila ditemukan adanya cacat kewenangan, prosedur, dan/atau substansi dalam proses penerbitannya.
Menimbang, bahwa ketentuan Pasal 53 ayat (2) huruf a dan huruf b Undang-Undang Republik Indonesia Nomor 9 Tahun 2004 tentang Perubahan atas Undang-Undang Nomor 5 Tahun 1986 tentang Peradilan Tata Usaha Negara mengatur:
Pasal 53 ayat (2)
"(2)
Alasan-alasan yang dapat digunakan dalam gugatan sebagaimana dimaksud pada ayat (1) adalah:
a.
Keputusan Tata Usaha Negara yang digugat itu bertentangan dengan peraturan perundang-undangan;
b.
Keputusan Tata Usaha Negara yang digugat itu bertentangan dengan asas-asas umum pemerintahan yang baik”;
Menimbang, bahwa berdasarkan ketentuan Pasal 70 ayat (1) dan Pasal 71 ayat (1) Undang-Undang Republik Indonesia Nomor 30 Tahun 2014
tentang Administrasi Pemerintahan mengatur bahwa:
Pasal 70 ayat (1)
"(1)
Keputusan dan/atau Tindakan tidak sah apabila:
a.
dibuat oleh Badan dan/atau Pejabat Pemerintahan yang tidak berwenang;

b.
dibuat oleh Badan dan/atau Pejabat Pemerintahan yang melampaui kewenangannya; dan/atau c.
dibuat oleh Badan dan/atau Pejabat Pemerintahan yang bertindak sewenang-wenang”;
Pasal 71 ayat (1)
"(1)
Keputusan dan/atau Tindakan dapat dibatalkan apabila:
a.
terdapat kesalahan prosedur; atau b.
terdapat kesalahan substansi”;
Menimbang, bahwa dalam pengujian legalitas terhadap objectum litis menurut penjelasan Pasal 53 ayat (2) Undang-Undang Republik Indonesia Nomor 9 Tahun 2004 tentang Perubahan Atas Undang-Undang Nomor 5
Tahun 1986 tentang Peradilan Tata Usaha Negara, antara lain meliputi:
1.
Segi kewenangan, yaitu apakah Tergugat berwenang atau tidak mengeluarkan keputusan objek sengketa;
2.
Segi prosedural, yaitu apakah keputusan objek sengketa telah dikeluarkan sesuai dengan prosedur formal yang ditentukan oleh peraturan perundang-undangan yang berlaku atau tidak;
3.
Segi substansi/materiil, yaitu apakah keputusan objek sengketa telah dikeluarkan sesuai atau tidak dengan peraturan perundang-
undangan yang berlaku secara materiil/substansial;
Aspek Kewenangan Menimbang, bahwa dalam sengketa a quo, Pengadilan berpendapat bahwa yang perlu diuji terlebih dahulu sebagai dasar pengujian untuk menentukan apakah keputusan objek sengketa tersebut sah (rechtmatig)
atau tidak adalah penilaian dari aspek kewenangan Tergugat untuk mengeluarkan keputusan objek sengketa dalam sengketa in litis, apakah didasarkan pada kewenangan yang ada padanya sesuai dengan peraturan perundang-undangan yang berlaku;
Menimbang, bahwa dalam rangka melakukan pengujian terhadap aspek kewenangan, Pengadilan berpedoman pada norma-norma hukum positif yang menjadi dasar atribusi, delegasi, maupun mandat kewenangan bagi Tergugat dalam menerbitkan objek sengketa a quo, sehingga dapat

dinilai apakah tindakan tersebut bersumber pada kewenangan yang sah menurut peraturan perundang-undangan yang berlaku;
Menimbang, bahwa dalam doktrin hukum administrasi negara ditegaskan bahwa suatu perbuatan hukum pemerintahan hanya dapat dinyatakan sah dan menimbulkan akibat hukum apabila dilakukan oleh organ pemerintahan atau pejabat (ambt) yang secara yuridis memiliki kewenangan
(bevoegdheid) untuk itu. Ketiadaan kewenangan mengakibatkan tindakan tersebut cacat secara yuridis dan berimplikasi pada ketidak absahannya.
Prinsip ini selaras dengan ketentuan Pasal 1 angka 5 Bab XI Pelaksanaan Administrasi Pemerintahan Untuk Mendukung Cipa kerja Undang-Undang Republik Indonesia Nomor 6 Tahun 2023 tentang Penetapan Peraturan Pemerintah Pengganti Undang-Undang Nomor 2 Tahun 2022 tentang Cipta Kerja menjadi Undang-Undang yang menegaskan bahwa wewenang adalah hak yang dimiliki oleh Badan dan/atau Pejabat Pemerintahan atau penyelenggara negara lainnya untuk mengambil keputusan dan/atau tindakan dalam penyelenggaraan pemerintahan, sehingga setiap tindakan pemerintahan wajib memiliki dasar kewenangan yang jelas, tegas, dan terukur dalam kerangka negara hukum.
Menimbang, bahwa setelah Pengadilan mencermati objek sengketa a quo, maka dapat diketahui bahwasanya dalam konsideran “mengingat”
objek sengketa tersebut, dicantumkan Peraturan Perundang-undangan yang dijadikan dasar dikeluarkannya objek sengketa, antara lain:
−
Undang-Undang Republik Indonesia Nomor 12 Tahun 2012 tentang Pendidikan Tinggi;
−
Peraturan Presiden Republik Indonesia Nomor 19 Tahun 2020
tentang Institut Agama Kristen Negeri Kupang;
−
Peraturan Menteri Agama Republik Indonesia Nomor 24 Tahun 2020
tentang Organisasi Dan Tata Kerja Institut Agama Kristen Negeri Kupang;
−
Peraturan Menteri Agama Republik Indonesia Nomor 37 Tahun 2020
tentang Statuta Institut Agama Kristen Negeri Kupang;

Menimbang, bahwa dalam ketentuan Pasal 1 dan Pasal 7 Peraturan Menteri Agama Republik Indonesia Nomor 24 Tahun 2020 tentang Organisasi Dan Tata Kerja Institut Agama Kristen Negeri Kupang,
menentukan sebagai berikut:
Pasal 1
"(1)
Institut Agama Kristen Negeri Kupang yang selanjutnya disebut Institut adalah perguruan tinggi keagamaan yang diselenggarakan oleh kementerian yang menyelenggarakan urusan pemerintahan dibidang agama, berada di bawah dan bertanggung jawab kepada menteri yang menyelenggarakan urusan pemerintahan di bidang agama;
"(2)
Institut sebagaimana dimaksud pada ayat (1) secara fungsional dibina oleh Direktur Jenderal Bimbingan Masyarakat Kristen;
"(3)
Institut sebagaimana dimaksud pada ayat (1) dipimpin oleh Rektor”;
Pasal 7
"(1)
Dalam melaksanakan tugas sebagaimana dimaksud dalam Pasal 6,
Rektor dibantu oleh 3 (tiga) Wakil Rektor;
"(2)
Wakil Rektor sebagaimana dimaksud pada ayat (1) terdiri atas:
a.
Wakil Rektor Bidang Akademik dan Kelembagaan;
b.
Wakil Rektor Bidang Administrasi Umum, Perencanaan, dan Keuangan; dan c.
Wakil Rektor Bidang Kemahasiswaan dan Kerja Sama.
"(3)
Wakil Rektor Bidang Akademik dan Kelembagaan sebagaimana dimaksud pada ayat (2) huruf a mempunyai tugas membantu Rektor dalam bidang akademik dan kelembagaan;
"(4)
Wakil Rektor Bidang Administrasi Umum, Perencanaan, dan Keuangan sebagaimana dimaksud pada ayat (2) huruf b mempunyai tugas membantu Rektor dalam bidang administrasi umum,
perencanaan, dan keuangan;
"(5)
Wakil Rektor Bidang Kemahasiswaan dan Kerja Sama sebagaimana dimaksud pada ayat (2) huruf c mempunyai tugas membantu Rektor dalam bidang kemahasiswaan, alumni, dan kerja sama”;

Menimbang, bahwa selanjutnya dalam ketentuan Pasal 1 Angka 3,
Pasal 26, dan Pasal 27, Peraturan Menteri Agama Republik Indonesia Nomor 37 Tahun 2020 tentang Statuta Institut Agama Kristen Negeri Kupang,
menentukan sebagai berikut:
Pasal 1 Angka 3
“Rektor adalah organ Institut yang memimpin dan mengelola penyelenggaraan Pendidikan tinggi pada Institut”
Pasal 26
"(1)
Rektor mempunyai tugas dan kewajiban:
a.
menyiapkan RIP Institut;
b.
melaksanakan otonomi perguruan tinggi bidang manajemen organisasi,
akademik,
kemahasiswaan,
sumber daya manusia, sarana prasarana, dan keuangan sesuai dengan ketentuan peraturan perundang-undangan;
c.
mengelola pendidikan, penelitian, dan pengabdian kepada masyarakat;
d.
mengangkat dan memberhentikan pejabat di bawah Rektor sesuai dengan ketentuan peraturan perundang-undangan;
e.
melaksanakan fungsi manajemen Institut;
f.
membina dan mengembangkan hubungan baik Institut dengan lingkungan dan masyarakat pada umumnya;
g.
mengusulkan pembukaan,
penggabungan,
dan/atau penutupan Fakultas dan Program Studi yang dipandang perlu, atas persetujuan Senat kepada Menteri;
h.
dan menyampaikan pertanggungjawaban kinerja dan keuangan Institut kepada Menteri;
"(2)
Rektor berwenang untuk dan atas nama Menteri:
a.
mewakili Institut di dalam dan di luar pengadilan;
b.
melakukan kerja sama; dan c.
memberikan gelar doktor kehormatan sesuai dengan peraturan perundang-undangan”;
Pasal 27

"(1)
Dalam mengelola dan menyelenggarakan Institut, Rektor dibantu oleh Wakil Rektor;
"(2)
Wakil Rektor sebagaimana dimaksud pada ayat (1) diangkat dan diberhentikan oleh Rektor;
"(3)
Masa jabatan Wakil Rektor mengikuti masa jabatan Rektor dan dapat diangkat kembali dengan ketentuan tidak boleh lebih dari 2
(dua) kali masa jabatan berturut-turut;
"(4)
Pembidangan tugas dan kewenangan masing-masing Wakil Rektor terdiri atas bidang:
a.
akademik dan kelembagaan;
b.
administrasi umum, perencanaan, dan keuangan; dan c.
kemahasiswaan dan kerja sarna Menimbang, bahwa uraian peraturan perundang-undangan di atas menentukan bahwa Rektor selaku organ Institut yang memimpin dan mengelola penyelenggaraan Pendidikan tinggi pada suatu Institut berwenang dalam mengangkat maupun memberhentikan Wakil Rektor, apabila dihubungkan dengan objek sengketa a quo yang muatan substansinya berupa pemberhentian Wakil Rektor II Bidang Administrasi Umum,
Perencanaan dan Keuangan Institut Agama Kristen Negeri Kupang sehingga mengakibatkan Penggugat tidak dapat lagi melanjutkan tugas dan tanggung jawabnya sebagai Wakil Rektor II Bidang Administrasi Umum, Perencanaan dan Keuangan di Institut Agama Kristen Negeri Kupang (vide bukti P-1=T-8),
maka Tergugat berwenang menerbitkan objek sengketa a quo baik itu dari segi materi (bevoegdheid rationae materiae), segi tempat/wilayah kekuasaan Tergugat (bevoegdheid rationae loci), dan segi waktu (bevoegdheid rationae temporis). Dengan demikian, penerbitan objek sengketa tidak terdapat cacat yuridis dari aspek kewenangan;
Aspek Prosedur dan Aspek Substansi Menimbang, bahwa setelah Pengadilan mencermati secara seksama dan mendalam keseluruhan peraturan perundang-undangan yang relevan dengan tata kelola kelembagaan perguruan tinggi keagamaan negeri,
khususnya yang berkaitan dengan mekanisme pengangkatan dan

pemberhentian Wakil Rektor, yaitu Undang-Undang Republik Indonesia Nomor 12 Tahun 2012 tentang Pendidikan Tinggi, Peraturan Presiden Republik Indonesia Nomor 19 Tahun 2020 tentang Institut Agama Kristen Negeri Kupang, Peraturan Menteri Agama Republik Indonesia Nomor 24
Tahun 2020 tentang Organisasi Dan Tata Kerja Institut Agama Kristen Negeri Kupang, Peraturan Menteri Agama Republik Indonesia Nomor 37 Tahun
2020 tentang Statuta Institut Agama Kristen Negeri Kupang, Pengadilan tidak menemukan adanya pengaturan yang secara eksplisit dan terperinci mengatur mengenai prosedur formal, tahapan mekanisme, yang harus dipenuhi dalam hal pemberhentian Wakil Rektor oleh Rektor. Oleh karena itu Pengadilan akan mempertimbangkan aspek substansi penerbitan objek sengketa a quo;
Menimbang, bahwa berdasarkan jawab-menjawab, bukti-bukti yang diajukan para pihak di persidangan, Pengadilan telah memperoleh fakta-
fakta persidangan sebagai berikut:
1.
Bahwa Penggugat pertama kali diangkat sebagai Pegawai Negeri Sipil dengan pangkat Penata Muda Tingkat I/IIIb terhitung mulai tanggal 1 Maret 2016 (vide Bukti P-5);
2.
Bahwa Penggugat telah dinaikan pangkatnya dari Penata Muda Tingkat I/IIIb menjadi Penata III/c terhitung mulai tanggal 1 Oktober
2020 (vide Bukti P-6);
3.
Bahwa kemudian Penggugat telah dinaikan pangkatnya kembali dari Penata III/c menjadi Penata Tingkat Satu III/d terhitung mulai tanggal
1 April 2024 (vide Bukti P-7);
4.
Bahwa Penggugat diangkat dalam jabatan Wakil Rektor II Bidang Administrasi Umum, Perencanaan Dan Keuangan Institut Agama Kristen Negeri Kupang tanggal 25 September 2024 (vide bukti P-2 =
T-3);
5.
Bahwa pada tanggal 24 April 2025 Perwakilan Ombudsman Republik Indonesia Provinsi Nusa Tenggara Timur menerbitkan Surat Nomor T/0129/LM.48-18/0009.2025/IV/2025 perihal Permintaan Keterangan terkait laporan mengenai dugaan penyimpangan prosedur oleh

Institut Agama Kristen Negeri Kupang Terkait Perubahan Penetapan Penerima Bantuan Beasiswa Kartu Indonesia Pintar Tahap II Tahun
2024 (vide Bukti T-8);
6.
Bahwa Tergugat menerbitkan Nota Dinas Nomor:
3839/Ikn.01/I/KP.04.2/07/2025
tanggal
23
Juli
2025
perihal Menerbitkan SK Pemberhentian Pejabat (vide Bukti P-8 = T-7);
7.
Bahwa selanjutnya berdasarkan Nota Dinas Nomor:
3839/Ikn.01/I/KP.04.2/07/2025
tanggal
23
Juli
2025
perihal Menerbitkan SK Pemberhentian Pejabat, Tergugat menerbitkan Keputusan Rektor Institut Agama Kristen Negeri Kupang Nomor 497
Tahun 2025 tanggal 30 Juli 2025 tentang Pemberhentian Wakil Rektor II Bidang Administrasi Umum, Perencanaan Dan Keuangan Institut Agama Kristen Negeri Kupang atas nama Penggugat (vide Bukti P-1 = T-8);
8.
Bahwa Tergugat telah menerbitkan Surat Telaah tentang Pemberhentian Pejabat Pimpinan yang ditujukan kepada Direktur Jenderal Bimbingan Masyarakat Kristen Kementerian Agama Republik Indonesia Nomor 5111/ikn/01/1/OT.01.2/08/2025 (vide Bukti T-6);
9.
Bahwa berdasarkan bukti T-10, Tergugat memimpin rapat kerja tanggal 11 Agustus 2025 yang dihadiri oleh Penggugat dengan agenda rapat salah satunya adalah permintaan klarifikasi terkait pemberhentian WR II, WR III dan Dekan FISKK (vide bukti T-10);
Menimbang,
bahwa berkenaan dengan aspek substansi pemberhentian Wakil Rektor pada Institut Agama Kristen Negeri Kupang,
Pengadilan terlebih dahulu menelusuri landasan normatif yang menjadi dasar, yakni ketentuan Pasal 31 Peraturan Menteri Agama Republik Indonesia Nomor 37 Tahun 2020 tentang Statuta Institut Agama Kristen Negeri Kupang,
yang secara limitatif mengatur mengenai alasan pemberhentian Wakil Rektor dalam lingkungan Institut Agama Kristen Negeri Kupang, sehingga norma a quo menjadi parameter yuridis dalam menilai sah atau tidaknya objek sengketa yang diterbitkan oleh Tergugat.

Pasal 31
“Wakil Rektor diberhentikan dari jabatannya karena:
a.
telah berakhir masa jabatannya;
b.
mengundurkan diri atas permintaan sendiri;
c.
diangkat dalam jabatan yang lain;
d.
tidak dapat bekerja sama dengan Rektor;
e.
sakit jasmani dan/ atau rohani terus menerus;
f.
dikenakan sanksi hukuman disiplin tingkat berat;
g.
dipidana penjara;
h.
cuti di luar tanggungan negara; atau i.
meninggal dunia”;
Menimbang, bahwa mencermati Jawaban Tergugat dan Bukti T-6
berupa Surat Telaah tentang Pemberhentian Pejabat Pimpinan yang ditujukan kepada Direktur Jenderal Bimbingan Masyarakat Kristen Kementerian Agama Republik Indonesia Nomor
5111/IKN/01/1/OT.01.2/08/2025 (vide Bukti T-6), apabila dihubungkan dengan norma ketentuan Pasal 31 Peraturan Menteri Agama Republik Indonesia Nomor 37 Tahun 2020 tentang Statuta Institut Agama Kristen Negeri Kupang sebagaimana diuraikan di atas, diketahui alasan dari Tergugat menerbitkan objek sengketa a quo adalah tidak dapat bekerja sama dengan Rektor;
Menimbang, bahwa dalam ketentuan Pasal 31 Peraturan Menteri Agama Republik Indonesia Nomor 37 Tahun 2020 tentang Statuta Institut Agama Kristen Negeri Kupang tidak ada penjelasan lebih lanjut khususnya mengenai unsur-unsur dari alasan tidak dapat bekerjasama dengan Rektor,
oleh karena itu Pengadilan perlu terlebih dahulu untuk menguraikan tugas dari Penggugat sebagai Wakil Rektor II dengan kewenangan Rektor dalam memimpin Institut sesuai ketentuan Peraturan Menteri Agama Republik Indonesia Nomor 24 Tahun 2020 tentang Organisasi Dan Tata Kerja Institut Agama Kristen Negeri Kupang dan Peraturan Menteri Agama Republik Indonesia Nomor 37 Tahun 2020 tentang Statuta Institut Agama Kristen

Negeri Kupang, sehingga dapat dinilai secara terukur kerjasama antar keduanya;
Menimbang, bahwa dalam ketentuan 5 huruf a Peraturan Menteri Agama Republik Indonesia Nomor 24 Tahun 2020 tentang Organisasi Dan Tata Kerja Institut Agama Kristen Negeri Kupang menentukan pada pokoknya Organ pengelola Institut terdiri atas Rektor dan Wakil Rektor,
kemudian dalam ketentuan Pasal 6, Pasal 7 serta Pasal 77 dan Pasal 81
Peraturan tersebut, menentukan sebagai berikut:
Pasal 6
“Rektor sebagaimana dimaksud dalam Pasal 5 huruf a mempunyai tugas memimpin dan mengelola penyelenggaraan pendidikan tinggi sesuai dengan ketentuan peraturan perundang-undangan dan/atau kebijakan yang ditetapkan oleh Menteri yang menyelenggarakan urusan pemerintahan di bidang agama";
Pasal 7
"(1)
Dalam melaksanakan tugas sebagaimana dimaksud dalam Pasal 6,
Rektor dibantu oleh 3 (tiga) Wakil Rektor;
"(2)
Wakil Rektor sebagaimana dimaksud pada ayat (1) terdiri atas:
a.
Wakil Rektor Bidang Akademik dan Kelembagaan;
b.
Wakil Rektor Bidang Administrasi Umum, Perencanaan dan Keuangan; dan;
c.
Wakil Rektor Bidang Kemahasiswaan dan Kerjasama;
"(3)
Wakil Rektor Bidang Akademik dan Kelembagaan sebagaimana dimaksud pada ayat (2) huruf a mempunyai tugas membantu Rektor dalam bidang akademik dan kelembagaan;
"(4)
Wakil Rektor Bidang Administrasi Umum, Perencanaan dan Keuangan sebagaimana dimaksud pada ayat (2) huruf b mempunyai tugas membantu Rektor dalam bidang administrasi umum,
perencanaan dan keuangan;
"(5)
Wakil Rektor Bidang Kemahasiswaan dan Kerja Sama sebagaimana dimaksud pada ayat (2) huruf c mempunyai tugas membantu Rektor dalam bidang kemahasiswaan, alumni dan kerja sama;

Pasal 77
“Rektor dalam melaksanakan tugas dan fungsinya harus menerapkan sistem akuntabilitas kinerja instansi pemerintah”;
Pasal 81
“Organ di Institut dalam melaksanakan tugasnya harus menerapkan prinsip koordinasi, integrasi, dan sinkronisasi baik dalam lingkungan Institut maupun dalam hubungan antar lembaga”;
Menimbang, bahwa kemudian dalam Pasal 69 Peraturan Menteri Agama Republik Indonesia Nomor 37 Tahun 2020 tentang Statuta Institut Agama Kristen Negeri Kupang, menentukan sebagai berikut:
"(1)
Rektor menetapkan standar kinerja pejabat pada Institut;
"(2)
Rektor menilai kinerja para pejabat berdasarkan standar kinerja yang telah ditetapkan;
"(3)
Ketentuan mengenai standar kinerja sebagaimana dimaksud pada ayat (1) ditetapkan dengan Keputusan Rektor”;
Menimbang, bahwa apabila norma-norma peraturan sebagaimana diuraikan di atas dipahami secara sistematis maka norma ketentuan Pasal
31 huruf d yang memberikan ruang pemberhentian karena tidak dapat bekerja sama dengan Rektor, dapat dimaknai pada hakikatnya mensyaratkan adanya fakta objektif dan terukur mengenai disharmoni kerjasama antara Rektor dengan Wakil Rektor yang dapat berdampak pada terganggunya pelaksanaan tugas kelembagaan, sehingga alasan-alasan pemberhentian oleh Tergugat tersebut dalam pelaksanaanya harus didasarkan pada data dan indikator kinerja yang jelas agar norma tersebut tidak dipandang sebagai sebuah norma yang menimbulkan ketidakpastian hukum;
Menimbang, bahwa berdasarkan fakta hukum sebagaimana telah diuraikan sebelumnya, diperoleh pula fakta persidangan yang menunjukkan kronologis bahwa terbitnya objek sengketa a quo berawal pada tanggal 24
April 2025, ketika Perwakilan Ombudsman Republik Indonesia Provinsi Nusa Tenggara Timur menerbitkan Surat Nomor T/0129/LM.48-

18/0009.2025/IV/2025
perihal Permintaan Keterangan atas laporan mengenai dugaan penyimpangan prosedur oleh Institut Agama Kristen Negeri Kupang terkait perubahan penetapan penerima bantuan Beasiswa Kartu Indonesia Pintar Tahap II Tahun 2024 (vide Bukti T-8). Terhadap fakta tersebut Pengadilan berpendapat, surat dimaksud pada hakikatnya merupakan permintaan klarifikasi dan belum merupakan suatu putusan atau rekomendasi yang menyatakan adanya pelanggaran yang telah terbukti secara hukum karena selain telah dilakukan klarifikasi oleh Penggugat sebagaimana keterangan Saksi Roimanson Panjaitan. Lebih lanjut, selama proses pemeriksaan di persidangan tidak pula diperoleh bukti-bukti yang menunjukkan telah ada putusan maupun rekomendasi dari Ombudsman yang menyatakan adanya pelanggaran maladministrasi yang dilakukan oleh Penggugat;
Menimbang, bahwa selanjutnya dalam ketentuan Pasal 77 Peraturan Menteri Agama Republik Indonesia Nomor 37 Tahun 2020 tentang Statuta Institut Agama Kristen Negeri Kupang, menentukan sebagai berikut:
"(1)
Setiap warga kampus wajib melaksanakan kode etik kampus;
"(2)
Rektor membentuk Dewan Kode Etik Institut;
"(3)
Kode etik sebagaimana dimaksud pada ayat (1) meliputi nilai kristiani dan aturan hukum dalam berpikir,
berbicara,
bersikap,
berpenampilan, dan berperilaku di dalam kampus;
"(4)
Warga kampus yang melakukan pelanggaran dikenakan sanksi sesuai ketentuan peraturan perundang-undangan;
"(5)
Ketentuan mengenai kode etik sebagaimana dimaksud pada ayat (1)
dan sanksi pelanggarannya sebagaimana dimaksud pada ayat (3)
ditetapkan dengan Keputusan Rektor melalui Pertimbangan Dewan Kode Etik Institut”;
Menimbang, bahwa selama proses pemeriksaan di persidangan tidak pula diperoleh bukti yang menunjukkan adanya keputusan pelanggaran etik yang dilakukan oleh Penggugat sebagaimana ketentuan Pasal 77

Peraturan Menteri Agama Republik Indonesia Nomor 37 Tahun 2020 tentang Statuta Institut Agama Kristen Negeri Kupang yang telah diuraikan di atas;
Menimbang, bahwa mencermati keseluruhan alat bukti yang diajukan di persidangan, tidak ditemukan adanya dokumen yang menunjukkan telah dilakukannya pemeriksaan internal, klarifikasi kepada Penggugat, ataupun pemberian kesempatan bagi Penggugat untuk memberikan penjelasan sebelum diterbitkannya keputusan pemberhentian dimaksud sedangkan surat telaah tentang pemberhentian pejabat pimpinan Nomor:
5111/lkn/01/1/OT.01.2/08/2025 yang ditujukan kepada Direktur Jenderal Bimbingan Masyarakat Kristen Kementerian Agama Republik Indonesia (vide bukti T-6), disamping surat telaah tersebut tidak didukung dengan bukti-bukti yang menunjukkan hasil evaluasi kinerja dari Penggugat, berdasarkan keterangan saksi Tergugat bernama Relin Yosi Huka surat telaah tersebut disusun setelah diterbitkan objek sengketa a quo sehingga tidak dapat menjadi acuan untuk membenarkan penerbitan objek sengketa a quo;
Menimbang, bahwa berdasarkan keterangan saksi dari Tergugat bernama Ezra Tari, pernah dilaksanakan suatu pertemuan yang digagas oleh Tergugat dalam rangka melakukan evaluasi terhadap kinerja Penggugat yang dihadiri oleh Tergugat, saksi sendiri dalam kapasitasnya sebagai Direktur Pascasarjana bersama dengan Wakil Rektor I dan Dekan Fakultas Seni, namun setelah Pengadilan mencermati secara saksama substansi keterangan saksi tersebut, diperoleh fakta bahwa pertemuan dimaksud tidak dilaksanakan melalui mekanisme evaluasi yang bersifat formal dan administratif, karena tidak pernah dibentuk tim evaluasi secara resmi yang diberi mandat untuk melakukan penilaian terhadap kinerja Penggugat, tidak dibuatkan berita acara maupun notulensi yang mencatat jalannya pertemuan tersebut, serta tidak pula dihasilkan kesimpulan atau rekomendasi yang dapat dijadikan dasar administratif bagi pengambilan keputusan oleh pejabat yang berwenang in casu Tergugat;
Menimbang, bahwa berdasarkan rangkaian uraian pertimbangan di atas dihubungkan dengan norma Pasal 31 huruf d Peraturan Menteri Agama

Republik Indonesia Nomor 37 Tahun 2020 tentang Statuta Institut Agama Kristen Negeri Kupang, Pengadilan menilai Tergugat dalam menerbitkan keputusan objek sengketa tidak dapat membuktikan secara objektif adanya ketidakmampuan dari Penggugat bekerjasama dengan Rektor sebagaimana diamanatkan ketentuan tersebut, sehingga penerbitan objek sengketa a quo bertentangan dengan Pasal 31 Peraturan Menteri Agama Republik Indonesia Nomor 37 Tahun 2020 tentang Statuta Institut Agama Kristen Negeri Kupang;
Menimbang, bahwa selanjutnya berdasarkan ketentuan Pasal 53
ayat (2) huruf b Undang-Undang Republik Indonesia Nomor 9 Tahun 2004
tentang Perubahan Atas Undang-Undang Nomor 5 Tahun 1986 tentang Peradilan Tata Usaha Negara tersebut, ditegaskan bahwa salah satu alasan yang sah untuk menggugat suatu Keputusan Tata Usaha Negara adalah apabila keputusan tersebut bertentangan dengan Asas-Asas Umum Pemerintahan Yang Baik. Norma tersebut secara sistematik menempatkan Asas-Asas Umum Pemerintahan Yang Baik sebagai tolok ukur yuridis yang berdiri sejajar dengan pengujian terhadap peraturan perundang-undangan,
maka Pengadilan akan menguji apakah Keputusan Tata Usaha Negara yang menjadi objek sengketa dalam perkara a quo bertentangan dengan Asas-
Asas Umum Pemerintahan Yang Baik atau tidak;
Menimbang, bahwa definisi dan kedudukan normatif Asas-Asas Umum Pemerintahan Yang Baik ditegaskan dalam ketentuan Pasal 1 Angka
17 Undang-Undang Republik Indonesia Nomor 6 Tahun 2023 tentang Penetapan Peraturan Pemerintah Pengganti Undang-Undang Nomor 2
Tahun 2022 tentang Cipta Kerja menjadi Undang-Undang menentukan sebagai berikut:
“Asas-asas Umum Pemerintahan yang Baik yang selanjutnya disingkat AUPB adalah prinsip yang digunakan sebagai acuan penggunaan Wewenang bagi Pejabat Pemerintahan dalam mengeluarkan Keputusan dan/atau Tindakan dalam penyelenggaraan pemerintahan.”;
Menimbang, bahwa sebagaimana diuraikan sebelumnya bahwa objek sengketa diterbitkan berdasarkan Nota Dinas Nomor

3839/Ikn.01/I/KP.04.2/07/2025 tanggal 23 Juli 2025 yang pada pokoknya memerintahkan penerbitan Surat Keputusan Pemberhentian Pejabat dan dari keseluruhan alat bukti yang diajukan di persidangan, tidak ditemukan adanya dokumen yang menunjukkan telah dilakukannya pemeriksaan internal,
klarifikasi kepada Penggugat, ataupun pemberian kesempatan bagi Penggugat untuk memberikan penjelasan sebelum diterbitkannya keputusan pemberhentian dimaksud. Hal tersebut menunjukkan Tergugat dalam menerbitkan objek sengketa semata-mata mendasarkan tindakannya pada Nota Dinas internal, tanpa didahului oleh suatu prosedur pemeriksaan formal terhadap Penggugat yang mana hal demikian menimbulkan ketidakpastian atau ambiguitas bagi subjek hukum yang dikenai keputusan, oleh karena itu penerbitan objek sengketa bertentangan dengan asas kepastian hukum sebagaimana dimaksud dalam ketentuan Pasal 10 ayat (1) huruf a juncto Penjelasan Pasal 10 ayat (1) huruf a Undang-Undang Republik Indonesia Nomor 30 Tahun 2014 tentang Administrasi Pemerintahan yang menuntut agar setiap tindakan pemerintahan didasarkan pada landasan ketentuan peraturan perundang-undangan, kepatutan, keajegan, dan keadilan dalam setiap kebijakan penyelenggaraan pemerintahan;
Menimbang, bahwa selain asas kepastian hukum, Pengadilan juga mempertimbangkan asas tidak menyalahgunakan kewenangan dan asas kecermatan, yang menuntut agar setiap keputusan didasarkan pada data dan informasi yang lengkap serta dianalisis secara hati-hati sebelum diambil suatu tindakan yang berdampak signifikan terhadap karier dan reputasi seseorang. Dalam perkara ini, tidak terdapat bukti yang menunjukkan adanya mekanisme evaluasi formal terhadap kinerja Penggugat sebagai Wakil Rektor II sebelum diterbitkannya keputusan pemberhentian sementara berdasarkan bukti P-13 menunjukkan hasil penilaian kinerja Penggugat periode 1 Oktober 2024 sampai dengan 31 Desember 2024 mendapat predikat penilaian Baik dari atasannya (in casu Tergugat);
Menimbang, bahwa selain berpedoman pada asas kepastian hukum,
asas larangan penyalahgunaan kewenangan, dan asas kecermatan,
Pengadilan dalam memeriksa dan mengadili sengketa a quo juga

mendasarkan pertimbangannya pada asas motivasi. Menurut Ridwan HR dalam bukunya yang berjudul Hukum Administrasi Negara mendefinisikan asas motivasi adalah asas dalam hukum administrasi negara yang mewajibkan setiap Badan dan/atau Pejabat Pemerintahan untuk mencantumkan alasan atau pertimbangan yang jelas, rasional, dan dapat dipertanggungjawabkan dalam setiap keputusan dan/atau tindakan administrasi yang diterbitkannya. Asas ini menuntut agar suatu keputusan tidak lahir secara sewenang-wenang (willekeur), melainkan didasarkan pada argumentasi hukum dan fakta yang relevan, sehingga dapat diuji kebenarannya baik secara administratif maupun yudisial. Dalam perspektif Ridwan HR, kewajiban pemberian motivasi tersebut merupakan manifestasi dari prinsip transparansi dan akuntabilitas pemerintahan serta menjadi instrumen kontrol terhadap penyalahgunaan kewenangan, karena melalui alasan yang tertulis dan terukur, pihak yang dirugikan dapat memahami dasar pertimbangan keputusan sekaligus menilai apakah keputusan tersebut telah sesuai dengan peraturan perundang-undangan dan Asas-Asas Umum Pemerintahan yang Baik;
Menimbang, bahwa asas motivasi tersebut mensyaratkan adanya kewajiban hukum bagi setiap pejabat tata usaha negara untuk memberikan alasan atau pertimbangan yang jelas,
rasional,
dan dapat dipertanggungjawabkan dalam setiap keputusan dan/atau tindakan pemerintahan. Tidak boleh ada keputusan administrasi yang lahir tanpa dasar argumentasi yang transparan dan terukur. Motivasi tersebut harus menunjukkan: Dasar hukum yang melandasi kewenangan dan tindakan,
Fakta-fakta relevan yang menjadi pertimbangan dan Pertautan logis antara fakta dan norma yang menghasilkan keputusan;
Menimbang, bahwa setelah mencermati secara seksama Bukti Nota Dinas Nomor: 3839/Ikn.01/I/KP.04.2/07/2025 tanggal 23 Juli 2025 dari Rektor kepada Kepala Biro AUAK perihal penerbitan Surat Keputusan Pemberhentian Pejabat (vide Bukti P-8 = T-7) yang dihubungkan dengan Bukti T-6 dan Bukti T-10, Pengadilan menemukan adanya ketidaksesuaian mendasar mengenai alasan yang dijadikan dasar pemberhentian Penggugat

dari jabatannya sebagai Wakil Rektor II Bidang Administrasi Umum,
Perencanaan, dan Keuangan Institut Agama Kristen Negeri Kupang, dimana dalam Nota Dinas tersebut dinyatakan bahwa pemberhentian dilakukan dalam rangka penyegaran organisasi, sementara dalam Bukti T-6
dikemukakan alasan yang berbeda, yakni berkaitan dengan kinerja keuangan dan tata kelola, pengelolaan beasiswa, serta dugaan pelanggaran etika, sedangkan dalam Bukti T-10 tidak diuraikan secara tegas dan jelas alasan normatif yang dijadikan dasar pemberhentian Penggugat. Oleh karenanya perbedaan dan ketidakselarasan alasan tersebut menunjukkan adanya inkonsistensi dalam konstruksi pertimbangan yang melatarbelakangi penerbitan keputusan tata usaha negara a quo, yang pada akhirnya menimbulkan ketidakpastian mengenai motif administratif yang sebenarnya;
keadaan demikian menurut penilaian Pengadilan bertentangan dengan asas motivasi, yang dalam doktrin hukum administrasi negara menghendaki adanya kewajiban hukum bagi setiap pejabat tata usaha negara untuk menyertakan alasan atau pertimbangan yang jelas, rasional, objektif, dan dapat dipertanggungjawabkan secara hukum dalam setiap penerbitan keputusan dan/atau tindakan pemerintahan, sehingga setiap keputusan administrasi negara tidak hanya sah secara formal, tetapi juga dapat diuji rasionalitas serta akuntabilitasnya dalam kerangka prinsip-prinsip pemerintahan yang baik;
Menimbang, bahwa berdasarkan rangkaian pertimbangan hukum di atas, Pengadilan berkesimpulan penerbitan objek sengketa dari aspek substansi bertentangan dengan peraturan perundang-undangan dan Asas-
Asas Umum Pemerintahan yang Baik, khususnya asas kepastian hukum,
asas kecermatan, asas tidak menyalahgunakan kewenangan maupun Asas Motivasi. Dengan demikian, beralasan hukum untuk mengabulkan tuntutan Penggugat agar menyatakan batal objek sengketa a quo;
Menimbang, bahwa oleh karena objek sengketa a quo dinyatakan batal, maka Tergugat diwajibkan untuk mencabut objek sengketa a quo dan mewajibkan Tergugat untuk merehabilitasi harkat dan martabat serta mengembalikan kedudukan Penggugat pada jabatan semula sebagai Wakil

Rektor II Bidang Administrasi Umum, Perencanaan dan Keuangan, Institut Agama Kristen Negeri Kupang atau yang setingkat dengan jabatan tersebut sesuai dengan ketentuan perundang-undangan yang berlaku;
Menimbang, bahwa karena gugatan Penggugat dikabulkan untuk seluruhnya, maka berdasarkan ketentuan Pasal 110 jo Pasal 112 Undang-
Undang Republik Indonesia Nomor 5 Tahun 1986 tentang Peradilan Tata Usaha Negara, Tergugat selaku pihak yang kalah dalam sengketa ini patut dan beralasan menurut hukum untuk dihukum membayar biaya perkara yang timbul selama proses pemeriksaan perkara a quo, dengan jumlah sebagaimana ditetapkan dalam amar putusan;
Menimbang, bahwa berdasarkan ketentuan Pasal 100 jo Pasal 107
Undang-Undang Nomor 5 Tahun 1986 tentang Peradilan Tata Usaha Negara,
Pengadilan bebas untuk menentukan apa yang harus dibuktikan, beban pembuktian beserta penilaian pembuktian. Terhadap seluruh alat bukti yang diajukan oleh para pihak telah dipertimbangkan oleh Majelis Hakim, akan tetapi hanya alat bukti yang dinilai memiliki relevansi yang dijadikan dasar dalam membuat Putusan, namun alat bukti selebihnya tetap dilampirkan dalam berkas perkara sebagai bagian yang tidak terpisahkan dengan Putusan ini;
Menimbang, bahwa berdasarkan Pasal 26 Peraturan Mahkamah Agung Republik Indonesia Nomor 7 Tahun 2022 tentang Perubahan Atas Peraturan Nomor 1 Tahun 2019
tentang Administrasi Perkara dan Persidangan di Pengadilan Secara Elektronik dengan diucapkannya Putusan secara elektronik, maka secara hukum dianggap telah dihadiri oleh para pihak dan dilakukan sidang terbuka untuk umum;
Memperhatikan, Undang-Undang Republik Indonesia Nomor 5 Tahun
1986 tentang Peradilan Tata Usaha Negara sebagaimana telah beberapa kali diubah, terakhir dengan Undang-Undang Republik Indonesia Nomor 51
Tahun 2009 tentang Perubahan Kedua Atas Undang-Undang Republik

Indonesia Nomor 5 Tahun 1986 tentang Peradilan Tata Usaha Negara,
peraturan perundang-undangan dan ketentuan hukum lain yang berkaitan;
MENGADILI:
Pokok Perkara:
1.
Mengabulkan gugatan Penggugat untuk seluruhnya;
2.
Menyatakan batal Keputusan Rektor Institut Agama Kristen Negeri Kupang Nomor 497 Tahun 2025 tanggal 30 Juli 2025 tentang Pemberhentian Wakil Rektor II Bidang Administrasi Umum,
Perencanaan dan Keuangan Institut Agama Kristen Negeri Kupang atas nama Martin Chrisani Liufeto, M.Pd.;
3.
Mewajibkan Tergugat untuk mencabut Keputusan Rektor Institut Agama Kristen Negeri Kupang Nomor 497 Tahun 2025 tanggal 30
Juli 2025 tentang Pemberhentian Wakil Rektor II Bidang Administrasi Umum, Perencanaan dan Keuangan Institut Agama Kristen Negeri Kupang atas nama Martin Chrisani Liufeto, M.Pd.;
4.
Mewajibkan Tergugat untuk merehabilitasi harkat dan martabat serta mengembalikan kedudukan Penggugat pada jabatan semula sebagai Wakil Rektor II Bidang Administrasi Umum, Perencanaan dan Keuangan, Institut Agama Kristen Negeri Kupang atau yang setingkat dengan jabatan tersebut sesuai dengan ketentuan perundang-undangan yang berlaku;
5.
Menghukum Tergugat untuk membayar biaya perkara sejumlah Rp424.000 (empat ratus dua puluh empat ribu rupiah);
Demikian diputuskan dalam rapat musyawarah Majelis Hakim Pengadilan Tata Usaha Negara Kupang pada hari Jumat, tanggal 20
Februari 2026 oleh MUHAMMAD ZAINAL ABIDIN, S.H., M.Kn., sebagai Hakim Ketua Majelis, KOMANG ALIT ANTARA, S.H., M.H. dan PUTU CARINA SARI DEVI, S.H., masing-masing sebagai Hakim Anggota dan diucapkan dalam sidang terbuka untuk umum, dan disampaikan kepada para pihak yang sekaligus pula dipublikasikan untuk umum melalui Sistem Informasi Pengadilan pada hari Jumat, tanggal 6 Maret 2026 oleh Hakim Ketua Majelis dengan dihadiri para Hakim Anggota tersebut dan dibantu oleh

DEBORA S. ANDUWACU, S.H., sebagai Panitera Pengganti Pengadilan Tata Usaha Negara Kupang, serta dihadiri oleh kuasa para pihak pada persidangan secara e-Court;

HAKIM-HAKIM ANGGOTA

ttd

KOMANG ALIT ANTARA, S.H.,M.H.
HAKIM KETUA MAJELIS

ttd

MUHAMMAD ZAINAL ABIDIN, S.H., M.Kn.

ttd

PUTU CARINA SARI DEVI, S.H.

PANITERA PENGGANTI

ttd

DEBORA S. ANDUWACU, S.H.

Biaya-biaya Perkara:
1.
Biaya ATK Perkara/Pemberkasan Rp300.000 2.
Pendaftaran

Rp30.000 3.
Surat Panggilan Para Pihak

Rp54.000 4.
Meterai

Rp10.000 5.
Redaksi

Rp10.000 6.
PNBP Surat Panggilan Para Pihak Rp20.000
Jumlah

Rp424.000

