# DUPLIK TERGUGAT

## PERKARA TATA USAHA NEGARA NOMOR 119/G/2026/PTUN.JKT

### Pengadilan Tata Usaha Negara Jakarta

**Tergugat:** Menteri Keuangan Republik Indonesia  
**Penggugat:** Ninin Sapto Hargiyanto

---


KEMENTERIAN KEUANGAN REPUBLIK INDONESIA
PERKARA TATA USAHA NEGARA NOMOR 119/G/2026/PTUN.JKT
PENGADILAN TATA USAHA NEGARA JAKARTA
DUPLIK TERGUGAT
Dalam Perkara Nomor 119/G/PTUN.JKT
Menteri Keuangan Republik Indonesia, beralamat di Gedung Djuanda I
Lantai 3 Kementerian Keuangan, Jalan Dr. Wahidin Raya Nomor 1, Jakarta
Pusat, untuk selanjutnya disebut sebagai ..........................................................
TERGUGAT
m e l a w a n
Ninin Sapto Hargiyanto, beralamat di Jalan Bedeng 10 Kampung
Rawakaong RT 002/RW 00, Grogol Limo, Depok, Provinsi Jawa Barat,
untuk selanjutnya disebut sebagai................................................................
PENGGUGAT
----------00000O00000----------
Jakarta,  10 Juni 2026
Yth. Majelis Hakim
Perkara Tata Usaha Negara Nomor 
119/G/2065/PTUN.JKT
Pengadilan Tata Usaha Negara Jakarta
di Jakarta
Dengan hormat,
Kami yang bertanda tangan di bawah ini, berdasarkan Surat Kuasa Khusus Nomor SKU-
24/MK.01/2026 tanggal 29 April 2026, bertindak untuk dan atas nama serta mewakili
kepentingan Menteri Keuangan Republik Indonesia sebagai Tergugat dalam Perkara Nomor
119/G/2026/PTUN.JKT di Pengadilan Tata Usaha Negara Jakarta, dengan ini mengajukan
Duplik atas Replik Penggugat sebagai berikut:
I. DALAM PENUNDAAN
1.
Bahwa dalil Penggugat yang menyatakan bahwa Tergugat keliru menggunakan Pasal 65
ayat (1) Undang-Undang Nomor 30 Tahun 2014 tentang Administrasi Pemerintahan (“UU
AP”) sebagai dasar hukum karena lex specialis yang berlaku adalah Pasal 67 ayat (2) dan
ayat (4) Undang-Undang Peradilan Tata Usaha Negara (“UU PTUN”), adalah dalil yang
tidak tepat dan didasarkan pada pemahaman yang parsial terhadap sistem hukum
administrasi pemerintahan dan hukum acara peradilan tata usaha negara. Pertama, perlu
dibedakan secara tegas antara kewenangan administratif untuk menunda pelaksanaan
keputusan oleh pejabat pemerintahan dan kewenangan yudisial Pengadilan Tata
Usaha Negara untuk memerintahkan penundaan pelaksanaan KTUN dalam proses
sengketa.

2.
Bahwa Pasal 65 UU AP mengatur mengenai penundaan pelaksanaan keputusan dalam
ranah administrasi pemerintahan (bestuursrechtelijk schorsing), yaitu kewenangan yang
diberikan kepada Pejabat Pemerintahan atau Atasan Pejabat untuk menunda pelaksanaan
keputusan yang telah ditetapkan apabila berpotensi menimbulkan kerugian negara,
kerusakan lingkungan hidup, atau konflik sosial. Ketentuan tersebut merupakan norma
hukum administrasi materiil yang mengatur tindakan pemerintahan sebelum maupun di
luar proses peradilan. Sebaliknya, Pasal 67 UU PTUN mengatur mengenai permohonan
penundaan pelaksanaan KTUN yang diajukan oleh Penggugat kepada Pengadilan selama
proses pemeriksaan sengketa berlangsung. Norma tersebut merupakan hukum acara
(procedural law) yang mengatur kewenangan hakim dalam memberikan perlindungan
hukum sementara selama proses persidangan.
3.
Bahwa dengan demikian, Pasal 65 UU AP dan Pasal 67 UU PTUN mengatur objek yang
sama berupa penundaan pelaksanaan keputusan, tetapi berada pada kewenangan yang
berbeda, sehingga tidak terdapat hubungan lex specialis dan lex generalis sebagaimana
didalilkan Penggugat. Keduanya berlaku secara komplementer sesuai ruang lingkup
pengaturannya masing-masing.
4.
Bahwa selanjutnya, dalil Penggugat yang menyatakan bahwa Pasal 67 UU PTUN
merupakan satu-satunya lex specialis yang mengatur penundaan KTUN mengabaikan
fakta bahwa UU AP merupakan regulasi yang lahir kemudian (lex posterior) dan secara
khusus mengatur penyelenggaraan administrasi pemerintahan, termasuk mekanisme
penundaan keputusan oleh pejabat administrasi. Bahkan Pasal 65 ayat (3) UU AP secara
eksplisit menyebutkan bahwa penundaan keputusan dapat dilakukan berdasarkan
putusan pengadilan, yang menunjukkan adanya hubungan harmonis antara mekanisme
administratif dan mekanisme yudisial, bukan hubungan saling meniadakan.
5.
Bahwa berdasarkan hal-hal tersebut, dalil Penggugat yang menyatakan Tergugat keliru
memilih dasar hukum haruslah ditolak, karena Pasal 65 UU AP dan Pasal 67 UU PTUN
mengatur mekanisme penundaan yang berbeda baik dari segi subjek yang berwenang,
tujuan, maupun konteks penerapannya. Penggunaan Pasal 65 UU AP oleh Tergugat tidak
bertentangan dengan Pasal 67 UU PTUN dan justru merupakan penerapan norma yang
tepat sesuai kewenangan administratif yang dimiliki oleh pejabat pemerintahan.
6.
Bahwa asas praesumptio iustae causa (vermoeden van rechtmatigheid) merupakan salah satu
asas fundamental dalam hukum administrasi negara yang mengandung makna bahwa
setiap Keputusan Tata Usaha Negara harus dianggap sah, benar, dan dapat dilaksanakan
sepanjang belum ada putusan pengadilan yang berkekuatan hukum tetap yang
menyatakan sebaliknya. Oleh karena itu, keberadaan gugatan ataupun tuduhan adanya
cacat hukum dalam suatu KTUN tidak serta-merta menghilangkan atau melemahkan asas
tersebut. Selama KTUN belum dibatalkan oleh putusan pengadilan yang berkekuatan
hukum tetap, KTUN tetap memiliki kekuatan mengikat dan wajib dianggap sah menurut
hukum.
7.
Bahwa dalil Penggugat yang menyatakan bahwa asas praesumptio iustae causa "melemah
dengan sendirinya" ketika cacat KTUN merupakan pendapat yang tidak memiliki dasar
normatif. Penilaian mengenai ada atau tidaknya cacat hukum pada suatu KTUN
merupakan kewenangan hakim yang dilakukan melalui proses pembuktian di
persidangan. Selama proses tersebut belum selesai dan belum terdapat putusan yang
menyatakan KTUN cacat hukum yang telah memperoleh kekuatan hukum tetap, maka
tidak dapat dibenarkan apabila Penggugat secara sepihak menyimpulkan bahwa Objek
Sengketa patut diduga batal dan oleh karenanya asas praesumptio iustae causa tidak lagi
berlaku.
8.
Bahwa keberadaan Pasal 67 UU PTUN justru menegaskan bahwa asas praesumptio iustae
causa tetap menjadi prinsip umum (general rule), sedangkan penundaan pelaksanaan
KTUN merupakan pengecualian (exception) yang hanya dapat diberikan apabila syarat-

syarat yang ditentukan undang-undang terbukti secara nyata dan meyakinkan.
Penggugat juga tidak dapat mendalilkan bahwa KTUN patut diduga kuat batal hanya
berdasarkan penafsiran sepihak mengenai keberlakuan surut Objek Sengketa. Persoalan
ada atau tidaknya pelanggaran terhadap asas non-retroaktif merupakan bagian dari
pokok perkara yang harus dibuktikan dan diputus dalam putusan akhir. Apabila setiap
dugaan cacat hukum yang diajukan Penggugat langsung dianggap cukup untuk
menunda pelaksanaan KTUN, maka asas praesumptio iustae causa akan kehilangan makna
dan setiap KTUN akan dengan mudah kehilangan daya laksana hanya karena adanya
gugatan, yang jelas bertentangan dengan maksud pembentuk undang-undang.
9.
Bahwa alasan bahwa penundaan diperlukan untuk mencegah kerugian yang lebih fatal
dan tidak dapat dipulihkan juga tidak dapat diterima apabila tidak disertai bukti yang
konkret, aktual, dan spesifik mengenai bentuk kerugian tersebut. Kerugian yang bersifat
dugaan, asumsi, atau kemungkinan di masa mendatang tidak memenuhi syarat sebagai
keadaan yang mendesak sebagaimana dimaksud dalam Pasal 67 UU PTUN.
10. Bahwa berdasarkan uraian tersebut, dalil Penggugat yang menyatakan bahwa asas
praesumptio iustae causa telah melemah karena adanya dugaan cacat keberlakuan surut
pada Objek Sengketa a quo adalah dalil yang prematur dan tidak berdasar hukum.
Sampai terdapat putusan pengadilan yang menyatakan sebaliknya, Objek Sengketa tetap
harus dianggap sah dan memiliki kekuatan mengikat serta dapat dilaksanakan. Oleh
karena itu, asas praesumptio iustae causa tetap berlaku sepenuhnya dalam perkara a quo dan
tidak terdapat alasan hukum yang cukup untuk mengesampingkan asas tersebut maupun
untuk menunda pelaksanaan Objek Sengketa.
II. DALAM POKOK PERKARA
1.
Bahwa Tergugat dengan tegas menyatakan tetap pada pendirian semula sebagaimana
disampaikan dalam jawaban yang telah diajukan, serta Tergugat menolak dalil-dalil
Penggugat sebagaimana yang dikemukakan dalam gugatan dan replik yang diajukannya,
kecuali terhadap hal-hal yang diakui secara tegas kebenarannya oleh Tergugat dan
mohon agar apa yang telah diuraikan dalam eksepsi tersebut secara mutatis mutandis
tercantum pula dalam pokok perkara ini.
2.
Bahwa Tergugat dengan tegas menolak dalil Penggugat pada angka 12 s.d. 15 yang pada
pokoknya menyatakan bahwa Objek Sengketa mengandung keberlakuan surut yang
melanggar Pasal 58 ayat (6) UU AP serta menimbulkan kerugian bagi Penggugat.
3.
Bahwa frasa “berlaku surut sejak 1 November 2025” harus ditafsirkan secara sistematis
dan tidak dapat dipahami secara terpisah dari keseluruhan substansi keputusan.
Penggugat secara keliru menafsirkan frasa “berlaku surut sejak 1 November 2025” secara
harfiah tanpa memperhatikan konteks, tujuan, dan substansi pengaturan yang
terkandung dalam Objek Sengketa secara keseluruhan. Dalam hukum administrasi
pemerintahan, penafsiran terhadap suatu Keputusan Tata Usaha Negara tidak dapat
dilakukan hanya berdasarkan satu frasa tertentu yang dipisahkan dari keseluruhan
diktum keputusan. Yang harus dinilai adalah akibat hukum nyata yang ditimbulkan oleh
keputusan tersebut serta tujuan administratif yang hendak dicapai oleh pejabat yang
menerbitkannya.
4.
Bahwa penggunaan frasa “berlaku surut sejak 1 November 2025” tidak serta-merta berarti
bahwa Tergugat telah menciptakan akibat hukum baru terhadap suatu keadaan yang
pada saat itu telah selesai dan berkekuatan tetap. Frasa tersebut harus dipahami sebagai
penentuan tanggal efektif administratif yang digunakan untuk penyesuaian status

kepegawaian dan administrasi keuangan sesuai kondisi faktual yang telah terjadi
sebelumnya.
5.
Bahwa 
selanjutnya, 
Penggugat 
mendalilkan 
bahwa 
setiap 
keputusan 
yang
mencantumkan tanggal efektif sebelum tanggal penetapan keputusan otomatis
merupakan retroaktivitas yang dilarang oleh Pasal 58 UU AP. Pandangan demikian tidak
sejalan dengan praktik administrasi pemerintahan maupun hukum kepegawaian yang
mengenal penetapan tanggal efektif administratif untuk menyesuaikan status hukum
dengan keadaan faktual yang telah terjadi sebelumnya. Dalam berbagai keputusan
kepegawaian, pengangkatan, pemberhentian, kenaikan pangkat, penyesuaian jabatan,
maupun pembetulan administrasi sering kali ditetapkan dengan tanggal efektif tertentu
guna menjaga tertib administrasi dan kesinambungan hak serta kewajiban pegawai.
6.
Bahwa yang tidak diperbolehkan adalah pemberian akibat hukum yang merugikan
secara tidak sah terhadap peristiwa yang telah selesai atau menciptakan kewajiban baru
yang sebelumnya tidak ada tanpa dasar hukum yang jelas. Oleh karena itu, keberadaan
tanggal efektif administratif tidak dapat serta-merta disamakan dengan retroaktivitas
yang dilarang oleh undang-undang.
7.
Bahwa penetapan tanggal efektif tersebut dalam rangka penyesuaian administrasi
kepegawaian dan pengelolaan hak keuangan yang berkaitan dengan status jabatan
Penggugat. Kebijakan tersebut dimaksudkan untuk memastikan adanya kesesuaian
antara kondisi faktual, status administratif, dan hak keuangan yang diterima oleh
Penggugat sehingga tercipta kepastian hukum serta tertib administrasi pemerintahan.
Dengan demikian, tujuan penerbitan Objek Sengketa bukanlah untuk membebankan
kerugian kepada Penggugat, melainkan untuk menyesuaikan administrasi kepegawaian
berdasarkan kondisi hukum yang berlaku.
8.
Bahwa Penggugat telah keliru dan salah mengartikan serta mengaitkan kewajiban
pengembalian tunjangan kinerha dengan keberlakuan surut objek sengketa. Perlu
Tergugat tegaskan bahwa apabila terdapat penyesuaian hak keuangan atau koreksi
pembayaran tunjangan, hal tersebut bukan semata-mata disebabkan oleh adanya
pencantuman tanggal efektif administratif dalam Objek Sengketa, melainkan karena
adanya penyesuaian status kepegawaian yang menjadi dasar pemberian hak keuangan
tersebut.
9.
Bahwa kewajiban pengembalian pembayaran yang tidak sesuai dengan status jabatan
yang berlaku merupakan konsekuensi administratif dari pengelolaan keuangan negara
dan prinsip akuntabilitas pengelolaan anggaran, bukan bukti bahwa Objek Sengketa
diterbitkan secara melawan hukum. Oleh karenanya, dalil Penggugat yang menyatakan
bahwa kewajiban pengembalian tunjangan secara otomatis membuktikan adanya
pelanggaran Pasal 58 ayat (6) UU AP merupakan kesimpulan yang tidak memiliki
hubungan sebab-akibat yang memadai.
10. Bahwa Penggugat juga mendalilkan bahwa alasan Tergugat mengenai perlindungan
finansial atau penyelamatan hak keuangan Penggugat bertentangan dengan fakta adanya
pengembalian tunjangan kinerja.
11. Bahwa dalil tersebut mengabaikan kenyataan bahwa perlindungan finansial harus
dipahami secara menyeluruh dan jangka panjang, tidak hanya terbatas pada satu
komponen penghasilan tertentu. Kebijakan administrasi yang ditempuh Tergugat

ditujukan untuk memastikan kesesuaian status jabatan, hak kepegawaian, dan
konsekuensi keuangan yang melekat pada status tersebut sesuai ketentuan peraturan
perundang-undangan. Oleh sebab itu, keberadaan penyesuaian atau koreksi atas salah
satu komponen hak keuangan tidak serta-merta meniadakan tujuan perlindungan
administratif yang menjadi dasar diterbitkannya Objek Sengketa.
12. Berdasarkan seluruh uraian tersebut, dalil Penggugat yang menyatakan bahwa Objek
Sengketa mengandung keberlakuan surut yang melanggar Pasal 58 ayat (6) UU AP serta
menimbulkan kerugian bagi Penggugat tidak beralasan hukum dan sudah sepatutnya
ditolak.
13. Bahwa selanjutnya, Tergugat dengan tegas membantah dalil Penggugat pada angka 16
yang pokoknya menyatakan bahwa Tergugat mampu menerbitkan keputusan secara
prospektif terhadap pegawai lain yang mengalami putusan yang sama dengan
Penggugat, sehingga dengan adanya perlakuan surut yang khusus dikenakan kepada
Penggugat merupakan konsekuensi dari keterlambatan Tergugat dalam menerbitkan
objek sengketa dan berdasarkan asas nullus commodum capere potest de injuria sua propria,
Tergugat tidak boleh mengambil keuntungan administratif (keseragaman tanggal) dari
kelalaiannya sendiri.
14. Bahwa dalam hukum administrasi negara berlaku prinsip bahwa setiap keputusan
pemerintahan diterbitkan berdasarkan fakta, data, dan keadaan konkret masing-masing
subjek hukum. Oleh karena itu, perbedaan bentuk atau waktu pemberlakuan suatu
keputusan tidak serta-merta menunjukkan adanya perlakuan yang berbeda secara
melawan hukum apabila terdapat perbedaan keadaan faktual maupun administratif yang
melatarbelakanginya.
15. Bahwa sebagaimana telah Tergugat sampaikan dan jelaskan dalam Jawaban terdahulu,
bahwa hal tersebut bukan merupakan kelalaian yang diakibatkan oleh Tergugat
melainkan adanya permintaan sendiri dari Penggugat yang meminta agar dapat
ditempatkan di unit lain yang berbeda dari permintaan awal Penggugat, sehingga hal
tersebut membutuhkan waktu dan koordinasi dengan unit dimaksud.
16. Bahwa terkait dengan hal tersebut, dapat Tergugat sampaikan kembali hal-hal sebagai
berikut:
a.
Bahwa melalui aplikasi pesan whatsapp, Penggugat secara informal mengirimkan
pesan kepada salah satu staf pada BPPK tertanggal 8 Oktober 2025 yang
menginformasikan bahwa Penggugat mengetahui jika Penggugat akan
diberhentikan dari jabatan fungsional pranata komputer dan meminta agar
Penggugat dapat dimutasikan atau dikembalikan ke BPPK selaku instansi awal
Penggugat sebelum dimutasikan ke BaTii.
b.
Bahwa selanjutnya, ketika proses pengurusan dan penerbitan objek sengketa,
Penggugat kembali menyampaikan secara informal melalui pesan singkat aplikasi
whatsapp kepada salah satu staf di BPPK pada tanggal 10 November 2025 yang
pokoknya menyampaikan bahwa Penggugat memohon untuk dapat dimutasi ke
salah satu unit di Kementerian Keuangan yaitu Direktorat Jenderal Anggaran
(”DJA)”) dan meminta agar Surat Keputusan yang awalnya akan ditempatkan di
BPPK dapat dirubah ke DJA.

c.
Bahwa latar belakang dari permohonan perpindahan unit adalah adanya informasi
yang diterima oleh Penggugat bahwa adanya ketersediaan di DJA sehingga
terhadap penghasilan Penggugat tidak terlalu terdampak. Namun demikian,
setelah BaTii melakukan konfirmasi kepada DJA ditemukan fakta bahwa tidak
pernah terdapat tawaran untuk perpindahan dari BaTii ke DJA.
17. Bahwa penerbitan suatu keputusan tata usaha negara, khususnya yang berkaitan dengan
status kepegawaian, memerlukan serangkaian proses administrasi, verifikasi data,
koordinasi antarunit kerja, penelitian aspek hukum, serta pemenuhan prosedur yang
ditentukan oleh peraturan perundang-undangan. Oleh karena itu, tenggang waktu antara
terjadinya suatu keadaan hukum dengan diterbitkannya keputusan administratif tidak
dapat secara otomatis dikualifikasikan sebagai kelalaian.
18. Bahwa Penggugat juga keliru dalam menerapkan asas nullus commodum capere potest de
injuria sua propria. Asas tersebut pada hakikatnya ditujukan untuk mencegah seseorang
memperoleh manfaat hukum dari perbuatan melawan hukum atau kesalahannya sendiri.
Namun dalam perkara a quo, Tergugat tidak memperoleh keuntungan pribadi maupun
keuntungan hukum tertentu dari penetapan tanggal efektif sebagaimana tercantum
dalam Objek Sengketa.
19. Bahwa penetapan tanggal efektif administratif dilakukan dalam rangka penyesuaian
status administrasi kepegawaian dan pencatatan hak serta kewajiban kepegawaian sesuai
kondisi yang dianggap relevan oleh pejabat yang berwenang. Tindakan tersebut
merupakan pelaksanaan fungsi administrasi pemerintahan, bukan sarana untuk
memperoleh keuntungan bagi Tergugat. Oleh sebab itu, unsur utama penerapan asas
nullus commodum capere potest de injuria sua propria, yaitu adanya keuntungan yang
diperoleh dari kesalahan sendiri, tidak terbukti dalam perkara a quo.
20. Bahwa Tergugat dengan tegas menolak dalil Penggugat bahwa objek sengketa
menegasikan tugas yang telah ditunaikan oleh Penggugat.
21. Bahwa Objek Sengketa tidak menghapus fakta bahwa Penggugat pernah melaksanakan
pekerjaan, menjalankan tugas kedinasan, ataupun memperoleh penilaian kinerja tertentu.
Fakta-fakta tersebut tetap tercatat dan tetap menjadi bagian dari riwayat kepegawaian
Penggugat, yang dilakukan oleh Objek Sengketa adalah penyesuaian status administratif
tertentu beserta konsekuensi hukumnya. Dengan demikian, tidak benar apabila
dikatakan bahwa Objek Sengketa menghapus eksistensi pekerjaan yang telah dilakukan
oleh Penggugat.
22. Bahwa Tergugat dengan tegas menolak dalil Penggugat pada angka 18 s.d. 23 yang pada
pokoknya menyatakan bahwa Penggugat tidak pernah diberikan kesempatan untuk
melakukan penjelasan dan/atau pembelaan sebelum objek sengketa diterbitkan, padahal
sesuai ketentuan Pasal 41 ayat (5) Permenpan RB Nomor 1 Tahun 2023 bersifat imperatif
dimana pejabat fungsional yang akan diberhentikan harus diperiksa terlebih dahulu.
23. Bahwa terhadap dalil Penggugat dimaksud, dapat Tergugat sampaikan sebagai berikut:
a.
Bahwa sebagaimana telah Tergugat sampaikan dalam Jawaban terdahulu bahwa
ketentuan Pasal 41 ayat (5) Permenpan RB Nomor 1 Tahun 2023 masih memiliki
korelasi dengan ketentuan Pasal 43 huruf b Permenpan RB Nomor 1 Tahun 2023,
dimana Penggugat secara faktual berdasarkan pemeriksaan administrasi belum
memenuhi standar kompetensi yang ditentukan.

b.
Bahwa batas waktu untuk pemenuhan standar kompetensi yang ditentukan untuk
menduduki jabatan fungsional pranata komputer telah dijelaskan dalam ketentuan
Pasal 59 ayat (3) Permenpan RB Nomor 32 Tahun 2020, dimana ketentuan tersebut
masih tetap berlaku karena ketentuan mengenai syarat kualifikasi pendidikan
jabatan pranata computer masih menggunakan ketentuan Pasal 59 ayat (3)
Permenpan RB Nomor 32 Tahun 2020.
c.
Bahwa penegasan mengenai syarat kualifikasi pendidikan terkait jabatan fungsional
pranata komputer dinyatakan kembali dalam Lampiran Keputusan Menteri
Pendayagunaan Aparatur Negara dan Reformasi Birokrasi Republik Indonesia
Nomor SKJ.4 Tahun 2024 tentang Standar Kompetensi Jabatan Fungsional Pranata
Komputer (“SKJ.4 Tahun 2024”) yang menyatakan bahwa Penggugat yang memiliki
jabatan Pranata Komputer Mahir dalam Jabatan Fungsional Keterampilan harus
memiliki pendidikan minimal diploma tiga di bidang teknologi informasi dan
kualifikasi pendidikan lainnya yang ditetapkan oleh instansi Pembina.
d. Bahwa dalam hukum administrasi, suatu norma tidak dapat ditafsirkan secara
parsial, melainkan harus dibaca secara sistematis dalam keseluruhan struktur
pengaturannya. Oleh karena itu, makna pemeriksaan sebagaimana dimaksud Pasal
41 ayat (5) Permenpan RB Nomor 1 Tahun 2023 harus dilihat berdasarkan
karakteristik alasan pemberhentian yang menjadi dasar penerapannya.
e.
Bahwa pada dasarnya, kewajiban pemeriksaan terlebih dahulu relevan apabila
terdapat fakta atau keadaan yang masih memerlukan pembuktian, klarifikasi, atau
penilaian 
terhadap 
perilaku 
maupun 
tindakan 
pejabat 
fungsional 
yang
bersangkutan. Sebaliknya, apabila dasar pemberhentian bersumber pada keadaan
administratif yang objektif dan dapat diverifikasi secara langsung melalui data
kepegawaian, maka kebutuhan akan pemeriksaan substantif sebagaimana dimaksud
Penggugat menjadi tidak relevan, dimana dalam perkara a quo terbukti berdasarkan
pemeriksaan administrasi bahwa Penggugat tidak pernah mengajukan untuk
mengajukan untuk melanjutkan pendidikan sejak Permenpan RB Nomor 32 Tahun
2020 berlaku yang menetapkan batas waktu 5 (lima) tahun bagi Penggugat untuk
dapat memperoleh ijazah Diploma III di bidang teknologi informasi sejak aturan
tersebut diberlakukan.
f.
Bahwa PermenPANRB Nomor 1 Tahun 2023 tidak memberikan definisi khusus yang
membatasi bahwa pemeriksaan hanya dapat dilakukan melalui mekanisme tertentu,
seperti pemeriksaan disiplin, sidang, atau pemeriksaan dengan menghadirkan
pegawai yang bersangkutan. Karena itu, sepanjang instansi telah melakukan
penelitian, pencocokan, validasi, dan verifikasi terhadap data yang menjadi dasar
penerbitan keputusan, maka proses tersebut pada hakikatnya merupakan bentuk
pemeriksaan administratif terhadap fakta yang relevan. Terlebih lagi dalam perkara
a quo, objek yang diperiksa bukan perilaku atau kesalahan Penggugat, melainkan
terpenuhi atau tidak terpenuhinya persyaratan jabatan yang bersifat objektif yang
dapat dibuktikan melalui dokumen resmi.
g.
Bahwa dalam perkara a quo, dasar penerbitan Objek Sengketa adalah
ketidakmampuan atau ketidakmemenuhan persyaratan yang ditentukan untuk tetap
menduduki Jabatan Fungsional, khususnya terkait persyaratan kualifikasi yang telah
ditetapkan dalam peraturan perundang-undangan. Keadaan tersebut merupakan

fakta administratif yang objektif, terukur, dan dapat dibuktikan melalui dokumen
kepegawaian tanpa memerlukan pemeriksaan mengenai unsur kesalahan, niat,
ataupun pelanggaran disiplin pegawai.
h.
Bahwa dengan demikian, berbeda dengan kasus yang memerlukan pemeriksaan
untuk membuktikan suatu pelanggaran atau dugaan kesalahan pegawai, dalam
perkara a quo fakta yang menjadi dasar pemberhentian telah bersifat pasti dan dapat
diverifikasi melalui data administratif yang tersedia. Oleh karena itu, tidak tepat
apabila Penggugat menyamakan seluruh jenis pemberhentian dalam Pasal 41 ayat
(1) Permepan RB Nomor 1 Tahun 2023 sebagai peristiwa yang harus melalui prosedur
pemeriksaan substantif yang sama.
i.
Bahwa apabila fakta yang menjadi dasar tindakan administrasi telah dapat
dipastikan melalui dokumen resmi, data kepegawaian, dan ketentuan normatif yang
berlaku, maka tujuan pemeriksaan pada hakikatnya telah tercapai melalui verifikasi
administratif yang dilakukan oleh instansi yang berwenang.
j.
Bahwa dengan tidak disebutkannya kata “disiplin” dalam ketentuan Pasal 41 ayat
(5) Permenpan RB Nomor 1 Tahun 2023 tidak berarti bahwa pemeriksaan harus
dimaknai identik untuk seluruh keadaan yang diatur dalam ketentuan Pasal
dimaksud.
k.
Bahwa Penggugat secara tidak langsung berusaha menambahkan makna baru
terhadap ketentuan Pasal 41 ayat (5) Permenpan RB Nomor 1 Tahun 2023 dengan
menyatakan bahwa pemeriksaan harus dilakukan melalui mekanisme tertentu dan
tidak dapat berupa verifikasi administratif. Padahal, norma Pasal 41 ayat (5)
Permenpan RB Nomor 1 Tahun 2023 hanya menyebutkan bahwa pejabat fungsional
"harus diperiksa terlebih dahulu dan mendapatkan izin dari PyB", tanpa menentukan
bentuk, tata cara, ataupun prosedur pemeriksaan sebagaimana didalilkan Penggugat.
24. Bahwa berdasarkan hal-hal tersebut, maka dalil Penggugat yang menyatakan Penggugat
tidak pernah diberikan kesempatan untuk melakukan penjelasan dan/atau pembelaan
sebelum objek sengketa diterbitkan, padahal sesuai ketentuan Pasal 41 ayat (5)
Permenpan RB Nomor 1 Tahun 2023 bersifat imperatif dimana pejabat fungsional yang
akan diberhentikan harus diperiksa terlebih dahulu sudah sepatutnya ditolak.
25. Bahwa Tergugat dengan tegas menolak dalil Penggugat pada angka 24 s.d. 26 yang pada
pokoknya menyatakan bahwa Tergugat dalam keputusan menyatakan bahwa Penggugat
“dianggap cakap dan memenuhi syarat untuk ditunjuk/diangkat dalam jabatan”. Selain
itu, Tergugat juga menyatakan bahwa Penggugat “cakap dan memenuhi syarat” dalam
pelatihan-pelatihan yang diikuti oleh Penggugat.
26. Bahwa terhadap dalil Penggugat dimaksud, dapat Tergugat sampaikan penjelasan
sebagai berikut:
a.
Bahwa frasa “cakap dan memenuhi syarat” yang tercantum dalam keputusan
pengangkatan maupun dokumen pelatihan harus dimaknai sesuai konteks
penerbitannya. Pernyataan tersebut merupakan penilaian terhadap pemenuhan
persyaratan yang berlaku pada saat keputusan atau kegiatan dimaksud diterbitkan,
dan tidak dapat ditafsirkan sebagai pengesampingan terhadap ketentuan peraturan
perundang-undangan yang mengatur kualifikasi pendidikan jabatan fungsional
secara imperatif.

b.
Bahwa secara hukum frasa "memiliki kualifikasi pendidikan yang dibutuhkan"
merupakan syarat formal yang spesifik, sedangkan "cakap dan memenuhi syarat"
merupakan penilaian yang lebih luas mengenai kelayakan seseorang untuk
menduduki jabatan tertentu.
c.
Bahwa dalam hukum administrasi pemerintahan berlaku prinsip bahwa setiap
keputusan tata usaha negara harus tunduk pada ketentuan peraturan perundang-
undangan yang berlaku. Oleh karena itu, suatu pernyataan administratif mengenai
kecakapan atau kelayakan seseorang tidak dapat menciptakan hak yang
bertentangan dengan norma hukum yang lebih tinggi ataupun menghapus
kewajiban untuk memenuhi persyaratan jabatan yang ditentukan oleh peraturan
perundang-undangan.
d. Bahwa penilaian Penggugat yang mendalilkan mengenai frasa “cakap dan
memenuhi syarat” dalam pelatihan hanya menunjukkan bahwa Penggugat
memenuhi persyaratan untuk mengikuti atau menyelesaikan pelatihan tertentu serta
memiliki kompetensi teknis yang dinilai dalam pelatihan tersebut. Penilaian tersebut
sama sekali tidak identik dengan pemenuhan persyaratan kualifikasi pendidikan
yang menjadi syarat jabatan.
e.
Bahwa kompetensi, kecakapan, pengalaman kerja, dan kelulusan pelatihan
merupakan aspek yang berbeda secara yuridis dengan kualifikasi pendidikan formal.
Seseorang dapat dinilai kompeten dalam pelaksanaan tugas tertentu, namun tetap
tidak memenuhi persyaratan kualifikasi pendidikan yang secara tegas diwajibkan
oleh peraturan jabatan fungsional. Oleh karena itu, keberhasilan Penggugat dalam
mengikuti pelatihan tidak dapat dijadikan dasar untuk mengabaikan persyaratan
pendidikan minimal yang telah ditentukan.
f.
Bahwa ketentuan mengenai kualifikasi pendidikan Jabatan Fungsional Pranata
Komputer merupakan norma yang bersifat mengikat (mandatory). Dalam hal
peraturan perundang-undangan mensyaratkan kualifikasi pendidikan tertentu,
maka pemenuhan syarat tersebut harus dibuktikan dengan ijazah pendidikan formal
yang sesuai. Persyaratan tersebut tidak dapat digantikan dengan pengalaman kerja,
pelatihan, sertifikat kompetensi, maupun penilaian subjektif mengenai kecakapan
pegawai, kecuali apabila peraturan perundang-undangan secara tegas memberikan
pengecualian.
g.
Bahwa pemindahan jabatan fungsional pranata komputer Penggugat dalam jabatan
berdasarkan ketentuan peralihan atau kebijakan penyesuaian jabatan pada masa
tertentu, tidak menghilangkan kewajiban Penggugat untuk memenuhi persyaratan
pendidikan yang kemudian diwajibkan oleh peraturan perundang-undangan.
Ketentuan Permenpan RB Nomor 32 Tahun 2020 telah memberikan kesempatan
dalam jangka waktu yang cukup kepada Penggugat yang belum memenuhi syarat
untuk memenuhi aturan dimaksud. Apabila sampai berakhirnya tenggang waktu
yang diberikan persyaratan tersebut tidak dipenuhi, maka Tergugat berwenang
mengambil tindakan administratif sesuai ketentuan yang berlaku.
h.
Bahwa dengan demikian, dalil Penggugat yang menyamakan frasa “cakap dan
memenuhi syarat” dengan terpenuhinya kualifikasi pendidikan Diploma III bidang
Teknologi Informasi adalah penafsiran yang tidak tepat dan bertentangan dengan
sistem persyaratan jabatan fungsional yang membedakan secara tegas antara

kompetensi jabatan dan kualifikasi pendidikan formal. Karena Penggugat hanya
memiliki pendidikan Diploma I dan tidak memenuhi kualifikasi pendidikan minimal
yang dipersyaratkan oleh ketentuan jabatan fungsional yang berlaku.
27. Bahwa berdasarkan hal-hal tersebut, maka dalil Penggugat yang menyatakan bahwa
Tergugat dalam keputusan menyatakan bahwa Penggugat “dianggap cakap dan
memenuhi syarat untuk ditunjuk/diangkat dalam jabatan”. Selain itu, Tergugat juga
menyatakan bahwa Penggugat “cakap dan memenuhi syarat” dalam pelatihan-pelatihan
yang diikuti oleh Penggugat sudah sepatutnya ditolak.
28. Bahwa Tergugat dengan tegas menolak dalil Penggugat pada angka 28 s.d. 31 yang pada
pokoknya menyatakan bahwa Tergugat telah melakukan inkonsistensi penerapan
parameter “bidang teknologi informasi” dengan memberhentikan Penggugat karena
tidak memiliki ijazah Diploma III bidang teknologi informasi, namun disisi lain Tergugat
mengangkat/mempertahankan pegawai lain daru rumpun non teknologi informasi
dalam jabatan fungsional pranata komputer.
29. Bahwa Penggugat telah membaca dan mempelajari aturan dan ketentuan yang mengatur
mengenai jabatan fungsional secara parsial dan tidak menyeluruh, dimana Penggugat
hanya menggunakan satu pasal dari satu aturan namun Penggugat tidak
menghubungkan dengan ketentuan dan aturan lain yang mengatur dalam rumpun yang
sama.
30. Bahwa di dalam ketentuan SKJ.4 Tahun 2024 telah menegaskan bahwa untuk Jabatan
Fungsional Pranata Komputer Mahir harus memiliki jenjang pendidikan bidang
teknologi informasi dan kualifikasi pendidikan lainnya yang ditetapkan oleh instansi
Pembina.
31. Bahwa selama terdapat formasi yang memperbolehkan bagi bidang ilmu lain selain
bidang teknologi informasi untuk dapat menduduki suatu jabatan fungsional pranata
komputer yang telah ditetapkan oleh instansi Pembina, maka tidak ada larangan bagi
rumpun ilmu lain untuk menduduki jabatan fungsional dimaksud.
32. Bahwa data pembanding yang disajikan oleh Penggugat di dalam Repliknya secara jelas
menggambarkan bahwa subjek pegawai lain yang diangkat telah memiliki jenjang
minimal yang dipersyaratkan oleh SKJ.4 Tahun 2024 yaitu Diploma III dan bidang ilmu
lain yang ditetapkan oleh instansi pembina.
33. Bahwa dapat Tergugat sampaikan bahwa pada awalnya, Penggugat diangkat pertama
kali untuk menduduki jabatan fungsional adalah sebagai jabatan fungsional pranata
komputer 
yang 
didasarkan 
pada 
Keputusan 
Menteri 
Keuangan 
Nomor
1105/KM.3/UP.11/2009 tanggal 7 September 2009.
34. Bahwa dalil yang disampaikan oleh Penggugat dibangun atas asumsi bahwa seluruh
pegawai yang dibandingkan dengan Penggugat berada dalam kondisi hukum, fakta, dan
status kepegawaian yang sama. Padahal, dalam hukum administrasi pemerintahan,
penilaian terhadap keabsahan suatu tindakan administrasi harus dilakukan berdasarkan
kondisi konkret masing-masing pegawai, termasuk waktu pengangkatan, dasar hukum
yang berlaku saat pengangkatan, status peralihan, mekanisme penyesuaian jabatan,
jenjang jabatan, serta ketentuan khusus yang berlaku terhadap pegawai yang
bersangkutan.

35. Bahwa sekalipun terdapat pegawai lain yang berasal dari disiplin ilmu di luar
nomenklatur Teknologi Informasi, hal tersebut tidak otomatis berarti bahwa pegawai
tersebut tidak memenuhi persyaratan jabatan. Dalam praktik kepegawaian, penentuan
kesesuaian bidang pendidikan dilakukan berdasarkan ketentuan peraturan perundang-
undangan, hasil verifikasi administrasi, pemetaan rumpun ilmu, atau kebijakan instansi
pembina jabatan fungsional yang berwenang menilai relevansi suatu program studi
dengan kebutuhan jabatan.
36. Bahwa objek sengketa diterbitkan berdasarkan hasil evaluasi terhadap status dan
kualifikasi Penggugat sendiri, khususnya terkait tidak terpenuhinya kualifikasi
pendidikan yang dipersyaratkan dalam Jabatan Fungsional Pranata Komputer setelah
diberikan kesempatan penyesuaian sesuai ketentuan yang berlaku. Oleh karena itu,
legalitas objek sengketa harus dinilai berdasarkan fakta dan kondisi yang melekat pada
Penggugat, bukan berdasarkan dugaan mengenai kondisi pegawai lain yang tidak
menjadi objek pemeriksaan dalam perkara a quo.
37. Bahwa Dalil Penggugat pada angka 33 s.d. 35 yang pada pokoknya menyatakan bahwa
Tergugat wajib melakukan “uji harmonisasi” terlebih dahulu sebelum menerapkan Pasal
59 PermenPANRB Nomor 32 Tahun 2020, serta bahwa Penggugat merupakan pemegang
verkregen recht yang tidak dapat dibebani oleh ketentuan kualifikasi yang lahir kemudian,
adalah dalil yang keliru dan tidak mempunyai dasar hukum.
38. Bahwa ketentuan Pasal 61 PermenPANRB Nomor 1 Tahun 2023 pada pokoknya
mengatur bahwa ketentuan teknis yang telah ada sebelum berlakunya peraturan tersebut
tetap berlaku sepanjang tidak bertentangan dan belum diubah atau diganti berdasarkan
peraturan yang baru.
39. Bahwa norma tersebut merupakan ketentuan peralihan (transitional provision) yang
ditujukan untuk menjamin keberlangsungan pelaksanaan administrasi pemerintahan dan
mencegah terjadinya kekosongan hukum setelah berlakunya PermenPANRB Nomor 1
Tahun 2023. Ketentuan tersebut tidak memuat perintah maupun prosedur yang
mewajibkan setiap pejabat administrasi untuk melakukan suatu “uji harmonisasi” secara
tersendiri sebelum menerapkan setiap ketentuan teknis yang masih berlaku.
40. Bahwa Penggugat sendiri tidak membantah fakta bahwa ketentuan mengenai kualifikasi
pendidikan dalam Pasal 59 PermenPANRB Nomor 32 Tahun 2020 tidak dicabut dengan
adanya ketentuan PermenPANRB Nomor 1 Tahun 2023.
41. Bahwa PermenPANRB Nomor 1 Tahun 2023 merupakan regulasi yang mengatur
manajemen jabatan fungsional secara umum, sedangkan ketentuan mengenai kualifikasi
pendidikan Jabatan Fungsional Pranata Komputer tetap diatur secara khusus dalam
ketentuan teknis jabatan tersebut yaitu Permenpan RB Nomor 21 Tahun 2020.
42. Bahwa Tidak terdapat satu pun norma dalam PermenPANRB Nomor 1 Tahun 2023 yang
menyatakan bahwa pejabat fungsional yang tidak memenuhi kualifikasi pendidikan
sebagaimana diatur dalam regulasi teknis tetap dapat dipertahankan dalam jabatan tanpa
batas waktu. Karena itu, tidak terdapat konflik norma yang memerlukan penyelesaian
melalui metode harmonisasi sebagaimana didalilkan Penggugat.
43. Bahwa dalil Penggugat yang menyatakan dirinya merupakan pemegang verkregen recht
karena diangkat pada tahun 2009 saat syarat pengangkatan masih memungkinkan
lulusan SLTA atau Diploma I juga tidak tepat.

44. Bahwa pengangkatan Penggugat pada saat itu dilakukan berdasarkan ketentuan yang
berlaku ketika pengangkatan dilaksanakan. Akan tetapi, hak yang diperoleh Penggugat
adalah hak untuk memperoleh pengangkatan yang sah berdasarkan peraturan yang
berlaku pada saat itu, bukan hak absolut untuk selamanya terbebas dari perubahan
kebijakan kepegawaian maupun perkembangan persyaratan jabatan yang ditetapkan
kemudian oleh pembentuk peraturan.
45. Bahwa dalam hukum administrasi negara, suatu jabatan publik bukan merupakan hak
keperdataan yang tidak dapat disentuh oleh perubahan regulasi. Jabatan publik selalu
tunduk pada dinamika kebutuhan organisasi, standar kompetensi, dan ketentuan
peraturan perundang-undangan yang berlaku. Oleh sebab itu, keberadaan Penggugat
sebagai Jabatan Fungsional Pranata Komputer sejak tahun 2009 tidak menghapus
kewajiban untuk menyesuaikan diri dengan ketentuan yang kemudian berlaku, terutama
apabila peraturan tersebut memberikan masa transisi atau mekanisme penyesuaian yang
memadai.
46. Bahwa dalil Penggugat bahwa pencabutan sebagian ketentuan melalui Pasal 62 huruf b
angka 169 Permenpan RB Nomor 1 Tahun 2023 menunjukkan adanya “transisi yang
belum tuntas” sehingga pemberhentian tidak dapat dilakukan, juga tidak beralasan.
Justru ketentuan peralihan dalam suatu peraturan dimaksudkan agar norma yang belum
dicabut tetap dapat dijalankan sampai dilakukan penyesuaian lebih lanjut. Apabila setiap
ketentuan teknis yang belum dicabut dianggap tidak dapat diterapkan hanya karena
sedang berada dalam masa transisi, maka akan timbul ketidakpastian hukum dan
kekosongan pengaturan yang bertentangan dengan tujuan dibentuknya ketentuan
peralihan itu sendiri.
47. Bahwa dengan demikian, fakta bahwa hanya sebagian ketentuan teknis lama yang
dicabut tidak dapat ditafsirkan bahwa seluruh ketentuan lainnya kehilangan daya
berlaku atau harus ditangguhkan penerapannya.
48. Bahwa dalil Penggugat pada angka 37 sampai dengan angka 39 yang pada pokoknya
menyatakan bahwa Objek Sengketa cacat hukum karena tidak mencantumkan
PermenPANRB Nomor 32 Tahun 2020 dan SKJ.4/2024 dalam bagian "Mengingat",
sehingga menimbulkan ketidakpastian hukum dan cacat motivasi (motiveringgebrek),
adalah dalil yang tidak berdasar baik secara normatif maupun dalam praktik hukum
administrasi pemerintahan.
49. Bahwa tidak terdapat ketentuan peraturan perundang-undangan yang mewajibkan
seluruh norma, kebijakan teknis, standar kompetensi, atau peraturan yang menjadi bahan
pertimbangan administratif harus dicantumkan satu per satu dalam bagian "Mengingat"
suatu Keputusan Tata Usaha Negara. Bagian "Mengingat" berfungsi menunjukkan
landasan hukum utama kewenangan dan tindakan administratif yang diambil oleh
pejabat yang bersangkutan. Oleh karena itu, tidak dicantumkannya setiap peraturan
teknis yang berkaitan dengan materi keputusan tidak serta-merta menyebabkan
keputusan tersebut kehilangan dasar hukum atau menjadi tidak sah.
50. Bahwa suatu keputusan dapat didasarkan pada keseluruhan sistem peraturan
perundang-undangan yang relevan, termasuk ketentuan teknis, pedoman, standar
kompetensi, hasil verifikasi administrasi, maupun data kepegawaian yang menjadi
bagian dari proses pembentukan keputusan, meskipun tidak seluruhnya dicantumkan
secara eksplisit dalam bagian "Mengingat".

51. Bahwa Tergugat tidak pernah mendalilkan bahwa PermenPANRB Nomor 32 Tahun 2020
maupun SKJ.4/2024 tidak relevan terhadap substansi perkara. Yang didalilkan Tergugat
adalah bahwa keberlakuan norma dalam kedua instrumen tersebut tidak bergantung
pada pencantumannya dalam bagian "Mengingat" Objek Sengketa. Penggugat secara
keliru menyamakan antara keberadaan suatu norma dalam sistem hukum dengan
kewajiban pencantumannya dalam redaksi formal suatu keputusan administrasi.
52. Bahwa dalil Penggugat yang mendasarkan argumentasinya pada Pasal 9 ayat (1) UU AP
juga tidak tepat. Ketentuan tersebut mengharuskan setiap keputusan didasarkan pada
peraturan perundang-undangan dan Asas-Asas Umum Pemerintahan yang Baik. Norma
tersebut tidak mengatur bahwa seluruh dasar hukum substantif wajib dicantumkan
secara lengkap dalam bagian "Mengingat" dengan ancaman batalnya keputusan apabila
terdapat norma yang tidak disebutkan.
53. Bahwa yang menjadi ukuran keabsahan adalah apakah keputusan tersebut memiliki
dasar kewenangan, dasar prosedural, dan dasar substantif yang sah menurut hukum,
bukan semata-mata banyak atau sedikitnya peraturan yang dicantumkan dalam
konsiderans. Oleh karenanya, sepanjang Tergugat memiliki kewenangan menerbitkan
keputusan, mengikuti prosedur yang ditentukan, dan mendasarkan substansi keputusan
pada ketentuan hukum yang berlaku, maka tidak terdapat pelanggaran terhadap Pasal 9
ayat (1) UU AP.
54. Bahwa dalil Penggugat mengenai adanya cacat motivering juga tidak beralasan. Motivasi
atau alasan suatu keputusan administrasi tidak semata-mata dinilai dari bagian
"Mengingat", melainkan dari keseluruhan dokumen administrasi yang melatarbelakangi
penerbitan keputusan tersebut, termasuk hasil evaluasi kepegawaian, telaahan staf,
verifikasi data pendidikan, dan dokumen lain yang menjadi bagian dari proses
pengambilan keputusan.
55. Bahwa dalam perkara a quo, alasan penerbitan Objek Sengketa adalah karena Penggugat
tidak memenuhi kualifikasi pendidikan yang dipersyaratkan untuk menduduki Jabatan
Fungsional Pranata Komputer berdasarkan ketentuan yang berlaku. Oleh karena itu,
tidak terdapat ketidakjelasan alasan maupun ketidakpastian dasar tindakan administrasi
sebagaimana didalilkan Penggugat.
56. Bahwa dalil Penggugat yang menyatakan bahwa pencantuman PermenPANRB Nomor
32 Tahun 2020 dan SKJ.4/2024 dalam KMK Nomor 9/MK/SJ/2026 merupakan
pengakuan adanya cacat hukum pada Objek Sengketa semula juga tidak dapat
dibenarkan.
57. Bahwa pencantuman dasar hukum yang lebih lengkap dalam keputusan yang diterbitkan
kemudian tidak dapat secara otomatis ditafsirkan bahwa keputusan sebelumnya tidak
memiliki dasar hukum yang sah. Penambahan atau penegasan dasar hukum dalam suatu
keputusan lanjutan merupakan bentuk klarifikasi dan penguatan argumentasi
administratif atas dasar hukum yang sejak awal telah menjadi bagian dari kerangka
normatif yang digunakan oleh pejabat administrasi.
58. Bahwa dengan demikian, keberadaan KMK Nomor 9/MK/SJ/2026 tidak membuktikan
bahwa Objek Sengketa sebelumnya kehilangan dasar hukum, melainkan justru
menunjukkan konsistensi dasar normatif yang digunakan dalam menilai status
kepegawaian Penggugat.

59. Bahwa apabila benar (quod non) Pengadilan menilai terdapat kekurangan formal dalam
penyusunan konsiderans "Mengingat", hal tersebut tidak serta-merta mengakibatkan
batalnya suatu Keputusan Tata Usaha Negara apabila kewenangan, substansi, tujuan, dan
prosedur penerbitannya tetap memenuhi ketentuan hukum yang berlaku. Doktrin dan
praktik peradilan tata usaha negara membedakan antara cacat formal yang bersifat
administratif dengan cacat yang secara nyata mempengaruhi legalitas substansi
keputusan. Dalam perkara a quo, Penggugat tidak dapat membuktikan bahwa tidak
dicantumkannya PermenPANRB Nomor 32 Tahun 2020 dan SKJ.4/2024 dalam bagian
"Mengingat" telah menghilangkan kewenangan Tergugat, mengubah fakta hukum yang
menjadi dasar keputusan, atau menyebabkan Penggugat sebenarnya memenuhi
persyaratan jabatan yang dipersyaratkan.
60. Bahwa dalam doktrin dan praktik Peradilan Tata Usaha Negara (PTUN), konsiderans
"Mengingat" bukanlah satu-satunya tempat untuk menilai legalitas dasar hukum
Keputusan Tata Usaha Negara (KTUN). Keabsahan dan legalitas substansial suatu KTUN
juga bersumber dari kewenangan atributif, delegatif, atau mandat yang diatur dalam
peraturan perundang-undangan lain.
Maka :
Berdasarkan hal-hal tersebut, Tergugat mohon kepada Majelis Hakim Pengadilan Tata
Usaha Negara Jakarta yang memeriksa dan mengadili perkara a quo berkenan
memberikan putusan sesuai dengan amar sebagaimana telah disampaikan dalam
Jawaban Tergugat terdahulu.

Hormat kami,
Kuasa Hukum Tergugat
Ditandatangani secara elektronik
Masayu Windri Asmara
Ditandatangani secara elektronik
Lulus Hadi Purnawan, S.H., M.H.
Ditandatangani secara elektronik
Heru Joko Surono
Ditandatangani secara elektronik
Sylvia Mulyawati
Ditandatangani secara elektronik
Daryan Ciptadi
Ditandatangani secara elektronik
Ikhwan Arif Rahman
Ditandatangani secara elektronik
Haenry Waskito Jati, S.H.
Ditandatangani secara elektronik
Irene Natalia Verda
Ditandatangani secara elektronik
Nasru Syava
Ditandatangani secara elektronik
Syahrul Sidiq
Ditandatangani secara elektronik
Muhammad Nurul Falah Huseini
Dokumen ini telah ditandatangani menggunakan sertifikat elektronik yang diterbitkan oleh Balai Besar Sertifikasi Elektronik (BSrE), BSSN. Untuk memastikan keaslian tanda
tangan elektronik, silakan pindai QR Code pada laman https://satu.kemenkeu.go.id atau unggah dokumen pada laman https://tte.komdigi.go.id/verifyPDF

