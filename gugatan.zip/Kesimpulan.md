# KESIMPULAN PENGGUGAT

## Perkara Tata Usaha Negara Nomor 119/G/2026/PTUN.JKT

**Pengadilan Tata Usaha Negara Jakarta**

---

Jakarta, 4 Agustus 2026

Kepada Yth.
Majelis Hakim Pemeriksa Perkara Nomor 119/G/2026/PTUN.JKT
Pengadilan Tata Usaha Negara Jakarta
di Jakarta

**Perihal: Kesimpulan Penggugat**

Dengan hormat,

Yang bertanda tangan di bawah ini, **Ninin Sapto Hargiyanto** (NIP 19860720 200701 1 001), Pegawai Negeri Sipil pada Kementerian Keuangan Republik Indonesia, beralamat di Jalan Bedeng 10, Kampung Rawakaong RT 002/RW 004, Grogol, Limo, Depok, Provinsi Jawa Barat, dalam hal ini bertindak untuk dan atas nama diri sendiri selaku **PENGGUGAT**;

**m e l a w a n**

**Menteri Keuangan Republik Indonesia**, beralamat di Gedung Djuanda I Lantai 3 Kementerian Keuangan, Jalan Dr. Wahidin Raya Nomor 1, Jakarta Pusat, dalam hal ini diwakili oleh kuasanya berdasarkan Surat Kuasa Khusus Nomor SKU-24/MK.01/2026 tanggal 29 April 2026, selaku **TERGUGAT**;

dengan ini menyampaikan Kesimpulan sebagai berikut.

---

# I. PENDAHULUAN

1. Bahwa Objek Sengketa dalam perkara *a quo* adalah **Keputusan Menteri Keuangan Republik Indonesia Nomor 199/MK/SJ.5/2025 tanggal 13 November 2025** tentang Pemberhentian dari Jabatan Fungsional Pranata Komputer Mahir dan Pemindahan Pegawai Negeri Sipil antar Unit Jabatan Pimpinan Tinggi Madya di Lingkungan Kementerian Keuangan atas nama Sdr. Ninin Sapto Hargiyanto (NIP 19860720 200701 1 001) — **satu-satunya** Keputusan Tata Usaha Negara yang menjadi objek pengujian dalam perkara ini (P-18 = T-12).

2. Bahwa Keputusan Menteri Keuangan Nomor 9/MK/SJ/2026 tanggal 23 Januari 2026 tentang Penguatan atas keputusan tersebut (P-23 = T-14) **bukanlah Objek Sengketa**. Sebagaimana telah Penggugat tegaskan sejak Gugatan, keputusan penguatan tersebut merupakan penegasan administratif atas ditolaknya upaya keberatan Penggugat, yang tidak mengandung perubahan, pengurangan, maupun penambahan hak dan kewajiban hukum baru. Kedudukannya dalam perkara *a quo* terbatas pada dua hal: **pertama**, sebagai penanda selesainya upaya administratif dan titik awal penghitungan tenggang waktu pengajuan gugatan; dan **kedua**, sebagai alat bukti yang memperlihatkan sikap serta pengakuan Tergugat sendiri. Penggugat tidak memohon pembatalan atasnya.

3. Bahwa Kesimpulan ini disusun berdasarkan seluruh fakta hukum yang terungkap dalam pemeriksaan persidangan, yaitu pembacaan Gugatan pada 7 Mei 2026; Jawaban Tergugat pada 20 Mei 2026; Replik Penggugat pada 3 Juni 2026; Duplik Tergugat pada 10 Juni 2026; penyerahan dan pemeriksaan bukti surat para pihak pada 24 Juni 2026 dan 1 Juli 2026; tambahan bukti surat serta pemeriksaan saksi Penggugat secara konvensional pada 8 Juli 2026; dan tambahan bukti surat pada 15 Juli 2026 dan 29 Juli 2026.

4. Bahwa Kesimpulan ini tidak mengulang Gugatan maupun Replik secara verbatim, melainkan menyusun kembali dalil-dalil Penggugat menurut **urutan pengujian keabsahan Keputusan Tata Usaha Negara**, yaitu aspek **wewenang**, aspek **prosedur**, dan aspek **substansi** sebagaimana Pasal 52 ayat (1) Undang-Undang Nomor 30 Tahun 2014 tentang Administrasi Pemerintahan, yang harus terpenuhi **secara kumulatif** dalam penerbitan suatu Keputusan.

5. Bahwa dengan hormat Penggugat sampaikan, pokok persoalan dalam perkara *a quo* bukanlah semata-mata apakah Penggugat memiliki ijazah Diploma III pada tanggal tertentu. Pokok persoalannya adalah apakah Objek Sengketa — sebagai Keputusan Tata Usaha Negara yang berdampak langsung pada hak, status, karier, penghasilan, dan reputasi seseorang — ditetapkan oleh organ yang berwenang atas materi yang dinilainya, melalui prosedur yang ditentukan peraturan perundang-undangan, dan dengan substansi yang selaras dengan Asas-Asas Umum Pemerintahan yang Baik.

---

# II. FAKTA HUKUM YANG TERUNGKAP DI PERSIDANGAN

Bahwa berdasarkan dalil-dalil Gugatan, jawab-menjawab para pihak, serta hasil pemeriksaan di persidangan yang dikaitkan dengan alat bukti surat dan keterangan saksi yang diajukan para pihak, Penggugat memperoleh fakta-fakta hukum sebagai berikut.

## A. Kedudukan hukum Penggugat

6. Bahwa Penggugat diangkat pertama kali dalam Jabatan Fungsional Pranata Komputer kategori keterampilan berdasarkan Keputusan Menteri Keuangan Nomor 1105/KM.1/UP.11/2009 terhitung mulai tanggal 1 Agustus 2009 (P-1), pada saat syarat pendidikan minimal untuk pengangkatan tersebut adalah SLTA atau Diploma I — syarat yang dipenuhi Penggugat melalui ijazah Diploma I Kebendaharaan Negara. Keabsahan pengangkatan tersebut diakui Tergugat (Jawaban, bagian Kronologis butir 2 dan butir 3; Duplik, Dalam Pokok Perkara angka 33 dan angka 44).

7. Bahwa Tergugat menaikkan jenjang jabatan Penggugat menjadi **Pranata Komputer Mahir** melalui Keputusan Menteri Keuangan Nomor 321.1/KM.1/UP.11/2022 tanggal 30 Maret 2022 (P-2 = T-3), yaitu di bawah keberlakuan Peraturan Menteri PANRB Nomor 32 Tahun 2020, tanpa Tergugat mempersoalkan strata pendidikan Penggugat (Jawaban, bagian Kronologis butir 8).

## B. Rangkaian pengakuan resmi Tergugat atas kelayakan Penggugat

8. Bahwa unit kerja Tergugat sendiri, melalui Surat Keterangan Plt. Kepala Pusat Pendidikan dan Pelatihan Keuangan Umum BPPK Nomor KET-137/PP.7/2024 tanggal 15 Mei 2024 (P-3), menyatakan Penggugat memenuhi kriteria memiliki latar belakang pendidikan Teknologi Informasi yang dibuktikan ijazah **dan/atau** telah berkecimpung di ranah Teknologi Informasi minimal 5 (lima) tahun. Tergugat tidak menyangkal keberadaan dokumen tersebut dan hanya berdalih agar dimaknai "sesuai konteks" (Duplik angka 26).

9. Bahwa Penggugat dinyatakan **"Kompeten"** dalam Pelatihan Fungsional Pranata Komputer Kategori Keterampilan selama 280 (dua ratus delapan puluh) jam pelajaran, melalui Sertifikat Nomor 0024/PRAKOM-TERAMPIL/106/BPS/III/2024 tanggal 29 Oktober 2024, yang diselenggarakan BPPK bersama **Badan Pusat Statistik selaku Instansi Pembina** Jabatan Fungsional Pranata Komputer (P-4). Kedudukan Badan Pusat Statistik selaku Instansi Pembina diakui sendiri oleh Tergugat (Jawaban, bagian Kronologis butir 4).

10. Bahwa pada tanggal 16 Mei 2025 — **sebelum** tenggat 26 Mei 2025 yang didalilkan Tergugat — Kepala Pusdiklat Keuangan Umum telah memproses permohonan izin belajar mandiri atas nama Penggugat melalui Nota Dinas ND-472/PP.7/2025 (P-6 = T-6), dan pada tanggal 10 Juni 2025 Sekretariat BPPK menerbitkan **Surat Tugas Belajar Mandiri (Tidak Diberhentikan) Nomor ST-497/PP.1/2025** yang menegaskan bahwa selama tugas belajar pegawai berstatus pegawai aktif yang memiliki hak dan kewajiban pegawai sesuai tugas dan fungsi dalam jabatannya (P-7, yang diajukan pula oleh Tergugat sebagai alat bukti).

11. Bahwa pada tanggal **19 Juni 2025** — 24 (dua puluh empat) hari setelah tenggat 26 Mei 2025 — Tergugat menerbitkan Keputusan Menteri Keuangan Nomor 117/MK/SJ.5/2025 (P-8 = T-7), yang **Diktum KESATU**-nya berbunyi: *"memindahkan para pejabat fungsional kategori keterampilan yang namanya sebagaimana tersebut pada lajur 2 dari jabatan dan tempat kedudukan sebagaimana tersebut pada lajur 4 menjadi jabatan dan tempat kedudukan sebagaimana tersebut pada lajur 5 lampiran yang merupakan bagian tidak terpisahkan dari keputusan menteri ini"*, dan **Diktum KEDUA**-nya berbunyi: *"kepada pegawai negeri sipil yang namanya tersebut pada diktum kesatu diberikan tunjangan jabatan fungsional setiap bulan sesuai dengan ketentuan peraturan perundang-undangan yang berlaku"*. Pada lampirannya, nama Penggugat tercantum pada baris ke-23 dengan jabatan dan tempat kedudukan lama *Pranata Komputer Mahir pada Pusat Pendidikan dan Pelatihan Keuangan Umum — Badan Pendidikan dan Pelatihan Keuangan*, dan jabatan serta tempat kedudukan baru *Pranata Komputer Mahir pada Pusat Data dan Informasi — Badan Teknologi, Informasi, dan Intelijen Keuangan*.

12. Bahwa pada tanggal **23 Juni 2025** — 28 (dua puluh delapan) hari setelah tenggat 26 Mei 2025 — Kepala BaTii menerbitkan Keputusan Nomor KEP-2/TI/2025 (P-9 = T-8) yang dalam konsiderans Menimbang huruf b menyatakan pegawai yang namanya tercantum dalam lampiran **"dianggap cakap dan memenuhi syarat untuk ditunjuk/diangkat dalam jabatan"**. Tergugat sendiri, dalam Daftar Buktinya atas bukti T-8, menerangkan bahwa bukti tersebut *"menunjukkan dan membuktikan bahwa Penggugat sebagai salah satu dari pejabat fungsional pranata komputer yang dianggap cakap dan memenuhi syarat untuk ditunjuk/diangkat dalam jabatan pada unit yang ditunjuk"*.

13. Bahwa Penggugat memperoleh Predikat Kinerja Pegawai **"Sangat Baik"** dengan Capaian Kinerja Organisasi **"Istimewa"** pada periode penilaian Triwulan III Tahun 2025 (P-10), yaitu periode terdekat sebelum Objek Sengketa diterbitkan, dan Penggugat tidak pernah dijatuhi hukuman disiplin dalam bentuk apa pun.

14. Bahwa Tergugat membayarkan Tunjangan Kinerja secara penuh kepada Penggugat selaku Pranata Komputer Mahir sekurang-kurangnya hingga Oktober 2025 (P-29).

15. Bahwa pada tanggal **7 November 2025** — enam hari setelah tanggal berlaku surut 1 November 2025 dan enam hari sebelum penetapan Objek Sengketa — Sekretaris BaTii masih menerbitkan Surat Tugas Nomor ST-182/TI.1/2025 yang menugaskan Penggugat mengikuti pelatihan pada tanggal 10 sampai dengan 14 November 2025 dengan pencatatan jabatan **"Prakom Mahir pada Pusat Data dan Informasi"** (P-17).

## C. Proses internal yang mendahului Objek Sengketa

16. Bahwa seluruh proses yang oleh Tergugat disebut sebagai "pemeriksaan" terdiri atas tiga nota dinas antar-unit, yaitu:
    a. **T-9** — Nota Dinas Nomor ND-489/TI.1/2025 tanggal 29 September 2025 hal Permintaan Konfirmasi Status Jabatan Fungsional Pranata Komputer, **dari** Sekretaris BaTii **kepada** Kepala Pusat Data dan Informasi; pada poin ketiganya terdapat frasa *"dalam data monitoring kami"*. Tergugat sendiri menerangkan bukti ini menunjukkan bahwa *"berdasarkan penelusuran yang dilakukan, bahwa Penggugat belum memiliki ijazah D-3, sehingga Sekretaris Badan Teknologi, Informasi, dan Intelijen Keuangan meminta kepada Kepala Pusat Data dan Informasi untuk dapat melakukan konfirmasi mengenai status administrasi Penggugat"*;
    b. **T-10** — Nota Dinas Nomor ND-120/TI.5/2025 tanggal 8 Oktober 2025 hal Penyampaian Usulan Pemberhentian dari Jabatan Fungsional Pranata Komputer di Lingkungan Pusat Data dan Informasi, **dari** Kepala Pusat Data dan Informasi **kepada** Sekretaris BaTii; pada poin ketiganya terdapat frasa *"bahwa berdasarkan penelitian terhadap data pranata komputer di lingkungan Pusat Data dan Informasi"*. Tergugat sendiri menerangkan bukti ini menunjukkan bahwa *"berdasarkan penelitian terhadap data yang dilakukan oleh Pusat Data dan Informasi, diketahui bahwa Penggugat belum memenuhi ketentuan Pasal 59 Permenpan RB Nomor 32 Tahun 2020, sehingga terhadap Penggugat diusulkan untuk diberhentikan"*; dan
    c. **T-11** — Nota Dinas Nomor ND-684/TI.1/2025 tanggal 5 November 2025 hal Permohonan Pemberhentian, **dari** Sekretaris BaTii **kepada** Biro Sumber Daya Manusia; yang juga memuat frasa *"bahwa berdasarkan penelitian terhadap data pranata komputer di lingkungan Pusat Data dan Informasi"*. Tergugat sendiri menerangkan bukti ini menunjukkan bahwa Sekretaris BaTii *"telah menyampaikan nota dinas kepada Biro Sumber Daya Manusia untuk dapat memproses Surat Keputusan Pemberhentian dari Jabatan Fungsional Pranata Komputer atas nama Penggugat"*.

17. Bahwa konsiderans Menimbang huruf c Objek Sengketa hanya menyebut satu dokumen prosedural, yaitu Nota Dinas ND-684/TI.1/2025 (T-11), dan tidak menyebut satu pun dokumen pemeriksaan, pemanggilan, atau klarifikasi terhadap Penggugat.

18. Bahwa ketiadaan tersebut dikuatkan oleh rekam jejak sistem persuratan resmi Tergugat sendiri, yang menunjukkan tidak terdapat satu pun naskah dinas pemberitahuan, pemanggilan, maupun pemeriksaan terhadap Penggugat sebelum Objek Sengketa diterbitkan (P-25).

19. Bahwa terungkap pula dari rekaman dan transkrip pertemuan tanggal 16 Oktober 2025 di BaTii (P-14), yang dihadiri Kepala Bagian SDM, Kepala Subbagian Administrasi Jabatan Fungsional, saksi Riyanto Sihaloho, dan Penggugat, adanya pengakuan pejabat pengelola kepegawaian Tergugat sendiri bahwa pola pemindahan Pranata Komputer ke BaTii yang seolah-olah hanya untuk diberhentikan merupakan **maladministrasi**, serta bahwa opsi penetapan terhitung mulai tanggal yang **tidak surut** tersedia dan telah dibahas secara internal.

## D. Keterangan saksi

20. Bahwa saksi **Riyanto Sihaloho**, yang didengar keterangannya di bawah sumpah pada persidangan tanggal 8 Juli 2026, pada pokoknya menerangkan:
    a. saksi tidak pernah diberitahu mengenai kewajiban memperoleh ijazah Diploma III bidang Teknologi Informasi;
    b. jarak antara pemberitahuan tahun 2023 dan tenggat tahun 2025 adalah 2 (dua) tahun, dan waktu tersebut tidak cukup untuk menyelesaikan pendidikan Diploma III;
    c. saksi **tidak pernah diperiksa** sebelum diberhentikan dari Jabatan Fungsional Pranata Komputer, dan saksi mengetahui bahwa Penggugat pun tidak diperiksa sebelum Objek Sengketa terbit;
    d. saksi diberhentikan melalui keputusan tertanggal **23 Oktober 2025** dengan terhitung mulai tanggal **1 November 2025**;
    e. penghasilan saksi turun sekitar Rp8.000.000,00 setelah diberhentikan sebagai Pranata Komputer;
    f. pada tanggal 16 Oktober 2025 saksi memperoleh ancaman dan intimidasi agar mengembalikan tuntutan ganti rugi, dan saksi menyaksikan Penggugat memperoleh ancaman serupa; atas pertanyaan Majelis Hakim mengenai siapa yang mengancam, saksi menyebut dua nama pejabat;
    g. saksi mendengar pengakuan pejabat pengelola kepegawaian mengenai adanya maladministrasi berkaitan dengan tidak adanya pemberitahuan, keterlambatan eksekusi, dan pemindahan ke BaTii; dan
    h. saksi menyaksikan Penggugat masih bekerja selaku Pranata Komputer setelah Objek Sengketa terbit.

21. Bahwa keterangan saksi pada huruf c, huruf f, dan huruf h bersesuaian dengan bukti surat P-25, P-14, dan P-17, sehingga terdapat persesuaian antar alat bukti sebagaimana dikehendaki hukum pembuktian pada Peradilan Tata Usaha Negara.

---

# III. ANALISIS YURIDIS

Bahwa untuk menilai apakah penerbitan Objek Sengketa telah sesuai dengan peraturan perundang-undangan yang berlaku, batu uji yang dipergunakan adalah Pasal 52 ayat (1) Undang-Undang Nomor 30 Tahun 2014, yang menentukan syarat sahnya Keputusan meliputi ditetapkan oleh pejabat yang berwenang, dibuat sesuai prosedur, dan substansi yang sesuai dengan objek Keputusan — atau dengan kata lain harus terpenuhinya **Aspek Kewenangan, Aspek Prosedur, dan Aspek Substansi secara kumulatif**. Selanjutnya, Pasal 53 ayat (2) huruf b Undang-Undang Peradilan Tata Usaha Negara menempatkan Asas-Asas Umum Pemerintahan yang Baik sebagai tolok ukur yuridis yang berdiri sejajar dengan pengujian terhadap peraturan perundang-undangan.

## A. ASPEK WEWENANG — PREMIS SUBSTANTIF DIBANGUN DI LUAR CAKUPAN BIDANG WEWENANG TERGUGAT

22. Bahwa Penggugat menegaskan tidak mempersoalkan kewenangan atributif Tergugat selaku Pejabat Pembina Kepegawaian untuk **menetapkan** pemberhentian dari jabatan fungsional. Yang Penggugat persoalkan adalah kewenangan atas **materi penilaian** yang dijadikan alasan pemberhentian, yaitu pernyataan pada konsiderans Menimbang huruf a Objek Sengketa bahwa Penggugat *"tidak memenuhi kualifikasi pendidikan yang dipersyaratkan untuk menduduki Jabatan Fungsional Pranata Komputer Mahir sesuai dengan peraturan perundang-undangan terkait Jabatan Fungsional Pranata Komputer"*.

23. Bahwa Tergugat sendiri yang merumuskan norma kualifikasi tersebut sebagai norma yang **belum lengkap tanpa penetapan Instansi Pembina**. Pada Duplik angka 30 Tergugat menyatakan bahwa untuk Jabatan Fungsional Pranata Komputer Mahir harus dimiliki jenjang pendidikan bidang teknologi informasi *"dan kualifikasi pendidikan lainnya yang ditetapkan oleh instansi Pembina"*; dan pada Duplik angka 31 Tergugat menegaskan bahwa *"selama terdapat formasi yang memperbolehkan bagi bidang ilmu lain selain bidang teknologi informasi untuk dapat menduduki suatu jabatan fungsional pranata komputer yang telah ditetapkan oleh instansi Pembina, maka tidak ada larangan bagi rumpun ilmu lain untuk menduduki jabatan fungsional dimaksud."* Rumusan yang sama disampaikan pada Jawaban, bagian Kronologis butir 13 dan bagian aspek kewenangan huruf d.

24. Bahwa Tergugat pula yang mengakui **Badan Pusat Statistik selaku Instansi Pembina** Jabatan Fungsional Pranata Komputer (Jawaban, bagian Kronologis butir 4). Dengan demikian, menurut konstruksi hukum yang dibangun Tergugat sendiri, isi kualifikasi pendidikan yang berlaku bagi Jabatan Fungsional Pranata Komputer ditentukan melalui penetapan Instansi Pembina, bukan melalui pembacaan sepihak unit kepegawaian instansi pengguna.

25. Bahwa mencermati keseluruhan alat bukti yang diajukan di persidangan, baik oleh Penggugat maupun oleh Tergugat, **tidak ditemukan adanya dokumen apa pun yang menunjukkan telah diperolehnya penetapan Instansi Pembina yang menyatakan Penggugat tidak memenuhi kualifikasi pendidikan**. Yang ditemukan justru sebaliknya, yaitu penilaian **"Kompeten"** yang diterbitkan bersama Instansi Pembina atas penugasan Tergugat sendiri (P-4).

26. Bahwa dengan demikian, premis "tidak memenuhi kualifikasi pendidikan" pada konsiderans Menimbang huruf a Objek Sengketa **terbit tidak didasarkan pada informasi dan dokumen yang lengkap untuk mendukung legalitas Keputusan**, khususnya tanpa penetapan dari organ yang oleh Tergugat sendiri diakui berwenang menentukan isi kualifikasi tersebut. Cacat demikian tidak terletak pada ada atau tidaknya kewenangan formal untuk memberhentikan, melainkan pada ketiadaan dasar materiil bagi alasan pemberhentian itu sendiri.

27. Bahwa Undang-Undang Nomor 30 Tahun 2014 telah menyediakan ukuran normatif untuk keadaan demikian. **Pasal 17 ayat (1)** menentukan bahwa Badan dan/atau Pejabat Pemerintahan dilarang menyalahgunakan Wewenang, dan **Pasal 17 ayat (2)** merinci larangan tersebut meliputi larangan melampaui Wewenang, larangan mencampuradukkan Wewenang, dan/atau larangan bertindak sewenang-wenang. Selanjutnya **Pasal 18 ayat (2) huruf a** menentukan bahwa Badan dan/atau Pejabat Pemerintahan dikategorikan **mencampuradukkan Wewenang** apabila Keputusan dan/atau Tindakan yang dilakukan berada *"di luar cakupan bidang atau materi Wewenang yang diberikan"*.

28. Bahwa ukuran normatif tersebut mengenai perkara *a quo* secara tepat. Wewenang yang diberikan kepada Tergugat selaku Pejabat Pembina Kepegawaian adalah wewenang **menetapkan pemberhentian**; sedangkan penetapan mengenai **materi kualifikasi pendidikan** Jabatan Fungsional Pranata Komputer — termasuk kualifikasi pendidikan lainnya yang dapat diterima — berada pada Instansi Pembina, sebagaimana diakui Tergugat sendiri. Dengan menilai sendiri materi yang berada di luar cakupan bidang wewenangnya, tanpa memperoleh penetapan dari Instansi Pembina, Tergugat menempatkan Objek Sengketa pada kategori sebagaimana dimaksud ketentuan tersebut. Penegasan ini Penggugat sampaikan secara terukur dan tanpa menuduh adanya maksud tercela pada diri Tergugat, sebab ketentuan tersebut tidak mensyaratkan adanya itikad buruk; yang diukur adalah **kesesuaian antara materi keputusan dan cakupan bidang wewenang** yang diberikan.

29. Bahwa Penggugat menyadari sepenuhnya bantahan terkuat Tergugat atas dalil ini, sebagaimana dikemukakan pada Jawaban bagian tanggapan atas dalil nondiskriminatif huruf f, yaitu bahwa ruang yang diberikan kepada Instansi Pembina *"murni hanya berlaku untuk fleksibilitas rumpun ilmunya, dan sama sekali tidak memberikan dasar hukum untuk menurunkan batas minimum jenjang strata pendidikan dari D-3 menjadi D-1"*. Terhadap bantahan tersebut Penggugat menjawab secara berlapis sebagaimana angka 30 di bawah ini.

30. Bahwa jawaban Penggugat adalah sebagai berikut:
    a. **Pertama**, Objek Sengketa sendiri tidak membedakan antara strata dan rumpun ilmu; konsiderans Menimbang huruf a hanya menyebut "kualifikasi pendidikan" secara umum. Pembedaan antara syarat strata dan syarat rumpun ilmu adalah konstruksi yang **baru dibangun Tergugat pada tahap Jawaban dan Duplik**, sehingga tidak dapat menjadi acuan untuk membenarkan penerbitan Objek Sengketa *a quo*; suatu keputusan tata usaha negara dinilai dari alasan yang tertuang di dalamnya, bukan dari alasan yang disusun kemudian untuk mempertahankannya di persidangan.
    b. **Kedua**, sepanjang dalih tersebut dibaca sebagai persoalan rumpun ilmu, penilaiannya berada pada Instansi Pembina, dan satu-satunya penilaian Instansi Pembina yang ada dalam berkas justru menyatakan Penggugat "Kompeten" (P-4).
    c. **Ketiga**, sepanjang dalih tersebut dibaca sebagai persoalan strata, Penggugat adalah pemegang kedudukan yang telah diperoleh secara sah (*verkregen recht*) berdasarkan pengangkatan tahun 2009 yang sah menurut peraturan yang berlaku saat itu (P-1). Peraturan Menteri PANRB Nomor 32 Tahun 2020 yang dijadikan dasar substantif oleh Tergugat justru **mempertahankan** kedudukan tersebut melalui Pasal 59 ayat (2), yang menentukan bahwa Pranata Komputer kategori terampil yang belum memperoleh ijazah minimal diploma tiga **tetap melaksanakan tugas jabatan sesuai dengan jenjang jabatannya**.
    d. **Keempat**, Keputusan Menteri PANRB Nomor SKJ.4 Tahun 2024, berdasarkan **Diktum Kesebelas**, mulai berlaku pada tanggal ditetapkan, yaitu 14 Mei 2024, sehingga berlaku **prospektif**. Menjadikannya sumber premis untuk membatalkan kedudukan yang telah diperoleh sejak tahun 2009 tidaklah tepat, sebab tidaklah tepat menghukum seseorang dengan menggunakan dasar hukum yang lahir setelah hubungan hukumnya terbentuk.
    e. **Kelima**, dan yang paling menentukan, kedua peraturan yang menjadi satu-satunya sumber substantif kewajiban kualifikasi — Peraturan Menteri PANRB Nomor 32 Tahun 2020 dan Keputusan Menteri PANRB Nomor SKJ.4 Tahun 2024 — **tidak dicantumkan sama sekali** dalam konsiderans Mengingat Objek Sengketa. Ketiadaan ini diakui sendiri oleh Tergugat (Duplik angka 48 sampai dengan angka 51). Dengan demikian, premis strata yang kini dipertahankan Tergugat di persidangan tidak memiliki pijakan tekstual apa pun di dalam Keputusan yang sedang diuji.

31. Bahwa berdasarkan angka 22 sampai dengan angka 30, Penggugat berkesimpulan konsiderans Menimbang huruf a Objek Sengketa dibangun tanpa penetapan organ yang berwenang atas materi yang dinilainya, sehingga **Aspek Kewenangan sebagaimana dimaksud Pasal 52 ayat (1) huruf a Undang-Undang Nomor 30 Tahun 2014 tidak terpenuhi**, dan Objek Sengketa bertentangan dengan Pasal 17 ayat (2) huruf b *juncto* Pasal 18 ayat (2) huruf a undang-undang yang sama. Cacat ini melekat pada premisnya, sehingga tidak dapat dipulihkan dengan menambah dasar hukum pada konsiderans Mengingat maupun dengan menempuh formalitas pemeriksaan di kemudian hari, sepanjang penilaian atas kualifikasi tetap berada pada Instansi Pembina.

## B. ASPEK PROSEDUR — TIDAK ADA PEMERIKSAAN TERHADAP PENGGUGAT SEBELUM PEMBERHENTIAN

### B.1. Norma yang dilanggar

32. Bahwa **Pasal 41 ayat (5) Peraturan Menteri PANRB Nomor 1 Tahun 2023** menentukan secara imperatif: *"Pejabat Fungsional sebagaimana dimaksud pada ayat (1) huruf a dan huruf f harus diperiksa terlebih dahulu dan mendapatkan izin dari PyB sebelum ditetapkan pemberhentiannya."*

33. Bahwa Tergugat sendiri yang menempatkan perkara *a quo* di bawah **Pasal 41 ayat (1) huruf f** *juncto* Pasal 43 huruf b peraturan yang sama (Jawaban, bagian aspek kewenangan huruf c; Duplik angka 23 huruf a). Dengan memilih dasar huruf f, Tergugat justru **mengaktifkan** kewajiban pemeriksaan pada ayat (5), bukan mengecualikannya. Tergugat bahkan mengakui secara tegas bahwa Pasal 41 ayat (5) *"masih memiliki korelasi dengan ketentuan Pasal 43 huruf b"* (Duplik angka 23 huruf a).

34. Bahwa kewajiban tersebut bukan kewajiban yang berdiri sendiri, melainkan penjabaran dari kewajiban universal terhadap setiap Keputusan yang membebani, yaitu **Pasal 7 ayat (2) huruf f** Undang-Undang Nomor 30 Tahun 2014 — *"Pejabat Pemerintahan wajib memberikan kesempatan kepada Warga Masyarakat untuk didengar pendapatnya sebelum membuat Keputusan dan/atau Tindakan yang membebani"* — dan **Pasal 47** undang-undang yang sama, yang mewajibkan pemberitahuan paling lama 10 (sepuluh) hari kerja sebelum Keputusan yang menimbulkan pembebanan ditetapkan.

### B.2. Fakta: tidak ditemukan satu pun dokumen pemeriksaan

35. Bahwa mencermati keseluruhan alat bukti yang diajukan di persidangan, **tidak ditemukan adanya dokumen yang menunjukkan telah dilakukannya pemeriksaan terhadap Penggugat, klarifikasi kepada Penggugat, ataupun pemberian kesempatan bagi Penggugat untuk memberikan penjelasan sebelum diterbitkannya keputusan pemberhentian dimaksud**. Tidak terdapat surat panggilan, tidak pernah dibentuk tim pemeriksa secara resmi yang diberi mandat untuk menilai keadaan Penggugat, tidak dibuatkan berita acara maupun notulensi yang mencatat jalannya suatu pemeriksaan, tidak terdapat daftar hadir, dan tidak pula dihasilkan kesimpulan atau rekomendasi hasil pemeriksaan yang dapat dijadikan dasar administratif bagi pengambilan keputusan oleh pejabat yang berwenang.

36. Bahwa sifat pembuktian atas ketiadaan tersebut sangat kuat, karena bersumber dari **dokumen Tergugat sendiri**: konsiderans Menimbang Objek Sengketa hanya menyebut Nota Dinas ND-684/TI.1/2025 (T-11); rekam jejak sistem persuratan resmi Tergugat tidak memuat satu pun naskah dinas pemanggilan, pemberitahuan, atau pemeriksaan kepada Penggugat (P-25); dan keterangan saksi di bawah sumpah pada persidangan 8 Juli 2026 menegaskan hal yang sama.

### B.3. Benturan langsung dengan T-9, T-10, dan T-11

37. Bahwa justru ketiga alat bukti yang diandalkan Tergugat sebagai bukti telah dilakukannya "pemeriksaan" — T-9, T-10, dan T-11 — apabila dibaca menurut bunyinya sendiri, membuktikan hal yang sebaliknya. Ketiganya adalah **korespondensi antar-pejabat mengenai data kepegawaian**, dan tidak satu pun ditujukan kepada Penggugat.

38. Bahwa **T-9** adalah nota dinas **dari Sekretaris BaTii kepada Kepala Pusat Data dan Informasi**, yang pada poin ketiganya memakai frasa *"dalam data monitoring kami"*. Kata "monitoring" dan kata "data" menunjuk pada kegiatan pemantauan basis data kepegawaian, bukan pada pemeriksaan terhadap seseorang. Tergugat sendiri menerangkan bahwa melalui nota dinas itu Sekretaris BaTii *"meminta kepada Kepala Pusat Data dan Informasi untuk dapat melakukan konfirmasi mengenai status administrasi Penggugat"* — sehingga yang diminta konfirmasinya adalah **status administrasi**, dan yang dimintai konfirmasi adalah **kepala unit**, bukan Penggugat.

39. Bahwa **T-10** adalah jawaban **dari Kepala Pusat Data dan Informasi kepada Sekretaris BaTii**, yang pada poin ketiganya berbunyi *"bahwa berdasarkan penelitian terhadap data pranata komputer di lingkungan Pusat Data dan Informasi"*. Frasa yang dipilih Tergugat sendiri itu menunjuk pada **penelitian terhadap data**, bukan pemeriksaan terhadap orang. Frasa yang sama diulang Tergugat dalam Jawaban, bagian Kronologis butir 20, dan dalam keterangan atas buktinya sendiri.

40. Bahwa **T-11** mengulang frasa yang sama, *"bahwa berdasarkan penelitian terhadap data pranata komputer di lingkungan Pusat Data dan Informasi"*, dan ditujukan **kepada Biro Sumber Daya Manusia** untuk memproses penerbitan surat keputusan pemberhentian. Pada titik ini keputusan untuk memberhentikan telah terbentuk sepenuhnya, tanpa Penggugat pernah dilibatkan pada satu tahap pun.

41. Bahwa dengan demikian, rangkaian T-9 → T-10 → T-11 adalah rangkaian tertutup antar-unit yang bermula dari pemantauan basis data dan berakhir pada permohonan penerbitan surat keputusan. Ketiganya sama-sama tidak memuat satu kalimat pun mengenai pemanggilan Penggugat, permintaan penjelasan kepada Penggugat, atau pemberian kesempatan kepada Penggugat untuk membela diri. Keadaan demikian menunjukkan Tergugat dalam menerbitkan Objek Sengketa **semata-mata mendasarkan tindakannya pada nota dinas internal, tanpa didahului oleh suatu prosedur pemeriksaan formal terhadap Penggugat**, yang mana hal demikian menimbulkan ketidakpastian atau ambiguitas bagi subjek hukum yang dikenai keputusan.

42. Bahwa perlu Penggugat garis bawahi, dua di antara tiga frasa tersebut — *"dalam data monitoring kami"* dan *"berdasarkan penelitian terhadap data pranata komputer di lingkungan Pusat Data dan Informasi"* — adalah rumusan yang **dipilih dan dituliskan sendiri oleh Tergugat**. Tergugat tidak dapat menuliskan bahwa dasar tindakannya adalah pemantauan dan penelitian **data**, lalu di persidangan mendalilkan bahwa yang dilakukannya adalah "pemeriksaan" terhadap Penggugat dalam pengertian Pasal 41 ayat (5).

43. Bahwa terhadap dalil Tergugat bahwa "verifikasi administratif" telah memadai sebagai pemeriksaan (Duplik angka 23 huruf e sampai dengan huruf k), Penggugat menyampaikan bahwa norma Pasal 41 ayat (5) menentukan **objek** pemeriksaannya secara tegas, yaitu *"Pejabat Fungsional ... harus diperiksa"*. Norma itu meletakkan objek pemeriksaan pada **orang**, bukan pada berkas. Verifikasi data sepihak tanpa melibatkan pihak yang akan dikenai keputusan tidak dapat memenuhi norma tersebut, terlebih ketika undang-undang secara terpisah mewajibkan pemberian kesempatan untuk didengar dan pemberitahuan sebelum keputusan yang membebani ditetapkan.

44. Bahwa dalil Tergugat mengenai sosialisasi tahun 2020 (T-1 dan T-2) dan Nota Pemberitahuan tahun 2023 (T-4 dan T-5) juga tidak memenuhi pengertian pemeriksaan. Keduanya bersifat **normatif-informatif**, yaitu pemberitahuan tentang berlakunya suatu norma kepada khalayak pejabat fungsional, sedangkan yang diwajibkan Pasal 41 ayat (5) bersifat **prosedural-protektif**, yaitu perlindungan hak seseorang yang akan dikenai tindakan administratif yang merugikan. Keduanya pun tidak memenuhi syarat kesegeraan sebagaimana dikehendaki Pasal 47 Undang-Undang Nomor 30 Tahun 2014: sosialisasi tahun 2020 berjarak lebih dari 5 (lima) tahun, dan Nota Pemberitahuan tanggal 14 April 2023 berjarak 2 (dua) tahun 7 (tujuh) bulan, dari penetapan Objek Sengketa.

45. Bahwa terdapat pula pertentangan internal dalam pembelaan Tergugat yang dengan hormat perlu Penggugat sampaikan. Pada bagian Asas Tidak Menyalahgunakan Wewenang dalam Jawaban, Tergugat menyatakan penerbitan Objek Sengketa *"telah melalui serangkaian prosedur dan pemeriksaan sesuai dengan kewenangan yang dimiliki oleh Pejabat berwenang"*; namun pada bagian bantahan atas Pasal 41 ayat (5), Tergugat menyatakan yang dilakukan hanyalah verifikasi administratif dan bahwa pemeriksaan terhadap orang *"menjadi tidak relevan"*. Apabila benar telah dilakukan pemeriksaan, dokumen pemeriksaannya semestinya dapat ditunjukkan; ketiadaannya justru menegaskan tidak terpenuhinya Pasal 41 ayat (5).

46. Bahwa seharusnya Tergugat mempertimbangkan semua faktor dan keadaan yang berkaitan dengan materi keputusan yang akan diterbitkannya, yaitu dengan memanggil Penggugat untuk didengar alasan-alasannya, supaya penjatuhan dan penyampaian Keputusan Tata Usaha Negara tersebut tidak merugikan Penggugat. Terlebih, apabila hal itu dilakukan, Tergugat akan mengetahui bahwa unitnya sendiri telah menerbitkan Surat Tugas Belajar Mandiri bagi Penggugat (P-7) — suatu fakta yang, apabila dipertimbangkan, dapat mengubah keputusan yang diambil.

47. Bahwa hilangnya kesempatan Penggugat untuk mengajukan pembelaan diri (*right of self defense*) merupakan kekurangan yang sangat berat. Prinsip kehati-hatian (*prudence*) dan asas *due process of law* menghendaki agar setiap keputusan tata usaha negara yang berdampak pada hak dan status seseorang didasarkan pada proses pembuktian yang cermat, menyeluruh, dan adil.

48. Bahwa berdasarkan angka 32 sampai dengan angka 47, Penggugat berkesimpulan Tergugat telah melanggar Pasal 41 ayat (5) Peraturan Menteri PANRB Nomor 1 Tahun 2023 *juncto* Pasal 7 ayat (2) huruf f dan Pasal 47 Undang-Undang Nomor 30 Tahun 2014, serta melanggar Asas-Asas Umum Pemerintahan yang Baik khususnya **asas *audi et alteram partem***, yang pada intinya menghendaki agar sebelum mengambil keputusan pejabat pemerintahan mendengarkan keterangan pihak yang bersangkutan sehingga tidak mengabaikan prinsip keadilan dan kehati-hatian dalam bertindak, dan **asas kecermatan**, yang menghendaki agar administrasi bertindak cermat dalam menyelenggarakan tugas-tugas pemerintahan sehingga tidak menimbulkan kerugian bagi warga negara. Dengan demikian **Aspek Prosedur sebagaimana dimaksud Pasal 52 ayat (1) huruf b Undang-Undang Nomor 30 Tahun 2014 tidak terpenuhi**.

## C. ASPEK SUBSTANSI DAN ASAS-ASAS UMUM PEMERINTAHAN YANG BAIK

### C.1. Asas pemberian harapan yang wajar

49. Bahwa terdapat rangkaian tindakan resmi Tergugat sendiri yang berkesinambungan dan tidak terputus, yang secara kumulatif menimbulkan harapan yang wajar pada diri Penggugat bahwa kedudukannya selaku Pranata Komputer Mahir sah dan diakui, yaitu P-3, P-4, P-6, P-7, P-8, P-9, P-10, P-29, dan P-17.

50. Bahwa **dua** di antaranya diterbitkan **setelah** tenggat 26 Mei 2025 yang didalilkan Tergugat sendiri sebagai batas pemenuhan kualifikasi, dan keduanya bukan pencatatan administratif yang netral.

51. Bahwa yang **pertama**, Keputusan Menteri Keuangan Nomor 117/MK/SJ.5/2025 tanggal 19 Juni 2025 (P-8 = T-7), tidak sekadar memindahkan Penggugat. **Diktum KEDUA** keputusan tersebut secara tegas menyatakan: *"kepada pegawai negeri sipil yang namanya tersebut pada diktum kesatu diberikan tunjangan jabatan fungsional setiap bulan sesuai dengan ketentuan peraturan perundang-undangan yang berlaku"*, sementara lampirannya pada baris ke-23 mencantumkan nama Penggugat dengan jabatan dan tempat kedudukan baru **Pranata Komputer Mahir pada Pusat Data dan Informasi — Badan Teknologi, Informasi, dan Intelijen Keuangan**. Dengan keputusan tingkat Menteri tertanggal 19 Juni 2025 itu, Tergugat tidak hanya menempatkan Penggugat dalam jabatan fungsional setelah tenggat, tetapi juga **memerintahkan pembayaran tunjangan jabatan fungsional setiap bulan** kepadanya. Suatu tunjangan jabatan fungsional tidak diperintahkan pembayarannya kepada pegawai yang dipandang tidak memenuhi syarat jabatan tersebut.

52. Bahwa yang **kedua**, Keputusan Kepala BaTii Nomor KEP-2/TI/2025 tanggal 23 Juni 2025 (P-9 = T-8), dalam konsiderans Menimbang huruf b menyatakan Penggugat **"dianggap cakap dan memenuhi syarat untuk ditunjuk/diangkat dalam jabatan"**. Yang menentukan, Tergugat sendiri dalam Daftar Buktinya mengulang dan meneguhkan frasa tersebut, dengan menerangkan bahwa T-8 *"menunjukkan dan membuktikan bahwa Penggugat sebagai salah satu dari pejabat fungsional pranata komputer yang dianggap cakap dan memenuhi syarat untuk ditunjuk/diangkat dalam jabatan pada unit yang ditunjuk"*.

53. Bahwa lebih jauh, dalam keterangan atas buktinya sendiri pada **T-9**, Tergugat menyatakan bahwa frasa *"dianggap cakap dan memenuhi syarat untuk diangkat"* itu *"merupakan penilaian substantif mengenai kelayakan seseorang untuk menduduki jabatan tertentu"*. Dengan pengakuan tersebut, Tergugat tidak lagi dapat mengecilkan frasa itu menjadi formalitas administratif belaka: menurut rumusan Tergugat sendiri, yang diberikan kepada Penggugat pada 23 Juni 2025 adalah **penilaian substantif mengenai kelayakan**.

54. Bahwa dalih Tergugat bahwa kedua keputusan itu semata-mata merupakan produk pemindahan kelembagaan akibat penataan organisasi (Jawaban, bagian tanggapan angka 3 huruf c dan huruf o) karenanya tidak dapat diterima, dan tidak menjelaskan **mengapa Tergugat memilih rumusan kelayakan substantif dan memerintahkan pemberian tunjangan jabatan fungsional**. Suatu pemindahan kelembagaan yang murni mekanis tidak menuntut pernyataan afirmatif "cakap dan memenuhi syarat", tidak menuntut penegasan pemberian tunjangan jabatan fungsional setiap bulan, dan tidak akan diterangkan sendiri oleh penerbitnya sebagai "penilaian substantif mengenai kelayakan".

55. Bahwa Tergugat tidak menunjukkan **satu pun peristiwa hukum baru** yang terjadi antara tanggal 23 Juni 2025 dan tanggal 13 November 2025 yang dapat menjelaskan berubahnya kualifikasi Penggugat. Yang berubah dalam rentang itu bukanlah keadaan Penggugat, melainkan sikap administratif Tergugat. Sebaliknya, dalam rentang yang sama Tergugat justru terus membayarkan tunjangan kinerja secara penuh (P-29), memberikan Predikat Kinerja "Sangat Baik" (P-10), dan pada 7 November 2025 masih menugaskan Penggugat sebagai "Prakom Mahir" (P-17).

56. Bahwa dari fakta-fakta hukum tersebut dapat disimpulkan tindakan Tergugat telah melanggar Asas-Asas Umum Pemerintahan yang Baik khususnya **asas pemberian harapan yang wajar**, di samping **asas kepastian hukum** sebagaimana Pasal 2 huruf a Undang-Undang Nomor 20 Tahun 2023 dan Pasal 10 ayat (1) huruf a Undang-Undang Nomor 30 Tahun 2014 — asas yang menuntut agar setiap tindakan pemerintahan didasarkan pada landasan peraturan perundang-undangan, kepatutan, keajegan, dan keadilan dalam setiap kebijakan penyelenggaraan pemerintahan.

### C.2. Larangan keberlakuan surut

57. Bahwa **Diktum KELIMA** Objek Sengketa berbunyi: *"Keputusan Menteri ini mulai berlaku pada tanggal ditetapkan dan berlaku surut sejak 1 November 2025."* Rumusan itu dipilih dan dituliskan sendiri oleh Tergugat dalam dokumennya sendiri, sehingga pelabelan ulang menjadi "tanggal efektif administratif" pada tahap Jawaban dan Duplik tidak menghapus makna yuridis kata yang dipilih Tergugat.

58. Bahwa **Pasal 58 ayat (6) Undang-Undang Nomor 30 Tahun 2014** menentukan: *"Keputusan tidak dapat berlaku surut, kecuali untuk menghindari kerugian yang lebih besar dan/atau terabaikannya hak Warga Masyarakat."* Pengecualian tersebut bersifat limitatif, dan tidak satu pun di antaranya terpenuhi dalam perkara *a quo*.

59. Bahwa Tergugat menerbitkan Objek Sengketa yang **diberlakukan surut terhitung mulai tanggal 1 November 2025**, semata-mata untuk menyesuaikan pencatatan administratif, **tanpa mempertimbangkan akibat hukum atas hasil pelaksanaan tugas dan hak-hak yang telah Penggugat lakukan dan terima** dalam kurun waktu 1 November 2025 sampai dengan 13 November 2025, yaitu tanggal penerbitan keputusan itu sendiri.

60. Bahwa akibat merugikan tersebut nyata-nyata telah dieksekusi: tunjangan kinerja bulan November 2025 yang sah diterima Penggugat ditarik kembali sebesar Rp1.500.000,00 melalui Sistem Informasi PNBP Online dalam 10 (sepuluh) cicilan (P-19), di samping pemotongan retroaktif selisih tunjangan periode November 2025 sampai dengan Januari 2026 sebesar Rp795.000,00. Besaran dan keberlanjutan kerugian tersebut terukur secara otentik dari rekening koran pembanding periode Agustus 2025 (P-29) dan Februari 2026 (P-30) serta perhitungan kerugian materiil (P-31).

61. Bahwa Tergugat sendiri merumuskan tolok ukur keberlakuan tanggal efektif yang sah, yaitu sepanjang tidak menghilangkan hak yang telah sah diperoleh sebelumnya, tidak menimbulkan sanksi terhadap perbuatan masa lampau, dan tidak menimbulkan kerugian hukum yang bertentangan dengan asas kepastian hukum (Jawaban, bagian tanggapan angka 1 huruf i). Diukur dengan **tolok ukur Tergugat sendiri**, penarikan kembali tunjangan kinerja yang telah sah diterima adalah peniadaan hak yang telah diperoleh, sehingga Objek Sengketa gagal memenuhi tolok ukurnya sendiri.

62. Bahwa Tergugat pula yang menegaskan larangan retroaktif ditujukan terhadap pemberian akibat hukum yang merugikan atas peristiwa yang **telah selesai** (Duplik angka 6). Justru di titik inilah dalil Tergugat berbalik: P-17 membuktikan bahwa pada 7 November 2025 status Penggugat selaku Pranata Komputer Mahir masih melekat dan masih dijalankan, sehingga peristiwa yang di-surut-kan **belum selesai**; sedangkan P-19 membuktikan akibat hukum yang ditimbulkan **merugikan**. Kedua unsur yang Tergugat sendiri akui terlarang terpenuhi secara bersamaan.

63. Bahwa norma yang dijadikan dasar substantif oleh Tergugat pun tidak mengenal pemberhentian secara surut: Pasal 59 ayat (4) Peraturan Menteri PANRB Nomor 32 Tahun 2020 memerintahkan pemberhentian sebagai akibat hukum ke depan, bukan penarikan mundur status yang telah dijalankan.

64. Bahwa dengan demikian, penerbitan Objek Sengketa tidak sesuai dengan unsur proporsional dan keadilan, dan tidak pula sesuai dengan Asas-Asas Umum Pemerintahan yang Baik yakni **asas kecermatan** dan **asas kepastian hukum**, khususnya ketika Tergugat **memberlakukan mundur tanggal penerbitan Objek Sengketa *a quo***.

### C.3. Asas nondiskriminatif serta asas keadilan dan kesetaraan

65. Bahwa sumbu utama dalil ini adalah **perbedaan perlakuan**, bukan perbandingan bidang ilmu. Terungkap di persidangan bahwa Keputusan Menteri Keuangan Nomor 188/MK/SJ.5/2025 atas nama Sdr. Riyanto Sihaloho dan Sdr. Agus Riyanto — dengan alasan pemberhentian yang **sama**, yaitu tidak memenuhi kualifikasi pendidikan (diakui Tergugat dalam Jawaban, bagian tanggapan angka 1 huruf e), pada **periode yang sama**, dan terhadap Pejabat Fungsional dalam **kategori keterampilan yang sama** — ditetapkan pada tanggal 23 Oktober 2025 dengan terhitung mulai tanggal 1 November 2025, yaitu penetapan **mendahului** keberlakuan (P-15 dan P-16). Fakta ini dikuatkan keterangan saksi Riyanto Sihaloho di bawah sumpah.

66. Bahwa sebaliknya, terhadap Penggugat, keputusan ditetapkan pada tanggal 13 November 2025 dengan diberlakukan **surut** sejak 1 November 2025. Akibat hukum dari perbedaan penanggalan tersebut tidaklah netral: pembanding tidak memiliki rentang waktu yang di-surut-kan, sehingga tidak menghadapi penarikan kembali penghasilan atas masa yang telah dijalani; sedangkan terhadap Penggugat penarikan kembali telah nyata dieksekusi (P-19).

67. Bahwa keadaan Penggugat dan pembanding pada pokoknya sama, yaitu sama-sama Pejabat Fungsional Pranata Komputer kategori keterampilan yang diberhentikan dengan alasan yang sama pada periode yang sama; namun hanya terhadap Penggugat diberlakukan pola surut, sedangkan terhadap pembanding tidak. Dalam perspektif Asas-Asas Umum Pemerintahan yang Baik, tindakan Tergugat yang hanya memberlakukan surut terhadap Penggugat melanggar **asas persamaan**, dan bertentangan dengan **asas nondiskriminatif** serta **asas keadilan dan kesetaraan** sebagaimana Pasal 2 huruf j dan huruf l Undang-Undang Nomor 20 Tahun 2023.

68. Bahwa fakta pembanding tersebut sekaligus mematahkan dalih bahwa keberlakuan surut merupakan keniscayaan administratif. Tergugat terbukti **mampu dan biasa** menerbitkan keputusan secara prospektif untuk perkara sejenis pada periode yang sama. Hal ini bersesuaian dengan pengakuan pejabat pengelola kepegawaian Tergugat dalam pertemuan 16 Oktober 2025 bahwa opsi penetapan yang tidak surut tersedia dan telah dibahas secara internal (P-14). Apabila opsi tidak-surut tersedia, maka keberlakuan surut adalah **pilihan**, bukan keharusan.

69. Bahwa terhadap dalil Tergugat bahwa setiap keputusan dinilai menurut keadaan konkret masing-masing pegawai (Duplik angka 14, angka 34 sampai dengan angka 36), Penggugat menyampaikan dengan hormat bahwa Tergugat **tidak menunjukkan satu pun pembeda keadaan yang relevan** antara Penggugat dan pembanding, selain pilihan tanggal penetapan itu sendiri. Menjadikan keterlambatan penetapan sebagai pembeda berarti membebankan akibat keterlambatan kepada pihak yang dikenai keputusan, dan bertentangan dengan asas bahwa tidak seorang pun boleh memperoleh keuntungan dari kelalaiannya sendiri (*nullus commodum capere potest de injuria sua propria*).

70. Bahwa adapun pelantikan pegawai berlatar belakang pendidikan non-Teknologi Informasi dalam Jabatan Fungsional Pranata Komputer pada tanggal 10 Februari 2026 (P-26), Penggugat sampaikan sebagai penguat sekunder atas inkonsistensi penerapan parameter bidang ilmu, sejalan dengan pengakuan Tergugat pada Duplik angka 31.

### C.4. Asas motivering, asas kecermatan, dan asas kepastian hukum

71. Bahwa asas motivering mewajibkan setiap Badan dan/atau Pejabat Pemerintahan mencantumkan alasan atau pertimbangan yang jelas, rasional, dan dapat dipertanggungjawabkan dalam setiap keputusan yang diterbitkannya. Asas ini menuntut agar suatu keputusan tidak lahir secara sewenang-wenang (*willekeur*), melainkan didasarkan pada argumentasi hukum dan fakta yang relevan sehingga dapat diuji kebenarannya baik secara administratif maupun yudisial. Motivasi tersebut harus menunjukkan dasar hukum yang melandasi kewenangan dan tindakan, fakta-fakta relevan yang menjadi pertimbangan, serta pertautan logis antara fakta dan norma yang menghasilkan keputusan.

72. Bahwa pemberian alasan atau pertimbangan berdasarkan fakta yang benar dan lengkap dalam suatu Keputusan Tata Usaha Negara penting artinya agar dapat diketahui terutama oleh pihak yang merasa kepentingannya dirugikan dan hendak mengajukan keberatan atas Keputusan tersebut.

73. Bahwa konsiderans **Mengingat** Objek Sengketa hanya memuat 5 (lima) dasar hukum, yaitu Undang-Undang Nomor 20 Tahun 2023; Peraturan Pemerintah Nomor 11 Tahun 2017 sebagaimana telah diubah dengan Peraturan Pemerintah Nomor 17 Tahun 2020; Peraturan Menteri PANRB Nomor 1 Tahun 2023; Peraturan Menteri Keuangan Nomor 224/PMK.01/2020; dan Keputusan Menteri Keuangan Nomor 74/KMK.01/2012 sebagaimana telah diubah dengan Keputusan Menteri Keuangan Nomor 404/KMK.01/2013. **Tidak satu pun** di antaranya memuat kewajiban substantif memiliki ijazah Diploma III bidang Teknologi Informasi bagi Pranata Komputer kategori keterampilan yang telah menjabat.

74. Bahwa pada bagian "Mengingat" Objek Sengketa tidak dicantumkan Peraturan Menteri PANRB Nomor 32 Tahun 2020 maupun Keputusan Menteri PANRB Nomor SKJ.4 Tahun 2024, padahal Tergugat mendalilkan dalam Jawaban dan Dupliknya bahwa justru kedua peraturan itulah sumber kewajiban kualifikasi yang tidak dipenuhi Penggugat. Dengan demikian, dalih substantif Tergugat **tidak dapat ditelusuri ke peraturan apa pun** yang dirujuk dalam Keputusan yang sedang diuji, sehingga Objek Sengketa bertentangan dengan **asas pemberian dasar pertimbangan/alasan yang cukup dan mendukung (asas motivering)**, **asas kecermatan formal**, dan Pasal 9 ayat (1) Undang-Undang Nomor 30 Tahun 2014.

75. Bahwa terdapat pula ketidakselarasan antara alasan yang tertuang dalam Objek Sengketa dan alasan yang dikemukakan Tergugat di persidangan. Dalam konsiderans Menimbang huruf a disebut alasan "tidak memenuhi kualifikasi pendidikan" tanpa perincian; dalam Jawaban, alasan tersebut diuraikan sebagai kegagalan memenuhi **strata** Diploma III; sementara dalam bagian Asas Keadilan dan Asas Kemanfaatan pada Jawaban yang sama, Tergugat berulang kali mengkualifikasikan keadaan Penggugat sebagai **"pelanggaran disiplin"**, padahal pada bagian lain Tergugat menegaskan Objek Sengketa *"bukan merupakan hukuman disiplin, melainkan tindak lanjut administratif"*. Perbedaan dan ketidakselarasan alasan tersebut menunjukkan adanya inkonsistensi dalam konstruksi pertimbangan yang melatarbelakangi penerbitan keputusan *a quo*, yang pada akhirnya menimbulkan ketidakpastian mengenai motif administratif yang sebenarnya.

76. Bahwa ketidakselarasan itu diperkuat oleh dicantumkannya Peraturan Pemerintah Nomor 94 Tahun 2021 tentang Disiplin Pegawai Negeri Sipil sebagai salah satu pedoman penerbitan Objek Sengketa dalam Jawaban (bagian aspek prosedur huruf b), padahal peraturan tersebut sama sekali tidak tercantum dalam konsiderans Mengingat Objek Sengketa. Keadaan ini menimbulkan dilema bagi Tergugat: apabila Objek Sengketa benar berkarakter disiplin, maka seluruh tata cara pemeriksaan dan pembelaan dalam rezim disiplin wajib ditempuh dan nyata-nyata tidak ditempuh; apabila tidak berkarakter disiplin, maka pembelaan Asas Keadilan dan Asas Kemanfaatan Tergugat runtuh karena dibangun di atas premis "pelanggaran disiplin" yang sesungguhnya tidak ada.

77. Bahwa Penggugat mencatat pula, dalam keterangan atas buktinya sendiri pada T-9 Tergugat menyebut Peraturan Menteri PANRB Nomor 32 Tahun 2020 *"ditetapkan pada tanggal 26 Mei 2020"*, sementara dalam Jawaban bagian Kronologis butir 5 Tergugat menyebut peraturan yang sama *"telah diundangkan pada tanggal 27 Mei 2020"*. Hal ini Penggugat sampaikan sebagaimana adanya, tanpa maksud membesar-besarkan, semata-mata karena tanggal tersebutlah yang dijadikan Tergugat sebagai titik hitung tenggat 26 Mei 2025 dan sekaligus sebagai titik hitung ancaman tuntutan ganti rugi terhadap Penggugat.

78. Bahwa dalil Tergugat bahwa penambahan Peraturan Menteri PANRB Nomor 32 Tahun 2020 dan Keputusan Menteri PANRB Nomor SKJ.4 Tahun 2024 pada Keputusan Menteri Keuangan Nomor 9/MK/SJ/2026 merupakan "klarifikasi dan penguatan" (Duplik angka 56 sampai dengan angka 58) justru memperkuat dalil Penggugat. Perilaku menambahkan itulah yang memperlihatkan bahwa kedua peraturan tersebut memang pokok dan relevan, sehingga ketiadaannya pada Objek Sengketa menunjukkan ketidakcermatan yang melekat sejak Keputusan itu diterbitkan. Terlebih, keputusan penguatan tersebut **bukan Objek Sengketa** dalam perkara ini, dan bukan pula keputusan baru yang menerbitkan ulang pemberhentian dengan dasar hukum yang berbeda; ia hanya menegaskan penolakan keberatan. Suatu dokumen yang disusun setelah diterbitkannya keputusan yang diuji tidak dapat menjadi acuan untuk membenarkan penerbitan keputusan tersebut.

### C.5. Ancaman tuntutan ganti rugi — dihitung dari tenggat 26 Mei 2025 maupun dari 14 Mei 2024

79. Bahwa terungkap di persidangan melalui keterangan saksi di bawah sumpah, dan dikuatkan rekaman serta transkrip pertemuan tanggal 16 Oktober 2025 (P-14), bahwa Penggugat bersama rekan Pejabat Fungsional Pranata Komputer menerima ancaman dan intimidasi lisan berkaitan dengan **tuntutan ganti rugi** atas penghasilan yang telah diterima. Atas pertanyaan Majelis Hakim, saksi menyebut dua nama pejabat, dan menerangkan bahwa ia menyaksikan sendiri Penggugat memperoleh ancaman serupa.

80. Bahwa ancaman tersebut dihitung dari lewatnya tenggat yang didalilkan Tergugat, yaitu 26 Mei 2025, dan bahkan dari berlakunya Keputusan Menteri PANRB Nomor SKJ.4 Tahun 2024 pada 14 Mei 2024. Kedua titik hitung tersebut sama-sama tidak dapat dibenarkan menurut hukum, dengan alasan sebagai berikut.

81. Bahwa **pertama**, tuntutan ganti rugi mensyaratkan adanya perbuatan melawan hukum atau kelalaian. Peraturan Pemerintah Nomor 38 Tahun 2016 Pasal 1 angka 1 menentukan bahwa Kerugian Negara/Daerah adalah *"kekurangan uang, surat berharga, dan barang, yang nyata dan pasti jumlahnya sebagai akibat perbuatan melawan hukum baik sengaja maupun lalai"*. Sejalan dengan itu, Peraturan Menteri Keuangan Nomor 218/PMK.01/2017 pada Lampirannya Bab I huruf B menentukan bahwa yang diwajibkan mengganti Kerugian Negara adalah Pegawai Negeri Bukan Bendahara *"yang melanggar hukum atau melalaikan kewajibannya baik langsung atau tidak langsung merugikan keuangan negara"*. Kedua peraturan itulah yang justru dirujuk sendiri oleh Tergugat sebagai dasar tuntutan pengembalian (Jawaban, bagian tanggapan angka 1 huruf k).

82. Bahwa belum memiliki ijazah Diploma III bukanlah perbuatan melawan hukum, dan bukan pula kelalaian dalam pengertian ketentuan tersebut — terlebih ketika Tergugat sendiri melalui unitnya telah memproses permohonan izin belajar Penggugat pada 16 Mei 2025 (P-6 = T-6) dan menerbitkan Surat Tugas Belajar Mandiri pada 10 Juni 2025 (P-7) justru untuk memenuhi kualifikasi yang dipersoalkan itu. Tidak terdapat satu pun penetapan tuntutan ganti rugi yang sah dalam berkas perkara; yang ada hanyalah ancaman yang disampaikan secara lisan.

83. Bahwa **kedua**, sepanjang periode yang dijadikan titik hitung ancaman tersebut, kedudukan Penggugat selaku Pranata Komputer Mahir adalah **sah menurut keputusan Tergugat sendiri**. Pada 19 Juni 2025 Tergugat justru menerbitkan keputusan tingkat Menteri yang menempatkan Penggugat dalam jabatan itu dan **memerintahkan pemberian tunjangan jabatan fungsional setiap bulan** kepadanya (P-8 = T-7, Diktum KEDUA); pada 23 Juni 2025 Tergugat menyatakan Penggugat "cakap dan memenuhi syarat" (P-9 = T-8); Tergugat membayarkan tunjangan kinerja secara penuh sekurang-kurangnya sampai Oktober 2025 (P-29); menilai kinerja Penggugat "Sangat Baik" (P-10); dan pada 7 November 2025 masih menugaskannya selaku "Prakom Mahir" (P-17). Tergugat tidak dapat pada satu sisi mengancamkan tuntutan ganti rugi atas periode tersebut, sementara pada sisi lain melalui keputusannya sendiri mengakui hak Penggugat atas jabatan dan tunjangannya pada periode yang sama.

84. Bahwa **ketiga**, menjadikan Keputusan Menteri PANRB Nomor SKJ.4 Tahun 2024 sebagai titik hitung adalah penerapan yang bertentangan dengan substansi peraturan itu sendiri. Diktum Kesebelas menentukan keputusan tersebut mulai berlaku pada tanggal ditetapkan, yaitu 14 Mei 2024, sehingga berlaku prospektif dan tidak berlaku mundur terhadap hubungan hukum yang telah terbentuk sebelumnya. Menerapkannya terhadap Penggugat yang telah diangkat sejak 1 Agustus 2009 adalah penerapan secara surut; dan tidaklah tepat menghukum seseorang dengan menggunakan dasar hukum yang diterbitkan setelah hubungan hukumnya terbentuk.

85. Bahwa **keempat**, sepanjang jeda lebih dari 5 (lima) bulan antara tenggat yang didalilkan dan penetapan Objek Sengketa merupakan keterlambatan pada pihak Tergugat sendiri — sebagaimana secara implisit diakui pada Jawaban bagian tanggapan angka 1 huruf l — maka Tergugat tidak boleh mengambil keuntungan dari keterlambatan itu dengan menjadikan periode 26 Mei 2025 sampai dengan November 2025 sebagai dasar perhitungan tuntutan ganti rugi terhadap Penggugat.

86. Bahwa **kelima**, sekalipun ancaman tersebut belum berwujud penetapan formal, ia telah berwujud nyata pada satu titik: penarikan kembali tunjangan kinerja bulan November 2025 melalui Sistem Informasi PNBP Online (P-19) dilakukan **tanpa didahului penetapan tuntutan ganti rugi yang sah**, padahal penarikan itu justru dijustifikasi Tergugat dengan merujuk pada rezim tuntutan ganti rugi. Suatu pungutan terhadap penghasilan pegawai yang tidak berdasarkan penetapan yang sah adalah tindakan yang tidak memiliki dasar hukum.

87. Bahwa penghasilan yang telah diterima Penggugat pada periode ketika Penggugat masih nyata-nyata melaksanakan tugas jabatannya, dan ketika kedudukannya masih diakui melalui keputusan Tergugat sendiri, tidak dapat ditarik kembali. Tindakan menarik kembali penghasilan demikian melanggar Asas-Asas Umum Pemerintahan yang Baik khususnya **asas pemberian harapan yang wajar**, sehingga tuntutan Penggugat berkaitan dengan permohonan untuk tidak dibebani pengembalian penghasilan yang telah terlanjur dibayarkan adalah berdasar hukum.

88. Bahwa **keenam**, ancaman yang menggantung tanpa kepastian hukum tersebut menimbulkan tekanan psikologis berkelanjutan yang terdokumentasi secara medis berupa gangguan kecemasan dan gejala psikosomatis (P-12), yang merupakan kerugian immateriil tersendiri. Tekanan serupa berlanjut pada tahap peradilan, sebagaimana terungkap dari rekaman dan transkrip pertemuan tanggal 22 April 2026 (P-27), yang memperlihatkan prospek pemulihan karier Penggugat dikaitkan dengan pencabutan gugatan. Keadaan demikian bertentangan dengan **asas akuntabilitas** sebagaimana Pasal 2 huruf g Undang-Undang Nomor 20 Tahun 2023 dan **asas keterbukaan**, sekaligus mematahkan dalih bahwa sikap Tergugat semata-mata merupakan wujud perlindungan organisasi: perlindungan yang ditawarkan bersifat bersyarat atas penyerahan hak Penggugat untuk menempuh upaya hukum.

### C.6. Asas kemanfaatan dan proporsionalitas — pemberhentian bukan jalan keluar terakhir

89. Bahwa Objek Sengketa dijatuhkan bukan atas dasar kesalahan, pelanggaran disiplin, maupun penurunan kinerja. Penggugat tidak pernah dijatuhi hukuman disiplin ringan, sedang, maupun berat; sebaliknya, pada periode penilaian terdekat sebelum penerbitannya, Penggugat justru memperoleh Predikat Kinerja "Sangat Baik" dengan Capaian Kinerja Organisasi "Istimewa" (P-10). Predikat tersebut menggugurkan kemungkinan dasar pemberhentian menurut Pasal 43 huruf a Peraturan Menteri PANRB Nomor 1 Tahun 2023, sehingga satu-satunya pintu yang tersisa adalah Pasal 43 huruf b — yang justru menuntut pemeriksaan terlebih dahulu sebagaimana Pasal 41 ayat (5).

90. Bahwa pada saat Objek Sengketa diterbitkan, kualifikasi yang dipersoalkan Tergugat **sedang ditempuh Penggugat di bawah fasilitasi Tergugat sendiri**, melalui Surat Tugas Belajar Mandiri (Tidak Diberhentikan) Nomor ST-497/PP.1/2025 yang diterbitkan Sekretariat BPPK pada 10 Juni 2025 (P-7, yang diajukan pula oleh Tergugat sebagai alat bukti), dengan progres akademik yang terukur (P-28).

91. Bahwa terhadap dalil Tergugat mengenai perbedaan perguruan tinggi dan program studi antara pengajuan izin dan pelaksanaan studi (Jawaban, bagian tanggapan angka 3 huruf d; bukti T-15 dan T-16), peraturan Tergugat sendiri telah menyediakan jalan penyelesaiannya. **Pasal 51 ayat (4) Peraturan Menteri Keuangan Nomor 34 Tahun 2024** menentukan: *"Bagi PNS Tugas Belajar Mandiri yang mengalami perubahan/perpindahan perguruan tinggi dan/atau program studi, harus mengajukan permohonan untuk diterbitkan Surat Tugas Belajar Mandiri baru sesuai ketentuan Peraturan Menteri ini."* Norma tersebut menempatkan perubahan perguruan tinggi dan/atau program studi sebagai keadaan yang **cukup ditindaklanjuti dengan penerbitan surat tugas baru** — yaitu kelemahan administratif yang dapat disesuaikan, bukan pelanggaran yang meniadakan status tugas belajar maupun itikad baik Penggugat. Perlu pula Penggugat sampaikan bahwa perpindahan tersebut justru menuju program studi Diploma III bidang Manajemen Informatika, yaitu jenjang dan rumpun yang **tepat menjawab** kualifikasi yang dipersoalkan Tergugat, sejalan dengan tujuan pengelolaan tugas belajar sebagaimana Pasal 2 ayat (1) peraturan yang sama.

92. Bahwa terlebih, kedua dokumen yang dipersoalkan Tergugat pada bagian ini — Laporan Perkembangan Studi tanggal 10 Maret 2026 (T-15) dan tangkapan layar pangkalan data pendidikan tinggi (T-16) — **lahir setelah** Objek Sengketa diterbitkan, bahkan setelah Gugatan didaftarkan, sehingga tidak dapat menjadi acuan untuk membenarkan penerbitan Objek Sengketa *a quo*.

93. Bahwa menjatuhkan akibat terberat berupa pemberhentian dari jabatan fungsional, pada saat pemenuhan syarat yang dipersoalkan sedang berjalan atas fasilitasi Tergugat sendiri, tanpa didahului peringatan tertulis, tanpa pemeriksaan, dan tanpa mempertimbangkan kedekatan waktu penyelesaiannya, tidak memenuhi **asas kemanfaatan** sebagaimana Pasal 10 ayat (1) huruf b Undang-Undang Nomor 30 Tahun 2014, dan tidak memenuhi prinsip jalan keluar terakhir (*ultimum remedium*). Keterangan saksi di bawah sumpah bahwa jarak antara pemberitahuan tahun 2023 dan tenggat tahun 2025 hanya 2 (dua) tahun, dan bahwa waktu tersebut tidak memadai untuk menyelesaikan pendidikan Diploma III, memperkuat penilaian ini secara faktual.

### C.7. Kedudukan bukti P-32 dan batas penggunaannya

94. Bahwa Penggugat mendalilkan secara konsisten bahwa keabsahan suatu Keputusan Tata Usaha Negara dinilai menurut fakta dan hukum pada saat Keputusan itu diterbitkan, yaitu 13 November 2025. Konsistensi tersebut menuntut Penggugat membatasi sendiri penggunaan bukti Surat Keterangan Lulus Politeknik LP3I Jakarta Nomor 0394-1501/03/SKT/PLJ/VI/2026 tanggal 25 Juli 2026 (P-32), yang juga lahir setelah tanggal tersebut.

95. Bahwa oleh karena itu Penggugat menyatakan secara tegas dan terbatas bahwa P-32 hanya dipergunakan untuk tiga hal, yaitu:
    a. membantah **dalil fakta** Tergugat bahwa Penggugat tidak pernah mengajukan untuk melanjutkan pendidikan (Duplik angka 23 huruf e) — dalil yang telah terbantah pula oleh T-6 dan oleh Surat Tugas Belajar Mandiri yang diajukan Tergugat sendiri;
    b. menunjukkan bahwa **amar rehabilitasi dapat dilaksanakan tanpa hambatan faktual**; dan
    c. menegaskan secara *ex post* bahwa penilaian proporsionalitas atas keadaan per 13 November 2025 terbukti benar.

96. Bahwa dengan demikian Penggugat **tidak** mendalilkan bahwa Objek Sengketa menjadi tidak sah karena Penggugat kini telah lulus. Objek Sengketa cacat sejak diterbitkan; kelulusan Penggugat tidak menambah maupun mengurangi cacat tersebut, melainkan meniadakan alasan faktual apa pun bagi tindakan sejenis di masa mendatang.

---

# IV. MATRIKS POSITA — ALAT BUKTI — PENGAKUAN TERGUGAT

| Posita | Pokok dalil | Alat bukti Penggugat | Alat bukti Tergugat | Pengakuan Tergugat |
|---|---|---|---|---|
| **1** | Keberlakuan surut melanggar Pasal 58 ayat (6) UU 30/2014 dan menimbulkan kerugian nyata | P-18; P-17; P-19; P-29; P-30; P-31; P-14; P-15; P-16 | T-12 | Duplik angka 6 (yang terlarang adalah akibat merugikan atas peristiwa yang belum selesai); Duplik angka 8–9 (penarikan tunjangan diakui terjadi); Jawaban tanggapan angka 1 huruf i (tolok ukur yang dirumuskan sendiri) |
| **2** | Tidak ada pemeriksaan sebelum pemberhentian — Pasal 41 ayat (5) Permenpan RB 1/2023 | P-25; P-11; P-14; P-18 (Menimbang huruf c); keterangan saksi 8 Juli 2026 | T-9; T-10; T-11 | Duplik angka 23 huruf a (Pasal 41 ayat (5) berkorelasi dengan Pasal 43 huruf b); Jawaban aspek kewenangan huruf c (dasar Pasal 41 ayat (1) huruf f); Jawaban bagian Asas Tidak Menyalahgunakan Wewenang (klaim telah ada "pemeriksaan"); keterangan Tergugat sendiri atas T-9, T-10, dan T-11 dalam Daftar Buktinya |
| **3** | Asas kepastian hukum dan pemberian harapan yang wajar — pengakuan resmi pasca-tenggat | P-3; P-4; P-6; P-7; P-8; P-9; P-10; P-29; P-17 | T-6; T-7 (Diktum KEDUA); T-8 | Keterangan Tergugat atas T-8 ("cakap dan memenuhi syarat"); keterangan Tergugat atas T-9 (frasa tersebut "penilaian substantif mengenai kelayakan"); Duplik angka 25–27; Jawaban Kronologis butir 15 |
| **4** | Asas nondiskriminatif serta keadilan dan kesetaraan — perlakuan surut versus prospektif | P-15; P-16; P-14; P-26; keterangan saksi 8 Juli 2026 | — | Jawaban tanggapan angka 1 huruf e (KMK 188 diakui, alasan pemberhentian sama); Duplik angka 31 |
| **5** | Penerapan Pasal 59 Permenpan RB 32/2020 tanpa uji harmonisasi menurut Pasal 61 Permenpan RB 1/2023; *verkregen recht* | P-1; P-2; P-4 | T-3 | Duplik angka 44 (keabsahan pengangkatan 2009 diakui); Duplik angka 38–40 |
| **6** | Asas akuntabilitas — proses tidak terdokumentasi, keterlambatan lebih dari 5 bulan, ancaman tuntutan ganti rugi, dampak finansial nyata | P-25; P-11; P-12; P-13; P-14; P-19; P-27; P-29; P-30; P-31; keterangan saksi 8 Juli 2026 | T-9; T-10; T-11 | Jawaban tanggapan angka 1 huruf k (rujukan PMK 218/2017 jo. PP 38/2016) dan huruf l (jeda hingga 13 November 2025 diakui); Duplik angka 15–16 |
| **7** | Cacat motivering — dasar hukum substantif tidak dicantumkan dalam Mengingat | P-18; P-23 | T-12; T-14 | Duplik angka 48–51 (ketiadaan pencantuman diakui); Duplik angka 56–58 |
| **Lintas posita** | Cacat wewenang materiil — premis kualifikasi dinilai di luar cakupan bidang wewenang (Pasal 17 dan Pasal 18 ayat (2) huruf a UU 30/2014) | P-4; P-18 (Menimbang huruf a); P-8; P-9 | T-12 | Jawaban Kronologis butir 4 (BPS selaku Instansi Pembina) dan butir 13; Duplik angka 30–31; Jawaban tanggapan nondiskriminatif huruf f |

---

# V. TANGGAPAN ATAS DALIL-DALIL DUPLIK TERGUGAT

## A. Dalam Penundaan (Duplik angka 1 sampai dengan angka 10)

97. Bahwa terhadap Duplik angka 1 sampai dengan angka 5 mengenai hubungan antara Pasal 65 Undang-Undang Nomor 30 Tahun 2014 dan Pasal 67 Undang-Undang Peradilan Tata Usaha Negara, Penggugat menyerahkan sepenuhnya kepada kebijaksanaan Majelis Hakim, dengan menegaskan bahwa yang Penggugat mohonkan adalah penundaan oleh Pengadilan selama pemeriksaan berlangsung sebagaimana Pasal 67 ayat (2) Undang-Undang Peradilan Tata Usaha Negara.

98. Bahwa terhadap Duplik angka 6 sampai dengan angka 8 dan angka 10 mengenai asas *praesumptio iustae causa*, Penggugat tidak membantah berlakunya asas tersebut, dan justru mengajukan gugatan ini agar praduga dimaksud diuji melalui pembuktian di persidangan, sebagaimana telah berlangsung.

99. Bahwa terhadap Duplik angka 9 yang menuntut adanya kerugian yang konkret, aktual, dan spesifik, Penggugat telah memenuhinya melalui bukti yang otentik dan terukur, yaitu P-19, P-29, P-30, P-31, dan P-12. Kerugian yang Penggugat dalilkan bukan dugaan, melainkan kerugian yang telah dieksekusi dan berulang setiap bulan.

100. Bahwa oleh karena perkara telah memasuki tahap akhir, Penggugat menyerahkan permohonan penundaan tersebut sepenuhnya kepada pertimbangan Majelis Hakim, dan memusatkan permohonan pada pokok perkara.

## B. Dalam Pokok Perkara

101. Bahwa terhadap **Duplik angka 2 sampai dengan angka 7**, Penggugat telah menanggapinya pada angka 57 sampai dengan angka 64. Ditegaskan kembali: frasa "berlaku surut" dipilih dan dituliskan sendiri oleh Tergugat pada Diktum KELIMA; P-17 membuktikan peristiwanya belum selesai; dan P-19 membuktikan akibatnya merugikan.

102. Bahwa terhadap **Duplik angka 8 sampai dengan angka 9** yang menyebut penarikan tunjangan sebagai "konsekuensi administratif", Penggugat telah menanggapinya pada angka 81 sampai dengan angka 87. Penarikan kembali tunjangan yang telah sah diterima selama masa menjabat yang sah adalah peniadaan hak yang telah diperoleh, dan dilakukan tanpa penetapan tuntutan ganti rugi yang sah.

103. Bahwa terhadap **Duplik angka 10 sampai dengan angka 12** mengenai "perlindungan finansial jangka panjang", dalil tersebut berbenturan dengan fakta terukur: penghasilan Penggugat turun secara nyata dan berulang (P-29 dibanding P-30), dan di samping itu Penggugat masih dibebani penarikan kembali (P-19). Suatu kebijakan yang didalilkan melindungi tidak dapat diukur dengan hasil yang merugikan.

104. Bahwa terhadap **Duplik angka 13 sampai dengan angka 14**, Penggugat telah menanggapinya pada angka 65 sampai dengan angka 69.

105. Bahwa terhadap **Duplik angka 15 sampai dengan angka 16**, Tergugat sendiri mengakui seluruh komunikasi yang dirujuknya bersifat **informal melalui aplikasi pesan** (huruf a dan huruf b), dan mengakui pula bahwa *"tidak pernah terdapat tawaran untuk perpindahan dari BaTii ke DJA"* (huruf c). Komunikasi informal dengan seorang staf bukanlah permohonan formal turun jabatan, dan tidak dapat menjadi dasar Diktum KESATU yang memberhentikan Penggugat dari jabatan fungsional. Sebagaimana terbaca dari P-13, permohonan Penggugat diawali pernyataan bahwa status Pranata Komputernya "akan diberhentikan" — yaitu upaya meringankan dampak atas keputusan yang telah diambil, bukan persetujuan atas pemberhentian, dan sama sekali bukan persetujuan atas keberlakuan surut.

106. Bahwa terhadap **Duplik angka 17 sampai dengan angka 19**, yang dipersoalkan Penggugat bukanlah keuntungan pribadi pejabat, melainkan keuntungan administratif berupa keseragaman tanggal yang diperoleh dengan membebankan akibat keterlambatan kepada Penggugat. Keseragaman administratif semestinya dicapai melalui ketepatan waktu penetapan — sebagaimana nyata-nyata mampu dilakukan Tergugat pada P-15 dan P-16 — bukan melalui penarikan mundur tanggal berlaku.

107. Bahwa terhadap **Duplik angka 20 sampai dengan angka 21**, persoalannya bukan pada terhapusnya catatan riwayat pekerjaan, melainkan pada ditariknya kembali **hak keuangan** yang melekat pada pekerjaan yang telah nyata ditunaikan dalam periode yang di-surut-kan (P-19), padahal pada periode itu Penggugat masih ditugaskan secara resmi selaku Prakom Mahir (P-17).

108. Bahwa terhadap **Duplik angka 22 sampai dengan angka 24**, Penggugat telah menanggapinya pada angka 32 sampai dengan angka 48. Ditambahkan:
    a. Terhadap **Duplik angka 23 huruf e** yang menyatakan Penggugat tidak pernah mengajukan untuk melanjutkan pendidikan, dalil tersebut **terbantah oleh bukti Tergugat sendiri**, yaitu T-6 berupa Nota Dinas ND-472/PP.7/2025 tanggal 16 Mei 2025 — yang terbit **sebelum** tenggat 26 Mei 2025 — dan alat bukti Tergugat berupa Surat Tugas Belajar Mandiri (Tidak Diberhentikan) Nomor ST-497/PP.1/2025 tanggal 10 Juni 2025.
    b. Menurut ukuran Tergugat sendiri pada **Duplik angka 23 huruf e**, pemeriksaan relevan apabila terdapat fakta atau keadaan yang masih memerlukan pembuktian, klarifikasi, atau penilaian. Studi yang sedang berjalan atas fasilitasi Tergugat sendiri adalah keadaan yang demikian, sehingga menurut ukuran Tergugat sendiri pemeriksaan justru menjadi relevan.
    c. Terhadap **Duplik angka 23 huruf f dan huruf k** yang menyatakan Pasal 41 ayat (5) tidak menentukan bentuk pemeriksaan, norma tersebut menentukan **objek** pemeriksaan, yaitu Pejabat Fungsional yang akan diberhentikan. Verifikasi terhadap data tidak dapat menggantikan pemeriksaan terhadap orang, sebagaimana nyata dari bunyi T-9, T-10, dan T-11 yang seluruhnya berbicara tentang *data*.
    d. Terhadap **Duplik angka 23 huruf g dan huruf i** yang menyatakan fakta yang menjadi dasar bersifat objektif dan dapat diverifikasi, justru karena fakta tersebut mudah diverifikasi, memanggil dan mendengar Penggugat tidaklah membebani; dan apabila hal itu dilakukan, Tergugat akan mengetahui adanya Surat Tugas Belajar Mandiri yang diterbitkan unitnya sendiri.

109. Bahwa terhadap **Duplik angka 25 sampai dengan angka 27**, Penggugat telah menanggapinya pada angka 49 sampai dengan angka 56. Tergugat tidak menyangkal keberadaan pernyataan "cakap dan memenuhi syarat", bahkan mengulangnya dalam keterangan atas bukti T-8 dan menyebutnya sebagai "penilaian substantif mengenai kelayakan" dalam keterangan atas bukti T-9.

110. Bahwa terhadap **Duplik angka 28 sampai dengan angka 32**, Penggugat telah menempatkan sumbu utama dalil nondiskriminatif pada **perlakuan** (surut versus prospektif) sebagaimana angka 65 sampai dengan angka 69, sehingga bantahan strata Tergugat tidak menyentuh sumbu tersebut. Adapun pada angka 31 Tergugat mengakui sendiri bahwa rumpun ilmu selain Teknologi Informasi diperbolehkan sepanjang ditetapkan Instansi Pembina — pengakuan yang justru menegaskan bahwa penentuan isi kualifikasi berada pada Instansi Pembina, sebagaimana angka 22 sampai dengan angka 31.

111. Bahwa terhadap **Duplik angka 33** yang menyebut Keputusan Menteri Keuangan Nomor 1105/KM.3/UP.11/2009, nomor keputusan pengangkatan pertama Penggugat sebagaimana terbukti dari P-1 dan sebagaimana disebut Tergugat sendiri dalam Jawaban bagian Kronologis butir 2 adalah **Nomor 1105/KM.1/UP.11/2009**.

112. Bahwa terhadap **Duplik angka 34 sampai dengan angka 36**, dalil Penggugat justru bertumpu pada keadaan konkret Penggugat sendiri, yaitu perlakuan surut yang hanya dikenakan kepadanya. Adapun mengenai "hasil evaluasi terhadap status dan kualifikasi Penggugat" pada angka 36, tidak terdapat satu pun dokumen evaluasi yang melibatkan Penggugat dalam berkas perkara.

113. Bahwa terhadap **Duplik angka 37 sampai dengan angka 42**, Penggugat menegaskan tidak pernah mendalilkan bahwa syarat Diploma III telah hapus. Yang Penggugat persoalkan adalah bahwa Pasal 61 Peraturan Menteri PANRB Nomor 1 Tahun 2023 memberlakukan peraturan teknis lama secara **bersyarat**, yaitu *"sepanjang tidak bertentangan dan belum diubah"*. Beban menguji terpenuhinya syarat tersebut berada pada pejabat yang menerbitkan Keputusan, bukan pada warga masyarakat yang menerima akibatnya. Dalam berkas tidak terdapat dokumen apa pun yang menunjukkan pengujian demikian pernah dilakukan.

114. Bahwa terhadap **Duplik angka 41** yang menyebut ketentuan teknis Jabatan Fungsional Pranata Komputer diatur dalam "Permenpan RB Nomor 21 Tahun 2020", peraturan teknis yang dirujuk Tergugat di seluruh bagian lain Jawaban dan Duplik adalah **Peraturan Menteri PANRB Nomor 32 Tahun 2020**. Hal ini Penggugat sampaikan sebagaimana adanya, tanpa maksud membesar-besarkan.

115. Bahwa terhadap **Duplik angka 43 sampai dengan angka 47** mengenai *verkregen recht*, Penggugat tidak mendalilkan kekebalan permanen terhadap perubahan kebijakan. Yang Penggugat dalilkan adalah bahwa ketentuan peralihan pada dasarnya merupakan instrumen **perlindungan** bagi pihak yang berada dalam masa transisi, bukan sarana pembebanan tambahan; dan bahwa peraturan yang dijadikan dasar oleh Tergugat sendiri, melalui Pasal 59 ayat (2) Peraturan Menteri PANRB Nomor 32 Tahun 2020, secara tegas mempertahankan pelaksanaan tugas jabatan bagi Pranata Komputer kategori keterampilan yang belum memperoleh ijazah diploma tiga.

116. Bahwa terhadap **Duplik angka 48 sampai dengan angka 55**, Penggugat telah menanggapinya pada angka 71 sampai dengan angka 77. Yang Penggugat dalilkan bukan kewajiban mencantumkan seluruh peraturan, melainkan ketiadaan **satu-satunya sumber norma substantif** yang menjadi alasan pemberhentian, sehingga pihak yang dirugikan tidak dapat menelusuri dasar tindakan yang dikenakan kepadanya.

117. Bahwa terhadap **Duplik angka 56 sampai dengan angka 58**, Penggugat telah menanggapinya pada angka 78. Ditegaskan kembali bahwa Keputusan Menteri Keuangan Nomor 9/MK/SJ/2026 **bukan Objek Sengketa** dalam perkara ini, melainkan penegasan administratif atas ditolaknya keberatan, sehingga tidak dapat menjadi sarana menambal dasar hukum Objek Sengketa secara surut.

118. Bahwa terhadap **Duplik angka 59 sampai dengan angka 60** yang membedakan cacat formal administratif dari cacat yang mempengaruhi legalitas substansi, dalam perkara *a quo* keduanya bertaut. Ketiadaan dasar substantif dalam konsiderans Mengingat bukan kekurangan redaksional semata; ia berpadu dengan ketiadaan penetapan Instansi Pembina (angka 25 dan angka 28) dan ketiadaan pemeriksaan terhadap Penggugat (angka 35 sampai dengan angka 42), sehingga yang tersisa adalah suatu Keputusan yang membebani yang **terbit tidak didasarkan pada informasi dan dokumen yang lengkap untuk mendukung legalitas Keputusan**.

---

# VI. PENUTUP

119. Bahwa berdasarkan rangkaian uraian di atas, Penggugat berkesimpulan penerbitan Objek Sengketa mengandung **cacat prosedural maupun cacat substansial**, dan tidak memenuhi Aspek Kewenangan, Aspek Prosedur, maupun Aspek Substansi sebagaimana dituntut Pasal 52 ayat (1) Undang-Undang Nomor 30 Tahun 2014 secara kumulatif, sehingga Tergugat selaku Pejabat Pembina Kepegawaian nyata-nyata telah melanggar peraturan perundang-undangan yang berlaku dan telah melanggar Asas-Asas Umum Pemerintahan yang Baik — khususnya asas kepastian hukum, asas kecermatan, asas *audi et alteram partem*, asas pemberian harapan yang wajar, asas persamaan, asas motivering, asas akuntabilitas, dan asas kemanfaatan.

120. Bahwa dengan segala hormat, Penggugat memohon perkenan Majelis Hakim untuk memberikan pertimbangan atas **seluruh** dalil Gugatan, tidak terbatas pada satu di antaranya. Permohonan ini Penggugat sampaikan bukan untuk mengurangi kemerdekaan Majelis dalam menentukan dasar putusannya, melainkan karena ketiga cacat tersebut berdiri di atas landasan yang berbeda dan menimbulkan akibat hukum yang berbeda pula bagi pemulihan kedudukan Penggugat.

121. Bahwa secara khusus Penggugat memohon perkenan Majelis Hakim mempertimbangkan empat hal berikut: **pertama**, kewenangan materiil Instansi Pembina atas penetapan kualifikasi pendidikan Jabatan Fungsional Pranata Komputer, dan ketiadaan penetapan demikian dalam berkas perkara; **kedua**, harapan yang wajar yang ditumbuhkan oleh dua keputusan Tergugat sendiri yang terbit setelah tenggat 26 Mei 2025 — yaitu P-8 = T-7, yang bahkan memerintahkan pemberian tunjangan jabatan fungsional setiap bulan, dan P-9 = T-8, yang oleh Tergugat sendiri diterangkan sebagai penilaian substantif mengenai kelayakan; **ketiga**, perbedaan perlakuan berupa penerapan pola surut terhadap Penggugat dan pola prospektif terhadap pegawai dalam keadaan sebanding; dan **keempat**, ketiadaan dasar hukum bagi penarikan kembali penghasilan yang telah sah diterima Penggugat maupun bagi ancaman tuntutan ganti rugi yang dihitung dari tenggat 26 Mei 2025 maupun dari 14 Mei 2024.

122. Bahwa Penggugat menyampaikan pula, premis faktual yang dijadikan alasan pemberhentian pada saat ini telah terpenuhi seluruhnya (P-32), sehingga pengembalian kedudukan Penggugat pada Jabatan Fungsional Pranata Komputer Mahir dapat dilaksanakan tanpa hambatan faktual apa pun.

123. Bahwa Penggugat menyampaikan terima kasih atas kesabaran dan kecermatan Majelis Hakim dalam memeriksa perkara ini, serta atas kesempatan yang diberikan kepada Penggugat yang bertindak untuk dan atas nama diri sendiri.

---

## PENEGASAN PETITUM

Bahwa berdasarkan seluruh uraian tersebut di atas, Penggugat dengan hormat memohon kepada Majelis Hakim Pengadilan Tata Usaha Negara Jakarta yang memeriksa dan mengadili perkara *a quo* berkenan menjatuhkan putusan dengan amar sebagai berikut:

**DALAM POKOK PERKARA:**

1. Mengabulkan Gugatan Penggugat untuk seluruhnya;

2. Menyatakan batal atau tidak sah Keputusan Menteri Keuangan Republik Indonesia Nomor 199/MK/SJ.5/2025 tentang Pemberhentian dari Jabatan Fungsional Pranata Komputer Mahir dan Pemindahan Pegawai Negeri Sipil antar Unit Jabatan Pimpinan Tinggi Madya di Lingkungan Kementerian Keuangan atas nama Sdr. Ninin Sapto Hargiyanto (NIP 19860720 200701 1 001) tertanggal 13 November 2025;

3. Mewajibkan Tergugat untuk mencabut Keputusan Menteri Keuangan Republik Indonesia Nomor 199/MK/SJ.5/2025 tentang Pemberhentian dari Jabatan Fungsional Pranata Komputer Mahir dan Pemindahan Pegawai Negeri Sipil antar Unit Jabatan Pimpinan Tinggi Madya di Lingkungan Kementerian Keuangan atas nama Sdr. Ninin Sapto Hargiyanto (NIP 19860720 200701 1 001) tertanggal 13 November 2025;

4. Mewajibkan Tergugat untuk merehabilitasi harkat, martabat, serta kedudukan Penggugat seperti semula atau dalam kedudukan yang sejenis/setara sesuai ketentuan peraturan perundang-undangan yang berlaku;

5. Menghukum Tergugat untuk membayar seluruh biaya perkara yang timbul dalam sengketa ini.

Atau, apabila Majelis Hakim berpendapat lain, mohon putusan yang seadil-adilnya (*ex aequo et bono*).

---

Hormat kami,

**Penggugat,**


**Ninin Sapto Hargiyanto**
NIP 19860720 200701 1 001
