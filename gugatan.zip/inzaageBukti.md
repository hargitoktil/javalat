
# Karena PTSP melarang foto, bolehnya dicatat pulpen. Tetapi di argumen wajib dikutip verbatim di kesimpulan dengan menyebut T-, bukan menyebut Inzaage. 
## T-9 pada poin ketiga ada verbatim: 
"dalam data monitoring kami"
## T-10 pada poin ketiga ada verbatim: 
"bahwa berdasarkan penelitian terhadap data pranata komputer di lingkungan Pusat Data dan Informasi"
## T-11 ada verbatim: 
"bahwa berdasarkan penelitian terhadap data pranata komputer di lingkungan Pusat Data dan Informasi"
## T-7 
### diktum kesatu verbatim: 
"memindahkan para pejabat fungsional kategori keterampilan yang namanya sebagaimana tersebut pada lajur 2 dari jabatan dan tempat kedudukan sebagaimana tersebut pada lajur 4 menjadi jabatan dan tempat kedudukan sebagaimana tersebut pada lajur 5 lampiran yang merupakan bagian tidak terpisahkan dari keputusan menteri ini"
### diktum kedua verbatim: 
"kepada pegawai negeri sipil yang namanya tersebut pada diktum kesatu diberikan tunjangan jabatan fungsional setiap bulan sesuai dengan ketentuan peraturan perundang-undangan yang berlaku"
### lampiran: baris 1 sd baris 22 dst, baris 23 lajur 2 Nama: Ninin Sapto Hargiyanto NIP 198607202007011001, lajur 3 Pangkat (Golongan/ruang) TMT: Penata Muda (III/a) 1 April 2022, lajur 4 Jabatan dan tempat kedudukan lama: Pranata Komputer Mahir pada Pusat Pendidikan dan Pelatihan Keuangan Umum - Badan Pendidikan dan Pelatihan Keuangan, lajur 5 Jabatan dan tempat kedudukan baru: Pranata Komputer Mahir pada Pusat Data dan Informasi - Badan Teknologi, Informasi, dan Intelijen Keuangan