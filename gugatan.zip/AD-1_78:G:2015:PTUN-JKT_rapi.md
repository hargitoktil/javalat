# Halaman 1

P   U   T   U   S   A   N
Nomor  : 78/G/2015/PTUN-JKT
DEMI KEADILAN BERDASARKAN KETUHANAN YANG MAHA ESA
Pengadilan Tata Usaha Negara Jakarta yang m emeriksa, m emutus dan 
m enyelesaikan sengketa Tata Usaha Negara pada tingkat  pertama dengan acara 
biasa, memutuskan dengan pertimbangan-pertimbangan sebagai berikut, dalam 
perkara antara ;
H. AGUS SUSANTO,  S.H., warganegara Indonesia, Pekerjaan Pegawai Negeri 
Sipil, Tempat Tinggal Jalan Melon II Nomor 6, Harapan 
Baru, Bekasi, Jawa Barat, dalam hal ini memberikan kuasa 
kepada  Hasani, S.H., dan Basuni Ismail, S.H., pekerjaan 
Advokat dan Konsultan Hukum pada kantor  “AMF ”, 
beralamat di Teratai Griya Asri G.3 Nomor  25, Legok, 
Tangerang Banten, berdasarkan surat kuasa khusus 
tanggal 17 Maret 2015,  selanjutnya disebut sebagai 
PENGGUGAT  ; 
M E L A W A N  
MENTERI AGAMA REPUBLIK INDONESIA,  berkedudukan di Jalan Lapangan 
Banteng Nomor  3 – 4, Jakarta Pusat, dalam hal ini 
memberikan kuasa kepada dalam hal ini memberi kuasa 
kepada: H. Anang Kusmawadi, S.H.,M.Si., Saan,S.H.,M.H., 
Munsyaidah Wahyuningsih, S.H., Hj. Eddy Yanti, S.H., 
Abdul Latif, S.H., Nazia Anastasia, S.H., dan Muhammad 
Rudiansyah, S.H., kesemuanya warganegara Indonesia, 
Pekerjaan Pegawai Negeri Sipil pada Biro Hukum dan 
 Halaman 1 dari 53 halaman Putusan No.78/G/2015/PTUN-JKT  
Disclaimer
Kepaniteraan Mahkamah Agung Republik Indonesia berusaha untuk selalu mencantumkan informasi paling kini dan akurat sebagai bentuk komitmen Mahkamah Agung untuk pelayanan publik, transparansi dan akuntabilitas
pelaksanaan fungsi peradilan. Namun dalam hal-hal tertentu masih dimungkinkan terjadi permasalahan teknis terkait dengan akurasi dan keterkinian informasi yang kami sajikan, hal mana akan terus kami perbaiki dari waktu kewaktu.
Dalam hal Anda menemukan inakurasi informasi yang termuat pada situs ini atau informasi yang seharusnya ada, namun belum tersedia, maka harap segera hubungi Kepaniteraan Mahkamah Agung RI melalui :
 Halaman 1


# Halaman 2

Kerjasama Luar Negeri Kementerian Agama, beralamat di 
Jalan Lapangan Banteng Barat No. 3-4 Jakarta Pusat, 
berdasarkan Surat Kuasa Khusus Nomor : MA/106/2015, 
tertanggal 27 April 2015, selanjutnya disebut sebagai 
TERGUGAT ;
Pengadilan Tata Usaha Negara Jakarta tersebut, telah membaca;
1. Penetapan Ketua Pengadilan Tata Usaha Negara Jakarta  Nomor:  78/PEN-
DIS/2015/PTUN-JKT., tertanggal 9 April 2015,  tentang pemeriksaan 
dengan acara biasa;
2. Penetapan Ketua Pengadilan Tata Usaha Negara Jakarta  Nomor:  78/
PEN/2015/PTUN-JKT., tertanggal 9 April 2015, tentang penetapan susunan 
Majelis Hakim yang memeriksa perkara ini dengan acara biasa ; 
3. Surat Penunjukan Panitera Pengadilan Tata Usaha Negara Jakarta  Nomor:  
78/PEN/2015/PTUN-JKT., tertanggal  9 April 2015;
4. Penetapan Hakim Ketua Majelis Pengadilan Tata Usaha Negara Jakarta 
Nomor  : 78/PEN- PP /2015/PTUN-JKT, tertanggal  13 April 2015, tentang 
penetapan pemeriksaan persiapan; 
5. Penetapan Hakim Ketua Majelis Pengadilan Tata Usaha Negara Jakarta 
Nomor  : 78/PEN-HS/2015/PTUN-JKT, tertanggal  5 Mei 2015, tentang 
penetapan Hari Sidang 
6. Berkas perkara yang bersangkutan, membaca  surat-surat dan mendengar 
keterangan Para Pihak yang bersengketa;
TENTANG DUDUK  SENGKETA
Disclaimer
Kepaniteraan Mahkamah Agung Republik Indonesia berusaha untuk selalu mencantumkan informasi paling kini dan akurat sebagai bentuk komitmen Mahkamah Agung untuk pelayanan publik, transparansi dan akuntabilitas
pelaksanaan fungsi peradilan. Namun dalam hal-hal tertentu masih dimungkinkan terjadi permasalahan teknis terkait dengan akurasi dan keterkinian informasi yang kami sajikan, hal mana akan terus kami perbaiki dari waktu kewaktu.
Dalam hal Anda menemukan inakurasi informasi yang termuat pada situs ini atau informasi yang seharusnya ada, namun belum tersedia, maka harap segera hubungi Kepaniteraan Mahkamah Agung RI melalui :
 Halaman 2


# Halaman 3

Menimbang, bahwa    Penggugat   telah  mengajukan   gugatan  kepada 
Tergugat dengan surat gugatan tertanggal 6 April 2015, yang diterima  dan 
terdaftar di  Kepaniteraan Pengadilan Tata Usaha Negara Jakarta pada tanggal  7 
April 2015, dengan Register Perkara Nomor : 78/G/2015/PTUN-JKT, dan telah 
diperbaiki dalam sidang Pemeriksaan Persiapan tanggal 5 Mei 2015,  telah 
mengemukakan alasan-alasan sebagai   berikut : 
A. OBYEK GUGATAN  :
    Surat Keputusan Menteri Agama RI No.B.II/3/00311, tanggal 16 Januari 2015 
tentang Pemberhentian dari Jabatan Auditor atas nama H. AGUS SUSANTO,SH.
B. TENGGANG WAKTU  :
    Bahwa Surat Keputusan Menteri Agama RI No.B.II/3/00311, tanggal 16 Januari 
2015  tentang Pemberhentian Dari Jabatan Auditor kepada H. AGUS 
SUANTO,S.H,  telah diterima secara resmi pada tanggal 5 Pebruari 2015, 
mengingat pengajuan  gugatan ini didaftarkan di Kepaniteraan Pengadilan Tata 
Usaha Negara Jakarta pada tanggal 7 April 2015, maka sesuai dengan ketentuan 
Pasal 55 UU No.5 Tahun  1986 tentang Pengadilan Tata Usaha Negara, maka 
pengajuan surat gugatan ini masih dalam tenggang waktu 90 (sembilan puluh) hari 
sejak diterimanya Surat Keputusan Tergugat dimaksud;
C. KEWENANGAN PENGADILAN TATA USAHA NEGARA   :
1. Bahwa berdasarkan pasal 1 angka 3 UU No.5  Tahun  1986 tentang 
Pengadilan Tata Usaha Negara jo pasal 1 angka 9 UU No.51 Tahun  2009 
tentang Perubahan Kedua Undang-Undang No.5 Tahun 1986 tentang 
Pengadilan Tata Usaha Negara mendefisinikan Keputusan Tata Usaha 
Negara adalah : “Suatu penetapan tertulis yang dikeluarkan oleh badan atau 
pejabat tata usaha negara yang berisi tindakan hukum yang berdasarkan 
 Halaman 3 dari 53 halaman Putusan No.78/G/2015/PTUN-JKT  
Disclaimer
Kepaniteraan Mahkamah Agung Republik Indonesia berusaha untuk selalu mencantumkan informasi paling kini dan akurat sebagai bentuk komitmen Mahkamah Agung untuk pelayanan publik, transparansi dan akuntabilitas
pelaksanaan fungsi peradilan. Namun dalam hal-hal tertentu masih dimungkinkan terjadi permasalahan teknis terkait dengan akurasi dan keterkinian informasi yang kami sajikan, hal mana akan terus kami perbaiki dari waktu kewaktu.
Dalam hal Anda menemukan inakurasi informasi yang termuat pada situs ini atau informasi yang seharusnya ada, namun belum tersedia, maka harap segera hubungi Kepaniteraan Mahkamah Agung RI melalui :
 Halaman 3


# Halaman 4

peraturan perundang-undangan yang berlaku,  yang bersifat kongkrit, 
individual, dan final, yang membawa akibat hukum bagi seseorang atau 
badan hukum perdata”.
2. Bahwa berdasarkan definisi dalam angka 1 diatas, maka  “Surat Keputusan 
Menteri Agama Republik Indonesia No.B.II/3/00311, tanggal 16 Januari 
2015 tentang Pemberhentian dari Jabatan Auditor kepada H. AGUS 
SUANTO,  S.H adalah sebuah keputusan tertulis yang berisi penetapan 
tertulis (beschikking) dan langsung berlaku sejak dikeluarkan oleh pejabat 
yang membuatnya (einmalig);
3. Bahwa Surat Keputusan Menteri Agama Republik Indonesia   
No.B.II/3/00311, tanggal 16 Januari 2015 tentang Pemberhentian dari 
Jabatan Auditor kepada H. AGUS SUSANTO,S.H jelas sudah bersifat 
kongkrit, individual dan final dengan dasar sebagai berikut :
a. Bahwa Surat Keputusan Tergugat aquo bersifat kongkrit karena yang 
disebutkan dalam Surat Keputusan Tergugat nyata-nyata secara tegas 
menyebutkan Penggugat diberhentikan dari jabatan auditor;
b. Bahwa Surat Keputusan Tergugat aquo bersifat individual karena secara 
tegas menyebutkan nama Penggugat;
c. Bahwa Surat Keputusan Tergugat aquo telah bersifat final karena tidak 
lagi memerlukan persetujuan dari instansi tertentu baik bersifat 
horizontal maupun vertikal. Dengan demikian surat keputusan Tergugat 
aquo tersebut  telah bersifat final dan telah menimbulkan akibat hukum;
D. KEPENTINGAN HUKUM PENGUGAT  :
Disclaimer
Kepaniteraan Mahkamah Agung Republik Indonesia berusaha untuk selalu mencantumkan informasi paling kini dan akurat sebagai bentuk komitmen Mahkamah Agung untuk pelayanan publik, transparansi dan akuntabilitas
pelaksanaan fungsi peradilan. Namun dalam hal-hal tertentu masih dimungkinkan terjadi permasalahan teknis terkait dengan akurasi dan keterkinian informasi yang kami sajikan, hal mana akan terus kami perbaiki dari waktu kewaktu.
Dalam hal Anda menemukan inakurasi informasi yang termuat pada situs ini atau informasi yang seharusnya ada, namun belum tersedia, maka harap segera hubungi Kepaniteraan Mahkamah Agung RI melalui :
 Halaman 4


# Halaman 5

Surat Keputusan Menteri Agama Republik Indonesia No.B.II/3/00311, tanggal 
16 Januari 2015 tentang Pemberhentian Dari Jabatan Auditor kepada H. AGUS 
SUANTO,S.H,  aquo menimbulkan akibat hukum, yaitu Penggugat  telah 
diberhentikan dari jabatan sebagai Fungsional Auditor Ahli Madya, kehilangan 
jabatan Fungsional Auditor Ahli Madya dan kehilangan uang tunjangan, tidak 
mungkin diangkat kembali sebagai fungsional  auditor ahli madya dan 
kehilangan nama baik;
Bahwa berdasarkan keterang-keterangan tersebut diatas,  maka Surat 
Keputusan Menteri Agama Republik Indonesia No.B.II/3/00311, tanggal 16 
Januari 2015 tentang Pemberhentian Dari Jabatan Auditor kepada H. AGUS 
SUANTO,S.H,  telah memenuhi syarat sebagai obyek gugatan dalam perkara di 
Pengadilan Tata Usaha Negara;
E. ALASAN DAN DASAR GUGATAN  :
1. Bahwa Penggugat telah bekerja di Kementerian Agama RI  dan  saat ini 
ditempatkan  pada Inspektorat Jenderal Kementerian Agama Republik 
Indonesia sejak tahun 1993 hingga sekarang dengan Pangkat Pembina (IVa ) 
dan dengan jabatan terakhir sebagai Auditor Ahli Madya  sejak tahun 2008, 
sesuai dengan Surat keputusan Menteri Agama Nomor B.II/3/13180 tanggal 19 
September 2008 (terlampir bukti P.1), untuk wilayah III dengan daerah kerja 
meliputi : 
- Babel - Sumatera Selatan
- Lampung - Banten
- Kalimantan Barat - Sulawesi Selatan
- Nusa Tenggara Barat - Ambon
2.   Bahwa adapun tugas Penggugat sebagai Auditor Madya antara lain : 
 Halaman 5 dari 53 halaman Putusan No.78/G/2015/PTUN-JKT  
Disclaimer
Kepaniteraan Mahkamah Agung Republik Indonesia berusaha untuk selalu mencantumkan informasi paling kini dan akurat sebagai bentuk komitmen Mahkamah Agung untuk pelayanan publik, transparansi dan akuntabilitas
pelaksanaan fungsi peradilan. Namun dalam hal-hal tertentu masih dimungkinkan terjadi permasalahan teknis terkait dengan akurasi dan keterkinian informasi yang kami sajikan, hal mana akan terus kami perbaiki dari waktu kewaktu.
Dalam hal Anda menemukan inakurasi informasi yang termuat pada situs ini atau informasi yang seharusnya ada, namun belum tersedia, maka harap segera hubungi Kepaniteraan Mahkamah Agung RI melalui :
 Halaman 5


# Halaman 6

Berdasarkan Peraturan Menpan Nomor  : PER/220/M.PAN/7/2008 tentang 
Jabatan Fungsional Auditor dan Angka Kreditnya Bab VI pasal 9 angka 2 huruf 
c dengan rincian:
• Mendampingi/memberikan keterangan ahli dalam proses penyidikan dan/
atau peradilan kasus hasil pengawasan;
• Mengendalikan Teknis pelaksanaan kegiatan pengawasan (audit, evaluasi, 
review, pemantauan, dan pengawasan lain);
• Melaksanakan kegiatan pengorganisasian pengawasan;
• Melaksanakan kegiatan pengendalian pengawasan;
• Membantu melaksanakan kegiatan perencanaan dan evaluasi pengawasan.
Dengan bidang yang diaudit oleh Fungsional Auditor Madya antara lain 
dibidang : keuangan,  kinerja, kepegawaian, pembangunan,  pengadaan barang 
dan jasa;
3. Bahwa berdasarkan Bab II pasal  4 ayat (1) Peraturan Menteri 
Pendayagunaan Aparatur Negara Dan Reformasi Birokrasi RI No.40 Tahun  
2012 tentang Jabatan Fungsional Auditor Kepegawaian dan Angka 
Kreditnya, adapun tugas pokok dari Fungsional Auditor Kepegawaian  
adalah melaksanakan  wasdalpeg (pengawasan, pengendalian pelaksanaan 
peraturan perundang-undangan bidang kepegawaian);
Dengan demikian tugas pokok dari Fungsional Auditor Kepegawaian  khusus 
hanya mengaudit dibidang kepegawaian saja;
4. Bahwa berdasarkan uraian dalam butir No.2 dan butir No.3 tersebut diatas, 
jelas ada perbedaan yang mendasar tugas Fungsional Auditor Madya 
dengan tugas  Fungsional Auditor Kepegawaian yaitu :
Disclaimer
Kepaniteraan Mahkamah Agung Republik Indonesia berusaha untuk selalu mencantumkan informasi paling kini dan akurat sebagai bentuk komitmen Mahkamah Agung untuk pelayanan publik, transparansi dan akuntabilitas
pelaksanaan fungsi peradilan. Namun dalam hal-hal tertentu masih dimungkinkan terjadi permasalahan teknis terkait dengan akurasi dan keterkinian informasi yang kami sajikan, hal mana akan terus kami perbaiki dari waktu kewaktu.
Dalam hal Anda menemukan inakurasi informasi yang termuat pada situs ini atau informasi yang seharusnya ada, namun belum tersedia, maka harap segera hubungi Kepaniteraan Mahkamah Agung RI melalui :
 Halaman 6


# Halaman 7

a.  Tugas dari Auditor Madya lebih luas dibandingkan dengan tugas    sebagai  
Fungsional Auditor Kepegawaian;
b.  Surat Keputusan pengangkatan sebagai Auditor Madya untuk golongan IVa 
kebawah diterbitkan oleh Inspektorat Internal yaitu Inspektorat Kementerian 
Agama RI dan untuk golongan IVb keatas oleh BPKP, sedangkan Surat 
Keputusan pengangkatan sebagai auditor kepegawaian diterbitkan dari 
Badan Kepegawaian Negara (BKN );
c.  Penetapan Angka Kredit sebagai Fungsional Auditor Madya untuk golongan 
IVa minimal 550.000, sedangkan   Penetapan Angka Kredit sebagai 
Fungsional Auditor Kepegawaian Madya untuk golongan IVa minimal 
536,000;
d.  Jabatan Fungsional Auditor diatur dalam Peraturan Menteri Pendayagunaan 
Aparatur Negara Nomor  : PER/220/M.PAN/7/2008 tentang Jabatan 
Fungsional Auditor dan Angka Kreditnya, sedangkan jabatan Fungsional 
Auditor Kepegawaian diatur dalam Peraturan Menteri Pendayagunaan 
Aparatur Negara Nomor : No.40 Tahun  2012 tentang Jabatan Fungsional 
Auditor Kepegawaian  dan Angka Kreditnya;
5. Bahwa Penggugat dalam menjalankan pekerjaan  sebagai  Auditor Madya 
secara berkala dengan masa penilaian  per enam bulan mendapat penilaian 
dalam bentuk yang disebut PENETAPAN ANGKA KREDIT;
6. Bahwa berdasarkan Penetapan Angka Kredit Jabatan Fungsional Auditor 
No.Set.IJ/2.b/PS.04.3/0559/2014 untuk masa penilaian tanggal 1 Januari 
2014 s/d tanggal 30 Juni 2014 tertanggal 4 Agustus 2014, jumlah total 
Penetapan Angka Kredit Penggugat sebesar 556,094. (terlampir bukti P.2);
 Halaman 7 dari 53 halaman Putusan No.78/G/2015/PTUN-JKT  
Disclaimer
Kepaniteraan Mahkamah Agung Republik Indonesia berusaha untuk selalu mencantumkan informasi paling kini dan akurat sebagai bentuk komitmen Mahkamah Agung untuk pelayanan publik, transparansi dan akuntabilitas
pelaksanaan fungsi peradilan. Namun dalam hal-hal tertentu masih dimungkinkan terjadi permasalahan teknis terkait dengan akurasi dan keterkinian informasi yang kami sajikan, hal mana akan terus kami perbaiki dari waktu kewaktu.
Dalam hal Anda menemukan inakurasi informasi yang termuat pada situs ini atau informasi yang seharusnya ada, namun belum tersedia, maka harap segera hubungi Kepaniteraan Mahkamah Agung RI melalui :
 Halaman 7


# Halaman 8

Sedangkan angka kredit untuk kenaikan pangkat yang diminta sesuai peraturan 
adalah minimal 550,000, dengan demikian berdasarkan Penetapan Angka 
Kredit Jabatan Fungsional Auditor No.Set.IJ/2.b/PS.04.3/0559/2014 tertanggal 
4 Agustus 2014, untuk masa penilaian tanggal 1 Januari 2014 s/d tanggal 30 
Juni 2014 secara peraturan yang berlaku Penggugat tidak dapat 
dipertimbangkan untuk kenaikan pangkat/jabatan dari Pembina/Golongan (IV/a) 
menjadi Pembina tingkat I/Golongan (IV/b), terhitung sejak  tanggal 1 Oktober 
2014;
7. Bahwa   pada tanggal 5 Pebruari 2015 Penggugat sangat terkejut telah 
menerima 2 (dua) surat keputusan sekaligus yang masing-masing berisi 
Surat Keputusan Menteri Agama RI No.B.II/3/71262 tentang Pembebasan 
Sementara Dari Jabatan Auditor tertanggal 31 Desember 2014 dan Surat 
Keputusan Menteri Agama RI No.B.II/3/00311 tentang Pemberhentian Dari 
Jabatan Auditor tertanggal 16 Januari 2015, yang penggugat terima kedua 
surat keputusan termaksud pada tanggal 5 Pebruari 2015 (terlampir bukti 
P.3 dan P.4);
8. Bahwa berdasarkan Undang-Undang No.9 Tahun  2004 tentang Perubahan 
atas Undang-Undang No.5 Tahun 1986 tentang Peradilan Tata Usaha 
Negara, dalam pasal 53 ayat (1) disebutkan : “Orang atau badan hukum 
perdata yang merasa kepentingannya dirugikan oleh suatu keputusan tata 
usaha negara dapat mengajukan gugatan tertulis kepada pengadilan yang 
berwenang yang berisi tuntutan agar keputusan tata usaha negara yang 
disengketakan itu dinyatakan batal atau tidak sah, dengan atau tanpa 
disertai tuntutan ganti rugi dan/atau rehabilitasi”.
Disclaimer
Kepaniteraan Mahkamah Agung Republik Indonesia berusaha untuk selalu mencantumkan informasi paling kini dan akurat sebagai bentuk komitmen Mahkamah Agung untuk pelayanan publik, transparansi dan akuntabilitas
pelaksanaan fungsi peradilan. Namun dalam hal-hal tertentu masih dimungkinkan terjadi permasalahan teknis terkait dengan akurasi dan keterkinian informasi yang kami sajikan, hal mana akan terus kami perbaiki dari waktu kewaktu.
Dalam hal Anda menemukan inakurasi informasi yang termuat pada situs ini atau informasi yang seharusnya ada, namun belum tersedia, maka harap segera hubungi Kepaniteraan Mahkamah Agung RI melalui :
 Halaman 8


# Halaman 9

Dalam hal ini Penggugat merasa kepentingannya dirugikan oleh surat 
Keputusan Tata Usaha Negara yaitu Surat Keputusan Menteri Agama RI 
No.B.II/3/00311, tanggal 16 Januari 2015 tentang Pemberhentian Dari Jabatan 
Auditor atas nama H. Agus Susanto,SH, agar keputusan tersebut dinyatakan 
batal atau tidak sah serta direhabilitasinya jabatan Penggugat seperti semula;
9. Bahwa dalam pertimbangan Surat Keputusan Menteri Agama RI 
No.B.II/3/00311, tanggal 16 Januari 2015 tentang Pemberhentian Dari 
Jabatan Auditor atas nama H.Agus Susanto,SH terdiri dari :
huruf a  : “Bahwa dalam rangka menindak lanjuti BAB IV Pasal  40 butir (a) 
Peraturan Menteri Pendayagunaan Aparatur Negara dan 
Reformasi Birokrasi  RI No.40 Tahun  2012 tanggal 17 Juli 2012, 
dipandang perlu memberhentikan Pegawai Negeri Sipil dari 
jabatan fungsional Auditor Kepegawaian”
huruf b :   “Bahwa berdasarkan Keputusan Menteri Agama Nomor B.II.3/71262, 
tanggal 31 Desember  2014 H.Agus Susanto,SH NIP  1963722. 
199303.1 002 Pembina Tk.I (IV/b) telah dibebaskan sementara dari 
jabatan fungsional Auditor Kepegawaian Madya pada Inspektorat 
Wilayah III Inspektorat Jenderal Kementerian Agama terhitung 
mulai tanggal 1 Oktober 2013 sampai dengan tanggal 1 Oktober 
2014 yang bersangkutan tidak dapat mengumpulkan angka kredit 
sebanyak yang dipersyaratkan, maka dipandang perlu untuk 
memberhentikan dari jabatan fungsional Auditor Kepegawaian 
Madya pada Inspektorat Wilayah III Inspektorat Jenderal 
Kementerian Agama ”.
 Halaman 9 dari 53 halaman Putusan No.78/G/2015/PTUN-JKT  
Disclaimer
Kepaniteraan Mahkamah Agung Republik Indonesia berusaha untuk selalu mencantumkan informasi paling kini dan akurat sebagai bentuk komitmen Mahkamah Agung untuk pelayanan publik, transparansi dan akuntabilitas
pelaksanaan fungsi peradilan. Namun dalam hal-hal tertentu masih dimungkinkan terjadi permasalahan teknis terkait dengan akurasi dan keterkinian informasi yang kami sajikan, hal mana akan terus kami perbaiki dari waktu kewaktu.
Dalam hal Anda menemukan inakurasi informasi yang termuat pada situs ini atau informasi yang seharusnya ada, namun belum tersedia, maka harap segera hubungi Kepaniteraan Mahkamah Agung RI melalui :
 Halaman 9


# Halaman 10

10.Bahwa pasal 53 ayat (2) huruf a Undang-Undang No.9 Tahun  2004 tentang 
Perubahan atas Undang-Undang No.5 Tahun  1986 tentang Peradilan Tata 
Usaha Negara  : “Keputusan Tata Usaha Negara yang digugat itu 
bertentangan dengan perundang-undangan yang berlaku”, yaitu :
a. Peraturan bersama BPKP dan BKN Nomor PER-1310/K/J/F/2008 dan 
Nomor  24 tahun 2008 tanggal 11 Nopember  2008 tentang Petunjuk 
Pelaksanaan Jabatan Fungsional Auditor Dan Angka Kredit, dalam bagian 
kedua tentang Pembebasan Sementara pasal  23 ayat (3) yang 
menyebutkan :
“Pembebasan sementara bagi auditor sebagaimana dimaksud dalam 
pasal 31 ayat (1), ayat (2), ayat (3), ayat (4), ayat (5), ayat (6), ayat (7), 
dan ayat  (8) Peraturan Menteri Negara Pendayagunaan Aparatur 
Negara Nomor PER/220/M.PAN/7/2008  didahului dengan peringatan 
paling lambat  6 ( enam ) bulan sebelum pembebasandengan 
menggunakan contoh sebagaimana tersebut pada lampiran XIX 
peraturan bersama”
Pada kenyataannya surat peringatan tidak pernah ada, terbukti sampai saat 
ini Penggugat ternyata sama sekali belum menerima surat peringatan 
sesuai dengan lampiran XIX sebagaimana diatur dalam peraturan bersama 
tersebut;
Surat peringatan adalah hal yang sangat penting wajib disampaikan kepada 
Penggugat sebelum surat keputusan Pembebasan Sementara dan Surat 
Keputusan Pemberhentian dari Jabatan Auditor diterima, oleh karena tujuan 
dari surat peringatan untuk meningkatkan kinerja auditor agar angka kredit 
bisa tercapai, namun dalam gugatan sekarang ini sebenarnya angka kredit 
Disclaimer
Kepaniteraan Mahkamah Agung Republik Indonesia berusaha untuk selalu mencantumkan informasi paling kini dan akurat sebagai bentuk komitmen Mahkamah Agung untuk pelayanan publik, transparansi dan akuntabilitas
pelaksanaan fungsi peradilan. Namun dalam hal-hal tertentu masih dimungkinkan terjadi permasalahan teknis terkait dengan akurasi dan keterkinian informasi yang kami sajikan, hal mana akan terus kami perbaiki dari waktu kewaktu.
Dalam hal Anda menemukan inakurasi informasi yang termuat pada situs ini atau informasi yang seharusnya ada, namun belum tersedia, maka harap segera hubungi Kepaniteraan Mahkamah Agung RI melalui :
 Halaman 10


# Halaman 11

penggugat adalah berjumlah 556,094, sedangkan angka kredit yang diminta 
minimal berjumlah 550,000, namun berdasarkan Penetapan Angka Kredit 
Jabatan  Fungsional Auditor tertanggal 4 Agustus 2014 TIDAK DAPAT 
DIPERTIMBANGKAN UNTUK KENAIKAN PANGKAT/JABATAN PEMBINA 
Tk.1/Gol.IV/b dan  yang penggugat terima adalah pemberhentian dari 
jabatan sebagai auditor.
b. Peraturan Kepala Badan Kepegawaian Negara No.21 Tahun  2010 tentang 
Ketentuan Pelaksanaan Peraturan Pemerintah Nomor 53 Tahun  2010 
Tentang Disiplin Pegawai Negara Sipil, pada angka IV tentang PEJABAT 
YANG BERWENANG MENGHUKUM ditentukan secara limitatif yaitu :
1. Presiden
2. Instansi Pusat
3. Kepala Perwakilan Republik Indonesia
4. Instansi Daerah Provensi
5. Gubernur
6. Instansi Daerah Kabupaten/Kota dan seterusnya.
Dan dijelaskan dalam Peraturan Bersama Kepala Badan Pengawasan 
Keuangan Dan Pembangunan dan Kepala Badan Kepegawaian Negara 
Nomor  :PER-1310/K/JF/2008, Nomor  : 24 Tahun 2008 Tentang Petunjuk 
Pelaksanaan Jabatan Fungsional Auditor Dan Angka Kreditnya, dalam Bab 
I Ketentuan Umum Pasal 1butir 8 berbunyi :
“Pejabat Pembina Kepegawaian Pusat adalah Menteri,  Jaksa Agung,  
Pimpinan Kesekretariatan Lembaga Kepresidenan, Kepala Kepolisian 
Negara, Pimpinan Lembaga Non Departemen,  Pimpinan Kesekretariatan 
Lembaga Tinggi Negara …… .”
 Halaman 11 dari 53 halaman Putusan No.78/G/2015/PTUN-JKT  
Disclaimer
Kepaniteraan Mahkamah Agung Republik Indonesia berusaha untuk selalu mencantumkan informasi paling kini dan akurat sebagai bentuk komitmen Mahkamah Agung untuk pelayanan publik, transparansi dan akuntabilitas
pelaksanaan fungsi peradilan. Namun dalam hal-hal tertentu masih dimungkinkan terjadi permasalahan teknis terkait dengan akurasi dan keterkinian informasi yang kami sajikan, hal mana akan terus kami perbaiki dari waktu kewaktu.
Dalam hal Anda menemukan inakurasi informasi yang termuat pada situs ini atau informasi yang seharusnya ada, namun belum tersedia, maka harap segera hubungi Kepaniteraan Mahkamah Agung RI melalui :
 Halaman 11


# Halaman 12

Dengan demikian berdasarkan kedua peraturan tersebut diatas, maka untuk 
Penggugat dengan pangkat Pembina (IVa ) apabila terjadi pemberhentian 
dari jabatan, maka sesuai peraturan yang berlaku maka yang menanda 
tangani Surat Keputusannya tentang pemberhentian adalah harus  Menteri 
Agama Repulik Indonesia langsung sebagai Pejabat Pembina Kepegawaian 
(PPK) tingkat instansi pusat, namun entah kenapa tergugat telah melanggar  
prosedur dan ketentuan yang berlaku karena ternyata Surat Keputusan 
Menteri Agama RI No.B.II/3/00311 tanggal 16 Januari 2015 tentang 
Pemberhentiqan Dari Jabatan Auditor telah ditanda tangani oleh Sekretaris 
Jenderal yang bertindak atas nama Menteri Agama RI., dengan diparaf oleh 
satu orang eselon;
Sebagai bahan pembanding Penggugat sampaikan contoh Surat Keputusan 
Menteri Agama RI NO.B.II/3/PDJ/15616  atas nama H.SUHENDAR,  S.Pd, 
dimana Surat Keputusan aquo ditanda tangani oleh Menteri Agama RI 
(pada saat itu adalah Bapak Suryadharma Ali) sebagai Menteri Agama RI 
yang diparaf oleh dua orang eselon I dan eselon II (terlampir bukti P.5).;
11.Pasal 53 ayat (2) huruf b Undang-Undang No.9 Tahun  2004 tentang 
Perubahan atas Undang-Undang No.5 Tahun  1986 tentang Peradilan Tata 
Usaha Negara  : “Keputusan Tata Usaha Negara yang digugat itu 
bertentangan dengan asas-asas umum pemerintahan yang baik” 
Bahwa surat keputusan Tergugat tersebut telah salah dasar dan salah 
pertimbangan yang dimana surat keputusan tersebut menjadi tidak valid dan 
tentunya hal ini bertentangan dengan perundang-undangan dan Asas-asas 
Umum Pemerintahan yang Baik (AUPB ), yang sebagaimanan dicantumkan 
dalam Undang-Undang No.28  Tahun  1999 tentang Penyelenggaraan 
Disclaimer
Kepaniteraan Mahkamah Agung Republik Indonesia berusaha untuk selalu mencantumkan informasi paling kini dan akurat sebagai bentuk komitmen Mahkamah Agung untuk pelayanan publik, transparansi dan akuntabilitas
pelaksanaan fungsi peradilan. Namun dalam hal-hal tertentu masih dimungkinkan terjadi permasalahan teknis terkait dengan akurasi dan keterkinian informasi yang kami sajikan, hal mana akan terus kami perbaiki dari waktu kewaktu.
Dalam hal Anda menemukan inakurasi informasi yang termuat pada situs ini atau informasi yang seharusnya ada, namun belum tersedia, maka harap segera hubungi Kepaniteraan Mahkamah Agung RI melalui :
 Halaman 12


# Halaman 13

Negara Yang Bersih dan Bebas KKN, yaitu : Adanya Asas Kecermatan yaitu 
suatu tap harus diambil dan disusun dengan cermat (pihak ketiga, hearing, 
nasihat) dan Asas Pemberian Alasan yang dimana tap harus memberikan 
alasan, harus ada dasar fakta yang teguh dan alasannya harus mendukung.
a. Bahwa Surat Keputusan Menteri Agama RI No.B.II/3/00311 tanggal 16 
Januari 2015 tentang Pemberhentian  Dari Jabatan Auditor pada bagian 
diktum “membaca ”  yang berbunyi :
Surat Inspektur Jenderal Kementerian Agama Nomor  :Set.IJ/2.b/
Kp.04.2 /1126/2014 tanggal 29 Desember  2014 tentang usulan 
Pemberhentian Dari Jabatan Fungsional Auditor Kepegawaian Madya 
atas nama  H. Agus Susanto,SH NIP  19630722.199303.1.002
terasa sangat aneh dan janggal oleh karena Penggugat diberhentikan dari 
jabatan Fungsional Auditor Kepegawaian Madya berlaku sejak tanggal 2 
Oktober 2014, seharusnya  usulan Surat Inspektur Jenderal Kementerian 
Agama   disampaikan sebelum tanggal 2 Oktober 2014 yaitu sebelum 
pemberhentian  diberlakukan;
Namun pada kenyataannya surat usulan usulan Inspektur Jenderal 
kementerian termaksud tentang usulam diterbitkan pada tanggal 29 
Desember 2014, maka menurut penggugat jelas-jelas surat usulan tersebut 
sangat terlambat dikeluarkannya dan terkesan hanya formalitas belaka;
b. Bahwa Surat Keputusan Menteri Agama RI No.B.II/3/00311 tanggal 16 
Januari 2015 tentang Pemberhentian Dari Jabatan Auditorpada bagian 
diktum “membaca ” yang berbunyi :
 Halaman 13 dari 53 halaman Putusan No.78/G/2015/PTUN-JKT  
Disclaimer
Kepaniteraan Mahkamah Agung Republik Indonesia berusaha untuk selalu mencantumkan informasi paling kini dan akurat sebagai bentuk komitmen Mahkamah Agung untuk pelayanan publik, transparansi dan akuntabilitas
pelaksanaan fungsi peradilan. Namun dalam hal-hal tertentu masih dimungkinkan terjadi permasalahan teknis terkait dengan akurasi dan keterkinian informasi yang kami sajikan, hal mana akan terus kami perbaiki dari waktu kewaktu.
Dalam hal Anda menemukan inakurasi informasi yang termuat pada situs ini atau informasi yang seharusnya ada, namun belum tersedia, maka harap segera hubungi Kepaniteraan Mahkamah Agung RI melalui :
 Halaman 13


# Halaman 14

“Surat Inspektur Jenderal Kementerian Agama Nomor  : Set.IJ/2.b/ 
Kp.04.2/1126/2014 tanggal 29 Desember  2014, tentang usul 
Pemberhentian dari Jabatan Fungsional Auditor Kepegawaian Madya 
atas nama H.Agus Susanto,SH, NIP 19630722.199303.1.002”
Jabatan tersebut tidaklah sesuai dengan yang sebenarnya, oleh karena 
jabatan Penggugat yang benar adalah AUDITOR AHLI MADYA dan bukan 
Fungsional Auditor Kepegawaian Madya;
c. Bahwa Surat Keputusan Menteri Agama RI No.B.II/3/00311, tanggal 16 
Januari 2015 tentang Pemberhentian Dari Jabatan Auditor pada bagian 
memutuskan yang berbunyi :
“Memberhentikan dengan hormat H.  Agus Susanto,  S.H, NIP 
196630722.199303.1.002 Pembina Tk.1 (IV/a) dari jabatan Fungsional 
Auditor Kepegawaian Madya pada Inspektorat Wilayah III Inspektorat 
Jenderal Kementerian Agama”.
Sekali lagi Penggugat tegaskan jabatan Penggugat yang benar adalah 
Fungsional Auditor Ahli Madya dan bukan Fungsional Auditor Kepegawaian 
Madya sebagaimana yang disebutkan dalam Surat Keputusan 
Pemberhentian aquo pada bagian memutuskan;
d. Pertimbangan yang diambil dalam Surat Keputusan Tergugat 
No.B.II/3/00311, tanggal 16 Januari 2015 tentang Pemberhentian Dari 
Jabatan Auditor tidak cermat yaitu : Bahwa dalam rangka menindak 
lanjuti BAB IV Pasal 40 butir (a) Peraturan Menteri Pendayagunaan 
Aparatur Negara dan Reformasi Birokrasi  RI No.40 Tahun  2012 tanggal 
17 Juli 2012, adalah keliru dan tidak cermat oleh karena Peraturan 
Menteri Pendayagunaan Aparatur Negara dan Reformasi Birokrasi  RI 
Disclaimer
Kepaniteraan Mahkamah Agung Republik Indonesia berusaha untuk selalu mencantumkan informasi paling kini dan akurat sebagai bentuk komitmen Mahkamah Agung untuk pelayanan publik, transparansi dan akuntabilitas
pelaksanaan fungsi peradilan. Namun dalam hal-hal tertentu masih dimungkinkan terjadi permasalahan teknis terkait dengan akurasi dan keterkinian informasi yang kami sajikan, hal mana akan terus kami perbaiki dari waktu kewaktu.
Dalam hal Anda menemukan inakurasi informasi yang termuat pada situs ini atau informasi yang seharusnya ada, namun belum tersedia, maka harap segera hubungi Kepaniteraan Mahkamah Agung RI melalui :
 Halaman 14


# Halaman 15

No.40 Tahun  2012 tanggal 17 Juli 2012, menyangkut BAB IV hanya ada 
pasal 9 saja tentang JENJANG JABATAN DAN PANGKAT, sedangkan 
pasal 40 adanya di BAB XIV dan Peraturan Menteri Pendayagunaan 
Aparatur Negara dan Reformasi Birokrasi  RI No.40 Tahun  2012 tanggal 
17 Juli 2012 adalah tentang Jabatan Fungsional Auditor Kepegawaian 
Dan Angka Kreditnya bukan tentang Jabatan Fungsional Auditor Dan 
Angka Kreditnya;
e. Bahwa pemberhentian Penggugat dari jabatan fungsional auditor, tidak 
dapat diterapkan berdasarkan Peraturan Menteri Pendayagunaan 
Aparatur Negara dan Reformasi Birokrasi RI No.40 Tahun  2012 tentang 
Jabatan Fungsional Auditor Kepegawaian Dan Angka Kreditnya, tetapi 
haruslah berdasarkan Peraturan Menteri Pendayagunaan Aparatur 
Negara dan Reformasi Birokrasi RI Nomor : Per/220/M.PAN/7/2008 
tentang Jabatan Fungsional Auditor Dan Angka Kreditnya, oleh karena 
jabatan Penggugat adalah FUNGSIONAL AUDITOR.
f. Bahwa begitu pula judul Surat Keputusan Tergugat aquo tentang 
PEMBERHENTIAN DARI JABATAN AUDITOR,  namun isi putusannya 
PEMBERHENTIAN DARI JABATAN AUDITOR KEPEGAWAIAN,  hal ini 
tentunya sangat berbeda sekali;
12.Bahwa walaupun Penggugat telah diberhentikan dari jabatan auditor 
berdasarkan Keputusan Menteri Agama RI No.B.II/3/00310, tanggal 16 
Januari 2015 tentang Pemberhentian Dari Jabatan Auditor yang berlaku 
sejak tanggal 2 April 2014, namun sungguh aneh karena   pada 
kenyataannya Penggugat tetap dipekerjakan sebagai auditor seperti 
biasanya sebagaimana pada tanggal 4 Februari 2015 Penggugat mendapat 
 Halaman 15 dari 53 halaman Putusan No.78/G/2015/PTUN-JKT  
Disclaimer
Kepaniteraan Mahkamah Agung Republik Indonesia berusaha untuk selalu mencantumkan informasi paling kini dan akurat sebagai bentuk komitmen Mahkamah Agung untuk pelayanan publik, transparansi dan akuntabilitas
pelaksanaan fungsi peradilan. Namun dalam hal-hal tertentu masih dimungkinkan terjadi permasalahan teknis terkait dengan akurasi dan keterkinian informasi yang kami sajikan, hal mana akan terus kami perbaiki dari waktu kewaktu.
Dalam hal Anda menemukan inakurasi informasi yang termuat pada situs ini atau informasi yang seharusnya ada, namun belum tersedia, maka harap segera hubungi Kepaniteraan Mahkamah Agung RI melalui :
 Halaman 15


# Halaman 16

tugas untuk mengaudit Kinerja Tahun  Anggaran 2014 di Kantor 
Kementerian Agama Kota Metro Lampung sesuai dengan Surat Tugas 
Nomor  : IJ/1.a/PS.00.1/0111/ 2015 (lampiran bukti P.6);
13.Bahwa Penggugat bersama teman-teman sekantor yang mempunyai 
permasalahan yang sama pernah menyampaikan surat mohon keadilan 
kepada Bapak Menteri Agama RI,  (lampiran bukti P.7),namun hingga 
sekarang belum mendapat tanggapan sehingga dengan terpaksa 
penggugat mengajukan gugatan dalam perkara sekarang ini;
14.Berdasarkan uraian-uraian tersebut diatas telah sesuai dengan Pasal 53 
ayat (2) huruf a dan b UU No. 9 Tahun  2004, untuk itu Surat Keputusan 
Menteri Agama  RI No.B.II/3/00311 tanggal 16 Januari 2015 tentang 
Pemberhentian Dari Jabatan Auditor atas nama H. Agus Susanto, SH  
dinyatakan batal atau tidak sah;
Dengan demikian berdasarkan alasan-alasan tersebut diatas, Penggugat 
memohon kepada Pengadilan Tata Usaha Negara Jakarta untuk memeriksa, 
memutus serta menyelesaikan berdasarkan hukum, keadilan dan kebenaran 
sebagai berikut :
1. Mengabulkan gugatan Penggugat untuk seluruhnya;
2. Menyatakan batal atau tidak sah Surat Keputusan Menteri Agama RI 
No.B.II/3/00311tanggal 16 Januari 2015 tentang Pemberhentian Dari 
Jabatan Auditor  atas nama H. Agus Susanto,SH dengan segala akibat 
hukumnya ;
Disclaimer
Kepaniteraan Mahkamah Agung Republik Indonesia berusaha untuk selalu mencantumkan informasi paling kini dan akurat sebagai bentuk komitmen Mahkamah Agung untuk pelayanan publik, transparansi dan akuntabilitas
pelaksanaan fungsi peradilan. Namun dalam hal-hal tertentu masih dimungkinkan terjadi permasalahan teknis terkait dengan akurasi dan keterkinian informasi yang kami sajikan, hal mana akan terus kami perbaiki dari waktu kewaktu.
Dalam hal Anda menemukan inakurasi informasi yang termuat pada situs ini atau informasi yang seharusnya ada, namun belum tersedia, maka harap segera hubungi Kepaniteraan Mahkamah Agung RI melalui :
 Halaman 16


# Halaman 17

3. Mewajibkan Tergugat untuk mencabut Surat Keputusan Menteri Agama RI 
No.B.II/3/00311 tanggal 16 Januari 2015 tentang Pemberhentian Dari 
Jabatan Auditor  atas nama H.Agus Susanto,SH;
4. Mewajibkan Tergugat untuk merehabilitasi dan mengembalikan hak dan 
kewajiban Penggugat pada posisi semula sebagai Fungsional Auditor Ahli 
Madya ;
5. Membebankan biaya yang timbul dalam biaya perkara ini kepada Tergugat.
Menimbang, bahwa atas Gugatan Penggugat tersebut Tergugat telah 
mengajukan Jawaban pada persidangan tanggal  25 Mei 2015,  yang isinya 
sebagai berikut; 
I. DALAM POKOK PERKARA
1. Bahwa Tergugat menolak dan membantah secara tegas seluruh dalil-dalil 
gugatan Penggugat kecuali mengenai hal-hal yang secara jelas dan tegas 
diakui kebenarannya.
2. Bahwa benar Tergugat telah menerbitkan Surat Keputusan Menteri Agama 
Nomor  : B.II/3/003111 tanggal 16 Januari 2015 tentang Pemberhentian 
Dengan Hormat dari Jabatan Fungsional Auditor pada Inspektorat Jenderal 
Kementerian Agama Jakarta kepada  H. Agus Susanto,SH  NIP.  
196307221993031002 , pangkat/ golongan ruang: Pembina  (IV/a), Unit 
Kerja: Inspektorat Jenderal Kementerian Agama Jakarta, selanjutnya 
disebut SK a quo; 
3. Bahwa penerbitan SK a quo  telah melalui prosedur dan sesuai dengan 
kewenangan serta peraturan perundang-undangan yang berlaku 
sebagaimana akan dijelaskan dalam dalil-dalil di bawah ini:
 Halaman 17 dari 53 halaman Putusan No.78/G/2015/PTUN-JKT  
Disclaimer
Kepaniteraan Mahkamah Agung Republik Indonesia berusaha untuk selalu mencantumkan informasi paling kini dan akurat sebagai bentuk komitmen Mahkamah Agung untuk pelayanan publik, transparansi dan akuntabilitas
pelaksanaan fungsi peradilan. Namun dalam hal-hal tertentu masih dimungkinkan terjadi permasalahan teknis terkait dengan akurasi dan keterkinian informasi yang kami sajikan, hal mana akan terus kami perbaiki dari waktu kewaktu.
Dalam hal Anda menemukan inakurasi informasi yang termuat pada situs ini atau informasi yang seharusnya ada, namun belum tersedia, maka harap segera hubungi Kepaniteraan Mahkamah Agung RI melalui :
 Halaman 17


# Halaman 18

a. Penerbitan SK a quo  telah sesuai dengan prosedur sebagaimana   
dijelaskan dalam dalil-dalil di bawah ini:
1. Bahwa sebelum SK a quo  diterbitkan, Badan Pengawasan Keuangan 
dan Pembangunan Pusat Pembinaan Jabatan Fungsional Auditor 
berdasarkan Surat Tugas Nomor ST-698/JF/2/2014 pada tanggal 22 
Agustus 2014 yang ditandatangani Kepala Pusat untuk 
menyelesaikan evaluasi penerapan Jabatan Fungsional Auditor pada 
Inspektorat Jenderal Kementerian Agama; 
2. Bahwa menindaklanjuti surat tugas tersebut tim Badan Pengawasan 
Keuangan dan Pembangunan Pusat Pembinaan Jabatan Fungsional 
Auditor Nomor LHE-497/JF/2/2014 tanggal 29 Desember 2014, 
tentang hasil evaluasi atas penerapan Jabatan Fungsional Auditor 
pada Inspektorat Jenderal Kementerian Agama;
3. Bahwa dari hasil tersebut tim Badan Pengawasan Keuangan dan 
Pembangunan Pusat Pembinaan Jabatan Fungsional Auditor 
membuat notisi evaluasi atas penerapan Jabatan Fungsional Auditor 
pada Inspektorat Jenderal Kementerian Agama Tahun 2014;
4. Bahwa Inspektorat Jenderal menindaklanjuti hasil tim Badan 
Pengawasan Keuangan dan Pembangunan Pusat Pembinaan 
Jabatan Fungsional Auditor mengusulkan Pembebasan jabatan 
kepada Biro Kepegawaian Sekretariat Jenderal Kemeneterian Agama 
berdasarkan surat Nomor; Set. IJ/2.b/Kp.04.2/1125/2014 tanggal 29 
Desember  2014 tentang usul Pembebasan Sementara dari jabatan 
Fungsional Auditor kepada Penggugat;
Disclaimer
Kepaniteraan Mahkamah Agung Republik Indonesia berusaha untuk selalu mencantumkan informasi paling kini dan akurat sebagai bentuk komitmen Mahkamah Agung untuk pelayanan publik, transparansi dan akuntabilitas
pelaksanaan fungsi peradilan. Namun dalam hal-hal tertentu masih dimungkinkan terjadi permasalahan teknis terkait dengan akurasi dan keterkinian informasi yang kami sajikan, hal mana akan terus kami perbaiki dari waktu kewaktu.
Dalam hal Anda menemukan inakurasi informasi yang termuat pada situs ini atau informasi yang seharusnya ada, namun belum tersedia, maka harap segera hubungi Kepaniteraan Mahkamah Agung RI melalui :
 Halaman 18


# Halaman 19

5. Bahwa selanjutnya mengusulkan Pemberhentian dari Jabatan 
Fungsional Auditor atas nama Penggugat berdasarkan Surat 
Inspektur  Inspektur Jenderal Kementerian Agama Nomor: Set.IJ/2.b/
Kp.04.2/1126/2014 tanggal 29 Desember 2014 tentang usul 
Pemberhentian dari Jabatan Fungsional Auditor atas nama 
Penggugat;
6. Bahwa pada tanggal 16 Januari 2015 diterbitkan Surat Keputusan 
Menteri Agama Nomor: B.II/3/00310 tentang usulan Pemberhentian 
Dengan Hormat dari Jabatan Fungsional Auditor kepada Penggugat;
Bahwa berdasarkan urian tersebut penerbitan SK a quo   telah sesuai 
dengan Prosedur dan peraturan Perundang-undangan yang berlaku
a. Penerbitan SK a quo  telah sesuai dengan kewenangan yang ada 
pada Tergugat berdasarkan pada:
1) Undang-undang Nomor  5 Tahun Tahun 2014 tentang Aparatur Sipil Negara 
(selanjutnya disebut ASN).
Pasal 1 angka 14 berbunyi: ”Pejabat Pembina Kepegawaian adalah 
pejabat yang mempunyai kewenangan menetapkan 
pengangkatan,pemindahan, dan pemberhentian Pegawai ASN dan 
pembinaan Manajemen ASN di instansi pemerintah sesuai dengan 
ketentuan peraturan perundang-undangan ”.
Pasal 53 berbunyi: ”Presiden selaku pemegang kekuasaan tertinggi 
pembinaan ASN dapat mendelegasikan kewenangan menetapkan 
pengangkatan, pemindahan, dan pemberhentian pejabat selain 
 Halaman 19 dari 53 halaman Putusan No.78/G/2015/PTUN-JKT  
Disclaimer
Kepaniteraan Mahkamah Agung Republik Indonesia berusaha untuk selalu mencantumkan informasi paling kini dan akurat sebagai bentuk komitmen Mahkamah Agung untuk pelayanan publik, transparansi dan akuntabilitas
pelaksanaan fungsi peradilan. Namun dalam hal-hal tertentu masih dimungkinkan terjadi permasalahan teknis terkait dengan akurasi dan keterkinian informasi yang kami sajikan, hal mana akan terus kami perbaiki dari waktu kewaktu.
Dalam hal Anda menemukan inakurasi informasi yang termuat pada situs ini atau informasi yang seharusnya ada, namun belum tersedia, maka harap segera hubungi Kepaniteraan Mahkamah Agung RI melalui :
 Halaman 19


# Halaman 20

pejabat pimpinan tinggi utama dan madya, dan pejabat fungsional 
keahlian utama kepada: a. menteri di kementerian; b. .........”.
2) Peraturan Pemerintah Nomor 9 Tahun  2003 Jo. Nomor  63 Tahun  2009 
tentang Wewenang Pengangkatan,  Pemindahan, dan Pemberhentian 
Pegawai Negeri Sipil. 
Pasal 12 berbunyi: ”Pejabat Pembina Kepegawaian Pusat 
menetapkan pengangkatan,  pemindahan, dan pemberhentian 
Pegawai Negeri Sipil Pusat di lingkungannya dalam dan dari jabatan 
struktural eselon II ke bawah atau jabatan fungsional yang 
jenjangnya setingkat dengan itu”.
3) Keputusan Menteri Agama Nomor 492 Tahun  2003 tentang Pemberian 
Kuasa dan Pendelegasian Wewenang Pengangkatan Pemindahan dan 
Pemberhentian Pegawai Negeri Sipil, di Lingkungan Departemen Agama
Dalam Lampiran Keputusan Menteri Agama Nomor 492 Tahun  2003 
tersebut Pejabat (Sekretaris Jenderal Departemen Agama) diberi 
wewenang untuk memberikan penjatuhan hukuman disiplin berupa 
“Pembebasan dari jabatan” terhadap “Pejabat Fungsional”. (Kolom 
1, butir 1.huruf c)
4) Bahwa Penjatuhan Hukuman Disiplin berupa pembebasan jabatan terhadap 
Penggugat juga didasarkan atas Keputusan Menteri Agama Nomor 489 
Tahun  2003 tentang Pendelegasian wewenang penjatuhan hukuman disiplin 
Pegawai Negeri Sipil di lingkungan Departemen Agama  (Pasal 2)
Disclaimer
Kepaniteraan Mahkamah Agung Republik Indonesia berusaha untuk selalu mencantumkan informasi paling kini dan akurat sebagai bentuk komitmen Mahkamah Agung untuk pelayanan publik, transparansi dan akuntabilitas
pelaksanaan fungsi peradilan. Namun dalam hal-hal tertentu masih dimungkinkan terjadi permasalahan teknis terkait dengan akurasi dan keterkinian informasi yang kami sajikan, hal mana akan terus kami perbaiki dari waktu kewaktu.
Dalam hal Anda menemukan inakurasi informasi yang termuat pada situs ini atau informasi yang seharusnya ada, namun belum tersedia, maka harap segera hubungi Kepaniteraan Mahkamah Agung RI melalui :
 Halaman 20


# Halaman 21

Dalam Lampiran Keputusan Menteri Agama Nomor 489 Tahun  
2003 tersebut Pejabat Struktural Eselon I (Sekretaris Jenderal 
Departemen Agama ) diberi wewenang untuk memberikan 
penjatuhan hukuman disiplin berupa “Pembebasan dari jabatan” 
terhadap “Pejabat Fungsional”. (Kolom 1, butir 1.8)
Bahwa  Auditor merupakan jabatan fungsional, oleh karenanya 
penerbitan SK a quo  yang ditandatangani oleh Sekretaris Jenderal 
Dep. Agama  atas nama Menteri Agama   sesuai dengan 
kewenangan dan oleh karenanya tidak bertentangan dengan KMA 
Nomor  489 Tahun  2003
Bahwa Penggugat menduduki jabatan fungsional tertentu jenjang utama 
di lingkungannnya oleh karena itu berdasarkan uraian tersebut di atas 
dapat dipahami, penerbitan SK a quo  sudah sesuai dengan 
kewenangan yang diatur di dalam peraturan perundang-undangan yang 
berlaku.
4. Bahwa Penerbitan SK a quo  telah sesuai dengan peraturan Perundang-
undangan yang berlaku, sebagaimana Tergugat jelaskan dalam dalil-dalil 
dibawah ini:
a. Bahwa sebelum SK a quo diterbitkan, Badan Pengawasan Keuangan 
dan Pembangunan Pusat Pembinaan Jabatan Fungsional Auditor 
berdasarkan Surat Tugas Nomor ST-698/JF/2/2014 pada tanggal 22 
Agustus 2014 yang ditandatangani Kepala Pusat untuk 
menyelesaikan evaluasi penerapan Jabatan Fungsional Auditor pada 
Inspektorat Jenderal Kementerian Agama; 
 Halaman 21 dari 53 halaman Putusan No.78/G/2015/PTUN-JKT  
Disclaimer
Kepaniteraan Mahkamah Agung Republik Indonesia berusaha untuk selalu mencantumkan informasi paling kini dan akurat sebagai bentuk komitmen Mahkamah Agung untuk pelayanan publik, transparansi dan akuntabilitas
pelaksanaan fungsi peradilan. Namun dalam hal-hal tertentu masih dimungkinkan terjadi permasalahan teknis terkait dengan akurasi dan keterkinian informasi yang kami sajikan, hal mana akan terus kami perbaiki dari waktu kewaktu.
Dalam hal Anda menemukan inakurasi informasi yang termuat pada situs ini atau informasi yang seharusnya ada, namun belum tersedia, maka harap segera hubungi Kepaniteraan Mahkamah Agung RI melalui :
 Halaman 21


# Halaman 22

b. Bahwa menindaklanjuti surat tugas tersebut tim Badan Pengawasan 
Keuangan dan Pembangunan Pusat Pembinaan Jabatan Fungsional 
Auditor Nomor LHE-497/JF/2/2014 tanggal 29 Desember 2014, dan 
berdasarkan fakta dan data hasil evaluasi atas penerapan Jabatan 
Fungsional Auditor pada Inspektorat Kementerian Agama sebagai 
berikut:
1) Terdapat auditor yang sampai dengan tahun kelima dijabatan/
pangkatnya belum dapat mengumpulkan Angka Kredit yang 
dibutuhkan untuk naik ke jenjang jabatan/pangkat dalam hal ini 
Penggugat;
2) Terlewatinya batas waktu dan perolehan Angka Kredit bagi auditor 
disebabkan kurangnya kepedulian auditor terhadap peraturan ke 
Jabatan fungsional auditor;
3) Terdapat auditor yang harus diberhentikan dari Jabatan Fungsional 
Auditor karena tidak dapat mencapai perolehan angka kredit yang 
dipersyaratkan dalam hal ini Penggugat;
a. Bahwa Inspektorat Jenderal menindaklanjuti hasil tim Badan 
Pengawasan Keuangan dan Pembangunan Pusat Pembinaan 
Jabatan Fungsional Auditor dan mengusulkan surat Nomor; Set. 
IJ/2.b/Kp.04.2/1125/2014 tanggal 29 Desember 2014 dan Nomor:  
Set.Ij/2.b/Kp.04.2/1126/2014 tanggal 29 Desember 2014 kepada Biro 
Kepegawaian tentang usulan Pemberhentian Dengan Hormat dari 
Jabatan Fungsional Auditor
b. Bahwa berdasarkan ketentuan Pasal 13 PerMenpan  220 tahun 2008 
tentang Jabatan Fungsional Auditor dan Angka Kreditnya berbunyi:
Disclaimer
Kepaniteraan Mahkamah Agung Republik Indonesia berusaha untuk selalu mencantumkan informasi paling kini dan akurat sebagai bentuk komitmen Mahkamah Agung untuk pelayanan publik, transparansi dan akuntabilitas
pelaksanaan fungsi peradilan. Namun dalam hal-hal tertentu masih dimungkinkan terjadi permasalahan teknis terkait dengan akurasi dan keterkinian informasi yang kami sajikan, hal mana akan terus kami perbaiki dari waktu kewaktu.
Dalam hal Anda menemukan inakurasi informasi yang termuat pada situs ini atau informasi yang seharusnya ada, namun belum tersedia, maka harap segera hubungi Kepaniteraan Mahkamah Agung RI melalui :
 Halaman 22


# Halaman 23

Pasal 13 
” Jumlah angka kredit kumulatif minimal yang harus dipenuhi oleh setiap 
Pegawai Negeri Sipil untuk dapat diangkat dalam jabatan/pangkat 
auditor” 
Pasal 31 
ayat (1) “ Bahwa auditor Pelaksana, pangkat pengatur, golongn ruang II/
c sampai dengan Auditor Penyelia, pangkat Penata, golongan ruang III/
c dan Auditor Pertama,  pangkat Penata Muda,  golongan ruang III/a 
sampai dengan Auditor Utama,  pangkat Pembina Utama Madya,  
golongan ruang IV/d”.
ayat (2) “Bahwa berdasarkan ketentuan tersebut Penggugat dalam 
jangka waktu 1 (satu) tahun sejak dibebaskan sementara tanggal 1 April 
2013 tidak dapat mengumpulkan Angka Kredit minimal yang 
ditentukan”.
c. Bahwa berdasarkan Pasal 8 PerMenpan  220 tahun 2008 tentang 
Jabatan Fungsional Auditor dan Angka Kreditnya berbunyi:
Pasal 8
“bahwa dalam hal penugasan auditor berbentuk tim mandiri, susunan 
tim adalah adalah sebagai berikut:
a.  pengendali mutu;
b.  pengendali teknis;
c.  ketua tim; dan
 Halaman 23 dari 53 halaman Putusan No.78/G/2015/PTUN-JKT  
Disclaimer
Kepaniteraan Mahkamah Agung Republik Indonesia berusaha untuk selalu mencantumkan informasi paling kini dan akurat sebagai bentuk komitmen Mahkamah Agung untuk pelayanan publik, transparansi dan akuntabilitas
pelaksanaan fungsi peradilan. Namun dalam hal-hal tertentu masih dimungkinkan terjadi permasalahan teknis terkait dengan akurasi dan keterkinian informasi yang kami sajikan, hal mana akan terus kami perbaiki dari waktu kewaktu.
Dalam hal Anda menemukan inakurasi informasi yang termuat pada situs ini atau informasi yang seharusnya ada, namun belum tersedia, maka harap segera hubungi Kepaniteraan Mahkamah Agung RI melalui :
 Halaman 23


# Halaman 24

d.  anggota tim dengan rincian masing-masing”
e. Bahwa sesuai ketentuan Permenpan Nomor:  
PER/220/M.PAN/7/2008, Pasal 31 ayat (1) 
menyebutkan bahwa Auditor Pelaksana, pangkat 
Pengatur, golongan ruang II/c sampai dengan 
Auditor Penyelia, pangkat Penata, golongan 
ruang III/c dan Auditor Pertama, pangkat Penata 
Muda, golongan ruang III/a sampai dengan 
Auditor Utama, pangkat Pembina madya,  
golongan ruang IV/d, dibebaskan sementara dari 
jabatannya, apabila dalam jangka waktu 5 (lima) 
tahun sejak menduduki jabatan/pangkat terakhir 
tidak daapt mengumpulkan angka kredit minimal 
yang ditentukan untuk kenaikan pangkat 
setingkat lebih tinggi di jabatannya.
f. Bahwa selanjutnya berdasarkan evaluasi 
Penggugat dalam jangka waktu 1 (satu) tahun 
sejak dibebaskan sementara dari jabatannya, 
yang bersangkutan tidak mengumpulkan Angka 
Kredit minimal yang ditentukan, oleh karena itu  
ketentuan Permenpan Nomor:  PER/220/
M.PAN/7/2008, Pasal 33 huruf b, bahwa auditor 
diberhentikan dari jabatannya, apabila dalam 
jangka waktu 1 9satu) tahun sejak dibebaskan 
sementara dari jabatannya sebagaimana 
Disclaimer
Kepaniteraan Mahkamah Agung Republik Indonesia berusaha untuk selalu mencantumkan informasi paling kini dan akurat sebagai bentuk komitmen Mahkamah Agung untuk pelayanan publik, transparansi dan akuntabilitas
pelaksanaan fungsi peradilan. Namun dalam hal-hal tertentu masih dimungkinkan terjadi permasalahan teknis terkait dengan akurasi dan keterkinian informasi yang kami sajikan, hal mana akan terus kami perbaiki dari waktu kewaktu.
Dalam hal Anda menemukan inakurasi informasi yang termuat pada situs ini atau informasi yang seharusnya ada, namun belum tersedia, maka harap segera hubungi Kepaniteraan Mahkamah Agung RI melalui :
 Halaman 24


# Halaman 25

dimaksuid dalam Pasal 31 ayat (1), ayat 92), 
ayat (3), ayat (4), ayat (5), ayat (6), ayat (7), dan 
ayat (8) tidak dapat mengumpulkan angka  kredit 
yang ditentukan.
5. Bahwa Tergugat menolak dengan tegas dalil gugatan Penggugat angka 6 
halaman 4, dan angka 7 halaman 5 sebagaimana Tergugat uraikan dibawah 
ini:
Bahwa sudah tepat dan benar Tergugat tidak menerbitkan kenaikan 
pangkat Penggugat dari  Pembina/golongan (IV/a) menjadi Pembina tingkat 
I/golongan (IV/b) karena berdasarkan  Tim Badan Pengawasan Keuangan 
dan Pengembangan Pusat Pembinaan Jabatan Fungsional Auditor,  
Penggugat diberhentikan dari Jabatan Fungsional Auditor  karena Angka 
Kredit yang diperoleh Per 30 Juni 2014 hanya 535,640 kum, yang 
seharusnya Angka Kredit yang dipersyaratkan 550 kum, dengan demikian 
sesuai dengan ketentuan Pasal 33 huruf b dan Pasal 33 Ayat (1), Ayat (2), 
Ayat (3), Ayat (4), Ayat (5), Ayat (6), Ayat,(7), dan Ayat (7), PerMenpan 
Nomor:  PER/220/M.PAN/7/2008. Dengan demikian Penggugat tidak 
mengumpulkan angka kredit yang ditentukan.
Bahwa penerbitan Surat Keputusan Menteri Agama Nomor: B.II/3/71262 
tanggal 31 Desember 2014 tentang Pembebasan Sementara dari jabatan 
Auditor dan Surat Keputusan Menteri Agama Nomor: B.II/3/00311 tanggal 
16 Januari 2015 tentang Pemberhentian dari Jabatan Fungsional Auditor, 
menurut Tergugat sudah tepat karena berdasarkan notisi atas penerapan 
Jabatan Fungsional Auditor pada Inspektorat Jenderal Kementerian Agama 
Tahun  2014 Badan Pengawasan Keuangan dan Pembangunan Pusat 
 Halaman 25 dari 53 halaman Putusan No.78/G/2015/PTUN-JKT  
Disclaimer
Kepaniteraan Mahkamah Agung Republik Indonesia berusaha untuk selalu mencantumkan informasi paling kini dan akurat sebagai bentuk komitmen Mahkamah Agung untuk pelayanan publik, transparansi dan akuntabilitas
pelaksanaan fungsi peradilan. Namun dalam hal-hal tertentu masih dimungkinkan terjadi permasalahan teknis terkait dengan akurasi dan keterkinian informasi yang kami sajikan, hal mana akan terus kami perbaiki dari waktu kewaktu.
Dalam hal Anda menemukan inakurasi informasi yang termuat pada situs ini atau informasi yang seharusnya ada, namun belum tersedia, maka harap segera hubungi Kepaniteraan Mahkamah Agung RI melalui :
 Halaman 25


# Halaman 26

Pembinaan Jabatan Fungsional Auditor dibebaskan sejak 1 April 2013 s.d. 1 
April 2014 dan diberhentikan per 2 April 2014 kepada Penggugat.
Bahwa berdasarkan fakta tersebut membuktikan Penggugat tidak 
memenuhi syarat yang telah ditentukan, dengan demikian sudah tepat dan 
benar Tergugat menerbitkan SK a quo.
6. Bahwa Tergugat Menolak dengan Tegas dalil Penggugat  angka 9, dan 
angka 10 halaman 5 sebagaimana Tergugat uraikan dibawah ini:
a. Bahwa sebelum SK a quo diterbitkan, Badan Pengawasan Keuangan 
dan Pembangunan Pusat Pembinaan Jabatan Fungsional Auditor 
berdasarkan Surat Tugas Nomor ST-698/JF/2/2014 pada tanggal 22 
Agustus 2014 yang ditandatangani Kepa Pusat untuk menyelesaikan 
evaluasi penerapan Jabatan Fungsional Auditor pada Inspektorat 
Jenderal Kementerian Agama; 
b. Bahwa menindaklanjuti surat tugas tersebut tim Badan Pengawasan 
Keuangan dan Pembangunan Pusat Pembinaan Jabatan Fungsional 
Auditor Nomor LHE-497/JF/2/2014 tanggal 29 Desember 2014, dan 
berdasarkan fakta dan data hasil evaluasi atas penerapan Jabatan 
Fungsional Auditor pada Inspektorat Kementerian Agama sebagai 
berikut:
1) Terdapat auditor yang sampai dengan tahun kelima dijabatan/
pangkatnya belum dapat mengumpulkan Angka Kredit yang 
dibutuhkan untuk naik ke jenjang jabatan/pangkat dalam hal ini 
Penggugat;
Disclaimer
Kepaniteraan Mahkamah Agung Republik Indonesia berusaha untuk selalu mencantumkan informasi paling kini dan akurat sebagai bentuk komitmen Mahkamah Agung untuk pelayanan publik, transparansi dan akuntabilitas
pelaksanaan fungsi peradilan. Namun dalam hal-hal tertentu masih dimungkinkan terjadi permasalahan teknis terkait dengan akurasi dan keterkinian informasi yang kami sajikan, hal mana akan terus kami perbaiki dari waktu kewaktu.
Dalam hal Anda menemukan inakurasi informasi yang termuat pada situs ini atau informasi yang seharusnya ada, namun belum tersedia, maka harap segera hubungi Kepaniteraan Mahkamah Agung RI melalui :
 Halaman 26


# Halaman 27

2) Terlewatinya batas waktu dan perolehan Angka Kredit bagi 
auditor disebabkan kurangnya kepedulian auditor terhadap 
peraturan ke Jabatan fungsional auditor;
3) Terdapat auditor yang harus diberhentikan dari Jabatan 
Fungsional Auditor karena tidak dapat mencapai perolehan 
angka kredit yang dipersyaratkan dalam hal ini Penggugat;
a. Bahwa berdasarkan notisi atas penerapan Jabatan Fungsional 
Auditor pada Inspektorat Jenderal Kementerian Agama Tahun 2014 
Badan Pengawasan Keuangan dan Pembangunan Pusat Pembinaan 
Jabatan Fungsional Auditor dibebaskan sejak 1 April 2013 s.d. 1 April 
2014 dan diberhentikan per 2 April 2014 kepada Penggugat;
Bahwa berdasarkan fakta tersebut membuktikan Penggugat tidak 
memenuhi syarat yang telah ditentukan, dengan demikian sudah 
tepat dan benar Tergugat menerbitkan SK a quo dan menolak 
Penggugat yang menyatakan penerbitan SK a quo batal atau tidak 
sah;
7. Bahwa Tergugat Menolak dengan Tegas dalil gugatan Penggugat  angka 11 
huruf a dan huruf b  halaman 6 dan halaman 7 dan angka 12 huruf a s.d. 
huruf f halaman 7 dan halaman 8 sebagaimana Tergugat uraikan dibawah 
ini:
Bahwa faktanya membuktikan Penggugat tidak memenuhi syarat yang telah 
ditentukan berdasarkan tim Badan Pengawasan Keuangan dan 
Pembangunan Pusat Pembinaan Jabatan Fungsional Auditor Nomor 
LHE-497/JF/2/2014 tanggal 29 Desember 2014, dan berdasarkan fakta dan 
data hasil evaluasi atas penerapan Jabatan Fungsional Auditor pada 
 Halaman 27 dari 53 halaman Putusan No.78/G/2015/PTUN-JKT  
Disclaimer
Kepaniteraan Mahkamah Agung Republik Indonesia berusaha untuk selalu mencantumkan informasi paling kini dan akurat sebagai bentuk komitmen Mahkamah Agung untuk pelayanan publik, transparansi dan akuntabilitas
pelaksanaan fungsi peradilan. Namun dalam hal-hal tertentu masih dimungkinkan terjadi permasalahan teknis terkait dengan akurasi dan keterkinian informasi yang kami sajikan, hal mana akan terus kami perbaiki dari waktu kewaktu.
Dalam hal Anda menemukan inakurasi informasi yang termuat pada situs ini atau informasi yang seharusnya ada, namun belum tersedia, maka harap segera hubungi Kepaniteraan Mahkamah Agung RI melalui :
 Halaman 27


# Halaman 28

Inspektorat Kementerian Agama, Penggugat sampai dengan tahun kelima 
dijabatan/pangkatnya belum dapat mengumpulkan Angka Kredit yang 
dibutuhkan untuk naik ke jenjang jabatan/pangkat,terlewatinya batas waktu 
dan perolehan Angka Kredit bagi auditor disebabkan kurangnya kepedulian 
auditor terhadap peraturan ke Jabatan fungsional auditor, dan  harus 
diberhentikan dari Jabatan Fungsional Auditor karena tidak dapat mencapai 
perolehan angka kredit yang dipersyaratkan dalam hal ini Penggugat;
Bahwa seumpama benar  quod_non  Tergugat menerbitkan SK a quo tidak 
memberikan surat peringatan kepada Penggugat, bukan berarti merubah 
kesalahan Penggugat karena berdasarkan faktanya membuktikan 
Penggugat tidak memenuhi syarat yang telah ditentukan berdasarkan tim 
Badan Pengawasan Keuangan dan Pembangunan Pusat Pembinaan 
Jabatan Fungsional Auditor Nomor LHE-497/JF/2/2014 tanggal 29 
Desember  2014  dan notisi atas penerapan Jabatan Fungsional Auditor 
pada Inspektorat Jenderal Kementerian Agama Tahun 2014 Badan  
Pengawasan Keuangan dan Pembangunan Pusat Pembinaan Jabatan 
Fungsional Auditor dibebaskan sejak 1 April 2013 s.d. 1 April 2014 dan 
diberhentikan per 2 April 2014 kepada Penggugat. Dengan demikian 
penerbitan SK a quo tidak bertentangan dengan peraturan perundang-
undangan.
Bahwa berdasarkan Keputusan Menteri Agama Nomor 492 Tahun  2003 
tentang Pemberian Kuasa dan Pendelegasian Wewenang Pengangkatan 
Pemindahan dan Pemberhentian Pegawai Negeri Sipil, di Lingkungan 
Departemen Agama
Disclaimer
Kepaniteraan Mahkamah Agung Republik Indonesia berusaha untuk selalu mencantumkan informasi paling kini dan akurat sebagai bentuk komitmen Mahkamah Agung untuk pelayanan publik, transparansi dan akuntabilitas
pelaksanaan fungsi peradilan. Namun dalam hal-hal tertentu masih dimungkinkan terjadi permasalahan teknis terkait dengan akurasi dan keterkinian informasi yang kami sajikan, hal mana akan terus kami perbaiki dari waktu kewaktu.
Dalam hal Anda menemukan inakurasi informasi yang termuat pada situs ini atau informasi yang seharusnya ada, namun belum tersedia, maka harap segera hubungi Kepaniteraan Mahkamah Agung RI melalui :
 Halaman 28


# Halaman 29

Dalam Lampiran Keputusan Menteri Agama Nomor 492 Tahun 2003tersebut 
Pejabat (Sekretaris Jenderal Departemen Agama) diberi wewenang untuk 
memberikan penjatuhan hukuman disiplin berupa “Pembebasan dari jabatan” 
terhadap “Pejabat Fungsional”. (Kolom 1, butir 1.huruf c)
Bahwa Penjatuhan Hukuman Disiplin berupa pembebasan jabatan terhadap 
Penggugat juga didasarkan atas Keputusan Menteri Agama Nomor 489 Tahun  
2003 tentang Pendelegasian wewenang penjatuhan hukuman disiplin Pegawai 
Negeri Sipil di lingkungan Departemen Agama  (Pasal 2)
Dalam Lampiran Keputusan Menteri Agama Nomor 489 Tahun  2003 
tersebut Pejabat Struktural Eselon I (Sekretaris Jenderal Departemen 
Agama ) diberi wewenang untuk memberikan penjatuhan hukuman disiplin 
berupa “Pembebasan dari jabatan” terhadap “Pejabat Fungsional”. (Kolom 
1, butir 1.8)
Bahwa  Auditor merupakan jabatan fungsional, oleh karenanya penerbitan sk 
a quo yang ditandatangani oleh Sekretaris Jenderal Dep. Agama  atas nama 
Menteri Agama  sesuai dengan kewenangan dan oleh karenanya tidak 
bertentangan dengan KMA Nomor 492 Tahun  2003 dan KMA Nomor 489 
Tahun  2003 serta sesuai dengan peraturan perundang-undangan;
Bahwa penerbitan sk a quo telah sesuai prosedur dengan memperhatikan 
perbuatan Penggugat dengan aturan yang berlaku dengan dibentuknya tim 
untuk melakukan audit Jabatan Fungsional Auditor oleh Badan Pengawasan 
Keuangan dan Pembangunan Pusat Pembinaan Jabatan Fungsional Auditor 
dengan demikian sudah sesuai dengan Asas kecermatan, dengan demikian 
 Halaman 29 dari 53 halaman Putusan No.78/G/2015/PTUN-JKT  
Disclaimer
Kepaniteraan Mahkamah Agung Republik Indonesia berusaha untuk selalu mencantumkan informasi paling kini dan akurat sebagai bentuk komitmen Mahkamah Agung untuk pelayanan publik, transparansi dan akuntabilitas
pelaksanaan fungsi peradilan. Namun dalam hal-hal tertentu masih dimungkinkan terjadi permasalahan teknis terkait dengan akurasi dan keterkinian informasi yang kami sajikan, hal mana akan terus kami perbaiki dari waktu kewaktu.
Dalam hal Anda menemukan inakurasi informasi yang termuat pada situs ini atau informasi yang seharusnya ada, namun belum tersedia, maka harap segera hubungi Kepaniteraan Mahkamah Agung RI melalui :
 Halaman 29


# Halaman 30

penerbitan SK a quo sudah tepat dan benar sesuai dengan Asas Asas 
Umum Pemerintahan yang Baik;
Bahwa Penggugat tidak cermat dan tidak teliti penerbitan SK a quo dalam 
diktum “Membaca ” Bahwa Inspektorat Jenderal surat Nomor; Set. IJ/2.b/
Kp.04.2/1125/2014 tanggal 29 Desember  2014 dan Nomor:  Set.Ij/2.b/
Kp.04.2/1126/2014 tanggal 29 Desember 2014, menindaklanjuti Surat 
Tugas Nomor ST-698/JF/2/2014 pada tanggal 22 Agustus 2014 dan hasil 
tim Badan Pengawasan Keuangan dan Pembangunan Pusat Pembinaan 
Jabatan Fungsional AuditorNomor LHE-497/JF/2/2014 tanggal 29 
Desember  2014  dan notisi atas penerapan Jabatan Fungsional Auditor 
pada Inspektorat Jenderal Kementerian Agama Tahun 2014 Badan  
Pengawasan Keuangan dan Pembangunan Pusat Pembinaan Jabatan 
Fungsional Auditor memerintahkan untuk dibebaskan sejak 1 April 2013 s.d. 
1 April 2014 dan diberhentikan per 2 April 2014 kepada Penggugat, dengan 
demikian Tergugat menolak dalil Penggugat huruf a yang menyatakan tidak 
benar dan tidak tepat surat itjen terkesan hanya formalitas belaka;
Bahwa sungguh tidak cermat Penggugat membaca  penerbitan SK a quo  
tanggal 16 Januari 2015 tentang Pemberhentian dari Jabatan Fungsional 
Auditor bukan Pemberhentian dari Jabatan Fungsional Auditor 
Kepegawaian Madya;
Bahwa tidak relevan Penggugat mendalilkan sebagaimana huruf d s.d. huruf 
f karena tidak relevansinya dengan Peraturan Pendayagunaan Aparatur 
Negara dan Reformasi Birokrasi Nomor  40 Tahun  2014. Faktanya 
Disclaimer
Kepaniteraan Mahkamah Agung Republik Indonesia berusaha untuk selalu mencantumkan informasi paling kini dan akurat sebagai bentuk komitmen Mahkamah Agung untuk pelayanan publik, transparansi dan akuntabilitas
pelaksanaan fungsi peradilan. Namun dalam hal-hal tertentu masih dimungkinkan terjadi permasalahan teknis terkait dengan akurasi dan keterkinian informasi yang kami sajikan, hal mana akan terus kami perbaiki dari waktu kewaktu.
Dalam hal Anda menemukan inakurasi informasi yang termuat pada situs ini atau informasi yang seharusnya ada, namun belum tersedia, maka harap segera hubungi Kepaniteraan Mahkamah Agung RI melalui :
 Halaman 30


# Halaman 31

penerbitan SK a quo tentang Pemberhentian dari jabatan Fungsional 
Auditor;
Berdasarkan dalil-dalil sebagaimana tersebut diatas, membuktikan  bahwa 
terbitnya SK a quo telah sesuai dengan ketentuan peraturan perundang-undangan 
yang berlaku, dan tidak bertentangan dengan asas-asas umum pemerintahan yang 
baik, dan oleh karenanya SK a quo sah dan berdasarkan hukum;
Selanjutnya, mohon agar Majelis Hakim yang terhormat berkenan memberikan 
putusan;
DALAM POKOK PERKARA ;
• Menolak gugatan Penggugat seluruhnya atau setidak-
tidaknya gugatan Penggugat tidak dapat diterima;
- Menyatakan sah menurut hukum Surat Keputusan Menteri Agama Nomor : 
B.II/3/003111 tanggal 16 Januari 2015 tentang Pemberhentian Dengan Hormat 
dari Jabatan Fungsional Auditor pada Inspektorat Jenderal Kementerian 
Agama Jakarta kepada H. Agus Susanto,SH NIP. 196307221993031002 , 
pangkat/ golongan ruang: Pembina  (IV/a), Unit Kerja: Inspektorat Jenderal 
Kementerian Agama Jakarta; 
- Menolak permohonan Penggugat yang memerintahkan Tergugat untuk 
mencabut Surat Keputusan Menteri Agama Nomor : B.II/3/003111 tanggal 16 
Januari 2015 tentang Pemberhentian Dengan Hormat dari Jabatan Fungsional 
Auditor pada Inspektorat Jenderal Kementerian Agama Jakarta kepada H. 
Agus Susanto,SH NIP. 196307221993031002 , pangkat/ golongan ruang: 
Pembina  (IV/a), Unit Kerja: Inspektorat Jenderal Kementerian Agama Jakarta; 
 Halaman 31 dari 53 halaman Putusan No.78/G/2015/PTUN-JKT  
Disclaimer
Kepaniteraan Mahkamah Agung Republik Indonesia berusaha untuk selalu mencantumkan informasi paling kini dan akurat sebagai bentuk komitmen Mahkamah Agung untuk pelayanan publik, transparansi dan akuntabilitas
pelaksanaan fungsi peradilan. Namun dalam hal-hal tertentu masih dimungkinkan terjadi permasalahan teknis terkait dengan akurasi dan keterkinian informasi yang kami sajikan, hal mana akan terus kami perbaiki dari waktu kewaktu.
Dalam hal Anda menemukan inakurasi informasi yang termuat pada situs ini atau informasi yang seharusnya ada, namun belum tersedia, maka harap segera hubungi Kepaniteraan Mahkamah Agung RI melalui :
 Halaman 31


# Halaman 32

- Menolak permohonan Penggugat untuk merehabilitasi dan mengembalikan 
kedudukan Penggugat seperti semula sebagai Fungsional Auditor;
• Menghukum Penggugat untuk membayar biaya perkara;
Menimbang, bahwa atas Jawaban Tergugat, Pihak Penggugat telah  
mengajukan  Replik  pada persidangan tanggal 1 Juni  2015, dan atas Replik 
Penggugat tersebut, pihak Tergugat  mengajukan Duplik  pada persidangan 
tanggal  8 Juni 2015,  yang untuk singkatnya putusan ini, selengkapnya Replik dan 
Duplik tersebut cukup menunjuk dalam   Berita Acara Persidangan  dan  
merupakan bagian tidak terpisahkan dalam putusan ini ; 
Menimbang, bahwa untuk menguatkan dalil-dalil gugatannya, Penggugat 
telah mengajukan bukti berupa fotokopi surat-surat yang telah diberi meterai cukup 
dan telah disesuaikan dengan aslinya atau fotokopinya, serta diberi tanda P-1 s/d  
P-8 ,  adalah sebagai berikut : 
1.  Bukti P-1 : Surat Keputusan Menteri Agama Nomor B.II/3/13180 atas 
nama Agus Susanto,  S.H., tanggal 19 September 2008. 
(fotokopi sesuai dengan aslinya);
2.  Bukti P-2 : Penetapan angka kredit jabatan fungsional auditorNomor 
Set.IJ/2.b/PS.04.3/0559/2014tanggal 4 Agustus 2014. 
(fotokopi sesuai dengan aslinya);
3.  Bukti P-3 : Keputusan Menteri Agama Republik Indonesia Nomor 
B.II/3/71262, tentang Pembebasan Sementara dari Jabatan 
Auditor, tanggal 31 Desember 2014. (fotokopi sesuai dengan 
aslinya);
Disclaimer
Kepaniteraan Mahkamah Agung Republik Indonesia berusaha untuk selalu mencantumkan informasi paling kini dan akurat sebagai bentuk komitmen Mahkamah Agung untuk pelayanan publik, transparansi dan akuntabilitas
pelaksanaan fungsi peradilan. Namun dalam hal-hal tertentu masih dimungkinkan terjadi permasalahan teknis terkait dengan akurasi dan keterkinian informasi yang kami sajikan, hal mana akan terus kami perbaiki dari waktu kewaktu.
Dalam hal Anda menemukan inakurasi informasi yang termuat pada situs ini atau informasi yang seharusnya ada, namun belum tersedia, maka harap segera hubungi Kepaniteraan Mahkamah Agung RI melalui :
 Halaman 32


# Halaman 33

4.  Bukti P-4 : Keputusan Menteri Agama Republik Indonesia Nomor 
B.II/3/00311, tentang Pemberhentian dari Jabatan Auditor, 
tanggal 16 Januari 2015. (fotokopi sesuai dengan aslinya);
5.  Bukti P-5 : Keputusan Menteri Agama Republik Indonesia Nomor B.II/3/
PDJ/15616, tanggal 29  Desember 2011, atas nama H. 
Suhendar, S.Pd. (fotokopi sesuai dengan aslinya);
6.  Bukti P-6a : Tanda Terima atas nama Agus Susanto, dkk perihal mohon 
keadilan, tanggal 25 Februari 2015. (fotokopi sesuai dengan 
aslinya);
7.  Bukti P-6b : Surat dari Agus Susanto, DKK, kepada Menteri Agama R.I, 
tanggal 25 Februari 2015. (fotokopi sesuai dengan aslinya);
8.  Bukti P-7 : Surat dari BPKP Nomor LHE-497/JF/2/2014 perihal Laporan 
Hasil Evaluasi atas Penerapan JFA pada Inspektorat Jenderal 
Kementerian Agama, tanggal 29 Desember 2014. (fotokopi 
dari fotokopi);
9.  Bukti P-8 : Surat dari BPKP Pusat Pembinaan Jabatan Fungsional Nomor 
S- 693/JF/2/2015 perihal pemberitahuan Auditor yang tidak 
dapat mengumpulkan angka kredit Auditor sesuai ketentuan 
Permenpan PER/220/M.PAN/7/2008, tanggal 31 Maret 2015. 
(fotokopi dari fotokopi);
Menimbang, bahwa untuk menguatkan dalil-dalil bantahannya, Tergugat  
telah mengajukan bukti berupa fotokopi  surat-surat yang telah diberi meterai 
cukup dan telah disesuaikan dengan aslinya atau fotokopinya, serta diberi tanda 
T-1 s/d T-.6,  adalah sebagai berikut;
 Halaman 33 dari 53 halaman Putusan No.78/G/2015/PTUN-JKT  
Disclaimer
Kepaniteraan Mahkamah Agung Republik Indonesia berusaha untuk selalu mencantumkan informasi paling kini dan akurat sebagai bentuk komitmen Mahkamah Agung untuk pelayanan publik, transparansi dan akuntabilitas
pelaksanaan fungsi peradilan. Namun dalam hal-hal tertentu masih dimungkinkan terjadi permasalahan teknis terkait dengan akurasi dan keterkinian informasi yang kami sajikan, hal mana akan terus kami perbaiki dari waktu kewaktu.
Dalam hal Anda menemukan inakurasi informasi yang termuat pada situs ini atau informasi yang seharusnya ada, namun belum tersedia, maka harap segera hubungi Kepaniteraan Mahkamah Agung RI melalui :
 Halaman 33


# Halaman 34

1.  Bukti T-1 : Surat dari BPKP Nomor LHE-497/JF/2/2014 perihal Laporan 
Hasil Evaluasi Atas Penerapan JFA pada Inspektorat Jenderal 
Kementerian Agama, tanggal 29 Desember 2014. (fotokopi 
dari fotokopi);
2.  Bukti T-2 : Notisi Evaluasi atas Penerapan JFA pada Inspektorat Jenderal 
Kementerian Agama Tahun 2014 (fotokopi dari fotokopi);
3.  Bukti T-3 : Surat dari kemeterian Agama R.I Inspektorat Jenderal Nomor 
Set.IJ/2.b/Kp.04.2/1125/2014 perihal Usul Pembebasan 
Sementara Dari jabatan Funsional Auditor atas nama Drs. 
Mahrup Sumarno, DKK, tanggal 29 Desember  2014.( fotokopi 
sesuai dengan aslinya);
4.  Bukti T-4 : Keputusan Menteri Agama R.I Nomor  492 Tahun  2003 
Tentang Pemberian Kuasa Dan Pendelegasian Wewenang 
pengangkatan Pemindahan Dan Pemberhentian Pegawai 
Negeri Sipil Di Lingkungan Departemen Agama. (fotokopi 
sesuai dengan aslinya);
5.  Bukti T-5 : Keputusan Menteri Agama R.I Nomor  489 Tahun  2003 
Tentang Pendelegasian Wewenang Penjatuhan Hukuman 
Disiplin pemberhentian Pegawai Negeri Sipil Di Lingkungan 
Departemen Agama. (fotokopi sesuai dengan aslinya);
6.  Bukti T-6 : Peraturan Menteri Negara Pendayagunaan Aparatur Negara 
Nomor PER/220/M.PAN/7/2008, Tentang Jabatan Fungsional 
Auditor Dan Angka Kreditnya. (fotokopi dari fotokopi);
Disclaimer
Kepaniteraan Mahkamah Agung Republik Indonesia berusaha untuk selalu mencantumkan informasi paling kini dan akurat sebagai bentuk komitmen Mahkamah Agung untuk pelayanan publik, transparansi dan akuntabilitas
pelaksanaan fungsi peradilan. Namun dalam hal-hal tertentu masih dimungkinkan terjadi permasalahan teknis terkait dengan akurasi dan keterkinian informasi yang kami sajikan, hal mana akan terus kami perbaiki dari waktu kewaktu.
Dalam hal Anda menemukan inakurasi informasi yang termuat pada situs ini atau informasi yang seharusnya ada, namun belum tersedia, maka harap segera hubungi Kepaniteraan Mahkamah Agung RI melalui :
 Halaman 34


# Halaman 35

Menimbang, bahwa pada persidangan  Pihak Penggugat dan Pihak 
tergugat  tidak mengajukan saksi ataupun Ahli dalam sengketa ini meskipun telah 
diberikan kesempatan yang cukup untuk itu;
Menimbang, bahwa  Penggugat dan Tergugat   telah mengajukan 
Kesimpulan pada Persidangan tanggal 29 Juni 2015,  dan untuk mempersingkat 
uraian Putusan ini, kesimpulan tersebut cukup ditunjuk dalam B erita Acara 
Persidangan dalam perkara ini, dan merupakan bagian tidak terpisahkan dengan 
uraian Putusan ini; 
Menimbang, bahwa segala sesuatu yang terjadi di  persidangan 
sebagaimana termuat dalam berita acara persidangan perkara ini, merupakan 
bagian yang tidak terpisahkan dengan uraian putusan ini ; 
Menimbang, bahwa akhirnya Para Pihak menyatakan mereka tidak akan 
mengajukan sesuatu hal lagi dalam perkara ini, dan selanjutnya mohon putusan;
TENTANG PERTIMBANGAN HUKUM
Menimbang, bahwa maksud dan tujuan gugatan Penggugat adalah 
sebagaimana urain dalam duduk sengketa di atas;
Menimbang, bahwa yang menjadi obJek dalam sengketa a quo  adalah: 
Surat Keputusan Menteri Agama R.I Nomor B.II/3/00311, tanggal 16 Januari 2015 
tentang Pemberhentian dari Jabatan Auditor atas nama H. AGUS SUSANTO,  S.H. 
(vide bukti P-4);
Menimbang, bahwa dalam gugatannya pada pokoknya Penggugat 
memohon kepada Pengadilan Tata Usaha Negara Jakarta agar surat keputusan 
obyek sengketa  a quo   dinyatakan batal atau tidak sah karena telah bertentangan 
dengan peraturan perundang-undangan yang berlaku antara lain Peraturan 
Bersama BPKP dan BKN Nomor PER-1310/K/J/F/2008 dan Nomor 24 tahun 2008 
 Halaman 35 dari 53 halaman Putusan No.78/G/2015/PTUN-JKT  
Disclaimer
Kepaniteraan Mahkamah Agung Republik Indonesia berusaha untuk selalu mencantumkan informasi paling kini dan akurat sebagai bentuk komitmen Mahkamah Agung untuk pelayanan publik, transparansi dan akuntabilitas
pelaksanaan fungsi peradilan. Namun dalam hal-hal tertentu masih dimungkinkan terjadi permasalahan teknis terkait dengan akurasi dan keterkinian informasi yang kami sajikan, hal mana akan terus kami perbaiki dari waktu kewaktu.
Dalam hal Anda menemukan inakurasi informasi yang termuat pada situs ini atau informasi yang seharusnya ada, namun belum tersedia, maka harap segera hubungi Kepaniteraan Mahkamah Agung RI melalui :
 Halaman 35


# Halaman 36

tanggal 11 Nopember  2008 tentang Petunjuk Pelaksanaan Jabatan Fungsional 
Auditor Dan Angka Kredit, Peraturan Kepala Badan Kepegawaian Negara Nomor 
21 Tahun  2010 tentang Ketentuan Pelaksanaan Peraturan Pemerintah Nomor 53 
Tahun  2010 Tentang Disiplin Pegawai Negara Sipil, serta telah melanggaar Asas-
Asas Umum Pemerintahan yang Baik (AAUPB ) antara lain  Asas Kecermatan dan 
Asas Pemberian Alasan. Oleh karenanya gugatan Penggugat telah memenuhi 
ketentuan Pasal 53 ayat (2) huruf a dan b Undang-Undang Nomor 9 Tahun  2004 
tentang Perubahan Atas Undang-Undang Nomor 5 Tahun  1986 tentang Peradilan 
Tata Usaha Negara ;
Menimbang, bahwa terhadap dalil gugatan Penggugat tersebut Tergugat 
telah membantahnya yang tertuang dalam Jawabannya tertanggal 25 M ei 2015, 
yang pada pokoknya Tergugat  menyatakan bahwa penerbitan surat keputus objek 
sengketa sudah sesuai dengan wewenang dan prosedur serta tidak bertentangan 
dengan Peraturan Perundang-undangan yang berlaku dan Asas-Asas Umum 
Pemerintahan yang Baik ;
Menimbang, bahwa terhadap dalil-dalil gugatan Penggugat yang telah 
dibantah oleh Tergugat, Majelis Hakim dapat menyimpulkan bahwa hal yang 
menjadi pokok permasalahan yang harus diuji dan dibuktikan kebenarannya 
adalah : “Apakah penerbitan surat keputusan objek sengketa in casu Surat 
Keputusan Menteri Agama RI (Tergugat) Nomor B.II/3/00311, tanggal 16 Januari 
2015 tentang Pemberhentian dari Jabatan Auditor atas nama H. AGUS 
SUSANTO,SH.  (vide bukti P-4), secara prosedural formal maupun material 
substansial telah sesuai ataukah sebaliknya telah bertentangan dengan peraturan 
perundang-undangan dan atau Asas-Asas Umum Pemerintahan Yang Baik?”;
Disclaimer
Kepaniteraan Mahkamah Agung Republik Indonesia berusaha untuk selalu mencantumkan informasi paling kini dan akurat sebagai bentuk komitmen Mahkamah Agung untuk pelayanan publik, transparansi dan akuntabilitas
pelaksanaan fungsi peradilan. Namun dalam hal-hal tertentu masih dimungkinkan terjadi permasalahan teknis terkait dengan akurasi dan keterkinian informasi yang kami sajikan, hal mana akan terus kami perbaiki dari waktu kewaktu.
Dalam hal Anda menemukan inakurasi informasi yang termuat pada situs ini atau informasi yang seharusnya ada, namun belum tersedia, maka harap segera hubungi Kepaniteraan Mahkamah Agung RI melalui :
 Halaman 36


# Halaman 37

Menimbang, bahwa sebelum Majelis Hakim lebih jauh mempertimbangkan 
pokok permalasahan dalam sengketa a quo, terhadap keberadaan surat keputusan 
obyek sengketa Majelis Hakim berpendapat bahwa surat keputusan objek 
sengketa in casu Surat Keputusan Tergugat  Nomor B.II/3/00311, tanggal 16 
Januari 2015 tentang Pemberhentian dari Jabatan Auditor atas nama H. AGUS 
SUSANTO,SH.  sebagaimana dalam bukti P-4, merupakan Penetapan tertulis yang 
dikeluarkan oleh Tergugat sebagai Pejabat Tata Usaha Negara, yang mengandung 
materi sebagai  tindakan dalam lingkup hukum administrasi Negara, yang 
penerbitannya  didasarkan atas peraturan perundangg-undangan di bidang 
kepegawaian, yang bersifat konkret karena nyata adanya, bersifat individual 
karena jelas ditujukan kepada H. AGUS SUSANTO,SH  (Penggugat), dan final 
yaitu tidak memerlukan persetujuan pejabat atasan dan telah menimbulkan akibat 
hukum bagi Penggugat, karena berakibat Penggugat diberhentikan dari jabatannya 
sebagai auditor di Kementerian Agama; 
Menimbang, bahwa oleh karenanya surat keputusan objek sengketa a quo  
memenuhi semua unsur Keputusan Tata Usaha Negara sebagaimana dimaksud 
dalam Pasal 1 angka 9 Undang-Undang Nomor  9 Tahun  2004  tentang Perubahan 
atas Undang-Undang Nomor 5 Tahun  1986 tentang Peradilan Tata Usaha Negara, 
maka Pengadilan Tata Usaha Negara berwenang untuk mengadilinya;
Menimbang, bahwa terkait dengan kepentingan Penggugat mengajukan 
gugatan a quo,  dalam Pasal 53 ayat (1)  Undang-Undang Nomor  5 Tahun  1986 
disebutkan bahwa  “Orang atau badan hukum perdata yang merasa 
kepentingannya dirugikan oleh suatu Keputusan Tata Usaha Negara dapat 
mengajukan gugatan tertulis kepada pengadilan yang berwenang yang berisi 
tuntutan agar Keputusan Tata Usaha Negara yang disengketakan itu dinyatakan 
 Halaman 37 dari 53 halaman Putusan No.78/G/2015/PTUN-JKT  
Disclaimer
Kepaniteraan Mahkamah Agung Republik Indonesia berusaha untuk selalu mencantumkan informasi paling kini dan akurat sebagai bentuk komitmen Mahkamah Agung untuk pelayanan publik, transparansi dan akuntabilitas
pelaksanaan fungsi peradilan. Namun dalam hal-hal tertentu masih dimungkinkan terjadi permasalahan teknis terkait dengan akurasi dan keterkinian informasi yang kami sajikan, hal mana akan terus kami perbaiki dari waktu kewaktu.
Dalam hal Anda menemukan inakurasi informasi yang termuat pada situs ini atau informasi yang seharusnya ada, namun belum tersedia, maka harap segera hubungi Kepaniteraan Mahkamah Agung RI melalui :
 Halaman 37


# Halaman 38

batal atau tidak sah, dengan atau tanpa disertai tuntutan ganti rugi dan/atau 
direhabilitasi”;
Bahwa berdasarkan rumusan pasal tersebut Pengadilan berpendapat bahwa oleh 
karena akibat dari surat keputusan obyek sengketa yang telah menetapkan 
Penggugat diberhentikan sebagai auditor pada Kementerian Agama, Penggugat 
telah dirugikan kepentingannya karena Penggugat telah diberhentikan sebagai 
auditor, maka dengan demikian terbukti Penggugat mempunyai kepentingan 
mengajukan gugatan a quo;
Menimbang, bahwa surat keputusan in litis diterbitkan pada tanggal 16 
Januari 2015 yang diterima secara resmi oleh Penggugat pada tanggal 5 Februari 
2015, sementara itu gugatan Penggugat diterima dan didaftarkan di Kepaniteraan 
Pengadilan Tata Usaha Negara Jakarta pada tanggal 7 April 2015, oleh karenanya 
menjadi fakta hukum bahwa gugatan Penggugat diajukan masih dalam tengggang 
waktu 90 (sembilan puluh) hari sebagaimana ditentukan dalam Pasal 55 Undang-
Undang Nomor  5 Tahun  1986 tentang Peradilan Tata Usaha Negara;
Menimbang, bahwa selanjutnya dalam menguji pokok permasalahan dalam 
sengketa a quo, Pengadilan berpedoman pada konsepsi norma yang terkandung 
dalam Pasal 53 ayat (2) huruf a dan b Undang-Undang Nomor 9 Tahun  2004 
tentang Perubahan atas Undang-Undang Nomor  5 Tahun  1986 tentang Peradilan 
Tata Usaha Negara, yang substansinya menyebutkan bahwa suatu Keputusan 
Tata Usaha Negara dapat dinyatakan batal atau tidak sah apabila : 
a. Keputusan Tata Usaha Negara yang digugat itu bertentangan dengan 
Peraturan Perundang-undangan yang berlaku;
b. Keputusan Tata Usaha Negara yang digugat itu bertentangan dengan Azas-
azas Umum Pemerintahan Yang Baik (AAUPB ); 
Disclaimer
Kepaniteraan Mahkamah Agung Republik Indonesia berusaha untuk selalu mencantumkan informasi paling kini dan akurat sebagai bentuk komitmen Mahkamah Agung untuk pelayanan publik, transparansi dan akuntabilitas
pelaksanaan fungsi peradilan. Namun dalam hal-hal tertentu masih dimungkinkan terjadi permasalahan teknis terkait dengan akurasi dan keterkinian informasi yang kami sajikan, hal mana akan terus kami perbaiki dari waktu kewaktu.
Dalam hal Anda menemukan inakurasi informasi yang termuat pada situs ini atau informasi yang seharusnya ada, namun belum tersedia, maka harap segera hubungi Kepaniteraan Mahkamah Agung RI melalui :
 Halaman 38


# Halaman 39

Menimbang, bahwa kewenangan Hakim dalam menguji surat keputusan 
objek sengketa bersifat dominus litis, artinya tidak terbatas pada pembuktian 
maupun dalil yang diajukan para pihak, oleh karena itu berdasarkan dalil-dalil 
Gugatan, Jawaban, Replik dan Duplik serta alat-alat bukti yang diajukan para pihak 
di persidangan, maka untuk menjawab pokok permasalahan dalam sengketa a 
quo, Majelis Hakim akan menguji dan mempertimbangkan fakta-fakta yang 
terungkap di persidangan;
Menimbang, bahwa terhadap kewenangan Tergugat menerbitkan surat 
keputusan objek sengketa, Majelis Hakim berpendapat dari kedudukan, fungsi dan 
wewenang Tergugat sebagai Pejabat Pembina Kepegawaian pada Kementerian 
Agama RI, berwenang menerbitkan surat keputusan obyek sengketa a quo, hal ini  
didasarkan pada  ketentuan  dalam Pasal 1 angka 14 Undang-Undang Nomor   5 
Tahun  2014 tentang Aparatur Sipil Negara (Undang-Undang ASN ) menyebutkan 
bahwa  ”Pejabat Pembina Kepegawaian adalah pejabat yang mempunyai 
kewenangan menetapkan pengangkatan,  pemindahan, dan pemberhentian 
Pegawai ASN dan pembinaan Manajemen ASN di instansi pemerintah sesuai 
dengan ketentuan peraturan perundang-undangan”. Kemudian dalam Pasal 53 
Undang-Undang ASN menyebutkan bahwa  : ”Presiden selaku pemegang 
kekuasaan tertinggi pembinaan ASN dapat mendelegasikan kewenangan 
menetapkan pengangkatan, pemindahan, dan pemberhentian pejabat selain 
pejabat pimpinan tinggi utama dan madya, dan pejabat fungsional keahlian utama 
kepada: a. Menteri di Kementerian”. Dalam sengketa a quo  kewenangan 
dimaksud, telah didelegasikan kepada Tergugat;
Menimbang, bahwa kewenangan Tergugat dalam menerbitkan surat 
keputusan in litis juga telah sesuai dengan Peraturan Pemerintah  Nomor  9 Tahun  
 Halaman 39 dari 53 halaman Putusan No.78/G/2015/PTUN-JKT  
Disclaimer
Kepaniteraan Mahkamah Agung Republik Indonesia berusaha untuk selalu mencantumkan informasi paling kini dan akurat sebagai bentuk komitmen Mahkamah Agung untuk pelayanan publik, transparansi dan akuntabilitas
pelaksanaan fungsi peradilan. Namun dalam hal-hal tertentu masih dimungkinkan terjadi permasalahan teknis terkait dengan akurasi dan keterkinian informasi yang kami sajikan, hal mana akan terus kami perbaiki dari waktu kewaktu.
Dalam hal Anda menemukan inakurasi informasi yang termuat pada situs ini atau informasi yang seharusnya ada, namun belum tersedia, maka harap segera hubungi Kepaniteraan Mahkamah Agung RI melalui :
 Halaman 39


# Halaman 40

2003 juncto Nomor  63 Tahun  2009 tentang Wewenang Pengangkatan,  
Pemindahan, dan Pemberhentian Pegawai Negeri Sipil, disebutkan dalam Pasal 
12 yaitu: “Pejabat Pembina Kepegawaian Pusat menetapkan pengangkatan,  
pemindahan, dan pemberhentian Pegawai Negeri Sipil Pusat di lingkungannya 
dalam dan  dari jabatan struktural eselon II ke bawah atau jabatan fungsional yang 
jenjangnya setingkat dengan itu”. Kewenangan tersebut secara teknis diatur lebih 
lanjut dengan Keputusan Menteri Agama Nomor 492 Tahun  2003 tentang 
Pemberian Kuasa dan Pendelegasian Wewenang Pengangkatan Pemindahan dan 
Pemberhentian Pegawai Negeri Sipil, di Lingkungan Departemen Agama (vide 
bukti T-4), yang dalam Lampiran Keputusan Menteri Agama Nomor 492 Tahun  
2003 tersebut Pejabat dalam hal ini Sekretaris Jenderal Departemen Agama, diberi 
wewenang untuk memberikan penjatuhan hukuman disiplin berupa “Pembebasan 
dari jabatan” terhadap “Pejabat Fungsional”. (Kolom 1, butir 1.huruf c). Penjatuhan 
Hukuman Disiplin berupa pembebasan jabatan terhadap Penggugat juga 
didasarkan atas Keputusan Menteri Agama Nomor 489 Tahun  2003 tentang 
Pemberian Kuasa dan Pendelegasian Wewenang Penjatuhan Hukuman Disiplin 
Pegawai Negeri Sipil di Lingkungan Departemen Agama (vide bukti T-5), yang 
dalam Lampiran Keputusan Menteri Agama Nomor 489 Tahun  2003 tersebut 
Pejabat Struktural Eselon I (Sekretaris Jenderal Departemen Agama) diberi 
wewenang untuk memberikan penjatuhan hukuman disiplin berupa “Pembebasan 
dari jabatan” terhadap “Pejabat Fungsional”. (Kolom 1, butir 1.8);
Menimbang, bahwa berdasarkan uraian pertimbangan tersebut di atas, 
maka terbukti secara yuridis Sekretaris Jenderal Kementerian Agama RI 
berwenang menerbitkan surat keputusan yang menjadi obyek dalam sengketa a 
Disclaimer
Kepaniteraan Mahkamah Agung Republik Indonesia berusaha untuk selalu mencantumkan informasi paling kini dan akurat sebagai bentuk komitmen Mahkamah Agung untuk pelayanan publik, transparansi dan akuntabilitas
pelaksanaan fungsi peradilan. Namun dalam hal-hal tertentu masih dimungkinkan terjadi permasalahan teknis terkait dengan akurasi dan keterkinian informasi yang kami sajikan, hal mana akan terus kami perbaiki dari waktu kewaktu.
Dalam hal Anda menemukan inakurasi informasi yang termuat pada situs ini atau informasi yang seharusnya ada, namun belum tersedia, maka harap segera hubungi Kepaniteraan Mahkamah Agung RI melalui :
 Halaman 40


# Halaman 41

quo  atas nama Menteri Agama, yang dalam ilmu hukum administrasi Negara 
kewenangan yang seperti ini dikenal istilah “mandat’;
Menimbang, bahwa terhadap pokok permasalah dalam sengketa a quo  
casu Surat Keputusan Tergugat  Nomor B.II/3/00310, tanggal 16 Januari 2015, 
dihubungkan dengan dalil-dalil Penggugat dan Tergugat serta surat-surat bukti 
yang diajukan sebagaimana telah disebutkan di atas,  dengan mencermati surat 
keputusan obyek sengketa in para pihak, terdapat fakta sebagai berikut:
• Bahwa surat  Keputusan Tergugat Nomor   B.II/3/00311, 
tanggal 16 Januari 2015 tentang Pemberhentian Penggugat 
dari Jabatan Auditor;
• Bahwa   dalam konsideran “Membaca ” surat keputusan in litis 
disebutkan adanya Surat Inspektur Jenderal Kementerian 
Agama Nomor  : Set.IJ/2.b/Kp.04.2/1126/2014 tanggal 29 
Desember 2014 tentang Usul Pemberhentian dari Jabatan 
Fungsional Auditor Kepegawaian Madya atas nama 
Penggugat;
• Bahwa dalam konsideran “Menimbang ” surat keputusan in liti 
disebutkan dasar hukum penerbitan surat keputusan obyek 
sengketa adalah dalam rangka menindaklanjuti ketentuan 
dalam Bab IV Pasal  40 butir (a)  Peraturan Menteri  
Pendayagunaan Aparatur Negara dan reformasi Birokrasi RI 
Nomor  40 Tahun  2012 tanggal 17 Juli 2012 tentang Jabatan 
Fungsional Auditor Kepegawaian Dan Angka Kreditnya;
• Bahwa dasar penerbitan surat keputusan obyek sengketa 
juga didasarkan atas telah diterbitkannya  Surat Keputusan 
 Halaman 41 dari 53 halaman Putusan No.78/G/2015/PTUN-JKT  
Disclaimer
Kepaniteraan Mahkamah Agung Republik Indonesia berusaha untuk selalu mencantumkan informasi paling kini dan akurat sebagai bentuk komitmen Mahkamah Agung untuk pelayanan publik, transparansi dan akuntabilitas
pelaksanaan fungsi peradilan. Namun dalam hal-hal tertentu masih dimungkinkan terjadi permasalahan teknis terkait dengan akurasi dan keterkinian informasi yang kami sajikan, hal mana akan terus kami perbaiki dari waktu kewaktu.
Dalam hal Anda menemukan inakurasi informasi yang termuat pada situs ini atau informasi yang seharusnya ada, namun belum tersedia, maka harap segera hubungi Kepaniteraan Mahkamah Agung RI melalui :
 Halaman 41


# Halaman 42

Menteri Agama Nomor B.II/3/71262 tanggal 31 Desember 
2014 tentang Pembebasan Sementara Penggugat dari 
Jabatan Auditor;
• Bahwa dalam diktum  “Pertama” surat keputusan objek 
sengketa disebutkan Memberhentikan Penggugat dengan 
pangkat Pembina (IV/a) dari jabatan Fungsional Auditor 
Kepegawaian Madya pada Inspektorat Wilayah III Inpektorat 
Jenderal Kementerian Agama. Dan pada diktum “Kedua” 
disebutkan surat keputusan in litis berlaku sejak tanggal 2 
Oktober 2014;
Menimbang, bahwa dari kronologis dan prosedur penerbitan Surat 
Keputusan obyek sengketa diawali karena adanya Surat Tugas Nomor ST-698/
JF/2/2014 tanggal 22 Agustus 2014 dari Badan Pengawasan Keuangan dan 
Pembangunan  (BPKP ) Pusat Pembinaan Jabatan Fungsional Auditor untuk 
menyelesaikan evaluasi penerapan Jabatan Fungsional Auditor pada Inspektorat 
Jenderal Kementerian Agama. Hasil evaluasi atas penerapan Jabatan Fungsional 
Auditor pada Inspektorat Jenderal Kementerian Agama tersebut dituangkan dalam 
surat Badan Pengawasan Keuangan dan Pembangunan Pusat Pembinaan 
Jabatan Fungsional Auditor Nomor LHE-497/JF/2/2014 tanggal 29 Desember 2014 
(vide bukti P-7= T-1), yang kemudian dibuat notisi evaluasi atas penerapan Jabatan 
Fungsional Auditor pada Inspektorat Jenderal Kementerian Agama Tahun 2014 
(vide bukti T-2);
Menimbang, bahwa selanjutnya hasil evaluasi dan notisi evaluasi dari BPKP 
tersebut, Inspektorat Jenderal Kementerian Agama menindaklanjuti dengan 
mengusulkan Pembebasan Sementara dari Jabatan kepada Biro Kepegawaian 
Disclaimer
Kepaniteraan Mahkamah Agung Republik Indonesia berusaha untuk selalu mencantumkan informasi paling kini dan akurat sebagai bentuk komitmen Mahkamah Agung untuk pelayanan publik, transparansi dan akuntabilitas
pelaksanaan fungsi peradilan. Namun dalam hal-hal tertentu masih dimungkinkan terjadi permasalahan teknis terkait dengan akurasi dan keterkinian informasi yang kami sajikan, hal mana akan terus kami perbaiki dari waktu kewaktu.
Dalam hal Anda menemukan inakurasi informasi yang termuat pada situs ini atau informasi yang seharusnya ada, namun belum tersedia, maka harap segera hubungi Kepaniteraan Mahkamah Agung RI melalui :
 Halaman 42


# Halaman 43

Sekretariat Jenderal Kementerian Agama berdasarkan surat Nomor : Set. IJ/2.b/
Kp.04.2/1125/2014 tanggal 29 Desember  2014 tentang usul Pembebasan 
Sementara dari jabatan Fungsional Auditor kepada Penggugat (vide bukti T-3), 
yang atas usulan tersebut Tergugat menerbitkan Surat Keputusan Nomor; 
B.II/3/71262 tanggal 31 Desember 2014 tentang Pemberhensian Sementara 
Penggugat dari jabatan Auditor (vide bukti P-3). Kemudian selanjutnya Inspektur 
Jenderal Kementerian Agama dengan suratnya Nomor:  Set.IJ/2.b/Kp.04.2/ 
1126/2014 tanggal 29 Desember 2014 mengusulkan pemberhentian Penggugat 
dari Jabatan Fungsional Auditor Kepegawaian Madya (vide konsideran “Membaca “ 
Surat Keputusan obyek sengketa);
Menimbang, bahwa selanjutnya berdasarkan surat usulan Inspektur 
Jenderal Kementerian Agama dengan suratnya Nomor : Set.IJ/2.b/Kp.04.2/ 
1126/2014 tanggal 29 Desember 2014, Tergugat menerbitkan Surat Keputusan 
Nomor  : B.II/3/00311 tanggal 16 Januari 2015 tentang Pemberhentian (Penggugat) 
dari jabatan Auditor, yang menjadi obyek dalam sengketa a quo;
Menimbang, bahwa berdasarkan uraian kronologis dan prosedur penerbitan 
surat keputusan obyek sengketa tersebut, Majelis Hakim berpendapat bahwa 
penerbitan surat keputusan obyek sengketa dimaksudkan sebagai tindakan lebih 
lanjut atas hasil evaluasi dan temuan BPKP (vide bukti T-1) yang pada halaman 
23-24 angka 3) disebutkan “Terdapat auditor yang harus diberhentikan dari 
Jabatan Fungsional Auditor (JFA) karena tidak dapat mencapai angka kredit yang 
dipersyaratkan, antara lain auditor dimaksud adalah H. Agus Susanto, S.H. 
(Penggugat)”;
Menimbang, bahwa mencermati uraian dari hasil evaluasi sebagaimana 
surat BPKP Nomor LHE-497/JF/2/2014 tanggal 29 Desember 2014 ( bukti T-1, 
 Halaman 43 dari 53 halaman Putusan No.78/G/2015/PTUN-JKT  
Disclaimer
Kepaniteraan Mahkamah Agung Republik Indonesia berusaha untuk selalu mencantumkan informasi paling kini dan akurat sebagai bentuk komitmen Mahkamah Agung untuk pelayanan publik, transparansi dan akuntabilitas
pelaksanaan fungsi peradilan. Namun dalam hal-hal tertentu masih dimungkinkan terjadi permasalahan teknis terkait dengan akurasi dan keterkinian informasi yang kami sajikan, hal mana akan terus kami perbaiki dari waktu kewaktu.
Dalam hal Anda menemukan inakurasi informasi yang termuat pada situs ini atau informasi yang seharusnya ada, namun belum tersedia, maka harap segera hubungi Kepaniteraan Mahkamah Agung RI melalui :
 Halaman 43


# Halaman 44

khususnya pada halaman 23 sampai dengan 24), merupakan temuan atas tidak 
adanya tindakan dari Inspektorat Jenderal Kementerian Agama yang belum pernah 
memberlakukan pemberhentian  terhadap JFA bagi auditor yang dalam jangka 
waktu 1 tahun sejak dibebaskan sementara tidak mampu mengumpulkan angka 
kredit minimal yang ditentukan, yang antara lain auditor dimaksud disebutkan 
adalah H. Agus Susanto, S.H (Penggugat);
Menimbang, bahwa tindakan Inspektorat Jenderal Kementerian Agama 
menerbitkan surat usulan pemberhentian sementara tertanggal 29 Desember  2014 
sebagaimana dalam bukti T-3, untuk menindaklanjuti hasil evaluasi BPKP 
tertanggal 29 Desember  2014, sangat mengandung kejanggalan, baik dari tanggal 
penerbitannya yaitu tanggal 29 Desember  2014 yang bersamaan  dengan tanggal 
hasil evaluasi BPKP, maupun dari prosedurnya yang tidak terlebih dahulu 
dilakukan peringatan sebagaimana yang diatur dalam Peraturan Kepala BPKP 
Nomor PER-709/K/JF/2009. Demikian juga halnya dengan tindakan Inspektorat 
Jenderal Kementerian Agama yang menerbitkan surat Nomor Set.IJ/2.b/Kp.04.2/ 
1126/2014 tentang Usulan Pemberhentian Penggugat (vide konsideran “Membaca “ 
Surat Keputusan obyek sengketa), dengan tanggal yang sama yaitu tanggal 29 
Desember 2014. Di samping itu dari hasil evaluasi BPKP dimaksud seharusnya 
tidaklah kemudian disikapi oleh Tergugat dengan menerbitkan Surat Keputusan 
Pemberhentian Sementara Nomor B.II/3/71262 tanggal 31 Desember 2014 yang 
diberlakukan surut terhitung mulai tangggal 1 Oktober 2013, yang semata-mata 
untuk memenuhi temuan dari hasil evaluasi BPKP, tanpa mempertimbangkan 
akibat hukum atas hasil pelaksanaan tugas dan hak-hak yang telah Penggugat 
lakukan dan terima dalam kurun waktu mulai 1 Oktober  2013 sampai dengan 31 
Disclaimer
Kepaniteraan Mahkamah Agung Republik Indonesia berusaha untuk selalu mencantumkan informasi paling kini dan akurat sebagai bentuk komitmen Mahkamah Agung untuk pelayanan publik, transparansi dan akuntabilitas
pelaksanaan fungsi peradilan. Namun dalam hal-hal tertentu masih dimungkinkan terjadi permasalahan teknis terkait dengan akurasi dan keterkinian informasi yang kami sajikan, hal mana akan terus kami perbaiki dari waktu kewaktu.
Dalam hal Anda menemukan inakurasi informasi yang termuat pada situs ini atau informasi yang seharusnya ada, namun belum tersedia, maka harap segera hubungi Kepaniteraan Mahkamah Agung RI melalui :
 Halaman 44


# Halaman 45

Desember 2014 yaitu tanggal penerbitan surat keputusan tentang Pemberhentian 
Sementara dimaksud; 
Menimbang, bahwa surat-surat Inspektorat Jenderal Kementerian Agama 
yang mengandung kejanggalan dan Surat Keputusan Tergugat tentang 
Pemberhentian Sementara Nomor B.II/3/71262 tanggal 31 Desember 2014 
sebagaimana tersebut di atas, kemudian dijadikan dasar penerbitan surat 
keputusan obyek sengketa oleh Tergugat, oleh karenanya berdasarkan 
pertimbangan tersebut Majelis Hakim berpendapat penerbitan surat keputusan 
obyek sengketa secara prosedural mengandung cacat yuridis; 
Menimbang, bahwa selanjutnya secara substansial dengan mencermati 
surat keputusan obyek sengketa in casu Surat Keputusan Tergugat  Nomor 
B.II/3/00311  tanggal 16 Januari 2015 (vide bukti P-4), dihubungkan dengan dalil-
dalil Penggugat dan Tergugat serta surat-surat bukti yang diajukan para pihak, 
terdapat fakta sebagai berikut;
• Bahwa surat  Keputusan Tergugat Nomor B.II/3/00311, 
tanggal 16 Januari 2015 tentang Pemberhentian Penggugat 
dari jabatan sebagai Auditor;
• Bahwa   dalam konsideran “Membaca ” surat keputusan in litis 
disebutkan adanya Surat Inspektur Jenderal Kementerian 
Agama Nomor  : Set.IJ/2.b/Kp.04.2/1125/2014 tanggal 29 
Desember 2014 tentang Usul Pemberhentian dari Jabatan 
Fungsional Auditor Kepegawaian Madya atas nama 
Penggugat;
• Bahwa dalam konsideran “Menimbang ” surat keputusan in liti 
disebutkan dasar hukum penerbitan surat keputusan obyek 
 Halaman 45 dari 53 halaman Putusan No.78/G/2015/PTUN-JKT  
Disclaimer
Kepaniteraan Mahkamah Agung Republik Indonesia berusaha untuk selalu mencantumkan informasi paling kini dan akurat sebagai bentuk komitmen Mahkamah Agung untuk pelayanan publik, transparansi dan akuntabilitas
pelaksanaan fungsi peradilan. Namun dalam hal-hal tertentu masih dimungkinkan terjadi permasalahan teknis terkait dengan akurasi dan keterkinian informasi yang kami sajikan, hal mana akan terus kami perbaiki dari waktu kewaktu.
Dalam hal Anda menemukan inakurasi informasi yang termuat pada situs ini atau informasi yang seharusnya ada, namun belum tersedia, maka harap segera hubungi Kepaniteraan Mahkamah Agung RI melalui :
 Halaman 45


# Halaman 46

sengketa adalah dalam rangka menindaklanjuti ketentuan 
dalam Bab IV Pasal  40 butir (a)  Peraturan Menteri  
Pendayagunaan Aparatur Negara dan reformasi Birokrasi RI 
Nomor  40 Tahun  2012 tanggal 17 Juli 2012 tentang Jabatan 
Fungsional Auditor Kepegawaian Dan Angka Kreditnya;
• Bahwa dasar penerbitan surat keputusan obyek sengketa 
juga didasarkan atas telah diterbitkannya Surat Keputusan 
Menteri Agama Nomor B.II/3/71262 tanggal 29 Desember 
2014 tentang Pembebasan Sementara Penggugat dari 
Jabatan Auditor;
• Bahwa dalam diktum  “Pertama” surat keputusan obyek 
sengketa disebutkan Memberhentikan Penggugat dengan 
pangkat Pembina (IV/a) dari jabatan Fungsional Auditor 
Kepegawaian Madya pada Insfektorat Wilayah III Inspektorat 
Jenderal Kementerian Agama. Dan pada diktum “Kedua” 
disebutkan surat keputusan in litis berlaku sejak tanggal 2 
Oktober 2014;
Menimbang, bahwa dari fakta-fakta atas substansi surat keputusan obyek 
sengketa tersebut, Majelis Hakim akan mempertimbangkan penyebutan antara 
jabatan “Auditor” dengan jabatan “Fungsional Auditor Kepegawaian”, yang juga   
faktanya diatur dalam dua aturan yang berbeda, yaitu:
• Jabatan Auditor diatur dalam  Peraturan Menteri 
Pendayagunaan Aparatur Negara dan Reformasi Birokrasi 
R.I Nomor  : Per/220/M.PAN/7/2008 tentang Jabatan 
Fungsional Auditor Dan Angka Kreditnya (vide bukti T-6);
Disclaimer
Kepaniteraan Mahkamah Agung Republik Indonesia berusaha untuk selalu mencantumkan informasi paling kini dan akurat sebagai bentuk komitmen Mahkamah Agung untuk pelayanan publik, transparansi dan akuntabilitas
pelaksanaan fungsi peradilan. Namun dalam hal-hal tertentu masih dimungkinkan terjadi permasalahan teknis terkait dengan akurasi dan keterkinian informasi yang kami sajikan, hal mana akan terus kami perbaiki dari waktu kewaktu.
Dalam hal Anda menemukan inakurasi informasi yang termuat pada situs ini atau informasi yang seharusnya ada, namun belum tersedia, maka harap segera hubungi Kepaniteraan Mahkamah Agung RI melalui :
 Halaman 46


# Halaman 47

• Sementara itu untuk jabatan  “Fungsional Auditor 
Kepegawaian” diatur dalam Peraturan Menteri   
Pendayagunaan Aparatur Negara dan reformasi Birokrasi RI 
Nomor  40 Tahun  2012 tanggal 17 Juli 2012 tentang Jabatan 
Fungsional Auditor Kepegawaian Dan Angka Kreditnya;
Menimbang, bahwa dalam Pasal  1 angka 2 Peraturan Menteri 
Pendayagunaan Aparatur Negara dan Reformasi Birokrasi R.I Nomor : Per/220/
M.PAN/7/2008 disebutkan bahwa : “Auditor adalah Jabatan yang mempunyai 
ruang lingkup, tugas, tanggungjawab, dan wewenang untuk melakukan 
pengawasan intern pada instansi pemerintah, lembaga dan/atau pihak lain yang di 
dalamnya terdapat kepentingan negara sesuai dengan peraturan perundang-
undangan, yang diduduki oleh Pegawai Negeri Sipil dengan hak dan kewajiban 
yang diberikan secara penuh oleh pejabat yang berwenang”. Sementara itu dalam 
Pasal 1 angka 1 Peraturan Menteri  Pendayagunaan Aparatur Negara dan 
reformasi Birokrasi RI Nomor 40 Tahun  2012 disebutkan bahwa : “Jabatan 
Fungsional Auditor Kepegawaian adalah jabatan yang mempunyai ruang lingkup, 
tugas, tanggungjawab, wewenang dan hak untuk melakukan kegiatan pengawasan 
dan pengendalian pelaksanaan peraturan perundang-undangan bidang 
kepegawaian (wasdalpeg) pada instansi pemerintah pusat dan daerah, sesuai 
dengan peraturan perundang-undangan”;
Menimbang, bahwa setelah Majelis Hakim mempelajari dari dua aturan 
tersebut, Majelis Hakim berpendapat bahwa ada perbedaan yang mendasar antara  
tugas Fungsional Auditor Madya dengan tugas  Fungsional Auditor Kepegawaian 
yaitu :
 Halaman 47 dari 53 halaman Putusan No.78/G/2015/PTUN-JKT  
Disclaimer
Kepaniteraan Mahkamah Agung Republik Indonesia berusaha untuk selalu mencantumkan informasi paling kini dan akurat sebagai bentuk komitmen Mahkamah Agung untuk pelayanan publik, transparansi dan akuntabilitas
pelaksanaan fungsi peradilan. Namun dalam hal-hal tertentu masih dimungkinkan terjadi permasalahan teknis terkait dengan akurasi dan keterkinian informasi yang kami sajikan, hal mana akan terus kami perbaiki dari waktu kewaktu.
Dalam hal Anda menemukan inakurasi informasi yang termuat pada situs ini atau informasi yang seharusnya ada, namun belum tersedia, maka harap segera hubungi Kepaniteraan Mahkamah Agung RI melalui :
 Halaman 47


# Halaman 48

a. Tugas dari Auditor Madya lebih luas dibandingkan dengan tugas 
sebagai  Fungsional Auditor Kepegawaian;
b. Surat Keputusan pengangkatan sebagai Auditor Madya untuk 
golongan IV/a kebawah diterbitkan oleh Inspektorat Internal yaitu 
Inspektorat Kementerian Agama RI dan untuk golongan IV/b ke 
atas oleh BPKP, sedangkan Surat Keputusan pengangkatan 
sebagai auditor kepegawaian diterbitkan dari Badan Kepegawaian 
Negara (BKN );
c. Penetapan Angka Kredit sebagai Fungsional Auditor Madya untuk 
golongan IVa minimal 550.000, sedangkan Penetapan Angka 
Kredit sebagai Fungsional Auditor Kepegawaian Madya untuk 
golongan IVa minimal 536,000;
Menimbang, bahwa dalam gugatannya Penggugat mendalilkan  
pemberhentian Penggugat dari jabatan fungsional auditor, tidak dapat diterapkan 
berdasarkan Peraturan Menteri Pendayagunaan Aparatur Negara dan Reformasi 
Birokrasi R.I Nomor 40 Tahun  2012 tentang Jabatan Fungsional Auditor 
Kepegawaian Dan Angka Kreditnya, tetapi haruslah berdasarkan Peraturan 
Menteri Pendayagunaan Aparatur Negara dan Reformasi Birokrasi R.I Nomor : 
Per/220/M.PAN/7/2008 tentang Jabatan Fungsional Auditor Dan Angka Kreditnya, 
oleh karena jabatan Penggugat adalah Fungsional Auditor. Artinya Penggugat 
membedakan antara jabatan Fungsional Auditor dengan Jabatan Fungsional 
Auditor Kepegawaian;
Menimbang, bahwa sementara itu dalam jawabannya Tergugat mendalilkan 
bahwa surat keputusan obyek sengketa adalah tentang Pemberhentian Penggugat 
Disclaimer
Kepaniteraan Mahkamah Agung Republik Indonesia berusaha untuk selalu mencantumkan informasi paling kini dan akurat sebagai bentuk komitmen Mahkamah Agung untuk pelayanan publik, transparansi dan akuntabilitas
pelaksanaan fungsi peradilan. Namun dalam hal-hal tertentu masih dimungkinkan terjadi permasalahan teknis terkait dengan akurasi dan keterkinian informasi yang kami sajikan, hal mana akan terus kami perbaiki dari waktu kewaktu.
Dalam hal Anda menemukan inakurasi informasi yang termuat pada situs ini atau informasi yang seharusnya ada, namun belum tersedia, maka harap segera hubungi Kepaniteraan Mahkamah Agung RI melalui :
 Halaman 48


# Halaman 49

dari Jabatan Auditor bukan Pemberhentian dari Jabatan Fungsional Auditor 
Kepegawaian Madya;
Menimbang, bahwa dari dalil gugatan Penggugat dan jawaban Tergugat 
atas dalil gugatan Penggugat tersebut di atas, Majelis Hakim berpendapat bahwa 
Tergugat mengakui adanya perbedaan antara Jabatan Auditor dengan Jabatan 
Fungsional Auditor Kepegawaian, hal ini sesuai dengan pengertian dan adanya 
fakta pengaturan yang berbeda dari kedua jabatan tersebut sebagai uraian dalam 
pertimbangan di atas. Oleh karenanya fakta adanya perbedaan antara judul 
dengan diktum surat keputusan obyek sengketa, dapat menimbulkan maksud yang 
berbeda dari tujuan diterbitkannya surat keputusan obyek sengketa yaitu apakah 
Penggugat diberhentikan dari jabatan Fungsional Auditor ataukan jabatan 
Fungsional Kepegawaian, sementara itu jabatan Penggugat yang benar adalah 
jabatan Fungsional Auditor;
Menimbang, bahwa adanya fakta perbedaan penyebutan jabatan 
Penggugat dalam surat keputusan obyek sengketa telah membuktikan bahwa 
secara substansial surat keputusan obyek sengketa mengandung cacat yuridis;
Menimbang, bahwa selanjutnya terhadap alasan bahwa Penggugat tidak 
memenuhi syarat Angka Kredit minimal yang disyaratkan sebagaimana dalam hasil 
evaluasi BPKP dalam bukti T-1 maupun yang menjadi alasan Pemberhentian 
Penggugat sebagai Auditor, Majelis Hakim berpendapat bahwa alasan tersebut 
tidak dapat dibenarkan dan menjadi gugur,  karena berdasarkan bukti P-2 Surat 
dari Inspektorat Kementerian Agama Nomor: Set.IJ/2.b/PS.04.3/0559/2014 tanggal 
4 Agustus 2014, Untuk Masa Penilaian tanggal 1 januari 2014 s.d 30 juni 2014, 
telah membuktikan bahwa jumlah Total Angka Kredit yang dimiliki Penggugat 
 Halaman 49 dari 53 halaman Putusan No.78/G/2015/PTUN-JKT  
Disclaimer
Kepaniteraan Mahkamah Agung Republik Indonesia berusaha untuk selalu mencantumkan informasi paling kini dan akurat sebagai bentuk komitmen Mahkamah Agung untuk pelayanan publik, transparansi dan akuntabilitas
pelaksanaan fungsi peradilan. Namun dalam hal-hal tertentu masih dimungkinkan terjadi permasalahan teknis terkait dengan akurasi dan keterkinian informasi yang kami sajikan, hal mana akan terus kami perbaiki dari waktu kewaktu.
Dalam hal Anda menemukan inakurasi informasi yang termuat pada situs ini atau informasi yang seharusnya ada, namun belum tersedia, maka harap segera hubungi Kepaniteraan Mahkamah Agung RI melalui :
 Halaman 49


# Halaman 50

adalah 556, 094, bukan 535,640, sehingga seharusnya melebihi Angka Kredit 
minimal yang disayaratkan yaitu 550,00;
Menimbang, bahwa berdasarkan pertimbangan tersebut di atas 
dihubungkan dengan kapasitas Tergugat sebagai Pejabat Pembina Kepegawaian 
sebagai ketentuan Pasal 1 angka 14 juncto Pasal 53 Undang-Undang Nomor   5 
Tahun  2014 tentang Aparatur Sipil Negara (Undang-Undang ASN ), maka dalam 
penyelengggaraan kebijakan dan manajemen ASN,  Tergugat terbukti telah 
melangggar asas: Kepastian hukum, Profesionalitas, Proporsionalitas, 
akuntabilitas, efektif dan efisien (vide Pasal 2 Undang-Undang ASN ). Di samping 
itu apabila dihubungkan dengan kepentingan Penggugat yang telah menjalankan 
tugas dan kewajiban PNS dengan jabatan Fungsional Auditor Madya, maka 
tindakan Tergugat menerbitkan surat Keputusan obyek sengketa telah melangggar 
hak Penggugat sebagaimana diatur dalam Pasal 21 Undang-Undang ASN yaitu 
hak atas tunjangan dan pengembangan kompetensi;
Menimbang, bahwa berdasarkan seluruh uraian dalam pertimbangan 
hukum tersebut di atas, Majelis Hakim berpendapat bahwa terbukti Tergugat dalam 
menerbitkan surat keputusan obyek sengketa in casu Surat Keputusan Menteri 
Agama RI Nomor  : B.II/3/00311, tanggal 16 Januari 2015 tentang Pemberhentian 
Penggugat Dari Jabatan Auditor (vide bukti P-4) terbukti mengandung cacat 
prosedural maupun substansial, sehingga Tergugat sebagai Pejabat Pembina 
Kepegawaian Pusat nyata-nyata telah melanggar peraturan perundang-undangan 
yang berlaku dan telah melanggar Asas-Asas Umum Pemerintahan Yang Baik 
sebagaimana uraian dalam pertimbangan hukum di atas, oleh karenanya 
beralasan hukum kalau Majelis Hakim mengabulkan gugatan Penggugat 
seluruhnya dan menyatakan batal Surat Keputusan Menteri Agama Republik 
Disclaimer
Kepaniteraan Mahkamah Agung Republik Indonesia berusaha untuk selalu mencantumkan informasi paling kini dan akurat sebagai bentuk komitmen Mahkamah Agung untuk pelayanan publik, transparansi dan akuntabilitas
pelaksanaan fungsi peradilan. Namun dalam hal-hal tertentu masih dimungkinkan terjadi permasalahan teknis terkait dengan akurasi dan keterkinian informasi yang kami sajikan, hal mana akan terus kami perbaiki dari waktu kewaktu.
Dalam hal Anda menemukan inakurasi informasi yang termuat pada situs ini atau informasi yang seharusnya ada, namun belum tersedia, maka harap segera hubungi Kepaniteraan Mahkamah Agung RI melalui :
 Halaman 50


# Halaman 51

Indonesia Nomor : B.II/3/00311, tanggal 16 Januari 2015 tentang Pemberhentian 
Dari Jabatan Auditor yang menjadi objek sengketa ; 
   Menimbang, bahwa oleh karena surat keputusan obyek sengketa telah 
dinyatakan batal, maka sesuai ketentuan Pasal 97 ayat (9) huruf a Undang-
Undang Nomor  5 Tahun  1986, kepada Tergugat diwajibkan untuk mencabut surat 
keputusan objek sengketa disertai kewajiban kepada Tergugat untuk merehabilitasi 
dengan merehabilitasi dan mengembalikan hak dan kewajiban Penggugat pada 
posisi semula; 
   Menimbang, bahwa karena tuntutan pokok dalam gugatan Penggugat 
telah dikabulkan seluruhnya, maka berdasarkan ketentuan Pasal 110 juncto Pasal 
112 Undang-Undang Nomor  5 Tahun  1986 sebagaimana telah diubah dengan 
Undang-Undang Nomor  9 Tahun  2004 dan perubahan kedua dengan Undang-
Undang Nomor  51 Tahun  2009, sebagai pihak yang kalah Tergugat dihukum untuk 
membayar biaya perkara ini yang jumlahnya akan ditentukan dalam amar putusan 
ini ;  
  Menimbang, bahwa berdasarkan ketentuan Pasal 107 Undang-Undang 
Nomor  5 Tahun  1986 sebagaimana telah diubah dengan Undang-Undang Nomor 9 
Tahun  2004 dan perubahan kedua dengan Undang-Undang Nomor  51 Tahun  
2009, bahwa Majelis Hakim hanya mempertimbangkan bukti-bukti surat yang ada 
relevansinya dengan sengketa  a quo , dengan demikian terhadap bukti-bukti surat 
lainnya yang tidak ada relevansinya dengan sengketa a quo  yang diajukan oleh 
para pihak di persidangan haruslah dikesampingkan, namun tetap merupakan satu 
kesatuan dalam berkas perkara ini ; 
 Mengingat, Undang-Undang Nomor  5 Tahun  1986 tentang Peradilan Tata 
Usaha Negara sebagaimana telah diubah dengan Undang-Undang Nomor  9 
 Halaman 51 dari 53 halaman Putusan No.78/G/2015/PTUN-JKT  
Disclaimer
Kepaniteraan Mahkamah Agung Republik Indonesia berusaha untuk selalu mencantumkan informasi paling kini dan akurat sebagai bentuk komitmen Mahkamah Agung untuk pelayanan publik, transparansi dan akuntabilitas
pelaksanaan fungsi peradilan. Namun dalam hal-hal tertentu masih dimungkinkan terjadi permasalahan teknis terkait dengan akurasi dan keterkinian informasi yang kami sajikan, hal mana akan terus kami perbaiki dari waktu kewaktu.
Dalam hal Anda menemukan inakurasi informasi yang termuat pada situs ini atau informasi yang seharusnya ada, namun belum tersedia, maka harap segera hubungi Kepaniteraan Mahkamah Agung RI melalui :
 Halaman 51


# Halaman 52

Tahun  2004 dan perubahan kedua dengan Undang-Undang Nomor 51 Tahun  2009 
serta peraturan perundang-undangan lain yang berkaitan dengan sengketa ini ; 
M E N G A D I L I
1. Mengabulkan gugatan Penggugat untuk seluruhnya;
2. Menyatakan batal Surat Keputusan Menteri Agama R.I Nomor : B.II/3/00311 
tanggal 16 Januari 2015 tentang Pemberhentian Dari Jabatan Auditor atas 
nama H. AGUS SUSANTO.,  S.H.;
3. Mewajibkan Tergugat untuk mencabut Surat Keputusan Menteri Agama RI 
Nomor B.II/3/00311 tanggal 16 Januari 2015 tentang Pemberhentian Dari 
Jabatan Auditor  atas nama H. AGUS SUSANTO.,  S.H.;
4. Mewajibkan Tergugat untuk merehabilitasi dan mengembalikan hak dan 
kewajiban Penggugat pada posisi semula sebagai Fungsional Auditor Ahli 
Madya ;
5. Menghukum Tergugat untuk membayar  biaya perkara sebesar 
Rp .221.000.-(dua ratus dua puluh satu ribu rupiah);
Demikian diputus dalam rapat permusyawaratan Majelis Hakim Pengadilan  
Tata  Usaha   Negara Jakarta pada hari Kamis, tanggal 9  Juli 2015   oleh kami 
SUBUR M.S.,  S.H., M.H. selaku   Hakim   Ketua  Majelis, NUR AKTI ,  S.H.   dan  
FEBRU WARTATI , S.H., M.H .  selaku  Hakim  Anggota.  Putusan  tersebut 
diucapkan  dalam  sidang   yang  terbuka   untuk   umum pada   hari Rabu, tanggal 
29 Juli  2015,  oleh  Majelis Hakim tersebut dengan dibantu  oleh  YUSUF AMIN , 
S.H., selaku  Panitera  Pengganti  pada Pengadilan   Tata   Usaha    Negara   
Jakarta, dengan dihadiri oleh Kuasa Penggugat dan  Kuasa Tergugat;
Disclaimer
Kepaniteraan Mahkamah Agung Republik Indonesia berusaha untuk selalu mencantumkan informasi paling kini dan akurat sebagai bentuk komitmen Mahkamah Agung untuk pelayanan publik, transparansi dan akuntabilitas
pelaksanaan fungsi peradilan. Namun dalam hal-hal tertentu masih dimungkinkan terjadi permasalahan teknis terkait dengan akurasi dan keterkinian informasi yang kami sajikan, hal mana akan terus kami perbaiki dari waktu kewaktu.
Dalam hal Anda menemukan inakurasi informasi yang termuat pada situs ini atau informasi yang seharusnya ada, namun belum tersedia, maka harap segera hubungi Kepaniteraan Mahkamah Agung RI melalui :
 Halaman 52


# Halaman 53

                                                                                        HAKIM KETUA 
MAJELIS,
HAKIM -HAKIM  ANGGOTA:                          
         TTD            TTD  
I.   NUR AKTI , S.H.                                                     SUBUR M.S., S.H., M.H.
    TTD         
II.  FEBRU WARTATI , S.H.,M.H.
                              PANITERA PENGGANTI
           TTD         
                                    YUSUF AMIN,  S.H.
RINCIAN BIAYA PERKARA  :
1. Pendaftaran Rp. 30.000.-
2. Alat Tulis Kantor Rp.    125..000.-
3.  Materai Rp.        6.000.-
4  Redaksi Rp.        5.000.-
5.  Panggilan Rp.      55.000..-
           J u m l a h……………………    Rp.    .221.000-
          ( dua ratus dua puluh satu ribu rupia )
 Halaman 53 dari 53 halaman Putusan No.78/G/2015/PTUN-JKT  
Disclaimer
Kepaniteraan Mahkamah Agung Republik Indonesia berusaha untuk selalu mencantumkan informasi paling kini dan akurat sebagai bentuk komitmen Mahkamah Agung untuk pelayanan publik, transparansi dan akuntabilitas
pelaksanaan fungsi peradilan. Namun dalam hal-hal tertentu masih dimungkinkan terjadi permasalahan teknis terkait dengan akurasi dan keterkinian informasi yang kami sajikan, hal mana akan terus kami perbaiki dari waktu kewaktu.
Dalam hal Anda menemukan inakurasi informasi yang termuat pada situs ini atau informasi yang seharusnya ada, namun belum tersedia, maka harap segera hubungi Kepaniteraan Mahkamah Agung RI melalui :
 Halaman 53
