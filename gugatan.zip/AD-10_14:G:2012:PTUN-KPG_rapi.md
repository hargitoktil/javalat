Direktori Putusan 1 
 
 P U T U S A N 
Nomor : 14/G/201 2/PTUN -KPG 
 
“ DEMI KEADILAN BERDASARKAN KETUHANAN YANG MAHA ESA “ 
 
Pengadilan Tata Usaha Negara Kupang yang memeriksa, memutus dan 
menyelesaikan Sengketa Tata Usaha Negara pada tingkat pertama dengan acara biasa, telah 
menjatuhkan putusan sebagai berikut di bawah ini, dalam sengketa antara : ------------------ 
Nama : ROFINUS NOE ; --------------------------------------------------------- 
Kewarganegaraan : Indonesia ; ------------------------------------------------------------------- 
Pekerjaan : Tani ; -------------------------------------------------------------- ----------- 
Tempat Tinggal : RT. 003/RW.002, Kelurahan Mautapaga, Kecamatan Ende Timur, 
Kabupaten Ende ; ----------------------------------------------------------- 
Untuk selanjutnya disebut sebagai ........................................................ PENGGUGAT ; 
M E L A W A N 
Nama Jabatan : BUPATI ENDE ; ---------------------------------------------------------- 
Tempat Kedudukan : Jl. Eltari No. 2 Ende ; ------------------------------------------------------- 
Dalam hal ini diwakili oleh : --------------------------------------------------------------------------- 
1. Elisabeth M. Voni Kua, SH Kepala Sub Bidang Pengembangan Karier dan Pembinaan 
Disiplin PNS pada Bidang Pengembangan Badan Kepegawaian Daerah Kabupaten 
Ende ; ------------------------------------------------------------------------------------------------- 
2. Theresia Cisilia Bunga, SH, Kepala Sub Bidang Pensiun PNS pada Bidang Kesra dan 
Pensiun PNS Badan Kepegawaian Daerah Kabupaten Ende berdasarkan Surat Kuasa 
Khusus Nomor : BKD.800/7126/XI/2012 tanggal 26 Nopember 2012 ; ------------------- 
Untuk selanjutny a disebut sebagai........................................................... .......TERGUGAT ; 
 
Pengadilan .... 
Direktori Putusan 2 
 
 Pengadilan Tata Usaha Negara tersebut : ---------------- ----------- ----------------------- ------- 
1. Telah membaca Penetapan Ketua Pengadilan Tata Usaha Negara Kupang Nomor : 
14/PEN -DIS/2012/PTUN -KPG tanggal 30 Oktober 2012 tentang Dismissal ; ------------ - 
2. Telah membaca Penetapan Ketua Pengadilan Tata Usaha Negara Kupang Nomor : 
14/PEN -MH/2012/PTUN -KPG tanggal 30 Oktober 2012 tentang Penunjukan Majelis 
Hakim ; -------------------------------------------------------------------- ---------------------------- 
3. Telah membaca Penetapan Hakim Ketua Majelis Nomor : 14/PEN -PP/201 2/PTUN -
KPG tanggal 30 Oktob er 2012 tentang Hari Pemeriksaan Per siapan ; --------------------- 
4. Telah membaca Penetapan Hakim Ketua Majelis Nomor : 14/PEN.HS/20 12/PTUN -
KPG tanggal 12 Nopember 2012 tentang Hari Sidang ; -------------------------- ------ ------- 
5. Telah memeriksa berkas sengketa, dan bukti para pihak ; --------------------- -------- ------- - 
6. Telah mendengar kedua pihak yang bersengketa dalam persidangan ; -------------- -------- 
TENTANG DUDUK SENGKETA 
Menimbang, bahwa Penggugat dengan surat gugatannya tertanggal 29 Oktober 
2012 yang telah didaftarkan di Kepaniteraan Pengadilan Tata Usaha Negara Kupang 
tanggal 30 Oktober 2012 dalam register Nomor : 14/G/2012/PTUN -KPG dan telah 
diperbaiki pada pemeriksaan persiapan pada tanggal 12 Nopember 2012 pada pokoknya 
mengemukakan hal-hal sebagai berikut : ----------------------------------- -------------------------- 
OBYEK SENGKETA ; ------------------------------------------------------------------------------- 
Bahwa yang menjadi obyek sengketa adalah : ------------------------------------------------------ 
- Surat Keputusan Bupati Ende, Nomor : BKD.880/1747/MUT/2008, Tanggal 22 Juli 
2008, tentang Pemberhentian Tidak Dengan Hormat Saudara Rofinus Noe, NIP. 
010243147 Sebagai Pegawai Negeri Sipil ; ------------------------------------------------------- 
DASAR – DASAR GUGATAN/POSITA ; -------------------------------------------------------- 
1. Bahwa Surat Keputusan Tergugat tersebut telah memenuhi ketentuan Pasal 1 butir 9 
Undang -Undang Nomor 51 Tahun 2009 tentang Perubahan Kedua atas Undang -
Undang ..... 
Direktori Putusan 3 
 
 Undang Nomor 5 Tahun 1986 tentang Peradilan Tata Usaha Negara, yaitu telah 
memenuhi unsur konkrit, individual dan final, serta telah menimbulkan akibat hukum 
yaitu menimbulkan kerugian bagi Penggugat, sehingga Surat Keputusan tersebut dapat 
dijadikan obyek gugata n di Pengadilan Tata Usaha Negara ; ------------------------------- 
2. Bahwa pada tanggal 22 Juli 2008 Penggugat dipanggil oleh Badan Kepegawaian 
Daerah Kabupaten Ende dan menginformasikan bahwa Penggugat sudah diberhentikan 
tidak dengan hormat sebagai P egawai Negeri Sipil dan Penggugat dipersilahkan untuk 
mengambil Surat keputusan Bupati Ende tersebut, tetapi Penggugat menyatakan 
keberatan dan tidak mau menerima keputusan Bupati Ende ; -------------------------------- 
Penggugat secara lisan pada saat itu mohon untuk ditinjau kembali, karena Penggugat 
merasa tidak bersalah, dan tidak pernah dilakukan pemeriksaan oleh Tergugat, sehingga 
pada saat itu Kepala Badan Kepegawaian Daerah Kabupaten Ende membawa kembali 
SK tersebut ke ruang Bupati untuk menyampaika n permintaan klarifikasi dan setelah 
keluar dengan tanpa membawa Surat Keputusan Bupati Ende dari ruang Bupati Ende, 
Kepala Badan Kepegawaian Daerah menyampaikan kepada Penggugat bahwa, “Atas 
perintah Bupati Ende, Kamu (Penggugat) pulang, Bupati Ende masih meninjau kembali 
keputusan itu”, dan nanti hasilnya akan kami sampaikan, ternyata Kepala Badan 
Kepegawaian Daerah Kabupaten Ende dan Tergugat tidak pernah menyampaikan 
kepada Pengggugat Surat Keputusan Pemberhentian Penggugat sebagai Pegawai Negeri 
Sipil maupun Hasil Peninjauan Kembali oleh Bupati Ende atas keputusannya tersebut ;-- 
3. Bahwa Penggugat menerima Surat Keputusan Tergugat tersebut pada tanggal 2 Agustus 
2012 dari Kepala Badan Kepegawaian Daerah Kabupaten Ende ; -------------------------- 
4. Penguggat mendaftar gugatan di Pengadilan Tata Usaha Negara Kupang pada t anggal 
30 Oktober 2012, dengan demikian gugatan ini masih dalam tenggang waktu 90 hari 
sesuai ketentuan Pasal 55 Undang -Undang Nomor 5 Tahun 1986 tentang Peradilan Tata 
Usaha Negara ; -------------------------------------------------------------------- ------------------ 
5. Bahwa ..... 
Direktori Putusan 4 
 
 5. Bahwa berdasarkan Surat Keputusan Gubernur Kepala Daerah Tingkat I Nusa 
Tenggara Timur, Nomor : 813.2/9/18/29 -N,Tanggal 6 Maret 1993, Penggugat terhitung 
tanggal 1 Oktober 1992 diangkat sebagai Calon Pegawai Negeri Sipil Pusat dengan 
NIP. 010243147, Golongan Ruang (II/a), dan ditempatkan di Sekretariat 
Wilayah/Daerah Tingkat II Ende ; ---------------------------------------------------------------- 
6. Bahwa Penggugat diangkat sebagai Pegawai Negeri Sipil berdasarkan Surat Keputusan 
Gubernu r Kepala Daerah Tingk at I Nusa Tenggara Timur, Nomor : 821.13/I/9/26/5639 -
ND,Tanggal 29 Agustus 1994, dengan jabatan Staf Pelaksana pada bagian Penyusunan 
Program dengan Pangkat dan Golongan Ruang Pengatur Muda (II/a) pada Sekretariat 
Wilayah/Daerah Tingkat II Ende ; ---------------------------------- ------------------------------ 
7. Bahwa Penggugat sebagai Pegawai Negeri Sipil telah melaksanakan tugas dengan baik, 
terbukti berdasarkan ketentuan peraturan perundang -undangan Penggugat dinaikan 
pangkatnya berturut -turut : ------------------------------- ----------------------------------------- 
- Tahun 1997 : Pengatur Muda Tk.I (II/b) dalam jabatan Staf Pelaksana pada 
bagian Penyusunan Program di Sekretariat Wilayah/Daerah Tingkat II Ende ; -- 
- Tahun 2001 : Pengatur (II/c) dalam jabatan St af Pelaksana pada Bagian 
Pembangunan di Sekretariat Wilayah/Daerah Tingkat II Ende ; ------------------------- 
8. Bahwa pada tahun 2001 Penggugat di tempatkan di Dinas Perhubungan Kabupaten 
Ende dan mengikuti Pelatihan Praktek Alat Uji Kendaraan Bermotor d an Penglasan 
Konstruksi Kendaraan Bermotor dan memperoleh serifikat dari Ikatan Penguji 
Kendaraan Bermotor Indonesia ; ----------------------------------------------------------------- 
9. Bahwa pada tahun 2005 terjadi Korupsi Pengadaan Alat U ji Kendaraan Roda 4 (empat) 
yang ditangani oleh Aparat Penegak Hukum kabupaten Ende dan Penggugat menjadi 
saksi kunci yang telah memberikan keterangan dan data -data yang jelas kepada 
Penyidik tentang keterlibatan Bupati Ende (Drs. Paulinus Domi) dan Sekret aris 
Kabupaten Ende (Drs. Iskandar Moh. Mberu) tetapi kasusnya sampai saat ini masih 
dalam ..... 
Direktori Putusan 5 
 
 dalam proses karena Bupati Ende (Drs. Paulinus Domi) dan Sekretaris Kabupaten Ende 
(Drs. Iskandar Moh. Mberu) telah menjadi Terpidana kasus Penyalahgunaan APBD ; -- 
10. Bahwa sikap Penggugat memberikan keterangan dan data -data yang jelas kepada 
Penyidik dianggap oleh Bupati Ende (Drs. Paulinus Domi) dan Sekretaris Kabupaten 
Ende (Drs. Iskandar Moh. Mberu) adalah Penggugat dianggap sebagai Pegawai yang 
tidak menjaga rahasi a negara dan rahasia pimpinan, sebagai akibatnya Penggugat 
langsung dimutasikan dari Dinas Perhubungan Kabupaten Ende ke Dinas Pendapatan 
Daerah Kabupaten Ende ; -------------------------------------------------------------------------- 
11. Bahwa selanjutn ya ketika Penggugat melaporkan diri ke Dinas Pendapatan Daerah 
Kabupaten Ende, Kepala Dinas Pendapatan Daerah Kabupaten Ende (Imran Toya 
(almarhum) menolak Penggugat dengan menyatakan “Kau pulang saya tidak butuh 
kau”, oleh karena penolakan tersebut saat i tu juga Penggugat kembali dan 
menyampaikan atau malapor penolakan tersebut dan mohon petunjuk kepada Kepala 
Badan Kepegawaian Daerah Kabupaten Ende (Drs. Makarius Seko (almarhum) dan 
jawaban atau petunjuk dari Kepala Badan Kepegawaian daerah Kabupaten Ende 
adalah, “Kau tunggu Surat Keputusan Bupati yang berikutnya” ; --------------------------- 
12. Bahwa pada tanggal 6 Pebruari 2007 Penggugat dimutasikan dari Dinas Pendapatan 
Daerah Kabupaten Ende ke Dinas Pendaftaran Penduduk Kabupaten Ende, pada 
tanggal 8 Pebruari 2007 Penggugat melapor diri dan mulai melaksanakan tugas di 
Dinas Pendaftaran Penduduk Kabupaten Ende ; ------------------------------------------------ 
13. Bahwa terhitung tanggal 8 Pebruari 2007 sejak Penggugat melaksanakan tugas di Dinas 
Pendaftaran Penduduk Kabupaten Ende, atas perintah Sekretaris Daerah Kabupaten 
Ende kepada Bendahara Gaji Dinas Pendaftaran Penduduk Kabupaten Ende untuk 
menahan pembayaran gaji Penggugat yang waktu itu Penggugat menerima sebesar Rp. 
1.750.434, - (satu juta tujuh ratus lima puluh ribu empat ratus tiga puluh empat rupiah) 
setiap bulan dengan alasan yang tidak jelas dan tidak berdasar ; ----------------------------- 
Penah an..... 
Direktori Putusan 6 
 
 Penahan g aji Pengguga t tersebut sejak bulan Pebruari 2007 sampai dengan bulan Juni 
2007 P enggugat sudah melakukan upaya pendekatan secara kedinasan maupun 
kekeluargaan tetapi Bupati dan Sekretaris Daerah Kabupaten Ende tidak ada tanggapan 
untuk membayar gaji Penggugat ; ---------------------------------------------------------------- 
14. Bahwa pada tanggal 22 Juni 2007 Penggugat dimutasikan lagi ke Badan Kepegawaian 
Daerah dengan alasan untuk melakukan pembinaan terhadap Penggugat dan Penggugat 
tetap melaksanakan tugas dengan baik tanpa menerima gaji ; -------------------------------- 
15. Bahwa walaupun gaji Penggugat terus ditahan dan tidak dibayar, Penggugat tetap aktif 
melaksanakan tugas dan Penggugat tetap terus melakukan upaya dengan segala cara 
untuk mohon belas kasihan kepada Sekretaris Daerah dan Bupati Ende tetapi tidak 
pernah ada tang gapan untuk membayar gaji Penggugat ; ------------------------------------- 
Pada tanggal 5 Oktober 2007 Penggugat menyampaikan permasalahan Penggugat 
kepada Wakil Bupati Kabupaten Ende (Bernadus Gado Bani,BA) agar dapat membantu 
menyelesaikan permasalahan penahanan pembayaran gaji Penggugat, tetapi tidak ada 
hasil ; ------------------------------------------------------------------------------------------------- 
16. Bahwa oleh karena kondisi kebutuhan biaya kehidupan keluarga yang makin sulit, 
Penggugat se bagai Kepala Keluarga mengatur dan mambagi waku mencari nafkah di 
luar kantor tetapi tetap melaksanakan tugas walaupun kadang -kadang terpaksa atas ijin 
pimpinan meninggalkan tugas ; ------------------------------------------------------------------- 
17. Bahwa sikap Tergugat tidak membayar atau manahan pembayaran gaji Penggugat 
dengan tidak berdasar adalah merupakan cara Tergugat untuk mencari kesalahan 
Penggugat, yaitu apabila Penggugat tidak menerima gaji Penggugat akan mengalami 
gangguan atau ketidaknyama nan dalam bekerja sehingga putus asa dan mengalami 
gangguan kinerja seh ingga mudah dicari kesalahannya ; ------------------------------------- 
Tindakan Tergugat tersebut adalah tindakan tidak manusiawi, bertindak sewenang -
wenang serta ber maksud menindas pegawai bawahannya ; ----------------------------------- 
18. Bahwa ..... 
Direktori Putusan 7 
 
 18. Bahwa setelah Penggugat cermati Surat Keputusan Bupati Ende, Nomor : 
BKD.880/1747/MUT/2008, Tanggal 22 Juli 2008, tentang Pemberhentian Tidak 
Dengan Hormat Saudara Rofinus Noe, NI P. 010243147 Sebagai Pegawai Negeri Sipil, 
ternyata surat keputusan yang menjadi obyek sengketa tersebut adalah merupakan sikap 
dan tindakan Tergugat yang bertentangan dengan peraturan perundang -undangan yaitu 
melanggar Peraturan Pemerintah Nomor 30 tahun 1980 tentang Peraturan Disiplin 
Pegawai Negeri Sipil, Pasal 9 ayat (1), yaitu : “ Sebelum menjatuhkan hukuman 
disiplin, pejabat yang berwenang menghukum wajib memeriksa lebih dahulu Pegawai 
Negeri Sipil yang disangka melakukan pelanggaran disiplin it u”, dan melanggar Asas -
asas Umum Pemerintahan Yang Baik yaitu asas kecermatan, asas keadilan, Asas 
perlakuan yang layak dan asas kepastian hukum serta bertindak sewenang -wenang dan 
tidak prosedur sebab, Tergugat tidak pernah memanggil dan melakukan pemerik saan ; - 
19. Bahwa tindakan Tergugat tersebut merugikan Penggugat berupa kenaikan gaji berkala, 
pembuatan DP3, kenaikan pangkat, tidak menerima gaji sejak bulan Pebruari tahun 
2007 sampai dengan saat ini ; -------------------------------------------------- ------------------- 
 
PETITUM / TUNTUTAN 
Berdasarkan alasan -alasan yang diuraikan diatas, maka Penggugat mohon Majelis Hakim 
yang memeriksa, mengadili, memutus dan menyelesaikan sengketa ini dapat menjatuhkan 
putusan dengan amar sebagai berikut : --------- ------------------------------------------------------ 
1. Mengabulkan gugatan Penggugat untuk seluruhnya ; ------------------------------------- 
2. Menyatakan bahwa Tergugat dalam mengeluarkan Surat Keputusan Nomor : 
BKD.880/1747/MUT/2008, Tanggal 22 Juli 2008 tentang Pemberhentian Tidak 
Dengan Hormat Saudara Rofinus Noe, NIP. 010243147 Sebagai Pegawai Negeri 
Sipil bertentangan dengan Peraturan Pemeri ntah Nomor 30 Tahun 1980, Pasal 9 
ayat (1) dan asas kecermatan, keadilan serta asas kepastian hukum ; ------------------- 
3. Menyatakan ..... 
Direktori Putusan 8 
 
 3. Menyatakan batal atau tidak sah S urat Keputusan Bupati Ende, Nomor : 
BKD.880/1747/MUT/2008, Tanggal 22 Juli 2008, tentang Pemberhen tian Tidak 
Dengan Hormat Saudara Rofinus Noe, NIP. 010243147 Sebagai Pegawai Negeri 
Sipil ; --------------------------------------------------------------------------------------------- 
4. Memerintahkan kepada Tergugat untuk mencabut S urat Keputusan Bupa ti Ende, 
Nomor : BKD.880/1747/MUT/2008, Tanggal 22 Juli 2008, tentang Pemberhentian 
Tidak Dengan Hormat Saudara Rofinus Noe, NIP. 010243147 sebagai Pegawai 
Negeri Sipil ; ------------------------------------------------------------------------------------ 
5. Memerintahkan Tergugat menerbitkan surat keputusan baru tentang mengaktifkan 
atau mengangkat kembali Penggugat sebagai mana layaknya Pegawai Negeri Sipil 
sesuai perundang -undangan yang berlaku ; ------------------------------------------------- 
6. Memer intahkan Tergugat untuk merehabilitasi/memulihkan hak -hak Penggugat 
sebagaimana hak -hak seorang Pegawai Negeri Sipil sesuai dengan peraturan 
perundang -undangan yang berlaku ; --------------------------------------------------------- 
7. Menghukum Tergugat untuk membayar segala biaya yang timbul dalam sengketa 
ini ; ------------------------------------------------------------------------------------------------ 
Menimbang, bahwa terhadap gugatan Penggugat, Tergugat telah mengajukan 
Jawaban lisan pada persi dangan tanggal 27 Nopember 2012, yang pada pokoknya adalah 
Point 1 sam pai dengan point 8 adalah benar adanya dan point -point 9 sampai dengan 11 
adalah kewena ngan aparat penegak Hukum ( Polisi ) serta Point 12 sam pai dengan 19 
adalah benar ; --------------------------------------------------------------------------------------------- 
 Menimbang, bahwa atas jawaban lisan Tergugat, pihak Penggugat telah mengajukan 
Replik secara lisan pula pada persidangan tangg al 27 Nopember 2012 yang pada pokoknya 
menyatakan tetap pada gugatan Penggugat semula ; --------------------------------------- -------- 
Menimbang, bahwa atas Replik lisan Penggugat, pihak Tergugat telah 
mengajukan Duplik secara lisan pula pada persidangan tanggal 27 Nopember 2012, yang 
pada pokoknya menyatakan tetap pada jawaban lisan Tergugat semula ; ----------------------- 
Menimbang ..... 
Direktori Putusan 9 
 
 Menimbang, bahwa untuk menguatkan dalil -dalilny a Penggugat telah mengajukan 
bukti -bukti surat berupa foto copy yang telah bermaterai cukup dan telah dicocokan serta 
telah dilegalisir, sehingga sah sebagai alat bukti yang diberi tanda P - 1 sampai dengan P - 8 
bukti tersebut sebagai berikut : --------- ------------ --------------------------------------------------- 
- Bukti P. 1 : Fotocopy Surat Bupati Ende Nomor : BKD.880/1747/MUT/2008 
tanggal 22 Juli 2008 Tentang Pemberhentian Tidak Dengan Hormat 
Saudara ROFINUS NOE NIP. 010213147 SEBAGAI PEGAWAI 
NEGERI SIPIL ( sesuai dengan aslinya ) ---------------------------------- 
- Bukti P. 2 : Fotocopy Surat Ke pala Badan Kepegawaian Daerah Kabupaten Ende 
Nomor BKD.800/3586/VIII/PK/2012 tanggal 2 Agustus 2012 
tentang Berita Acara Penyerahan Keputusan Bupati Ende Nomor : 
BKD.880/1747/MUT/2008 tanggal 22 Juli 2008 Tentang 
Pemberhentian Tidak Dengan Hormat Saudara ROFINUS NOE 
NIP. 010213147 SEBAGAI PEGAWAI NEGERI SIPIL ( sesuai 
dengan aslinya ) ------------------------------------------------------------- 
- Bukti P. 3 : Fotocopy Surat Gubernur Kepala Daerah Tingkat I Nusa Tenggara 
Timur Nomor 813.2/9/18/29 -N ta nggal 6 Maret 1993 Tentang 
mengangkat saudara ROFINUS NOE menjadi calon Pegawai Negeri 
Sipil ( sesuai dengan aslinya ) ---------------------------------------------- 
- Bukti P. 4 : Fotocopy Surat Gubernur Kepala Daerah Tingkat I Nusa Tenggara 
Timur No mor 821.13/I/9/26/563 -ND tanggal 29 - 1994 Tentang 
mengangkat saudara ROFINUS NOE menjadi Pegawai Negeri Sipil 
(sesuai dengan aslinya ) ------------------------------------------------------ 
- Bukti P. 5 : Fotocopy Surat Kepala Badan Kepegawaian Negara Nomor : II.01 -
24/48001/KEP/IV/2001 tanggal 20 Pebruari 2001 tentang Kenaikan 
Pangkat ROFINUS NOE ( sesuai dengan aslinya ) --------------------- 
- Bukti P. 6..... 
Direktori Putusan 10 
 
 - Bukti P. 6 : Fotocopy Surat Keterangan Ikatan Penguji Ke ndaraan Bermotor 
Indonesia Nomor : 215/DPP/IPKBI/2003 ( sesuai dengan aslinya) -- 
- Bukti P. 7 : Fotocopy Surat Bupati Ende Nomor : SK.273.824/1286/MUT/2001 
tanggal 3 Agustus 2001 tentang Mutasi/Perbantuan Pegawai Negeri 
Sipil Lingkup Pemerinta Kabup aten Ende ( sesuai dengan aslinya ) --- 
- Bukti P. 8 : Fotocopy Surat Bupati Ende Nomor : KEP.045.824/0165/II/2007 
tanggal 6 Pebruari 2007 tentang Perpindahan Pegawai Negeri Sipil 
Lingkup Pemerinta Kabupaten Ende ( sesuai dengan aslinya ) --------- 
Meni mbang, bahwa untuk menguatkan dalil -dalilnya Tergugat telah mengajukan 
bukti surat berupa foto copy yang telah bermaterai cukup dan telah dicocokan serta telah 
dilegalisir sehingga sah sebagai alat bukti yang diberi tanda T - 1 bukti tersebut adalah 
sebagai berikut ; --------------------- ---------- --------------------------------- -------------------------- 
- Bukti T. 1 : Fotocopy Surat Bupati Ende Nomor : BKD.880/1431 /MUT/2008 
tanggal 25 Juli 2008 Tentang Pemberhentian Tidak Dengan Hormat 
Saudara ROFINUS NOE NIP. 010213147 SEBAGAI PEGAWAI 
NEGERI SIPIL ( sesuai dengan aslinya ) ---------------------------------- 
Menimbang bahwa dalam persidangan Tergugat juga menyerahkan lampiran bukti 
yaitu: ---------------------------------------------------------- --------------------------------------------- 
- Peraturan Pemerintah Nomor 30 Tahun 1980 tentang Peraturan Disiplin Pegawai 
Negeri Sipil (bukti lampi ran Bukti T-1) ; ---------------------------------------------------- -- 
Menimbang, bahwa dalam persidangan baik Penggugat maupun Tergugat tidak 
mengajukan saksi walaupun kesempatan untuk itu telah diberikan secara patut oleh 
Majeleis Hakim ; ------------------- ---------- ------------------------- ---------------------------- ------- 
Menimbang, bahwa Penggugat telah mengajukan kesimpulan tanggal 27 Desember 
2012 sedangkan Tergugat mengajukan kesimpulannya tertanggal 20 Desember 2012 
melalui pos surat tercatat dan diserahkan/diterima oleh Majelis Hakim Pengadilan T ata 
Usaha Negara Kupang tanggal 27 Desember 2012 ------------------------------------------------ 
Menimbang ..... 
Direktori Putusan 11 
 
 Meninbang, ba hwa kedua belah pihak sudah tidak mengajukan apa -apa lagi dan 
akhirnya mohon putusan ; ------------------------------------------------------------------------------ 
 Menimbang, bahwa hal -hal yang belum termuat dalam putusan ini telah tercatat 
dalam Berita Acara Sidang yang merupakan satu kesatuan dengan putusan ini ; ------- -- 
TENTANG PERTIMBANGAN HUKUM 
Menimbang, bahwa maksud dan tujuan gugatan Penggugat (Rofinus Noe) adalah 
sebagaimana terurai di atas ; -------------------------------------------- -------------------------------- 
Menimbang, bahwa yang menjadi objek sengketa adalah Surat Keputusan Bupati 
Ende, Nomor : BKD.880/1747/MUT/2008, tanggal 22 Juli 2008, Tentang Pemberhentian 
Tidak Dengan Hormat Saudara Rofinus Noe, NIP. 010243147 (Bukti P – 1) ; ----------------- 
Menimbang, bahwa ketentuan Pasal 1 angka 9 Undang -Undang Nomor : 51 tahun 
2009 Tentang Perubahan Kedua Atas Undang -Undang Nomor : 5 tahun 1986 Tentang 
peradilan Tata Usaha Negara, yang dapat dijadikan objek sengketa di Pengadilan Ta ta 
Usaha Negara hanyalah berupa suatu penetapan tertulis (Beschikking) y ang dikeluarkan 
oleh Badan atau Pejabat Tata Usaha Negara yang berisi tindakan hukum Tata Usaha 
Negara yang berdasarkan peraturan perundang -undangan yang berlaku, yang bersifat 
konkrit , individual, dan final yang menimbulkan akibat hukum bagi seseorang atau badan 
hukum perdata ; ------------------------------------------------------------------------------------------ 
Menimbang, bahwa Surat Keputusan objek sengketa a quo (Vide Bukti P – 1) yang 
dikeluarkan oleh Tergugat (Bupati Ende) secara limitatif memenuhi semua unsur secara 
komulatif pengertian Keputusan Tata Usaha Negara sebagaimana dimaksud Pasal 1 angka 
9 Undang -Undang Nomor 51 Tahun 2009 tentang Perubahan Kedua Atas Undang -Undang 
Nomor 5 Tahun 1986 Tentang Peradilan Tata Usaha Negara, dengan alasan -alasan sebagai 
berikut : --------------------------------------------------------------------------------------------------- 
- Bentuk formalnya Surat Keputusan Obyek sengketa a quo (Vide Bukti P – 1) 
merupakan penetapan tertulis ; --------------------------------------------------------------- 
Di keluarkan ..... 
Direktori Putusan 12 
 
 - Di keluarkan oleh Tergugat (Bupati Ende) selaku Badan atau Pejabat Tata Usaha 
Negara y ang melaksanakan urusan Pemerintahan (kegiatan eksekutif) dibidang 
kepegawaian berdasarkan peraturan publik sebagai peraturan dasarnya ; -------------- 
- Surat Keputusan Obyek sengketa a quo (Vide Bukti P – 1) telah bersifat kongkrit 
dan jelas individualis asinya yang telah menimbulkan akibat hukum berupa 
Pemberhentian Tidak Dengan Hormat , yang menimbulkan kerugian bagi Penggugat 
(Rofinus Noe) dan juga telah bersifat final (definitif) sebagai Keputusan akhir tanpa 
ada persetujuan instansi lain lagi ; ------------------------------------------------------------ 
Menimbang, bahwa berdasarkan alasan -alasan tersebut secara yuridis normatif Surat 
Keputusan objek sengketa a quo (Vide Bukti P – 1) dapat dikatagorikan sebagai Keputusan 
Tata Usaha Negara yang dapat diuji (toessing) keabsahannya dal am persidangan ; ----------- 
Menimbang, bahwa surat gugatan Penggugat tertanggal 29 Oktober 2012 yang 
didaftarkan di Kepaniteraan Pengadilan Tata Usaha Nega ra Kupang tanggal 30 Oktober 
2012 dengan Register Perkara No.14/G/2012/ PTUN -KPG ; ------------------------------------- 
Menimbang, bahwa ketentuan Pasal 55 Undang -Undang Nomor 5 Tahun 1986 
Tentang Peradilan Tata Usaha Negara Tentang tenggang waktu Pengaj uan gugatan secara 
limitatif telah menentukan bahwa "Gugatan dapat diajukan hanya dalam tenggang waktu 90 
(sembilan puluh) hari terhitung sejak saat diterimanya atau diumumkannya Keputusan 
Badan atau Pejabat Tata Usaha Negara ; ---------------------------- --------------------------------- 
Menimbang, bahwa Penggugat (Rofinus Noe) dalam gugatan menjelaskan bahwa ia 
menerima adanya Surat Keputusan Tata Usaha Negara (obyek sengketa a quo) berupa Surat 
Keputusan Bupati Ende, Nomor : BKD.880/1747/MUT/2008, tangga l 22 Juli 2008, 
Tentang Pemberhentian Tidak Dengan Hormat Saudara Rofinus Noe, NIP. 010243147 
(Vide Bukti P – 1) yang diterbitkan Bupati Ende dari Kepala Badan Kepegawaian Daerah 
Kabupaten Ende tanggal 2 Agustus 2012 (Vide Bukti P – 2) ; ------------------------------------ 
Menimbang, bahwa Penggugat adalah Pihak Ill yang tidak dituju langsung oleh 
Keputusan Tata Usaha Negara, dengan demikian tenggang waktu 90 (sembilan puluh) hari 
dihitung ..... 
Direktori Putusan 13 
 
 dihitung secara ka suistis sejak saat ia merasa kepentingannya dirugikan dan menerima 
adanya Keputusan Tata Usaha Negara, merujuk pada Yurisprudensi Mahkamah Agung RI 
Nomor : 5 K/TUN/1992 tanggal 21 Januari 1993 Juncto Yurisprudensi Mahkamah Agung 
RI Nomor : 41 K/TUN/1994 ta nggal 10 November 1994 Juncto Yurisprudensi Mahkamah 
Agung RI Nomor : 270 K/TUN/2001 tanggal 4 Mei 2002, dari ketiga Yurisprudensi 
tersebut di atas dapat disarikan initisari dari kaidah hukumnya bahwa "dalam hal tenggang 
waktu pengajuan gugatan bagi Pihak Ketiga yang tidak dituju langsung oleh Keputusan 
Tata Usaha Negara yang tidak menerima atau tidak mengetahui adanya Keputusan Badan 
atau Pejabat yang menerbitkan Keputusan sebagaimana dimaksud dalam Pasal 55 
Undang -Undang Nomor : 5 Tahun 1986 tentang Perad ilan Tata Usaha Negara secara 
kasuistis sejak Pihak Ketiga tersebut menerima dan merasa kepentingannya dirugikan oleh 
Keputusan Tata Usaha Negara yang merugikan tersebut" ; -------------------------------------- 
Menimbang, bahwa dalam Jawaban Tergugat sec ara lisan yang termuat dalam berita 
acara persidangan tertanggal 27 Nopember 2012 menjelaskan bahwa benar Penggugat 
(Rofinus Noe) menerima adanya Surat Keputusan Tata Usaha Negara berupa Surat 
Keputusan Bupati Ende, Nomor : BKD.880/1747/MUT/2008, tanggal 22 Juli 2008, 
Tentang Pemberhentian Tidak Dengan Hormat Saudara Rofinus Noe, NIP. 010243147 
(Vide Bukti P – 1) yang diterbitkan Bupati Ende dari Kepala Badan Kepegawaian Daerah 
Kabupaten Ende tanggal 2 Agustus 2012 (Vide Bukti P – 2) ; -------------------- ---------------- 
Menimbang, bahwa dengan demikian dalil gugatan Penggugat (Rofinus Noe) dan 
Jawaban Tergugat yang menyatakan Penggugat (Rofinus Noe) telah mengetahui sejak 
tanggal 2 Agustus 2012 (Vide Bukti P – 2) secara yuridis didukung pada alasan yang ti dak 
dibantah pada persidangan oleh Tergugat yang merupakan suatu kebenaran ; ----------------- 
Menimbang, bahwa dengan alasan pertimbangan demikian Pengadilan berpendapat 
sebagai dasar perhitungan tenggang waktu dimulai nya Penggugat (Rofinus Noe) 
mengetahui obyek sengketa menggunakan prinsip Contextualism yaitu Asas Noscitur a 
Sociis dikaitkan dengan pemberitahuan terhadap obyek sengketa yang merupakan suatu 
tindakan ..... 
Direktori Putusan 14 
 
 tindakan hukum Tergugat yaitu sejak Penggugat (Rofinus Noe) men erima adanya Surat 
Keputusan Tata Usaha Negara (obyek sengketa a quo) berupa Surat Keputusan Bupati 
Ende, Nomor : BKD.880/1747/MUT/2008, tanggal 22 Juli 2008, Tentang Pemberhentian 
Tidak Dengan Hormat Saudara Rofinus Noe, NIP. 010243147 (Vide Bukti P – 1) yang 
diterbitkan Bupati Ende dari Kepala Badan Kepegawaian Daerah Kabupaten Ende tanggal 
2 Agustus 2012 (Vide Bukti T – 2) ; ----------------------------------------------- -------- ----------- 
Menimbang, bahwa dengan demikian merujuk pada Yurisprudensi Mahk amah 
Agung RI Nomor : 5 K/TUN/1992 tanggal 21 Januari 1993 Juncto Yurisprudensi 
Mahkamah Agung RI Nomor : 41 K/TUN/1994 tanggal 10 November 1994 Juncto 
Yurisprudensi Mahkamah Agung RI Nomor : 270 K/TUN/2001 tanggal 4 Mei 2002, dan 
prinsip contextualism dan Jawaban Tergugat secara lisan yang termuat dalam berita acara 
persidangan tertanggal 27 Nopember 2012 serta dihitung sejak Penggugat (Rofinus Noe) 
menerima Obyek sengketa a quo (Vide Bukti P – 1) secara kasuisitis tanggal 2 Agustus 
2012 (Vide Bukti P – 2) sampai dengan gugatan diajukan di Pengadilan Tata Usaha Negara 
Kupang tanggal 30 Oktober 2012 terhitung 89 (Delapan Puluh Sembilan) hari, jadi masih 
dalam tenggang waktu 90 (Sembilan Puluh) Hari sebagaimana dimaksudkan Pasal 55 
Undang -Undang Nomor : 5 Tahun 1986 tentang Peradilan Tata Usaha Negara ; -------------- 
Menimbang, bahwa ketentuan pasal 48 ayat (1) Undang -Undang Nomor : 5 Tahun 
1986 tentang Peradilan Tata Usaha Negara mengatakan bahwa : -------------------------------- 
“Dalam hal suatu badan atau Pejabat Tata Usaha Negara diberi wewenang oleh atau 
berdasarkan peraturan Perundang -undangan untuk menyelesaikan secara administratif 
sengketa Tata Usaha Negara tertentu, maka sengketa tersebut harus diselesaikan 
melalui upaya ad ministratif yang tersedia ; ----------------------------------------------------- 
Menimbang, bahwa pasal 48 ayat (2) Undang -Undang Nomor : 5 Tahun 1986 Tentang 
Peradilan Tata Usaha Negara lebih lanjut menentukan bahwa : ------------------------ ---------- 
“Pengadilan baru berwenang memeriksa, memutus, dan menyelesaikan Sengketa Tata 
Usaha Negara tersebut jika seluruh upaya administratif yang bersangkutan telah 
digunakan ; --------------------------------------------------------------------- --------------------- 
Menimbang ..... 
Direktori Putusan 15 
 
 Menimbang, bahwa selanjutnya ketentuan Pasal 50 Undang -Undang Nomor : 5 
Tahun 1986 Tentang Peradilan Tata Usaha Negara, menyebutkan : ----------------------------- 
“Pengadilan Tata Usaha Negara bertugas dan berwenang memeriksa, memutu s, dan 
menyelesaikan sengketa Tata Usaha Negara di tingkat pertama” ; -------------------------- 
Menimbang, bahwa ketentuan Pasal 15 ayat (2) Peraturan Pemerintah Nomor : 30 
Tahun 1980 Tentang Disiplin Pegawai Negeri Sipil, menyebutkan : ------------------ ---------- 
“Pegawai Negeri Sipil yang dijatuhi salah satu hukuman disiplin sebagaimana yang 
dimaksud dalam Pasal 6 ayat (3) dan ayat (4) dapat mengajukan keberatan kepada 
atasan pejabat yang berwenang menghukum dalam jangka waktu 14 (empat belas) hari 
terhitung mulai tanggal ia menerima keputusan hukuman disiplin tersebut” ; ------------- 
Menimbang, bahwa upaya administratif adalah suatu prosedur yang dapat ditempuh 
oleh orang atau badan hukum perdata apabila tidak puas terhadap suatu Keputusan Tata 
Usaha N egara yang dilaksanakan di lingkungan pemerintahan sendiri (penjelasan Pasal 48 
ayat (1)) ; -------------------------------------------------------------------------------------------------- 
Menimbang, bahwa untuk mengetahui tersedia atau tidaknya upaya ad ministratif 
dalam suatu penyelesaian sengketa administrasi harus di telusuri dari peraturan yang 
menjadi dasar diterbitkannya Keputusan Tata Usaha Negara ; ------------------------------------ 
Menimbang, bahwa konsiderans yuridis “Mengingat” pada Keputusan Tata Usaha 
Negara / obyek sengketa a quo (Vide Bukti P – 1) dan Bukti Tergugat (Bukti T – 1) di 
dasarkan Peraturan Perundang -undangan sebagai berikut : ---------------------------------------- 
1. Undang -Undang Nomor : 8 Tahun 1974 Juncto Undang -Unda ng Nom or 43 Tahun 
1999 ; --------------------------------------------------------------------------------------------- 
2. Peraturan Pemerintah Nomor : 4 Tahun 1966 ; --------------------------------------- ------ 
3. Peraturan Pemerintah Nomor : 32 Tahun 1979 Ju ncto Peraturan Pemerintah Nomor : 
1 Tahun 1994 ; ----------------------------------------------------------------------- ----------- 
4. Peraturan Pemerintah Nomor : 9 Tahun 2003 ; ------------------------------- -------------- 
5. Keputusan Kepala Badan Kepegawaian Negara Nomor : 13 Ta hun 2003 ; ------------ 
Menimbang ..... 
Direktori Putusan 16 
 
 Menimbang, bahwa seluruh Peraturan Perundang -undangan tersebut dikaitkan 
dengan Keputusan Tata Usaha Negara sebagai dasar diterbitkan obyek sen gketa a quo 
(Vide Bukti P – 1) dan bukti Tergugat (Vide Bukti T – 1) tidak menyediakan penggunaan 
upaya administratif sebagaimana yang dimaksud dalam Pasal 48 Undang -Undang Nomor : 
5 Tahun 1986 tentang Peradilan Tata Usaha Negara sehingga sesuai ketentuan Pasal 50 
Undang -Undang Nomor : 5 Tahun 1986 tentang Peradilan Tata Usaha Negara dapat 
digunakan upaya prosedur gugatan langsung ke Pengadilan Tata Usaha Negara Kupang 
sebagai tingkat pertama ; ---------------------- ----------------------------------------- ---------------- 
Menimbang, bahwa unsur kepentingan merupakan unsur essensial yang dapat 
menimbulkan hak bagi orang atau badan hukum perdata untuk mengajukan suatu gugatan 
sebagaimana dalam Pasal 53 Ayat (1) Undang -Undang Nomor : 5 Tahun 1986 Tentang 
Perad ilan Tata Usaha Negara yang merupakan suatu asas hukum acara Peradilan Tata 
Usaha Negara, yaitu tidak ada kepentingan tidak ada gugatan (No Interest No Action) , 
sehingga unsur kepentingan perlu dipertimbangkan lebih dahulu sebelum 
mempertimbangkan sah atau tidaknya Keputusan Tata Usaha Negara yang menjadi objek 
sengketa a quo (Vide Bukti P – 1) ; ------------------------------------------------------------------- 
Menimbang, bahwa sebelum Majelis Hakim mempertimbangkan terhadap pokok 
sengketa, terlebih dahul u Majelis Hakim akan mempertimbangkan, apakah Penggugat 
(Rofinus Noe) orang yang berkepentingan untuk mengajukan gugatan sebagai orang yang 
kepentingannya dirugikan sebagai akibat dikeluarkan Surat Keputusan objek sengketa a 
quo (Vide Bukti P – 1) ; -------------------------------------------------------------------------------- 
Menimbang, bahwa berdasarkan gugatan, jawab -jinawab serta bukti surat yang 
diperiksa dipersidangan terdapat fakta hukum sebagai berikut : --------------- ------------------ 
- Bahwa, benar berdasarkan Surat Keputusan Bupati Ende, Nomor : 
BKD.880/1747/MUT/2008, tanggal 22 Juli 2008, Saudara Rofinus Noe, NIP. 
010243147 telah diberhentikan Tidak Dengan Hormat (Vide Bukti P – 1) dan Bukti 
Terguga t yaitu Surat Keputusan Bupati Ende, Nomor : BKD.880/1431/MUT/2008, 
Tang gal..... 
Direktori Putusan 17 
 
 tanggal 25 Juli 2008, Tentang Pemberhentian Tidak Dengan Hormat Saudara 
Rofinus Noe, NIP. 010243147 sebagai Pegawai Negeri Sipil (Vide Bukti T – 1) ; --- 
Menimbang, bahwa atas diterbitkan Surat Keputusan O bjek Sengketa a quo (Vide 
Bukti P – 1) Penggugat (Rofinus Noe) merasa sangat dirugikan kepentingannya, karena 
Penggugat (Rofinus Noe) telah diberhentikan Tidak Dengan Hormat (Vide Bukti P – 1) ; --- 
Menimbang, bahwa berdasarkan fakta hukum tersebut diatas, Majelis Hakim 
berkesimpulan bahwa Penggugat (Rofinus Noe) adalah orang yang berkepentingan untuk 
mengajukan gugatan dalam sengketa Tata Usaha Negara ini ; ------------------------------------ 
Menimbang, bahwa Penggugat dalam gugatannya me ndalilkan penerbitan objek 
sengketa a quo (Vide Bukti P – 1) yang dikeluarkan oleh Tergugat telah bertentangan 
dengan Peraturan Perundang -undangan yaitu melanggar Peraturan Pemerintah Nomor : 30 
Tahun 1980 tentang Peraturan Disiplin Pegawai Negeri Sipil Pa sal 9 ayat (1) ( bukti 
Lampiran Bukti T – 1) dan melanggar Asas -Asas Umum Pemerintahan Yang Baik yaitu 
asas kecermatan, asas keadilan, asas perlakuan yang layak dan asas kepastian hukum serta 
bertindak sewenang -wenang ; ------------------------------------- ------------------------------------- 
Menimbang, bahwa terhadap dalil -dalil gugatan Penggugat telah dibenarkan oleh 
Tergugat (Bupati Ende) dalam jawabannya tertanggal 27 Nopember 2012, yang pada 
Pokoknya penerbitan objek sengketa a quo (Vide Bukti P – 1) yang dikeluarkan oleh 
Tergugat (Bupati Ende) telah bertentangan dengan Peraturan Perundang -undangan yaitu 
melanggar Peraturan Pemerintah Nomor : 30 Tahun 1980 tentang Peraturan Disiplin 
Pegawai Negeri Sipil Pasal 9 ayat (1) (Vide bukti Lampiran Bukti T – 1) dan melanggar 
Asas -Asas Umum Pemerin tahan Yang Baik yaitu asas kecermatan, asas keadilan, asas 
perlakuan yang layak dan asas kepastian hukum serta bertindak sewenang -wenang ; --------- 
Menimbang, bahwa berdasarkan jawab -jinawab tersebut, maka yang perlu 
dibuktikan dan merupa kan pokok persengketaan dalam sengketa a quo (Vide Bukti P – 1) 
adalah apakah penerbitan objek sengketa a quo (Vide Bukti P – 1) yang dikeluarkan oleh 
Tergugat ..... 
Direktori Putusan 18 
 
 Tergugat (Bupati Ende) bertentangan dengan Peraturan Perundang -undangan yang berlaku 
serta bertentangan d engan Asas -Asas Umum Pemerintahan Yang Baik (AAUPB) ; ---------- 
Menimbang, bahwa Majelis Hakim di dalam mempertimbangkan terhadap pokok 
persengketaan a quo akan menguji secara marginal toetsing recht atau pengujian secara 
terbatas pada permasalahan hukum (Rechmatigeheid) ; ------------------------------------ -------- 
Menimbang, bahwa untuk memperkuat dalil gugatannya Penggugat telah 
mengajukan alat bukti surat yang diberi tanda bukti P – 1 sampai dengan P – 8 dan tidak 
mengajukan saksi meskipun telah dibe ri kesempatan yang patut oleh Majelis Hakim, 
sedangkan Tergugat tidak membantah dan untuk memperkuat dalil jawaban kebenarannya 
telah mengajukan alat bukti surat yang diberi tanda bukti T – 1 dan Lampiran yang diberi 
tanda bukti Lampiran Bukti T – 1 serta tidak mengajukan saksi meskipun telah diberi 
kesempatan yang patut oleh Majelis Hakim, yang selengkapnya sebagaimana termuat 
didalam Berita Acara Persidangan yang merupakan satu kesatuan yang tidak terpisahkan 
dengan Putusan ini ; ------------------- ------ ------------------------------------------------------------ 
Menimbang, bahwa berdasarkan Bukti P – 7 yakni Surat Keputusan Bupati End e, 
Nomor : SK.273.824/1286/MUT/2001, tanggal 3 Agustus 2001, Saudara Rofinus Noe, NIP. 
010243147 di Mutasi / di perbantukan dari Bagian Pembangunan Setda Kabupaten Ende 
(jabatan lama) ke Dinas Perhubungan Kabupaten Ende (jabatan baru) ; ------------------- ----- 
Menimbang, bahwa selanjutnya berdasarkan Bukti P – 8 yakni Surat Keputusan 
Bupati Ende, Nomor : KEP.045.824/0165/II/2007, tanggal 6 Pebruari 2007 Saudara 
Rofinus Noe, NIP. 010243147 dipindahkan dari Dinas Pendapatan Daerah Kabupaten Ende 
ke Dinas Pen daftaran Penduduk Kabupaten Ende dan berdasarkan Bukti P – 1 yakni Surat 
Keputusan Bupati Ende, Nomor : BKD.880/1747/MUT/2008, tanggal 22 Juli 2008, 
Saudara Rofinus Noe, NIP. 010243147 telah diberhentikan Tidak Dengan Hormat ; --------- 
Menimbang, bahwa Peraturan Pemerintah Nomor : 96 Tahun 2000 Juncto Peraturan 
Pemerintah Nomor 9 Tahun 2003 Tentang Wewenang Pengangkatan, Pemindahan, dan 
Pemberhentian Pegawai Negeri Sipil disebutkan bahwa : ----------------------------------------- 
Pasal 1 angka 5 ..... 
Direktori Putusan 19 
 
 Pasal 1 angka 5 : Pejabat Pembina Kepegawaian Kabupaten / Kota adalah 
Bupati/Walikota ; ---------------------------------------------------- 
Pasal 25 ayat (1) huruf b : Pejabat Pembina Kepegawaian Daerah Kabupaten/Kota 
menetapkan Pemberhentian Pegawai Ne geri Sipil daerah 
Kabupaten/Kota yang berpangkat Penata Tingkat I golongan 
ruang III/d ke bawah di lingkungannya ; -------------------------- 
Menimbang, bahwa b erdasarkan ketentuan tersebut, maka Majelis Hakim 
berkesimpulan bahwa Tergugat (Bupati Ende) memiliki kewenangan untuk mencabut dan 
menerbitkan obyek sengketa a quo (Vide Bukti P – 1) yang diperolehnya secara atributif 
dari Peraturan Perundang -undangan yang berlaku ; ------------------ ------------------------------ 
Menimbang, bahwa Penggugat (Rofinus Noe) diduga tidak melaksanakan tugas 
kedinasan tanpa alasan yang dapat di pertanggungjawabkan selama 6 (enam) bulan 
berturut -turut terhitung sejak tanggal 4 Januari 2008 sampai dengan 3 Juli 2008 ; ------------ 
Menimbang, bahwa jika diperhatikan Dictum “M emutuskan” (Vide Bukti P – 1) 
disebutkan bahwa : --------------------------------------------------------------------- ----------------- 
PERTAMA : Memberhentikan tidak dengan hormat sebagai Pegawai Negeri Sipil 
tersebut dibawah ini : ----------------------- --------------------------------- ---- 
 Nama : ROFINUS NOE ; ------------- --------------- 
 NIP : 010243147 ; ------------------- --------------- 
 Tempat/Tanggal lahir : Ende 18 Januari 1968 ; --------------------- 
 Pangkat/Golongan Ruang : Pengatur (II/c) ; ------------------ ------------ 
 Jabatan : Staf ; ----------------------------- -------------- 
 Unit Kerja : Badan Kepegawaian Daerah Kabupaten 
Ende ; ----------------------------------------- 
 Instansi : Pemerin tah Kabupaten Ende Propinsi 
Nusa Tenggara Timur ; -------- ------------- 
 Terhitung mulai tanggal : 28 Maret 2008 ; --------------- --------------- 
KEDUA ..... 
Direktori Putusan 20 
 
 KEDUA : Apabila dikemudian hari ternyata terdapat kekeliruan dalam Keputusan 
ini akan diadakan perbaikan dan perhitungan kembali sebagaimana 
mestinya ; -------------------------------------------------------------------------- 
Menimbang, bahwa Pasal 9 ayat (1) Peraturan Pemerintah Nomor : 30 Tahun 1980 
tentang Peraturan Disiplin Pegawai Negeri Sipil (Vide bukti Lampiran Bukti T – 1), 
mengatakan bahwa : -------------------------------------------------------- ----------------------------- 
“Sebelum menjatuhkan hukuman disiplin, pejabat yang berwenang menghukum wajib 
memeriksa lebih dulu Pegawai Negeri S ipil yang disangka melakukan pelanggaran 
disiplin itu”; ---------------------------------------------------------------------------------------- - 
Menimbang, bahwa selanjutnya Pasal 9 ayat (2) huruf b Peraturan Pemerintah 
Nomor : 30 Tahun 1980 tentang Perat uran Disiplin Pegawai Negeri Sipil (Vide bukti 
Lampiran Bukti T – 1), mengatakan bahwa : --------------------------------------- ----------------- 
“Pemeriksaan sebagaimana dimaksud dalam ayat (1) dilakukan secara tertulis apabila 
atas pertimbangan pejabat yang berwenang menghukum, pelanggaran disiplin yang 
dilakukan oleh Pegawai Negeri Sipil yang bersangkutan akan dapat mengakibatkan ia 
dijatuhi salah satu jenis hukuman disiplin sebagaimana dimaksud dalam pasal 6 ayat 
(3) dan ayat (4) ; ------------------------------------------------------------------------------------ 
Menimbang, bahwa lebih lanjut pasal 6 ayat (3) dan ayat (4) Peraturan Pemerintah 
Nomor : 30 Tahun 1980 tentang Peraturan Disiplin Pegawai Negeri Sipil (Vide bukti 
Lampiran Bukti T – 1), mengatakan bahwa : ----------------------------- -------------------- ------- 
1. ayat (3) jenis hukuman sedang terdiri dari : --------------------------------- ---------------- 
a. Penundaan kenaikan gaji berkala untuk paling lama 1 (satu) tahun ; --------------- 
b. Penurunan gaji sebesar satu kali kenaikan gaji berkala untuk paling lama 1 
(satu) tahun ; dan ---------------------------------------------- ----------------------------- 
c. Penundaan kenaikan pangkat untuk paling lama 1 (satu) tahun ; -------------------- 
2. ayat (4) jenis hukuman berat terdiri dari : -------------- ------------------------- ------------ 
a. penurunan pangkat pada pangkat yang setingkat lebih rendah untuk paling lama 
1 (satu) tahun ; ------------------------------------------------------------------ ------------ 
b. pembebasan dari jabatan ; ----------------------------------------------------- ------------ 
c.pemberhentian ....
. 
Direktori Putusan 21 
 
 c. pemberhentian dengan hormat tidak atas permintaan sendiri sebagai Pegawai 
Negeri Sipil ; dan ---------------------------------------------------------------------- ----- 
d. pemb erhentian tidak dengan hormat sebagai Pegawai Negeri Sipil ; --------------- 
Menimbang, bahwa yang menjadi inti pokok persengketaan a quo (Vide Bukti P – 
1) adalah a pakah Tergugat (Bupati Ende) dalam mengeluarkan Surat Keputusan objek 
sengketa a quo (Vide Bukti P – 1) memuat kekurangan yuridis (geen jundische gebreken in 
de wilsvorming) ? ------------------------------------------------------------------- ---------------------- 
Menimbang, bahwa keabsahan suatu Keputusan Tata Usaha Negara menurut Van 
der Pot, yaitu Keputusan suatu pernyataan kehendak (wilsverklaring), maka pembentukan 
kehendak itu tidak boleh memuat kekurangan yuridis (geen jundische gebreken in de 
wilsvorming) ; ------------ ---------------------------------------------------------------------- ---------- 
Menimbang, bahwa konsiderans yuridis “Mengingat” pada Keputusan Tata Usaha 
Negara / obyek sengketa a quo (Vide Bukti P – 1) tidak di dasarkan Peraturan Perundang -
undangan yakni Peraturan Pemerintah Nomor : 30 Tahun 1980 tentang Peraturan Disiplin 
Pegawai Negeri Sipil (Vide bukti Lampiran Bukti T – 1) ; -------------------------- -------------- 
Menimbang, bahwa berdasarkan hal tersebut timbul pertanyaan kenapa Tergugat 
(Bupati Ende ) dalam mengeluarkan Surat Keputusan objek sengketa a quo (Vide Bukti P – 
1) tidak berdasarkan Peraturan Perundang -undangan yakni Peraturan Pemerintah Nomor : 
30 Tahun 1980 tentang Peraturan Disiplin Pegawai Negeri Sipil (Vide bukti Lampiran 
Bukti T – 1) ? -------------- ------------------------------------------------------------------------------- 
Menimbang, bahwa Penggugat (Rofinus Noe) pada tanggal 3 Januari 2008 telah 
masuk kerja dan yang bersangkutan telah melaporkan diri kepada Kepala Badan 
Kepegawaian Daerah Kabupaten Ende ; ------------------------------ ------------------------------- 
Menimbang, bahwa Surat Bupati Ende Nomor : BKD.860/0537/MUT/2008 tanggal 
22 April 2008 kepada Pegawai Negeri Sipil yang bersangkutan telah diperintahkan kepada 
Kepala Kantor Satuan Polisi Pamong Praja Kabupaten Ende untuk dilakukan pemanggilan 
paksa..... 
Direktori Putusan 22 
 
 paksa guna didengar keterangannya, namun yang bersangkutan tidak dapat diketahui 
dimana keberadaannya ; -------------------------------------------------------------------------------- 
Menimbang, bahwa apabila Pegawai Negeri Sipil (Rofinus Noe) yang disangka 
melakukan pelanggaran disiplin tidak memenuhi panggilan untuk diperiksa tanpa alasan 
yang sah, maka dibuat panggilan kedua yang dibuat harus secara tertulis (penjelasan Pasal 9 
ayat (1) Peraturan Pemerintah Nomor : 30 Tahun 1980 tentang Peraturan Disiplin Pe gawai 
Negeri Sipil Vide bukti Lampiran Bukti T – 1) ; -------------------------------- -------------------- 
Menimbang, bahwa pemeriksaan secara tertulis dibuat dalam bentuk Berita Acara, 
sehingga dapat digunakan setiap saat apabila diperlukan namun sejak Su rat Bupati Ende 
Nomor : BKD.860/0537/MUT/2008 tanggal 22 April 2008 sampai dengan saat 
dikeluarkannya Surat Keputusan Obyek Sengketa a quo Tergugat (Bupati Ende) tidak 
pernah melakukan pemeriksaan kepada Penggugat (Rofinus Noe) ; ------------------------- ---- 
Menimbang, bahwa pemeriksaan bertujuan agar pejabat yang berwenang 
menghukum dalam hal ini Bupati Ende dapat mempertimbangkan permasalahan dengan 
seadil -adilnya tentang jenis hukuman disiplin yang akan dijatuhkan dengan teliti dan 
obyektif yang berpe doman pada hak -hak Penggugat (Rofinus Noe) selaku Pegawai Negeri 
Sipil ; -------------------------------- ---------------------------------------------------------------------- 
Menimbang, bahwa berdasarkan pertimbangan tersebut Majelis Hakim 
berkesimpulan T ergugat (Bupati Ende) wajib dan harus melakukan panggilan yang kedua 
secara tertulis serta melakukan pemeriksaan sebelum mengeluarkan Surat Keputusan 
Obyek Sengketa a quo (Vide Bukti P – 1) sebagaimana dimaksud Pasal 9 ayat (1) 
Peraturan Pemerintah Nomor : 30 Tahun 1980 tentang Peraturan Disiplin Pegawai Negeri 
Sipil (Vide bukti Lampiran Bukti T – 1) ; ------- ----------------------------------------------------- 
Menimbang, bahwa asas kecermatan menghendaki agar Pemerintah atau 
administra si bertindak cermat dalam melakukan berbagai aktivitas penyelenggaraan tugas -
tugas Pemerintahan sehingga tidak menimbulkan kerugian bagi warga negara ; --------------- 
Menimbang ..... 
Direktori Putusan 23 
 
 Menimbang, bahwa seharusnya Tergugat (Bupati Ende) mempertimbangkan semua 
faktor dan keadaan yang berkaitan dengan materi Surat Keputusan Obyek Sengketa a quo 
yang akan diterbitkan yaitu dengan memanggil Penggugat (Rofinus Noe) untuk didengar 
alasan -alasa n supaya penjatuhan dan penyampaian Keputusan tata Usaha Negara tersebut 
tidak merugikan Penggugat (Rofinus Noe) ; ------------------------------------ --------------------- 
Menimbang, bahwa Penggugat (Rofinus Noe) dirugikan atas Surat Keputusan yang 
diterb itkan Tergugat (Bupati Ende) yang tidak cermat dan teliti dalam hal menerbitkan 
Surat Keputusan Obyek Sengketa a quo dengan tidak memperhatikan tata cara 
pemeriksaan, penjatuhan, dan penyampaian Keputusan hukuman Disiplin sehingga 
tindakan Tergugat (Bupa ti Ende) bertentangan dengan Asas -Asas Umum Pemerintahan 
Yang Baik (AAUPB) yakni asas kecermatan ; ------------------------------------------------------ 
Menimbang, bahwa dengan demikian Surat Keputusan Obyek sengketa a quo (Vide 
Bukti P – 1) yang dikelu arkan Tergugat (Bupati Ende) batal karena memuat kekurangan 
yuridis (geen jundische gebreken in de wilsvorming) yang tidak didasarkan pada Peraturan 
Pemerintah Nomor : 30 Tahun 1980 tentang Peraturan Disiplin Pegawai Negeri Sipil dan 
juga bertentangan deng an Pasal 9 ayat (1) Peraturan Pemerintah Nomor : 30 Tahun 1980 
tentang Peraturan Disiplin Pegawai Negeri Sipil (Vide bukti Lampiran Bukti T – 1) serta 
bertentangan dengan Asas -Asas Umum Pemerintahan Yang Baik (AAUPB) yakni asas 
kecermatan ; --------------- ------------------- ------------------------------------------------------------ 
Menimbang, bahwa berdasarkan seluruh rangkaian pertimbangan tersebut diatas 
maka gugatan Penggugat (Rofinus Noe) mengenai Surat Keputusan Bupati Ende, Nomor : 
BKD.880/1747/MUT/ 2008, tanggal 22 Juli 2008, Tentang Pemberhentian Tidak Dengan 
Hormat Saudara Rofinus Noe, NIP. 010243147 ( vide Bukti P – 1) beralasan hukum dan 
patut dikabulkan seluruhnya ; ------------------------------------------------------- ------------------- 
Menimbang, bahwa dengan memperhatikan segala sesuatu yang terjadi dalam 
pemeriksaan persidangan dan hal -hal yang diajukan oleh Para Pihak, maka sesuai ketentuan 
Pasal 107 Undang -Undang Nomor : 5 Tahun 1986 Tentang Peradilan Tata Usaha Negara, 
Majeli s..... 
Direktori Putusan 24 
 
 Majelis Hakim bebas menentukan apa yang harus dibuktikan, beban pembuktian beserta 
penilaian pembuktian. Atas dasar itu terhadap alat -alat bukti yang diajukan oleh Para Pihak 
menjadi bahan pertimbangan, namun untuk mengadili dan memutus sengketanya hanya 
dipakai alat -alat bukti yang relevan dan terhadap alat bukti selebihnya tetap dilampirkan 
menjadi satu kesatuan dengan berkas perkaranya ; ---------------------------------------- --------- 
Menimbang, bahwa oleh karena Tergugat berada pada pihak yang kalah, mak a 
segala biaya yang timbul dalam sengketa ini berdasarkan ketentuan Pasal 110 Undang -
Undang Nomor : 5 Tahun 1986 Tentang Peradilan Tata Usaha Negara harus dibebankan 
kepada Pihak Tergugat ; ------------------------------------------------------------------ -------------- 
Memperhatikan Peraturan Pemerintah Nomor : 30 Tahun 1980 tentang Peraturan 
Disiplin Pegawai Negeri Sipil Pasal 9 ayat (1) dan pasal -pasal dalam Undang -Undang 
Peradilan Tata Usaha Negara serta ketentuan Peraturan lain yang berkaitan ; ------------------ 
M E N G A D I L I 
1. Mengabulkan gugatan Penggugat untuk seluruhnya ; ------------------------------ ----------- 
2. Menyatakan bahwa Tergugat dalam mengeluarkan Surat Keputusan Bupati Ende, 
Nomor : BKD.880/1747/MUT/2008, tanggal 22 Juli 2008, Tentang Pemberhentian 
Tidak Dengan Hormat Saudara Rofinus Noe, NIP. 010243147 sebagai Pegawai Negeri 
Sipil bertentangan dengan Per aturan Pemerintah Nomor : 30 Tahun 1980, Pasal 9 ayat 
(1) dan asas Kecermatan ; -------------------------------------------------------------- ---------- 
3. Menyatakan batal Surat Keputusan Bupati Ende, Nomor : BKD.880/1747/MUT/2008, 
tanggal 22 Juli 2008, Tentang Pemberhentian Tidak Dengan Hormat Saudara Rofinus 
Noe, NIP. 010243147 sebagai Pegawai Negeri Sipil ; --------------------- ------------------- 
4. Memerintahkan kepada Tergugat untuk mencabut Surat Keputusan Bupati Ende, 
Nomor : BKD.880/1747/MUT/2008, tanggal 22 Juli 2008, Tentang Pemberhentian 
Tidak Dengan Hormat Saudara Rofinus Noe, NIP. 010243147 sebagai Pegawai Negeri 
Sipil ; --------------- ---------------------------------------------------------------------------------- 
5.Memerintahkan ..
... 
Direktori Putusan 25 
 
 5. Memerintahkan Tergugat menerbitkan Surat Keputusan baru tentang mengaktifkan 
atau mengangkat kembali Penggugat sebagai mana layaknya Pegawai Negeri Sipil 
sesuai perundang -undangan yang berlaku ; ----------------------------------- ------------------ 
6. Memerintahkan Tergugat untuk merehabilitasi/memulihkan hak -hak Penggugat 
sebagaimana hak -hak seorang Pegawai Negeri Sipil sesuai dengan peraturan 
perundang -undangan yang berlaku ; ------------------------------------------------- ------------ 
7. Menghukum Ter gugat untuk membayar biaya sengketa sebesar Rp. 121.000,00 
(Seratus Dua Puluh Satu Ribu Rupiah) ; ----------------------------------------------- --------- 
Demikian diputuskan dalam Rapat Permusyawaratan Majelis Hakim Pengadilan 
Tata Usaha Negara Kupang pa da hari SENIN tanggal 14 JANUARI 2013 , oleh Kami 
SULARNO, S.H., M.Si ., sebagai Hakim Ketua Majelis, FADHOLY HERNANTO, S.H., 
M.H., dan RAHMAN HAKIM BUDI SULISTIYO, S.H., M.Kn., masing -masing sebagai 
Hakim Anggota, Putusan tersebut diucapkan dalam persida ngan yang terbuka untuk umum 
pada hari RABU, tanggal 16 JANUARI 2013 , oleh Majelis hakim tersebut diatas, dengan 
dibantu oleh HENDRIKUS, SH., sebagai Panitera Pengganti pada Pengadilan Tata 
Usaha Negara Kupang, serta dengan dihadiri oleh Penggu gat dan Kuasa Hukum Tergugat ; 
 HAKIM ANGGOTA, HAKIM KETUA MAJELIS, 
 
 T T D T T D 
1. FADHOLY HERNANTO , S.H. ,MH SULARNO, S.H.,M.Si 
 
 T T D 
2. RACHMAN HAKIM BUDI SULISTYO , S.H. ,M.Kn 
PANITERA PENGGANTI , 
 
 T T D 
 HENDRIKUS RABU ,SH