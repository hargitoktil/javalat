g e
h k
a i
m b

1
h a

a i
g e
P U T U S A N
nNOMOR : 36 / G / 2013 / PTUN.SBY. n
g“ DEMI KEADILAN BERDASARKAN KETUHANAN YANG MAHA ESA “
Pengadilan Tata Usaha Negara Surabaya yang memeriksa, memutus dan
menyelesaikan sengketa Tata Usaha Negara pada tingkat per tama dengan acara
h k
Pemeriksaan biasa yang bersidang di gedung yang telah disediakan untuk itu di Jalan
a i
m Raya H. Ir. Juanda, Semambung, Gedangan Sibdoarjo telah menjatuhkan putusan
sebagaimana tersebut dibawah ini, dalam usengketa Tata Usaha Negara antara : :
k --------------------------------------
h SARDJONO, SP, Warga Negara Indonesia, pekerjaan Pegawai Negeri Sipil, alamat a
a i
di Dusun Taman, Desa Kauman RT.04 RW.02, Kecamatan s
gKauman, Kabupaten Ponorogo, yang dalam perkara ini e
memberi kuasa kepada :--------------------------
• PRIHADI SAPUTRO,
S.H. ;-----------------------------------
• ABD. KHOLIQ, S.H., MI.Hum ;
h k
------------------------------
a i
• DEDY PURWOKOl, S.H. ;
m b
-------------------------------------
Kesemuanya berkewarganegaraan Indonesia, Para Advokat,
berkantor di Jalean Mleto No. 54 Surabaya, berdasarkan Surat
h a
a Kuasa KhRusus tertanggal 25 Pebruari 2013, selanjutnya i
M disebut sebagai
g e
1 o
h k

g e
h k
a i
m b

2
h a

a i
g e
-----------------------------------------------------------
PENGGUGAT ;
M e l a w a n :
KEPALA DINAS PENDAPATAN, PENGELOLAAN KEUANGAnN DAN ASET
DAERAH KABUPATEN PONOROGO, beIrkedudukan di
h k
Jalan......
a i
Jalan Alun-alun Utara Nomor l: 09 Ponorogo, selanjutnya
m b
disebut sebagai ....................................TERGUGAT ;
Pengadilan Tata Usaha Negarap Surabaya tersebut ;----------------------
h Telah membaca Surat Peenetapan Ketua Pengadilan Tata Usaha Negara a
a Surabaya Nomor : 36.K/PEN.TUN/2013/PTUN.SBY Tanggal 5 Maret 2013 tentang i
Penunjukan Majelis Hakim yang memeriksa, memutus, dan meyelesaikan sengketa
g e
Tata Usaha Nengara tersebut;------------------------------ n
Tuelah membaca Surat Penetapan Hakim Ketua Majelis Nomor : 36/
PENg.HS/2013/PTUN.SBY tertanggal 6 Maret 2013 tentang penetapan hari
Pemeriksaan Persiapan ;-----------------------------------------------------------------
Telah membaca Surat Penetapan Hakim Ketua Majelis Nomor : 36.K/
h k
PEN.TUN/2013 /PTUN.SBY tertanggal 27 Maret 2013 tentang Penetapan Hari
a i
m Sidang ;-------------------------------------------------------b------------------------
Telah mendengar para pihak yang bersengketa;--------------------------
k Telah memeriksa dan mempelajari alat-alat bukti berupa surat-surat
h a
yang diajukan oleh para pihak di persidangan dan saksi yang dihadirkan di
a i
persidangan ; ----------------------------------------------------------------------------- s
T g ENTANG DUDUKNYA PERKARA : e
h k

g e
h k
a i
m b

3
h a

a i
g e
Menimbang, bahwa Penggugat dengan surat gugatannya tertanggal 26
Pebruari 2013 yang terdaftar di Kepaniteraan Pengadilan Tata Usaha Negara
Surabaya tanggal 1 Maret 2013 dengan register perkara Nomor : 36/G/2013/
PTUN.SBY. yang telah diperbaiki dan diterima oleh Majelis Hakim pada
tanggal 27 Maret 2013, dengan mengemukakan alasan-alasan gugatan sebagai
hberikut:----------------------------------------------- k
a i
I.Obyek Sengketa :……..
m b
I Obyek Sengketa :-------------------------------------------------------
Adapun yang menjadi obyek gugatan dalam Sengketa Tata Usaha ini adalah
Surat Keterangan Pemberhentian Pembayaran No. 900 / 012 / 405.17 / 2013
h a
tertanggal 02 Januari 2R013, yang diterbitkan oleh Kepala Dinas Pendapatan,
a i
Pengelolaan Keuanga n dan Aset Daerah Kabupaten Ponorogo atas nama Bupati
g e
Ponorogo, dengan penerima pensiun Pengawai Negeri Sipil atas nama Sardjono,
SP;------------------------------ o
gKewenangan Tergugat dalam menerbitkan obyek sengketa adalah berdadsarkan
Apendelegasian wewenang dari Bupati Ponorogo sebagaimana dimaksud dalam
Peraturan Bupati Ponorogo Nomor 58 Tahun
h k
2008;--------------------------------------------------------------------------
a i
m II Dasar Gugatan :------------------------------b---------------------------
1 Bahwa Obyek Sengketa, diterimua Penggugat pada tanggal 03 Januari
k 2013 dan Penggugat mendaftarkan gugatan pada tanggal 01 Maret
h a
2013, dengan demikian pengajuan gugatan ini masih dalam tenggang
a i
waktu sebagaimana diatur dalam ketentuan Pasal 55 Undang-Undang s
g e
3 o
h k

g e
h k
a i
m b

4
h a

a i
g e
No. 5 Tahun 1986 jo Undang-Undang No. 51 Tahun
2009;--------------------------
2 Bahwa Obyek Sengketa merupakan Keputusan Tata Usaha Negara
sebagaimana dimaksud dalam ketentuan Pasal 1 angka 9 Undang-
Undang No. 5 Tahun 1986 jo Undang-Undang No. 51 Tahun 2009
h yang mempunyai k unsur-
a i
unsur :----------------------------------------------------------
m b
a Penetapan tertulis, Obyek Sengketa merupakan penetapan
tertulis yang dikeluarkan atau diterbitkan oleh Kepala Dinas
Pendapatan, Pengelolaan Keuangan dan Aset Daerah
h a
KabRupaten
a i
Ponorogo…….
g e
Ponorogo atas nama Bupati Ponorogo;-------------------------------------
b Dikeluarkan oleh badan / pejabat tata usaha negarao ,
g Kepala Dinas Pendapatan, Pengelolaan Keuangan dadn Aset
A Daerah Kabupaten Ponorogo atas nama Bupatni Ponorogo
merupakan badan / pejabat tata usah a negara yang
h k
menyelenggarakan urusan pemerintahan berdasarkan
a i
ketentuan peraturan perundang-undangan yang
m b
berlaku;-------------------u-----------------------------------
c Berisikan tindakpan hukum tata usaha negara, bahwa
h penerbitan Obyek Sengketa, merupakan suatu perbuatan a
a hukum Kepala Dinas Pendapatan, Pengelolaan Keuangan dan i
gAset Daerah Kabupaten Ponorogo yang bersumber pada e
h k

g e
h k
a i
m b

5
h a

a i
g e
ketentuan hukum tata usaha negara yang menimbulkan hak
dan kewajiban pada orang lain
(Penggugat);----------------------------------------------------------
----------
d Konkret, bahwa Obyek Sengketa tersebut tidak abstrak,
h tetapi berwujud, tertentu atau dkapat ditentukan, yakni
a i
penetapan pensiun sebagai Pegawai Negeri Sipil terhadap
m b
Penggugat;
e Individual, bahwa Obyek Sengketa ditujukan tertentu
kepada orang atau badan hukum perdata, yakni ditujukan
h a
kepaRda Pengggugat;
a i
M -- -----------------------------------------------------------------
g e
f Final, bahwa Obyek Sengketa adalah keputusan yang sudah
definitif, yang artinya tidak memerlukan persetujuan daori
g instansi lain dan telah menimbulkan dakibat
A hukum;--------------------------------
g Menimbulkan akibat hukum bagi seora ng atau badan
h k
hukum perdata, bahwa Obyek Sengketa merupakan
a i
m keputusan yang b
bersifat…….
k bersifat final dan mengikat dan telah menimbulkan akibat hukum bagi
h a
Penggugat; ---------------------------------------------------------------
a i
Dengan demikian unsur Keputusan Tata Usaha Negara sebagaimana dimaksud s
dalam ketentuan Pagsal 1 angka 9 Undang-Undang No. 5 Tahun 1986 jo Undang- e
5 o
h k

g e
h k
a i
m b

6
h a

a i
g e
Undang No. 51 Tahun 2009 terpenuhi, oleh karenanya Pengadilan Tata Usaha
Negara berwenang memeriksa, mengadili dan memutus perkara
ini;----------------------------------------------------------------
III Alasan Menggugat :----------------------------------------------------
1 Bahwa Penggugat adalah Pegawai Negeri Sipil yang bekerIja di lingkungan
h k
Pemerintah Kabupaten Ponorogo yang menduduki jabatan fungsional sebagai
a i
Penyuluh Kehutanan pada Dinas Pertanian Kabupalten Ponorogo, dengan Nomor
m b
Induk Pegawai : 19560513 198101 1 011, dengan Jabatan / Golongan Ruang :
Penata Tk. I / III-d;------------------------------
2 Bahwa Penggugat lahir di Ponorogo pada tanggal 13 Mei 1956, dan mencapai
h a
usia pensiun pada tanggRal 13 Mei 2012, sebagaimana yang telah diatur dalam
a i
M ketentuan Pasal 3 aya t (2) Peraturan Pemerintah Nomor 32 Tahun 1979 tentang
g e
Pemberhentian Pegawai Negeri Sipil, yang dinyatakan bahwa “batas usia
pensiun sebagaimana dimaksud dalam ayat (1) adalah 56 (lima puluh enamo)
ahun”;---------------------------------- d
A3 Bahwa sebagai Pegawai Negeri Sipil dengan jabatan fungsionanl Penyuluh
Kehutanan pada Dinas Pertanian Kabupaten Ponorogo, Peng gugat termasuk
h k
Pegawai Negeri Sipil yang memiliki integritas, dedikasi serta loyalitas yang baik.
a i
Setidaknya pada sepanjang tahun 2012, antara tanggal 01 Januari 2012 sampai
m b
dengan tanggal 31 Desember 2012, u
p Penggugat…….
h Penggugat masih menjalankan seeluruh kewajibannya sebagai Petugas Penyuluh a
a Kehutanan pada Dinas Pertanian Kabupaten Ponorogo, hal tersebut dibuktikan i
g e
h k

g e
h k
a i
m b

7
h a

a i
g e
dari kehadiran Penggugat di kantor dan beberapa penugasan yang Penggugat
terima sebagai berikut :--------------------------
a Penggugat dalam kurun waktu 1 (satu) tahun terakhir tidak pernah dijatuhi
hukuman disiplin tingkat sedang / berat. Hal demikian dibuktikan dengan
Surat Pernyataan Tidak Pernah Dijatuhi Hukuman Disiplin Tingkat
h Sedang / Berat Nomor : 800 / 2394 / 405.1k5 / 2012 tertanggal 17
a i
September 2012 yang dibuat dan ditandatangani oleh Ir. Harmanto, MMA
m b
selaku Kepala Dinas Pertanian Kabupaten
a Ponorogo;--------------------------------------------
b Surat Tugas Nomor 094 / 18 / 405.15 / 2012 tertanggal 7 Agustus 2012
h a
yang dikeluarkanR oleh Kepala Dinas Pertanian Kabupaten Ponorogo, pada
a i
intinya menugaskan kepada Penggugat sebagai Petugas Lapangan
g e
Penyuluh Kehutanan (PLPK) di wilayah Badegan, Sampung,
untuk :-------------------------------------------------------------
1 Melaksanakan pendampingan untuk penguatan kelembagaan, tedrhadap
Kelompok Masyarakat pelaksana Kebun Bibit Raknyat untuk
melaksanakan penyusunan Rencana Usulan KegiataIn Kelompok
h k
(RUKK).--------------------------------------------------------
a i
2 Memberikan bimbingan dan arahan pelaksanlaan teknis kegiatan proses
m b
produksi Kebun Bibit Rakyat.----------------------------------
3 Melakukan koordinasi dengan Balai Pengelolaan DAS Solo, dan
instansi terkait lainnyae dalam rangka untuk memperlancar
h a
a Pelaksanaan……. i
M pelaksanaan ke giatan Kebun Bibit Rakyat.---------------------------
g e
7 o
h k

g e
h k
a i
m b

8
h a

a i
g e
Bahwa pada saat Penggugat menerima penugasan ini, Penggugat berusia
56 tahun 3 bulan. Adanya penugasan ini menunjukkan bahwa keberadaan
Penggugat sebagai Pegawai Negeri Sipil dengan jabatan fungsional sebagai
Petugas Lapangan Penyuluh Kehutanan masih sangat dibutuhkan di
wilayah Kabupaten Ponorogo;------------
h c Keputusan Kuasa Pengguna Anggaran DIPA BAk-29 Tahun 2012 Nomor :
a i
SK. 143 / BPDAS.Slo-1 / 2012 tentang Penunjukan Petugas Lapangan
m b
Penyuluhan Kehutanan (PLPK) Sebagai Petugas Pendampingan Kebun
a Bibit Rakyat (KBR) Di Wilayah Kerja Balai Pengelolaan DAS Solo
Tahun 2012 tertanggal 20 Juli 2012, bahwa dalam penugasan ini
h a
Penggugat ditunRjuk menjadi salah satu Petugas Lapangan Penyuluhan
a i
Kehutanan untuk wilayah kerja kabupaten Ponorogo. Sebagai Petugas
g e
Lapangan Penyuluhan Kehutanan, Penggugat mempunyai tugas sebagai
berikut :------------
1 Melaksanakan pendampingan untuk penguatan kelembagaan, tedrhadap
Kelompok Masyarakat pelaksana Kebun Bibit Raknyat untuk
melaksanakan penyusunan Rencana Usulan KegiataIn Kelompok
h k
(RUKK).--------------------------------------------------------
a i
2 Memberikan bimbingan dan arahan pelaksanlaan teknis kegiatan proses
m b
produksi Kebun Bibit Rakyat.----------------------------------
3 Melakukan koordinasi dengan Balai Pengelolaan DAS Solo, dan
instansi terkait lainnya dealam rangka untuk memperlancar pelaksanaan
h a
a kegiatan Kebun Bibit Rakyat.--------------------------- i
M Bahwa…..
g e
h k

g e
h k
a i
m b

9
h a

a i
g e
Bahwa pada saat Penggugat menerima penugasan ini, Penggugat berusia
56 tahun 2 bulan. Adanya penugasan ini menunjukkan bahwa keberadaan
Penggugat sebagai Pegawai Negeri Sipil dengan jabatan fungsional sebagai
Petugas Lapangan Penyuluh Kehutanan masih sangat dibutuhkan di
wilayah Kabupaten Ponorogo;------------
h d Surat Keterangan No. 876/2999/405.15/2012 ktertanggal 27 Desember
a i
2012 yang diterbitkan oleh Kepala Dinas Pertanian Kabupaten Ponorogo,
m b
yang pada intinya menerangkan bahwa Penggugat sampai dengan akhir
a bulan Desember 2012 tetap menjalankan aktivitas sebagai Pegawai Negeri
Sipil;
h a
e Surat Badan KepRegawaian Daerah Kabupaten Ponorogo Nomor 822.3 /
a i
2227 / 405.18 / 2012 Perihal Kenaikan Gaji Berkala An. Sdr. Sardjono,
g e
SP, NIP. 19560513 198101 1 011 tertanggal 26 Juni 2012. Bahwa atas
Surat tersebut, Penggugat menerima kenaikan gaji berkala dari gaji lama
sebesar Rp. 2.641.100,- menjadi Rp. 3.426.200,-. Bahwa padda saat
Penggugat menerima surat tersebut, Penggugat berusia 5n6 tahun 1
bulan;------------------------------------- I
h k
4 Bahwa Penggugat pada awal bulan Desember 2012 menerima SMS yang isinya
a i
diminta untuk datang di Kantor kepegawaian Daerah lKabupaten Ponorogo dan
m b
menghadap ibu Siti Umi Fardasah, staf Kepegawaian pada tanggal 04 Desember
2012. Bahwa atas SMS yang Penggugat terima tersebut, Penggugat datang
menghadap ibu Siti Umi Fardasahe, dan pada saat menghadap tersebut, Penggugat
h a
a diberi salinan Surat Keputusan Kepala Badan Kepegawaian Negara No. 00275 / i
M KEP / CV / 23502 / 2012
g e
9 o
h k

g e
h k
a i
m b

10
h a

a i
g e
tertanggal……
tertanggal 05 November 2012, yang diterbitkan oleh Kepala Badan Kepegawaian
Negara. Bahwa isi Surat Keputusan dimaksud adalah keputusan pensiun sebagai
Pegawai Negeri Sipil Bagi Penggugat;----------
5 Bahwa atas Keputusan Kepala Badan Kepegawaian Negara No. 00275 / KEP /
h CV / 23502 / 2012 tertanggal 05 November 2012 tersekbut Penggugat keberatan
a i
dan mengajukan gugatan melalui Pengadilan Tata Usaha Negara Surabaya
m b
(perkara terpisah), dengan alasan Keputusan a quo bertentangan dengan peraturan
a perundang-undangan dan asas-asas umum pemerintahan yang
baik;---------------------------------------------------
h a
6 Bahwa sebagai tindak laRnjut dari Keputusan Kepala Badan Kepegawaian Negara
a i
sebagaimana terurai tersebut di atas, Tergugat menerbitkan Obyek Sengketa
g e
tertanggal 02 Januari 2013, yang mana Tergugat menerbitkan Obyek Sengketa
atas nama Bupati Ponorogo;------------------
7 Bahwa dari Keputusan Tergugat yang menjadi Obyek Sengketa Tata dUsaha
Negara tersebut, Penggugat keberatan dan mengajukan gugatann terhadap
Tergugat melalui Pengadilan Tata Usaha Negara Surabaya dengIan dasar atau
h k
alasan :--------------------------------------------------------
a i
abahwa Keputusan Tergugat bertentangan denglan peraturan perundang-
m b
undangan yang berlaku, sebagai berikut :--------------------
1 Kewajiban yang ditimbulkan dari adanya Obyek Sengketa bagi
Penggugat adalah adanyea kewajiban penggugat untuk mengembalikan
h a
a kepada negara (kas daerah) gaji terlanjur dibayar 7 bulan (Juni s/d i
g e
h k

g e
h k
a i
m b

11
h a

a i
g e
Desember 2012) dan gaji 13 sebesar Rp. 28.459.300,00 melanggar
ketentuan Undang – Undang
No. 11 Tahun 1969……
No. 11 Tahun 1969 tentang Pensiun Pegawai Dan Pensiun Janda / Duda
Pegawai, Pasal 24 (Mulainya pemberian pensiun-janda/duda)
h dinyatakan bahwa : “Pensiun-janda/atau bagiakn pensiun-janda menurut
a i
Undang-undang ini diberikan mulai bulan berikutnya pegawai negeri
m b
atau penerima pensiun-pegawai yang bersangkutan meninggal dunia
a atau mulai bulan berikutnya hak atas pensiun-janda/ bagian pensiun-
janda itu di dapat oleh yang bersangkutan. Bagi anak yang dilahirkan
h a
dalam batas waktu 300 hari setelah pegawai negeri atau penerima
a i
pensiun pegawai meninggal dunia, pensiun-janda/bagian pensiun-janda
g e
diberikan mulai bulan berikutnya tanggal kelahiran anak
itu”;------------------
2 Bahwa sebagai konsekuensi yuridis diberlakukannya surut Keputusan
Pensiun bagi Penggugat yang kemudian diikuti diterbitkannnya Obyek
Sengketa oleh Tergugat, melanggar ketentuan PeraturaIn Pemerintah
h k
Nomor Nomor 32 Tahun 1979 Tentang Pemberhentian Pegawai Negeri
a i
Sipil, Pasal 5 yang menyatakan bahwa : “Pemlberhentian dengan hormat
m b
sebagai Pegawai Negeri Sipil karena mencapai batas usia pensiun
sebagaimana dimaksud dalam Pasal 3 dan Pasal 4, diberitahukan
kepada Pegawai Negeri Sipil yang bersangkutan 1 (satu) tahun sebelum
h a
ia mencapai batas Rusia pensiun tersebut”;------------------
a i
M bbahwa Keputusan Tergugat bertentangan dengan asas-asas umum
g e
pemerintahan yang baik, sebagai berikut :---------------------------------
11 o
h k

g e
h k
a i
m b

12
h a

a i
g e
1 Asas Kepastian
Hukum :---------------------------------------
Pemberlakuan…..
Pemberlakuan surut obyek sengketa secara hukum jelas-jelas
merupakan pelanggaran terhadap asas kepastian Ihukum. Adanya
h k
ketidakpastian akan hak dan kewajiban, di satu sisi Penggugat sebagai
a i
Pegawai Negeri Sipil tetap menjalankan lseluruh kewajibannya sampai
m b
dengan tanggal 31 Desember 2012. Adanya kewajiban yang timbul dari
adanya Obyek Sengketa untuk mengembalikan gaji terlanjur dibayar 7
bulan (Juni s/d Desember 2012) dan gaji 13 sebesar Rp. 28.459.300,000,
h a
merupakan pelRanggaran atas asas kepastian hukum;----------------
a i
M 2 Asas Tertib Penyelenggaraan
g e
Negara :----------------------- n
uBahwa dari sengketa tata usaha negara antara Penggugat dengaon
gTergugt ini, menunjukkan tidak dilaksanakan penyelenggaraan negara
yang tertib. Keberadaan Keputusan Kepala Badan Kepegawaian Negara
No. 00275 / KEP / CV / 23502 / 2012 tertanggal 05 November 2012
h k
yang kemudian ditindaklanjuti dengan penerbitan Obyek Sengketa oleh
a i
m Tergugat pada tanggal 03 Januari 201b3 dikaitkan dengan keberadaan
Keputusan Kuasa Pengguna Anggauran DIPA BA-29 Tahun 2012 Nomor
: SK. 143 / BPDAS.Slo-1 / 2012 tentang Penunjukan Petugas Lapangan
h Penyuluhan Kehutanan (PLPK) Sebagai Petugas Pendampingan Kebun a
a i
Bibit Rakyat (KBR) Di Wilayah Kerja Balai Pengelolaan DAS Solo s
Tahun 20g12 tertanggal 20 Juli 2012, MEMBUKTIKAN BAHWA e
h k

g e
h k
a i
m b

13
h a

a i
g e
PENYELENGGARAAN NEGARA YANG TERTIB, sehingga
dengan demikian keberadaan Obyek
Sengketa……..
Sengketa jelas-jelas terbukti melanggar Asas Tertib Penyelenggaraan
Negara;------------------------------------------------
h 3 Asas kKepentingan
a i
Umum :--------------------l----------------
m b
a Berdasarkan Telaahan Staf Nomor 800 / 1308 /
405.15 / 2012 tertanggal 16 Mei 2012 dari
eKepala Dinas Pertanian Kabupaten Ponorogo
h a
a ditujukan kepada Bupati Ponorogo, dapat i
M diketahui bahwa keberadaan Penggugat sebagai
g e
Petugas Penyuluh Lapangan masih sangat n
dibutuhkan di lingkungan Pemerintaoh
g Kabupaten Ponogoro, khususnya pada dDinas
A Pertanian Kabupaten Ponorogo, oleh karenanya
terhadap keberadaan Pengguga t, Kepala Dinas
h k
Pertanian mengajukan permohonan
a i
m perpanjangan usbia pensiun sampai dengan usia
60 (enamu puluh) tahun kepada Bupati
Ponorpogo;---------------------------------------------
h ---------------- a
a b berdasarkan Surat Kepala Dinas Pertanian i
gKabupaten Ponorogo yang ditujukan kepada e
13 o
h k

g e
h k
a i
m b

14
h a

a i
g e
Bupati Ponorogo Nomor
522.4/448/405.15/2010 tertanggal 10 Mei 2010,
yang pada intinya menyatakan dilingkungan
Dinas Pertanian Kabupaten Ponorogo masih
kekurangan tenaga Petugas Penyuluh Lapangan,
h dan mengingat Pengkgugat adalah Petugas
a i
Penyuluh yang berprestasi dan mempunyai
m b
kinerja yang baik, direkomendasikan untuk
a dilakukan perpanjangan usia pensiun Penggugat
sampai dengan 60 (enam puluh) tahun
h a
Rc berdasarkan Surat Badan Kepegawaian
a i
Negara di Jakarta
g e
Nomor CI.26-30/V.301-6/51……
Nomor CI.26-30/V.301-6/51 tertanggal 23 Oktober 2012, Perihal
Permohonan Solusi Pemberian Perpanjangan Batas Usia Pednsiun,
pada intinya menyatakan bahwa PNS yang mendudnuki jabatan
fungsional Penyuluh Pertanian, Penyuluh Perikanan,I dan Penyuluh
h k
Kehutanan jenjang Madya dan jengan Utama BUPnya dapat
a i
diperpanjang sampai dengan 60 (enam pluluh) tahun. Perpanjangan
m b
BUP tersebut hendaknya dilakukan secara obyektif dengan tetap
menjaga suasana kerja yang kondusif agar penyelenggaraan tugas-
tugas pemerintahan edan pembangunan dapat terselenggara dengan
h a
a baik, maka diminta agar Kabupaten Ponorogo dapat melaksanakan i
M ketentuan y ang telah ditetapkan dalam Peraturan Presiden Nomor
g e
h k

g e
h k
a i
m b

15
h a

a i
g e
55 Tahun 2010 dan surat Kepala BKN Nomor K.26-30/V.316-1/99
tanggal 19 Oktober 2010;
Bahwa dari uraian tersebut di atas, dapat disimpulkan keberadaan
Penggugat sebagai Petugas Lapangan Penyuluh Kehutanan masih sangat
dibutuhkan di lingkungan Dinas Pertanian Kabupaten Ponorogo,
h mengingat jumlah Petugas Lapangan Penyuluhk Kehutanan masih sangat
a i
kurang dan sangat dibutuhkan, bahkan direkomendasikan untuk
m b
diperpanjang usia pensiunnya menjadi umur 60 (enam puluh)
a tahun;------------------
Dengan diterbitkannya Keputusan Kepala Badan Kepegawaian Negara
h a
No. 00275 / KREP / CV / 23502 / 2012 tertanggal 05 November 2012
a i
yang kemudian diikuti dengan diterbitkannya
g e
Obyek…….
Obyek Sengketa oleh Tergugat, kepentingan umum berupa terlayaninya
masyarakat dalam bidang kehutanan menjadi sangat tergdanggu,
sehingga dengan demikian Tergugat melalui Obyek Sengkneta terbukti
melanggar asas kepentingan umum;------------- I
h k
4 Asas
a i
Keterbukaan :---------------------------------------------
m b
Yang dimaksud dengan “Asas Keteurbukaan” adalah asas yang membuka
diri terhadap hak masyarakatp untuk memperoleh informasi yang benar,
h jujur, dan tidak diskrimeinatif tentang penyelenggaraan negara dengan a
a tetap memperhatikan perlindungan atas hak asasi pribadi, golongan dan i
rahasia ne g gara. Berkait dengan pengertian asas keterbukaan tersebut, e
15 o
h k

g e
h k
a i
m b

16
h a

a i
g e
Tergugat melakukan tindakan diskriminatif dengan memberikan
perlakuan yang berbeda antara Penggugat dengan salah seorang
Pegawai Negeri Sipil yang juga menjabat dengan jabatan fungsional
Petugas Penyuluh Lapangan yang bernama Sunarso, SP, Golongan
Ruang III-b (belum Penyuluh Pertanian Madya). PIerlakuan terhadap
h Sunarso, SP, yang bersangkutan tidak dibkebani kewajiban untuk
a i
mengembalikan gaji yang terlanjur dibaylarkan sekitar kurang lebih 12
m b
(dua belas) bulan;---------------
5 Asas Proporsionalitas :
------e----------------------------------
h a
a Kewajiban yang ditimbulkan dari adanya Obyek Sengketa bagi i
M Penggugat a dalah adanya kewajiban penggugat untuk mengembalikan
g e
kepada negara (kas daerah) gaji terlanjur dibayar 7 bulan (Juni s/d n
uDesember 2012) dan gaji 13 sebesar o
g Rp. 28.459.300,00,…..
Rp. 28.459.300,00, jelas-jelas merupakan pelanggaran atas asas
proporsionalitas. Pelanggaran ini dapat dilihat dalam ku run waktu antara
h k
bulan Juni 2012 sampai dengan Desember 2012 tetap menjalankan
a i
m kewajibannya sebagai Pegawai Negeri bSipil, bahkan pada setidaknya
terdapat 3 penugasan dan 1 suurat Badan Kepegawaian Daerah
Kabupaten Ponorogo yang diterima oleh Penggugat sebagai
h berikut :---------------------------------------------- a
a i
a Surat Tugas Nomor 094 / 18 / 405.15 / 2012 s
gtertanggal 7 Agustus 2012 yang dikeluarkan e
h k

g e
h k
a i
m b

17
h a

a i
g e
oleh Kepala Dinas Pertanian Kabupaten
Ponorogo;---------------------------------------------
----
b Keputusan Kuasa Pengguna Anggaran DIPA
BA-29 Tahun 2012 Nomor : SK. 143 /
h BPDAS.Slo-1 / 201k2 tentang Penunjukan
a i
Petugas Lapangan Penyuluhan Kehutanan
m b
(PLPK) Sebagai Petugas Pendampingan Kebun
a Bibit Rakyat (KBR) Di Wilayah Kerja Balai
Pengelolaan DAS Solo Tahun 2012 tertanggal
h a
R20 Juli
a i
2012;----------------------------------------------
g e
c Surat Keterangan No. 876/2999/405.15/2012
tertanggal 27 Desember 2012 yang diterbitkan
oleh Kepala Dinas Pertanian Kabdupaten
Ponorogo, yang pada intinya mnenerangkan
bahwa Penggugat sampai dengaIn akhir bulan
h k
Desember 2012 tetap menjalankan aktivitas
a i
sebagai Pegawai Negelri Sipil;------------
m b
d Surat Badan Kepegawaian Daerah Kabupaten
Ponorogo Nomor 822.3 / 2227 / 405.18 / 2012
Peerihal Kenaikan Gaji Berkala An. Sdr.
h a
a Sardjono, SP, NIP. 19560513 198101 1 011 i
M tertanggal…..
g e
17 o
h k

g e
h k
a i
m b

18
h a

a i
g e
tertanggal 26 Juni 2012. Bahwa atas Surat tersebut, Penggugat
menerima kenaikan gaji berkala dari gaji lama sebesar Rp.
2.641.100,- menjadi Rp. 3.426.200,-;--------------
Bahwa berdasarkan uraian tersebut di atas, nampak jelas pelanggaran
atas asas proporsionalitas.--------------------------------
h 6 Asas Profesioknalitas :
a i
-------------------------------l----------
m b
Kewajiban yang ditimbulkan dari adanya Obyek Sengketa bagi
Penggugat adalah adanya kewajiban penggugat untuk mengembalikan
kepada negara (kas daerah) gaji terlanjur dibayar 7 bulan (Juni s/d
h a
Desember 201R2) dan gaji 13 sebesar Rp. 28.459.300,00 menunjukkan
a i
M bahwa adan ya pelanggaran atas asas profesionalitas. Tergugat tidak
g e
menghormati nilai-nilai profesionalitas kerja dari Penggugat yang telah
mengabdikan diri sebagai Pegawai Negeri Sipil dengan jabataon
gfungsional selaku Petugas Lapangan Penyuluh Kehutanan. Sdeluruh
Akewajiban Penggugat selaku Petugas Lapangan Penyuluh Kehutanan
telah Penggugat laksanakan, dengan diminta kembali gaji yang telah
h k
terbayarkan (Juni s/d Desember 2012) yang secara hukum merupakan
a i
pelanggaran atas hak-hak Penggugat; ------------------
m b
Bahwa berdasarkan hal-hal sebagaimana yuang terurai tersebut di atas, sangat
jelas terbukti Obyek Sengketa berptentangan dengan peraturan perundang-
h undangan yang berlaku serta bertentangan dengan Asas-Asas Umum a
a Pemerintahan Yang Baik. Oleh karenanya secara hukum (Pasal 53 ayat (2) i
huruf a dan huruf g b Undang-Undang No. 5 Tahun 1986 jo e
h k

g e
h k
a i
m b

19
h a

a i
g e
Undang-Undang……..
Undang-Undang No. 51 Tahun 2009) sangatlah beralasan dan berdasar pada
ketentuan hukum yang berlaku apabila Keputusan Tergugat yang menjadi obyek
sengketa dinyatakan batal atau tidak sah;--------------------
8 Bahwa mengingat Obyek Sengketa bertentangan dengan peraturan perundang-
h undangan yang berlaku dan bertentangan dengan asas-aksas umum pemerintahan
a i
yang baik, kiranya secara hukum Obyek Sengketa layak dinyatakan batal atau
m b
tidak sah. Dengan demikian karena Obyek Sengketa dinyatakan batal atau tidak
a sah, mohon kiranya kepada Penggugat dikembalikan pada pada posisi dan jabatan
semula beserta seluruh hak-hak yang melekat didalamnya;
h a
------------------------------R------
a i
9 Bahwa mengingat Obyek Sengketa yang diterbitkan oleh Tergugat tersebut
g e
bertentangan dengan ketentuan peraturan perundang-undangan yang berlaku serta
bertentangan dengan asas-asas umum pemerintahan yang baik, Penggugat
memohon kepada Pengadilan Tata Usaha Negara Surabaya, c.q. Majelis dHakim
yang memeriksa, mengadili dan memutus perkara ini berkenann menunda
pelaksanaan Obyek Sengketa. Selain dari pada itu, permohonan Ipenundaan ini
h k
juga didasarkan pada pertimbangan-pertimbangan sebagai
a i
berikut :---------------------------------- l
m b
1 Gaji yang Penggugat terima antara bulan Juni 2012 sampai Desember 2012
telah Penggugat pergunakan untuk membiayai kebutuhan hidup Penggugat
beserta keluarga;-----------------e----------
h a
a i
g e
19 o
h k

g e
h k
a i
m b

20
h a

a i
g e
2 Bahwa apabila Obyek Sengketa dilaksanakan, maka kepentingan Penggugat
akan sangat dirugikan, bahkan kerugian tersebut juga akan berdampak kepada
kelangsungan hidup Penggugat beserta
keluarga;……..
keluarga;------------------------------------------------------------------------
h 3 Bahwa dengan ditundanya Obyek Sengketa, tidak kakan berdampak kepada
a i
kepentingan umum, mengingat gaji yang telah Penggugat terima tersebut
m b
murni dari hasil kerja dan pengabdian Penggugat selaku Pegawai Negeri
a Sipil.-------------------------------------------------
Maka kiranya sangat beralasan dan sesuai dengan ketentuan Pasal 67 Undang-
h a
Undang No. 5 Tahun R1986 sebagaimana yang telah diubah dengan Undang-
a i
Undang No. 9 Tahun 2004 jo Undang-Undang No. 51 Tahun 2009, apabila
g e
Obyek Sengketa a quo ditunda terlebih dahulu
pelaksanaannya.---------------------------------------------------------------------
Bahwa berdasarkan pertimbangan-pertimbangan sebagaimana yang terurai tersdebut di
atas, Penggugat memohon kepada Ketua Pengadilan Tata Usaha Neganra Surabaya
yang memeriksa, mengadili dan memutus perkara ini kiranya berkenaIn memberikan
h k
putusan sebagai berikut :--------------------------
a i
I Dalam Penundaan-------------------------------------------l-----------
m b
Menyatakan Surat Keterangan Pemberhentian Pembayaran No. 900 / 012 /
405.17 / 2013 tertanggal 02 Januari 2p013, yang diterbitkan oleh Kepala Dinas
Pendapatan, Pengelolaan Keuangean dan Aset Daerah Kabupaten Ponorogo atas
h a
a nama Bupati Ponorogo, dengan penerima pensiun Pengawai Negeri Sipil atas i
M nama Sardjono, SP, ditun da pelaksanaannya.
g e
h k

g e
h k
a i
m b

21
h a

a i
g e
II Dalam Pokok Perkara--------------------------------------------------
1 Mengabulkan gugatan Penggugat untuk seluruhnya;--------------------------
2 Menyatakan batal atau tidak sah Surat Keterangan Pemberhentian
Pembayaran No. 900 / 012 / 405.17 / 2013 tertanggal 02 Januanri 2013,
Iyang……
h k
yang diterbitkan oleh Kepala Dinas Pendapatan, Pengelolaan Keuangan dan Aset
a i
Daerah Kabupaten Ponorogo atas nama Bupati lPonorogo, dengan penerima
m b
pensiun Pengawai Negeri Sipil atas nama Sardjono, SP;
3 Mewajibkan kepada Tergugat untuk mencabut Surat Keterangan
Pemberhentian Pembayaran No. 900 / 012 / 405.17 / 2013 tertanggal 02
h a
Januari 2013, yang Rditerbitkan oleh Kepala Dinas Pendapatan, Pengelolaan
a i
M Keuangan dan As et Daerah Kabupaten Ponorogo atas nama Bupati Ponorogo,
g e
dengan penerima pensiun Pengawai Negeri Sipil atas nama Sardjono,
SP;----------------------------------------------------------------- o
g4 Memerintahkan kepada Tergugat untuk mengembalikan Penggugadt pada
Aposisi dan jabatan semula beserta seluruh hak-hak yanng melekat
didalamnya;----------------------------------------------------------- ----------------
h k
5 Menghukum Tergugat untuk membayar biaya perkara.-----------------------
a i
Menimbang, bahwa atas gugatan Penggugat tersebut, Tergugat telah
m b
menyampaikan jawaban tertanggal 10 Aprilu 2013, yang mengemukakan hal-hal
sebagai berikut : ------------------------------p-------------
h I TENTANG EKSEPSI----------e--------------------------------------------------------- a
a 1 Bahwa TERGUGAT menolak dengan tegas dalil-dalil yang diajukan i
oleh PE g NGGUGAT kecuali yang benar-benar diakui dan sesuai e
21 o
h k

g e
h k
a i
m b

22
h a

a i
g e
dengan fakta yang
ada.--------------------------------------------------------------------------
2 Bahwa yang mengenai obyek gugatan dalam Sengketa Tata Usaha
oleh PENGGUGAT adalah merupakan Surant Keterangan
Pemberhentian Pembayaran (SKPP) yang Iditerbitkan oleh
h k
TERGUGAT dengan Nomor : 900/012/405.17/2013 tertanggal 02
a i
Januari 2013 adalah SALAH l
m b
GUGATAN…….
GUGATAN, karena surat tersepbut hanya merupakan surat keterangan bukan
merupakan surat keputusaen TERGUGAT yang keberadaannya didasarkan
h a
a pada Keputusan Kepala Badan Kepegawaian Negara Nomor : 00275/KEP/ i
M CV/23502/2012 yang menetapkan Pemberhentian Dengan Hormat
g e
PENGGUGAT sebagai Pegawai Negeri Sipil karena telah mencapai batas n
usuia pensiun. Dengan demikian jelas bahwa yang seharusnya menjadi Obyeok
gSengketa Tata Usaha Negara adalah Keputusan Kepala Badan Kepegawaian
Negara Nomor : 00275/KEP/CV/23502/2012 bukan surat keterangan dari
TERGUGAT yang timbul didasarkan pada Keputusan Kepala Badan
h k
Kepagawaian Negara tersebut, oleh karena itu gugatan PENGGUGAT patut
a i
m ditolak oleh Yang Mulia Majelis Hakim ybang memeriksa dan mengadili
perkara ini karena SALAH SASARAN atau TIDAK TEPAT OBYEK
k GUGATAN. ----------------------------------------------------------------------
h a
II DALAM POKOK
a i
PERKARA------------------------------------------------------------ s
g e
h k

g e
h k
a i
m b

23
h a

a i
g e
1 Bahwa TERGUGAT dengan ini membantah seluruh dalil-dalil yang
diajukan oleh PENGGUGAT kecuali atas hal-hal yang secara tegas diakui
oleh TERGUGAT dalam JAWABAN ini.---------------------------------
2 Bahwa mohon hal-hal yang terurai dalam EKSEPSI nsecara mutatis
mutandis dianggap terulang kembali dalam JAWABAIN pokok perkara
h k
ini.-----------------------------------------------------------------------------------
a i
3 Bahwa berdasarkan Peraturan Menteri Dalam Negeri Nomor 13 Tahun
m b
2006 tentang Pedoman Pengeloluaan Keuangan Daerah dalam Pasal
k 5 ayat (3) huruf b…..
h a
5 ayat (3) huruf b, Kepala Daerah selaku pemegang kekuasaan pengelolaan
a i
keuangan daerah melimpahkan sebagian atau seluruh kekuasaannya kepada s
g e
Kepala SKPKD selaku Pejabat Pengelola Keuangan Daerah (PPKD)
sebagaimana tertuang dalam Keputusan Bupati Nomor 188/25/4O5.17/2013
tanggal15 Januari 2103 tentang penunjukan pejabat pemegang kekuasaan
pengelolaan keuangan daerah, coordinator pengelolaan keuangan daerah,
pejabat pengelolaan keuangan daerah (PPKD), kuasa bendaharaI umum daerah
h (KUASA BUD) dan pejabat yang memberikan wkewenang melakukan
a i
verifikasi, evaluasi dan analisis laporan pertanglgungjawaban penerimaan
m b
satuan kerja perangkat daerah (SKPD) kabupaten ponorogo tahun anggaran
2013 dan selanjutnya dalam Pasal 1 angka 15 Perturan Menteri Dalam Negeri
No. 13 Tahun 2006 Pejabat Pengelola Keuangan Daerah yang disingkat
h a
dengan PPKD adalah KRepala Satuan Kerja Pengelola Keuangan Daerah yang
a i
selanjutnya disebut dengan Kepala SKPKD yang mempunyai tugas
g e
23 o
h k

g e
h k
a i
m b

24
h a

a i
g e
melaksanakan pengelolaan APBD dan bertindak sebagai Bendahara Umum
Daerah.
4 Bahwa berdasarkan Peraturan Bupati Ponorogo Nomor 58 Tahun 2008
tentang Uraian Tugas dan Fungsi Dinas Pendapatann, Pengelolaan
Keuangan dan Asset Daerah Kabupaten Ponorogo dalamI Pasal 22 ayat (1)
h k
menyatakan bahwa Dinas Pendapatan, Pengelolaan Keuangan dan Asset
a i
Daerah (DPPKAD) mempunyai tugals menyelesaikan masalah
m b
perbendaharaan belanja pegawai dan ganti rugi serta memproses Surat
Keterangan Pemberhentian Pembayaran (SKPP).--------------------
h e 5.Bahwa…… a
a i
5 Bahwa berdasarkan uraian tersebut diatas, jelas bahwa penerbitan Surat s
Keteranggan Pemberhentian Pembayaran (SKPP) sudah sesuai dengan e
ketentuan peraturan perundang-undangan yang berlaku, dan apabila
TERGUGAT tidak mengeluarkan Surat Keterangan Pemberhentian
Pembayaran (SKPP) tersebut, sedangkan surat keputusan dari Kepala
Badan Kepegawaian Negara yang menetapkan Pemberhentian dengan
h hormat sebagai Pegawai Negeri Sipil sudah terbitk, maka TERGUGAT
a akan dipersalahkan karena sebagai kewenanigannya tidak segera
m b
menerbitkan Surat Keterangan Pemberhentian Pembayaran (SKPP) yang
a dapat mengakibatkan kerugian negara.
-----------------------------------------------------------------
h a
Jadi, sudah jelas sekali disini bahwa penerbitan Surat Keterangan
a i
Pemberhentian Pembayaran (SKPP) oleh TERGUGAT didasarkan atas
g e
terbitnya SK Pensiun dari Kepala Badan Kepegawaian Negara kepada
h k

g e
h k
a i
m b

25
h a

a i
g e
PENGGUGAT dan atas kewenangan TERGUGAT yang diberikan oleh
ketentuan atau peraturan perundang-undangan yang berlaku.-----------
6 Bahwa karena permohonan gugatan PENGGUGAT tidak selayaknya
dikabulkan oleh Majelis Hakim yang memeriksa dan menngadili perkara
ini, maka sudah selayaknya pula PENGGUGAT dIiwajibkan untuk
h k
membayar biaya yang timbul dalam perkara ini sesuai dengan Peraturan
a i
Perundang-undangan yang berlaku. Atas ulraian Jawaban TERGUGAT
m b
tersebut diatas, maka mohon kepada Yang Mulia Majelis Hakim yang
memeriksa dan mengadili Sengketa Tata usaha Negara Surabaya Nomor :
36/6/2013/PTUN.SBY ememutuskan sebagai berikut:
h a
a R 1.Menerima…… i
1 Menegrima Jawaban TERGUGAT.------------------------------------------- e
2 Menyatakan menolak permohonan Gugatan PENGGUGAT atau
setidak-tidaknya menyatakan permohonan PENGGUGAT tidak dapat
diterima.------------------------------------------------------------n-----------
3 Membebankan biaya perkara yang timbul pada per kara ini kepada
h k
PENGGUGAT, atau jika Majelis Hakim Pengadilan Tata Usaha
a i
Negara Surabaya yang memeriksa dan mengadili perkara ini
m b
berpendapat lain, mohon putusan yang seadil-adilnya.----------------
Menimbang, bahwa atas jawaban Tergugat tersebut, pihak Penggugat telah
h menyerahkan Replik tertanggal 17 April 2013 ; --------------- a
a i
Menimbang, bahwa atas Replik Penggugat tersebut, Tergugat s
menyampaikan Duplikngya tertanggal 1 Mei 2013; ---------------------------------- e
25 o
h k

g e
h k
a i
m b

26
h a

a i
g e
Menimbang, bahwa untuk menguatkan dalil-dalil gugatannya pihak
Penggugat di persidangan telah mengajukan foto kopi surat-surat bukti yang
dilegalisir dan bermeterai cukup, dan telah dicocokkan dan sesuai dengan aslinya
dengan diberi tanda P – 1 sampai dengan P – 13, adalah sebagai
berikut :-----------------------------------------------------------------------------------
h 1 Bukti P – 1 : Foto kopi sesuai dengan asklinya Keputusan Kepala
a i
Badan Kepegawaian Negara Nomor : 00275/KEP/CV/23502/2012 tanggal 2
m b
Nopember 2012 tentang telah mencapai batas usia pensiun atas nama
a SARDJONO, SP ;---------------------------
2 Bukti P – 2 : Foto kopi sesuai dengan aslinya Surat Keterangan
h a
R Pemberhentian.....
a i
Pemberhentian Pembayaran dari An. Bupati Ponorogo
g e
Kepala Dinas Pendapatan, Pengelolaan Keuangan dan
Asset Daerah Nomor : 900/012/405.17/2013 tanggal 2
Januari 2013 atas nama SARDJdONO,
SP;--------------------------- n
3 Bukti P – 3 : Foto kopi sesuai dengan aslinya Surat KIeterangan dari
h k
Kepala Dinas Pertanian Kabupaten Ponorogo Nomor : 876/2999/405.15/2012
a i
tanggal 27 Desember 2012 atas nama SARDJONO,l SP;-------
m b
4 Bukti P – 4 : Foto kopi sesuai dengan aslinya surat dari Kepala
Dinas Pertanian Kabupaten Ponorogo yang ditujukan kepada Bupati
Ponorogo, Nomor : 800/130e8/405.15/2012 tanggal 16 Mei 2012, perihal
h a
a usulan perpanjangan usia pensiun penyuluh pertanian atas nama SARDJONO, i
M SP;
g e
h k

g e
h k
a i
m b

27
h a

a i
g e
5 Bukti P – 5 : Foto kopi sesuai dengan aslinya surat dari Badan
Kepegawaian Negara yang ditujukan kepada Bupati Ponorogo, Nomor :
CI.26-30/V.301-6/51 tanggal 23 Oktober 2012, perihal permohonan solusi
pemberian perpanjangan batas usia pensiun ;------------------------------------
6 Bukti P – 6 : Foto kopi sesuai dengan aslinya Keputusan Kuasa
h Pengguna Anggaran DIPA BA-26 Tahun 2012 kNomor : SK.143/
a i
BPDAS.Slo-1/2012 tentang
m b
Penunjukan......
a Penunjukan Petugas Lapangan Penyuluhan Kehutanan
(PLPK) sebagai Petugas Pendamping Kebun Bibir
h a
RRakyat (KBR) Di Wilayah Kerja Balai Pengelolaan
a i
Das Solo Tahun 2012 tanggal 20 Juli
g e
2012 ;----------------------------------------------------
7 Bukti P – 7 : Foto kopi sesuai dengan aslinya Surat Tugas Nomor :
094/18/405.15/2012 tanggal 7 Agustus 2012 dari Kepala Dinas Pedrtanian
Kabupaten Ponorogo kepada Sardjono, SP ;--------------------- n
8 Bukti P – 8 : Foto Kopi sesuai dengan aslinya SuraIt dari Kepala
h k
Badan Kepegawain Daerah (BKD) Kabupaten Ponorogo Nomor :
a i
822.3/2227/405.18/2012 tanggal 26 Juni 2012, perilhal Kenaikan Gaji berkala
m b
atas nama Sdr. SARDJONO, SP NIP. 19560513 198603 1
011 ;-----------------------------
9 Bukti P – 9 : Foto koepi sesuai dengan aslinya Daftar hadir Apel/
h a
a Siang Karyawan/Karyawati Dinas Pertanian bulan Juni i
M 2012 ;------------------- --------------------
g e
27 o
h k

g e
h k
a i
m b

28
h a

a i
g e
10 Bukti P – 10 : Foto kopi sesuai dengan aslinya Daftar hadir Apel/
Siang Karyawan/Karyawati Dinas Pertanian bulan Juli
2012 ;----------------------------------------
11 Bukti P – 11 : Foto kopi sesuai dengan aslinya Daftar hadir Apel/
Siang Karyawan/Karyawati Dinas Pertanian bulan Agustus
h 2012 ;---------------------------------- k
a i
12.Bukti P – 12........
m b
12 Bukti P – 12 : Foto kopi sesuai dengan aslinya Daftar hadir Apel/
a Siang Karyawan/Karyawati Dinas Pertanian bulan September
2012 ;-------------------------------
h a
13 Bukti P – 13 :RFoto kopi sesuai dengan aslinya Daftar hadir Apel/
a i
Siang Karyawan/Karyawati Dinas Pertanian bulan Oktober
g e
2012 ;----------------------------------
14 Bukti P – 14 : Foto kopi sesuai dengan aslinya Daftar hadir Apel/
Siang Karyawan/Karyawati Dinas Pertanian bulan Nopdember
2012 ;------------------------------- n
15 Bukti P – 15 : Foto kopi sesuai dengan aslinya DaftaIr hadir Apel/
h k
Siang Karyawan/Karyawati Dinas Pertanian bulan Desember
a i
2012 ;-------------------------------- l
m b
Menimbang, bahwa untuk menguatkan alasan – alasan
jawabannya, pihak Tergugat di persidangan telah mengajukan foto kopi surat -
surat bukti yang dilegalisir dan bermeeterai cukup, yang telah dicocokkan dan sesuai
h a
a dengan asli maupun kopinya dengan diberi tanda i
M T – 1 sampai denga T – 6 ad alah sebagai berikut :-------------------------------
g e
h k

g e
h k
a i
m b

29
h a

a i
g e
1 Bukti T – 1 : Foto kopi Peraturam Menteri Dalam
Negeri Nomor 13 Tahun 2006 tentang Pedoman
Pengelolaan Keuangan Daerah ;------------------
2 Bukti T – 2 : Foto kopi Peraturan Bupati Ponorogo
Nomor 58 Tahun 2008 Uraian Tugas Dan Fungsi Dinas
h Pendapatan, Pengelolaan Keuangkan Dan Asset Daerah
a i
Kabupaten Ponorogo ;--------------------
m b
3.Bukti T – 3......
a 3 Bukti T – 3 : Foto kopi sesuai dengan aslinya
Keputusan Bupati Ponorogo Nomor : 188/25/405.17/2013
h a
tenRtang Penunjukan Pejabat Pemegang Kekuasaan
a i
Pengelolaan Keuangan Daerah, Koordinator Pengelolaan
g e
Keuangan Daerah, Pejabat Pengelola Keuangan Daerah
(PPKD), Kuasa Bendahara Umum Daerah (Kuasa BUD)
Dan Pejabat yang diberi Wewenang Melakukan Verdifikasi,
Evaluasi Dan Analisis Laporan Pertanggnungjawaban
Penerima Satuan Kerja Perangkat DaeIrah (SKPD)
h k
Kabupaten Ponorogo Tahun Anggaran 2013 ;----------------
a i
4 Bukti T – 4 : Foto kopi l sesuai dengan aslinya
m b
Keputusan
Kepala Badan Kepegawain Negara Nomor : 00275/
KEPe/CV/23502/2012 tanggal 5 Nopember 2012
h a
a atas nama SARDJONO, SP ; i
g e
29 o
h k

g e
h k
a i
m b

30
h a

a i
g e
5 Bukti T – 5 : Foto kopi tanpa asli (asli ada pada
Penggugat) Keputusan Kepala Badan Kepegawaian Negara
Nomor : 00275/KEP/CV/23502/2012 tanggal 5 Nopember
2012 atas nama SARDJONO, SP ;
6 Bukti T – 6 : Foto kopi sesuai dengan aslinya daftar
h pengantar Nomor : 931/2991/4k05.15/2012 tanggal 26
a i
Desember 2012 dari Kepala Dinas Pertanian Kabupaten
m b
Ponorogo kepada Kepala
a Dinas.......
Dinas Pendapatan, Pengelolaan Keuangan dan Aset
h a
RDaerah Kabupaten Ponorogo ;--------------
a i
Menimbang, bahwa Penggugat telah mengajukan 2 (dua) orang saksi yang
g e
memberikan keterangan dibawah sumpah, pada pokoknya menjelaskan sebagai
berikut :----------------------------------------------------------
SAKSI Ir. BISMARK PETRUS Y, pada pokoknya menerangkan sebagai bedrikut :
A----------------------------------------------------------------------------------- n
• Bahwa saksi sebelum pensiun bekerja di Dinas Perta nian Kabupaten
h k
Ponorogo ;----------------------------------------------------------------------------
a i
--
m b
• Bahwa saksi bekerja di Dinas Pertaniuan Kabupaten Ponorogo sejak Tahun
1977 sampai dengan Desember p2012 ; -------------------------------------------
h • Bahwa saksi menjabat sebagai Penyuluh pertanian ; a
a i
--------------------------- s
g e
h k

g e
h k
a i
m b

31
h a

a i
g e
• Bahwa sebagai Penyuluh pertanian saksi memberikan pendampingan dan
penyuluhan kepada kelompok tani dan memberikan kemudahan dengan
cara memberikan pengetahui teknologi kepada kelompok tani ; --------------
• Bahwa saksi sebagai penyuluh Pertanian, ada tingkatan atau jenjang
jabatan ;---------------------------------------------------------I----------------------
h k
-
a i
• Bahwa usia saksi sekarangl 57 Tahun ;
m b
--------------------------------------------
• Bahwa batas usia pensiun bagi jabatan penyuluh adalah 60 Tahun ; --------
h • Bahwa Penggugat dane saksi adalah sama-sama Penyuluh pertanian di a
a Dinas Pertanian Kabupaten Ponorogo, tetapi wilayahnya berbeda (beda i
kecamata g n) ; e
-----n--------------------------------------------------------------------- n
•uBahwa selama saksi bekerja di Dinas Pertanian Kabupaten Ponorogo, ada
surat tugas dan setiap ada kenaikan tingkat, kami selalu mendapat surat
tugas…….
tugas dan surat tugas saksi sampai sekarang belum dicabut ; ----------------
h k
a • Bahwa saksi tidak diperbolehkan untuk bekerjai di Dinas Pertanian
m b
Kabupaten Ponorogo sejak bulan Desember 2012 ; ----------------------------
a • Bahwa saksi pensiun sejak 1 Juli 2012 ;
------------------------------------------
h a
• Bahwa untuk saksi tidak ada surat perpanjangan pensiun ; -------------------
a i
• Kapan saksi menerima Surat Keputusan Pensiun dan ditetapkan tanggal 4
g e
Desember 2012, dan Surat Keputusannya terbit tanggal 5 November
31 o
h k

g e
h k
a i
m b

32
h a

a i
g e
2012;-----------------------------------------------------------------------------------
-
• Bahwa Surat Keputusan saksi dengan Surat Keputusan Penggugat sama
tanggal terima, tanggal terhitung dan tanggal ditetapkannya Surat
Keputusan Pensiun I ;
h ------------------------------------------------------------k-----
a i
• Bahwa saksi dan Penggugat masih bekerjla sampai dengan tanggal 30
m b
Desember 2012 ;
---------------------------------------------------------------------
• Bahwa alasan saksi dean Penggugat masih bekerja karena kami masih
h a
a menerima gaji sampai dengan 2 Desember 2012 ; ----------------------------- i
M • Bahwa saksi tidak bekerja lagi karena sudah ada Surat Keputusan
g e
pensiunan dari Badan Kepegawaian Negara, oleh Badan Kepegawaian n
uDaerah saksi juga tidak diperbolehkan bekerja lagi o;
g---------------------------
• Bahwa setelah Penggugat menerima Surat Keputusan Pensiun, juga
menerima surat keputusan yang lain dari Kepala Dinas Pertanian
h k
a Kabupaten Ponorogo, tetapi surat dari Dinas Piendapatan Pengelolaan
m Keuangan dan Asset Daerah, yang isinyab saksi disuruh mengembalikan
gaji yang telah saksi terima sebesar Rp. 24.000.000,- (Dua pulu empat juta
k rupiah) ;
h a
--------------------------------------------------------------------------------
a i
Bahwa…….. s
g e
h k

g e
h k
a i
m b

33
h a

a i
g e
• Bahwa didalam Surat Keputusan Pensiun, tidak ada tertulis kewajiban
agar
Penggugat mengembalikan gaji yang sudah diterima ; ------------------------
• Bahwa benar saksi telah menerima Surat Keputusan Pensiun ;
--------------- I
h k
• Bahwa saksi tidak tahu atas permintaan siapa SKPP terbit ;
a i
------------------- l
m b
• Bahwa yang minta SKPP Dinas pertanian Kabupaten Ponorogo bukan
saksi;---------------------------p--------------------------------------------------------
- e
h a
a • Bahwa saksi mengetahui bahwa masa kerja saksi diperpanjang oleh Dinas i
Pertanian g Kabupaten Ponorogo ; e
-----n---------------------------------------------- n
•uBahwa nama saksi tercantum di surat usulan pada urutan 16 ; ---------------
• Bahwa Perpanjangan usia pensiun atas inisiatif kami, kemudian diusulkan
oleh Kepala Dinas Pertanian Kabupaten Ponorogo ;
h ---------------------------- k
a • Bahwa yang diusulkan untuk diperpanjang usia piensiunnya ada 12 orang
m b
yang diusulkan oleh Dinas Pertanian Kabupaten Ponorogo kepada Bupati
a Ponorogo ;
-----------------------------------------------------------------------------
h a
• Bahwa saksi lupa kapan perpanjangan usia pensiun tersebut diusulkan,
a i
setahu saksi jabatan fungsional dapat diperpanjang sampai usia 60 tahun;
g e
33 o
h k

g e
h k
a i
m b

34
h a

a i
g e
• Bahwa dasar hukum usulan perpanjangan usia pensiun diatur dalam
Peraturan Presiden Nomor 55 Tahun 2010 ;
-------------------------------------
• Bahwa pada saat diusulkan perpanjangan usia pensiun, saksi dalam
kondisi sehat I ;
h k
-------------------------------------------------------------------------
a i
• Bahwa persyaratan untuk diusulkan perpanljangan usia pensiun adalah :
m b
Surat Keputusan Calon Pegawai Negeri Sipil, Surat Keputusan terakhir,
DP3, dan surat keterangan sehat dari dokter ; ---------------------------------
• Bahwa saksi saat ini haedir dipersidangan dalam keadaan sehat ; -----------
h a
a Bahwa…….. i
M • Bahwa tenaga penyuluh pertanian di Kabupaten Ponorogo masih
g e
kuranng, n
karenau pegawai di Dinas Pertanian Kabupaten Ponorogo ada 100 orang dan tenaga
honorer 113 orang ; ---------------------------------------------------
• Bahwa saksi sebagai anggota Forum Silaturrohmi Penyuluh Pertanian dan
Kehutanan yang sampai saat ini jumlah anggotanya ada 18 orang;----------
h k
a • Bahwa forum dibentuk sejak saksi dan teman-temain pensiun ; --------------
m b
• Bahwa saksi pernah mendapat surat dari Badan Kepegawaian Negara
a Jakarta dan pernah membacanya (bukti P-5) ; ----------------------------------
• Bahwa saksi mengetahui isi surat tersebut adalah bahwa Pangkat III/c dan
h a
III/d jabatan PenyulRuh dapat diperpanjang masa kerjanya sampai usia 60
a i
tahun ;
g e
---------------------------------------------------------------------------------
h k

g e
h k
a i
m b

35
h a

a i
g e
• Bahwa saksi mohon dengan hormat kepada Majelis Hakim agar
permohonan saksi dan Penggugat dikabulkan, karena kami masih sehat ; -
SAKSI BUCHORI, SP, pada pokoknya menerangkan sebagai berikut : --------
• Bahwa sebelum pensiun saksi bekerja di Dinas Pertannian Kabupaten
Ponorogo ; -----------------------------------------------------------I------------------
h k
• Bahwa saksi bekerja di Dinas Pertanian Kabupaten Ponorogo sejak Tahun
a i
1971 sampai dengan bulan Oktober 2012 ; --------------------------------------
m b
• Bahwa saksi menjabat sebagai Penyuluh pertanian ; ---------------------------
• Bahwa tugas saksi memberikan ppenyuluhan kepada petani ; -----------------
h • Bahwa saksi menerima Surat Keputusan Pensiun pada bulan Januari 2013, a
a i
dan saksi pensiun bulan Oktober 2013 dan bulan September saksi sudah tidak s
bekerja lagi ;g -------------------------------------------------------------------- e
• Bahwa saksi tahu Penggugat terakhir bekerja bulan Desember 2012 ; ------
Bahwa………
• Bahwa saksi pensiun di usia 60 tahun ; -------------------------------------------
• Bahwa saksi tidak pernah mengajukan perpanjangan usia pensiun ; --------
h k
• Bahwa saksi 1 (satu) tahun sebelum pensiun mengajukan usulan pensiun kira-
a i
kira bulan Oktober 2011; -------------------------------l-----------------------
m b
• Bahwa atas usulan dari Kepala Dinas Pertanian Kabupaten Ponorogo yang
mengerjakan bidang kepegawaian ; -----------------------------------------------
• Bahwa saksi menerima Surat Keeputusan Pensiun sejak bulan Januari 2013;
h a
a • Bahwa selain saksi yang pensiun di usia 60 tahun ada juga Pak Buchori, SP. i
dan Cuk Sujarwo g h; -------------------------------------------------------------- e
35 o
h k

g e
h k
a i
m b

36
h a

a i
g e
• Bahwa saksi tidak pernah disuruh mengembalikan gaji ; ----------------------
• Bahwa setelah saksi menerima Surat Keputusan pensiun pernah mengajukan
permohonan pemberhentian gaji dalam bentuk SKPP diajukan pada Dinas
Pendapatan Pengelolaan Keuangan dan Asset Daerah ; ---------n
• Bahwa surat permohonannya dikerjakan oleh bagian keIpegawaian, saksi
h k
tinggal tanda tangan saja ; ---------------------------------------------------------
a i
• Bahwa saksi menerima Surat Keputusan pensiuln pada tanggal 14 November
m b
2012, sedangkan SKPP saksi terima tanggal 17 Januari 2013;--
• Bahwa Surat Keputusan Pensiunp diterima lebih dulu setelah itu baru SKPP;-
h • Bahwa Surat Keputusan pensiun saksi ditandatangani oleh Presiden ;------- a
a i
• Bahwa atas inisiatif saksi sendiri melalui kepegawaian Dinas Pertanian;----
• Bahwa SKPPg saksi terima sari Dinas Pendapatan, Pengelolaan Keuangan dan e
Asset Daerah ; -------------------------------------------------------------------
• Bahwa pengajuan usulan pensiun saksi dan Penggugat tidak bersamaan;-
• Bahwa tidak ada Surat Keputusan untuk mengembalikan gaji ; --------------
IBahwa………
h k
• Bahwa Pegawai Negeri Sipil pensiun usia 56 tahun, dan Penggugat usianya
a i
dibawah saya 10 tahun ; --------------------------------------l----------------------
m b
• Bahwa Tergugat tidak tahu tentang usulan perpanjangan usia pensiun bagi
Penggugat ; ---------------------------------------------------------------------------
• Bahwa tidak ada teman-temane saksi yang pensiun di usia 60 tahun disuruh
h a
a mengembalikan gaji ; ---------------------------------------------------------------- i
• Bahwa yang pensiun di usia 60 tahun ada 7 orang ; ---------------------------
g e
h k

g e
h k
a i
m b

37
h a

a i
g e
• Bahwa saksi kenal dengan orang bernama Bambang Guritno ; ---------------
• Bahwa Bambang Guritno sudah pensiun ; ----------------------------------------
• Bahwa saksi tidak tahu Bambang Guritno pernah mengembalikan gaji ;-----
• Bahwa saksi kenal dengan Hadi Sunyoto ; ------------------------n---------------
• Bahwa masa kerja saksi dengan Penggugat selisih 10 tahu n ; --------------
h k
Menimbang, bahwa untuk menanggapi alat-alat bukti maupun jalannya
a i
pemeriksaan sengketa di persidangan, Majelis Hakim telah memberi kesempatan
m b
kepada para pihak untuk menyampaikan kesiumpulan;-------------
Menimbang, bahwa atas kesemppatan tersebut, pihak Penggugat dan Tergugat
h telah menyampaikan kesimpuleannya masing-masing tertanggal 27 Juni a
a 2013;---------------------------------------------------------------------------------- i
Menimbang g , bahwa untuk selengkapnya segala sesuatu yang belum termuat e
dalam duduknyna sengketa tersebut di atas Majelis Hakim menunjuk Berita Acara n
Pemeriksauan Persiapan dan Berita Acara Persidangan yang merupakan satu kesatuan
yang tidak terpisahkan dengan putusan ini;----------
Menimbang, bahwa Para Pihak tidak ada lagi hal-hal yang akan
disampaikan dan mohon kepada Hakim untuk diberikan Putusan ; --- -----------
h k
a iTENTANG…..
m b
TENTANG PERTIMBANGAN HUKUM
Menimbang, bahwa maksud dan tujuan dari gugatan Penggugat adalah
sebagaimana diuraikan dalam duduknya perkara tersebut diatas ;----
h a
DALAM EKSEPSI :------------R----------------------------------------------------------
a i
g e
37 o
h k

g e
h k
a i
m b

38
h a

a i
g e
Menimbang, bahwa terhadap gugatan Penggugat tersebut Tergugat telah
mengajukan eksepsi di dalam Jawabannya tertanggal 10 April 2013 yang pada
pokoknya mengemukakan sebagai berikut : ---------------------------
Bahwa obyek gugatan dalam Sengketa Tata Usaha oleh Penggugat adalah merupakan
Surat Keterangan Pemberhentian Pembayaran (SKPP) yang diterbitkan oleh Tergugat
hdengan Nomor : 900/012/405.17/2013 tertanggal 02 Jankuari 2013 adalah salah
a i
gugatan, karena surat tersebut hanya merupakan surat keterangan bukan merupakan
m b
surat keputusan Tergugat yang keberadaaannya didasarkan pada Keputusan Kepala
a Badan Kepegawaian Negara Nomor : 00275/KEP/CV/23502/2012 yang menetapkan
pemberhentian dengan hormat Penggugat sebagai Pegawai Negeri Sipil karena telah
h a
mencapai batas usia penRsiun. Dengan demikian jelas bahwa yang seharusnya
a i
menjadi obyek sengketa tata usaha Negara adalah keputusan kepala badan
g e
kepegawaian Negara Nomor : 00275/KEP/
CV/23502/2012.;-----------------------------------------------------------
Menimbang, bahwa Penggugat telah menanggapi eksepsi Tergugat tersdebut di
dalam Repliknya tertanggal 17 April 2013 yang pada pokoknnya sebagai
berikut :-------------------------------------------------------------------------- I
h k
Bahwa obyek sengketa yang diterbitkan oleh Tergugat nyata-nyata telah
a i
menimbulkan akibat hukum bagi Penggugat yaitu adanya klewajiban yang
m b
harus……
harus Penggugat laksanakan berupa pengembalian gaji yang terlanjur dibayarkan,
padahal dalam kenyataannya Penggugeat masih menjalankan tugas dan kewajibannya
h a
a sebagai Pegawai Negeri Sipil dan gaji yang dibayarkan tersebut sangat layak untuk i
M Penggugat terima ;------------- ---------
g e
h k

g e
h k
a i
m b

39
h a

a i
g e
Menimbang, bahwa selanjutnya Pengadilan akan mempertimbangkan eksepsi
Tergugat tersebut sebagai berikut :------------------------------------------
Menimbang, bahwa yang menjadi obyek gugatan dalam sengketa ini adalah
Surat Keterangan Pemberhentian Pembayaran Nomor : 900/012/405.17/2013 tanggal
02 Januari 2013 atas nama SARDJONO, SP yang diterbitkan oleh Kepala Dinas
hPendapatan Pengelolaan Keuangan dan Aset Daerah Kabkupaten Ponorogo atas
a i
nama Bupati Ponorogo ( Vide bukti
m b
P-2) ;---------------------------------------------------------------------------------
a Menimbang, bahwa sesuai ketentuan Pasal 53 ayat (1) UU No. 9 Tahun 2004
tentang Peradilan Tata Usaha Negara : seseorang atau badan hukum perdata yang
h a
merasa kepetingannya diruRgikan oleh suatu keputusan tata usaha Negara dapat
a i
mengajukan gugatan tertulis kepada Pengadilan yang berwenang yang berisi tuntutan
g e
agar keputusan tata usaha Negara yang disengketakan itu dinyatakan batal atau tidak
sah, dengan atau tanpa disertai tuntutan ganti rugi dan/atau
rehabilitasi ;---------------------------------- d
Menimbang, bahwa bila mencermati obyek sengekta ( Vide nbukti P-2 )
diterbitkan berdasarkan Surat Keputusan Kepala BKN Nomor :I 00275/KEP/
h k
CV/23502/2012 tanggal 5 November 2012 yang menyatakan bahwa Penggugat
a i
pensiun sebagai Pegawai Negeri Sipil terhitung mulai tanglgal (TMT) 1 Juni
m b
2012 dengan pensiun pokok sebesar
Rp. 2.606.400,00;……..
Rp. 2.606.400,00;- dan gaji terakhir deibayarkan pada bulan Desember 2012 dengan
h a
a jumlah bersih sebesar Rp. 3.567.400,- dalam Surat keputusan tersebut Penggugat i
M diwajibkan untuk mengemb alikan gaji yang terlanjur dibayarkan selama 7 bulan
g e
39 o
h k

g e
h k
a i
m b

40
h a

a i
g e
mulai bulan Juni sampai dengan Desember 2012 dan gaji 13 sebesar Rp. 28.459.300,-
yang merupakan hutang kepada
Negara;-------------------------------------------------------------------------------------
Menimbang, bahwa Penggugat merasa dirugikan dengan diterbitkannya
obyek sengketa a quo yang mewajibkan kepada Penggugat untuk mengembalikan
hgaji yang terlanjur dibayarkan selama 7 (tujuh) bulan dari k bulan Juni sampai
a i
dengan Desember 2012 dan gaji 13 sebesar
m b
Rp. 28.459.300,- karena berdasarkan surat tugas nomor : 094/18/405.15/2012 tanggal
a 7 Agustus 2012 yang diterbitkan oleh Kepala Dinas Pertanian Kabupaten Ponorogo
Penggugat dengan nomor urut 7 (tujuh) ditunjuk sebagai Petugas lapangan Penyuluh
h a
Kehutanan (PLPK) di wilRayahnya masing-masing (Vide bukti P-7) dan Surat
a i
Keterangan Kepala Dinas Pertanian Kabupaten Ponorogo No: 876/2999/405.15/2012
g e
tanggal 27 Desember 2012 bahwa Penggugat masih melaksanakan tugas sebagai
Penyuluh Pertanian dan menerima gaji sampai bulan Desember 2012 pada Dinas
Pertanian kabupaten Ponorogo ( Vide bukti P-3) ;--------------------------- d
Menimbang, bahwa dari pertimbangan hukum tersebut nPengadilan
berpendapat dalil-dalil bantahan Penggugat terhadap eksepsi yang disaImpaikan oleh
h k
Tergugat beralasan, karena telah memenuhi ketentuan pasal 53 ayat (1) UU No. 9
a i
Tahun 2004 tentang Peradilan Tata Usaha Negara, dengan ldemikian eksepsi Tergugat
m b
tidak berdasar hukum dan harus
dinyatakan……..
dinyatakan tidak diterima ;--------------e------------------------------------------------
h a
a DALAM POKOK PERKARA :---------------------------------------------------------- i
g e
h k

g e
h k
a i
m b

41
h a

a i
g e
Menimbang, bahwa Penggugat dalam gugatannya memohon kepada
Pengadilan agar obyek sengketa dinyatakan batal atau tidak sah berupa : Surat
Keterangan Pemberhentian Pembayaran Nomor : 900/007/405.17/2013 tanggal 2
Januari 2013 atas nama SARDJONO, SP yang diterbitkan oleh Kepala Dinas
Pendapatan Pengelolaan Keuangan dan Aset Daerah Kabupaten Ponorogo ( Vide
hbukti P-2) ;-----------------------------------------------------------k-
a i
Menimbang, bahwa menurut dalil Penggugat obyek sengketa yang diterbitkan
m b
oleh Tergugat melanggar pasal 24 UU Nomor 11 Tahun 1969 tentang Pensiun
a Pegawai dan Pensiun Janda/Duda Pegawai, dan pasal 5 Peraturan Pemerintah Nomor
32 Tahun 1979 tentang Pemberhentian Pegawai Negeri Sipil, serta melanggar Asas-
h a
asas umum pemerintahan Ryang baik, yaitu : asas kepastian hukum, asas tertib
a i
penyelenggaraan Negara, asas kepentingan umum, asas keterbukaan, asas
g e
proporsionalitas dan asas
profesionalitas ;---------------------------------------------------------------------------
Menimbang, bahwa Tergugat telah membantah seluruh dalil gdugatan
Penggugat yang pada pokoknya Tergugat dalam menerbitkan obyek senngketa a quo
telah sesuai dengan Pasal 1 angka 15, dan Pasal 5 ayat (3) huruf b PeraIturan Menteri
h k
Dalam Negeri Nomor 13 Tahun 2006 tentang Pedoman Pengelolaan Keuangan
a i
Daerah serta pasal 22 ayat (1) Peraturan Bupati Ponoroglo Nomor 58 Tahun 2008
m b
tentang Uraian Tugas dan Fungsi Dinas Pendapatan, Pengelolaan Keuangan dan Aset
Daerah Kabupaten Ponorogo ;
Menimbang, bahwa dari jawabe-jinawab para pihak dalam persidangan
h a
a yang…… i
g e
41 o
h k

g e
h k
a i
m b

42
h a

a i
g e
yang menjadi pokok permasalahan dalam sengketa ini adalah apakah penerbitan
obyek sengketa Surat Keterangan Pemberhentian Pembayaran Nomor :
900/012/405.17/2013 tanggal 02 Januari 2013 atas nama SARDJONO, SP yang
diterbitkan oleh Kepala Dinas Pendapatan Pengelolaan Keuangan dan Aset Daerah
Kabupaten Ponorogo, melanggar peraturan perundang-undangan yang berlaku atau
hasas-asas umum pemerintahan yang baik ataukah tidak, bakik dari segi kewenangan
a i
maupun dari segi
m b
substansinya;------------------------------------------------------------------------------
a Menimbang, bahwa sebelum Pengadilan mempertimbangkan mengenai
substansi gugatann terlebih dahulu akan dipertimbangkan apakah Kepala Dinas
h a
Pendapatan, Pengelolaan KReuangan dan Aset Daerah mempunyai kewenangan
a i
menerbitkan obyek sengketa a quo ;------------------
g e
Menimbang, bahwa sesuai ketentuan pasal 22 ayat (1) Peraturan Bupati
ponorogo No. 58 Tahun 2008 tentang Uraian Tugas dan Fungsi Dinas Pendapatan,
Pengelolaan Keuangan dan Aset Daerah Kabupaten Ponorogo, yang menydatakan
bahwa Dinas Pendapatan, Pengelolaan Keuangan dan Aset Daerah n(DPPKAD)
mempunyai tugas menyelesaikan masalah perbendaharaaan belanjaI pegawai dan
h k
ganti rugi serta proses Surat Keterangan Pemberhentian Pembayaran (SKPP). Dengan
a i
berdasarkan ketentuan tersebut Pengadilan berkesimpullan bahwa kewenangan
m b
penerbitan obyek sengketa a quo ada pada Kepala Dinas Pendapatan, Pengelolaan
Keuangan dan Aset Daerah ;-----------------------------------------------------------
Menimbang, bahwa selanjutnyea Pengadilan akan mempertimbangkan apakah
h a
a alasan substansi/materi diterbitkannya obyek sengketa a quo telah i
M sesuai…….
g e
h k

g e
h k
a i
m b

43
h a

a i
g e
sesuai dengan ketentuan perundang-undangan yang berlaku dan atau asas-asas umum
pemerintahan yang baik atau tidak ;------------------------------------
Menimbang, bahwa dari bukti-bukti surat yang diajukan oleh para pihak
ditemukan fakta hukum antara lain sebagai berikut : ----------------------
• Bahwa Penggugat masih melaksanakan tugas sebagai Penyuluh Pertanian dan
h menerima gaji sampai bulan Desember 2012 pada Dkinas Pertanian Kabupaten
a i
Ponorogo (Vide bukti P-3);-------------------------l---
m b
• Bahwa Penggugat menandatangani dauftar hadir Apel/Siang di Dinas Pertanian
Kabupaten Ponorogo dari bulanp Juni 2012 sampai dengan Bulan Desember
h 2012 ( Vide bukti P-9, P-10, P-11, P-12, P-13, P-14, a
a P-15 )-------------------------------------------------------------------------- i
g e
• Bahwa Penggugat nomor urut 7 (tujuh) berdasarkan Surat Perintah Tugas
Nomor : 094/18/405.15/2012 tanggal 7 Agustus 2012 di tunjuk sebagai
Petugas Lapangan Penyuluh Kehutanan (PLPK) di wilayahnya masing-
masing yang diterbitkan oleh Kepala Dinas Pertanian Kapupatenn Ponorogo
(Vide bukti P-7);---------------------------- I
h k
• Bahwa Penggugat termasuk dalam salah seorang dari 18 orang yang
a i
m diusulkan oleh Kepala Dinas Pertanian bKabupaten Ponorogo untuk
perpanjangan usia pensiun penyuluh pertanian sesuai telaahan staf tanggal 16
k Mei 2012 Nomr : 800/1308/405.15/2012 yang ditujukan kepada Bupati
h a
Ponorogo pada Nomor Urut 18 lampiran telaahan staf (Vide bukti
a i
P-4) ;----------------------------------------------------------------- s
g e
43 o
h k

g e
h k
a i
m b

44
h a

a i
g e
• Bahwa Penggugat tetap menerima gaji sampai dengan bulan Desember 2012
selama melaksanakan tugas sebagai Penyuluh
Pertdanian……
Pertanian pada Dinas Pertanian Kabupaten Ponorogo ( Vide bukti P-3);
h k
• Bahwa SARDJONO, SP (NIP 195605131986031011, tanggal lahir 13 Mei
a i
1956 Unit Kerja Dinas Pertanian berdasarkaln Keputusan Kepala Badan
m b
Kepegawaian Negara Nomor ; 00275/KEP/CV/23502/2012 tanggal 5
November 2012 diberhentikan dengan hormat dengan hak pensiun TMT 1
Juni 2012 ( Vide bukti P-1)e ;---------------------------------
h a
a i
• Bahwa atas dasar Keputusan Kepala Badan Kepegawaian Negara Nomor : s
00275/KEP/CgV/23502/2012 tanggal 5 November 2012, Kepala Dinas e
Pendapatan, Pengelolaan Keuangan dan Aset Daerah menerbitkan Surat
Keterangan Pemberhentian Pembayaran (SKPP) No. 900/012/405.17/2013
tanggal 2 Januari 2013 atas nama SARDJONO, SP (Penggugat) TMT 1 Juni
2012 dan diwajibkan untuk mengembalikan gaji yang terlanjur dibayarkan
h selama 7 (tujuh) bulan Juni sampai dengan Desembker 2012 dan gaji 13
a i
sebesar Rp. 28.459.300,- yang merupakan hutang kepada Negara (Vide bukti
m b
P-2);
Menimbang, bahwa dari fakta hukpum tersebut persoalan yang harus dijawab
adalah : ------------------------------------e-------------------------------------
h a
a i
g e
h k

g e
h k
a i
m b

45
h a

a i
g e
1 Apakah pemberhentian dengan hormat Penggugat dengan hak pensiun sudah
sesuai dengan peraturan perundang-undangan yang berlaku atau
tidak ;--------------------------------------------------------------
A2 Apakah pemberhentian pembayaran gaji dengan kewajiban penngembalian gaji
yang terlanjur dibayar selama 7 ( tujuh) bulan dan gaji 13 sudah sesuai dengan
h k
peraturan perundang-undangan yang berlaku atau
a i
tidak? ;-------------------------------------------------------------
m b
Menimbang…….
Menimbang, bahwa terhadap persoalan yang ke 1 Pengadilan akan
h a
mempertimbangkannya sebaRgai berikut :---------------------------------------------
a i
Menimbang, bahwa berdasar ketentuan Pasal 3 Peraturan Pemerintah Nomor
g e
32 Tahun 1979 tentang Pemberhentian Pegawai Negeri Sipil :----------
1 Pegawai negeri yang telah mencapai batas usia pensiun, diberhentikan
dengan hormat sebagai pegawai negri sipil ;--------------- d
2 Batas usia pensiun sebagaimana dimaksud dalam ayat (1) adalah 56
(limapuluh enam) tahun ; ------------------------------------------- -----------
h k
a i
Menimbang, bahwa Penggugat dilahirkan pada tanggal 13 Mei 1956 bila
m b
berpedoman pada ketentuan Pasal 3 ayat (2) Peraturan Pemerintah tersebut, maka
a Penggugat memasuki masa pensiun pada usia 56 tahun di bulan Mei
2012 ;--------------------------------------------------------------------------
h a
Menimbang, bahwa berRdasar ketentuan Pasal 4 Peraturan Pemerintah Nomor
a i
32 Tahun 1979 tentang Pemberhentian PNS :------------------------------
g e
45 o
h k

g e
h k
a i
m b

46
h a

a i
g e
1 Batas usia pensiun sebagaimana dimaksud dalam pasal 3, dapat diperpanjang
bagi PNS yang memangku jabatan tertentu ; --------------
2 Perpanjangan batas usia pensiun sebagaimana dimaksud dalamd ayat (1),
Aadalah sampai dengan ; -----------------------------------------------n----
a 65 (enampuluh lima) tahun bagi PNS yang memangku jabatan :
h k
a i
1 Ahli peneliti/peneliti yang ditugaskan secara penuh di bidang
m b
penelitian ; ---------------------------------------------------------------
2 Guru besar. Lektor Kepapla, Lektor yang ditugaskan secara penuh pada
h perguruan tinggi ; -e--------------------------------------- a
a i
3 Jabatan lain yang ditentukan oleh presiden ; ----------------------- s
g e
Menimbang……..
Muenimbang, bahwa jabatan yang dijabat oleh Penggugat sebagai Penyuluh
Pertanian, perpanjangan batas usia pensiunnya diatur dalam Ketentuan Pasal 1
Peraturan Presiden RI No. 55 Tahun 2010 tentang Perpanjangan Batas Usia Pensiun
bagi PNS yang menduduki jabatan fungsional Penyuluh Perta nian, Penyuluh
h k
a Perikanan, dan Penyuluh Kehutanan, yang menyebutkan bahiwa PNS yang diangkat
m dan ditugaskan secara penuh dalam jabatan fungsionabl penyuluh pertanian, penyuluh
perikanan dan penyuluh kehutanan jenjang Madya dan jenjang Utama dapat
k diperpanjang batas usia pensiunnnya sampai dengan 60 (enampuluh) tahun;
h a
Menimbang, bahwa tata cara perpanjangan usia pensiun sebagaimana Pasal 1
a i
Peraturan Presiden RI No. 55 Tahun 2010 tersebut diatur dalam Surat Kepala Bdan s
Kepegawaian Negara Ngomor K.26-30/V.316-1/99 tanggal 19 Oktober 2010 pada e
h k

g e
h k
a i
m b

47
h a

a i
g e
angka 3 menyebutkan bahwa perpanjangan usia pensiun sampai dengan 60
(enampuluh) tahun tersebut harus ditetapkan dengan Keputusan Pejabat Pembina
Kepegawaian masing-masing untuk 1 (satu) kali masa perpanjangan paling lama 2
(dua) tahun setelah mendapat pertimbangan
Baperjakat ;-------------------------------------------------------------
h Menimbang, bahwa berdasarkan uraian ketentuakn tersebut dihubungkan
a i
dengan fakta-fakta hukum di persidangan, bahwa Penggugat belum pernah ditetapkan
m b
oleh Pejabat Pembina Kepegawaian dalam hal ini Bupati Ponorogo untuk
a perpanjangan usia pensiun walaupun sudah ada Usulan Perpanjangan Usia Pensiun
Penyuluh Pertanian kepada Bupati sebagaimana bukti P-4, maka Majelis Hakim
h a
berkesimpulan bahwa KepuRtusan Kepala BKN No. 00275/KEP/CV/23502/2012
a i
tanggal 5 November 2012
g e
tentang……
tentang pemberhentian dengan hormat sebagai PNS atas nama Penggugat dengan hak
pensiun ( Videbukti P-1) adalah telah sesuai ketentuan dyang
berlaku ;------------------------------------------------------------------------------n------
Menimbang, bahwa selanjutnya Majelis Hakim akan mempIertimbangkan
h k
mengenai persoalan hukum kedua yaitu apakah pemberhentian pembayaran gaji
a i
dengan kewajiban pengembalian gaji yang terlanjur dibaylar selama 7 (tujuh) bulan
m b
dan gaji 13 (keputusan Tata usaha Negara obyek sengketa vide bukti P-2) sudah
sesuai dengan ketentuan perundang-undangan yang berlaku dan asas-asas umum
yang ebaik atau
h a
a tidak;---------------------------------------------------------------------------------------- i
g e
47 o
h k

g e
h k
a i
m b

48
h a

a i
g e
Menimbang, bahwa sebagaimana dipertimbangkan sebelumnya bahwa
Penggugat telah diberhentikan dengan hormat sebagai PNS atas nama Penggugat
dengan hak pensiun (Vide bukti P-1= T-5). Selanjutnya Kepala Dinas Pendapatan,
Pengelolaan Keuangan dan Aset Daerah atas nama Bupati Ponorogo menindak-
lanjuti hal tersebut dengan menerbitkan Surat Keterangan Pemberhentian
hPembayaran (SKPP) No. 900/012/405.17/2013 tertanggal 0k2 Januari 2013 atas nama
a i
Penggugat TMT 1 Juni 2012, dimana dalam SKPP tersebut Penggugat diwajibkan
m b
untuk mengembalikan gaji yang terlanjur dibayar selama 7 (tujuh) bulan mulai bulan
a Juni sampai dengan bulan Desember 2012 dan gaji 13 sebesar Rp. 28.459.300,- yang
dalam obyek sengketa a quo disebut sebagai `Hutang-hutang kepada Negara ` (Vide
h a
bukti P-2) ;--------------------R-----------------------------------------------------
a i
Menimbang, bahwa setelah Pengadilan telah mencermati Bukti P-7 berupa
g e
Surat Tugas dari Kepala Dinas Pertanian Kabupaten Ponorogo Nomor
820/18/405.15/2012……..
820/18/405.15/2012 tertanggal 7 Agustus 2012 penggugat dengan nomor durut 5
ditunjuk sebgai Petugas Lapangan Penyuluh kehutanan (PLPK) di nwilayahnya
masing-masing, Bukti P-3 berupa Surat Keterangan dari Kepala DIinas Pertanian
h k
Kabupaten Ponorogo Nomor 876/2999/405.15/2012 tertanggal 27 Desember 2012
a i
yang menerangkan bahwa Penggugat masih melaksanakaln tugas sebagai Penyuluh
m b
Pertanian dan menerima gaji sampai bulan Desember 2012, Daftar Hadir Penggugat
pada Dinas Pertanian Kabupaten Ponorogo dari Bulan Juni 2012 sampai dengan
Desember 2012 ( Vide bukti P-9, P-e10, P-11, P-12, P-13, P-14, P-15 ) pada Dinas
h a
a Pertanian Kabupaten Ponorogo, serta keterangan saksi-saksi Penggugat bernama i
M Ir. .BISMARK PETRUS Y dan BUCHORI, SP yang bekerja satu instansi dengan
g e
h k

g e
h k
a i
m b

49
h a

a i
g e
Penggugat menerangkan bahwa Penggugat masih melaksanakan tugas sampai dengan
bulan Desember 2012 ;-----------------------------------------------
Menimbang, bahwa dengan adanya Telaahan Staf No. 800/1308/405.15/2012
Perihal Usulan Perpanjangan Usia Pensiun Penyuluh Pertanian dari Kepala Dinas
Pertanian tertanggal 16 Mei 2012 atas nama Penggugat dalam Lampirannya pada
hNo. Urut 18 (Vide bukti P-4) dan Surat Nomor C.I26-30/kV.301-6/51 tertanggal 23
a i
Oktober 2012 Perihal Permohonan Solusi Pemberian Perpanjangan Batas Usia
m b
Pensiun yang ditujukan kepada Bupati Ponorogo,( Videbukti P-5) serta Surat
a Keterangan dari Kepala Dinas Pertanian Kabupaten Ponorogo Nomor
876/2999/405.15/12 tertanggal 27 Desember 2012 yang menyatakan Penggugat
h a
masih melaksanakan tugas sRampai dengan Desember 2012 sebagaimana bukti P-3, di
a i
kuatkan dengan Daftar Hadir penggugat pada Dinas Pertanian Kabupaten Ponorogo
g e
dari Bulan
Juni 2012…….
Juni 2012 sampai dengan Desember 2012 (Vide bukti P-9, P-10, P-11, P-12d, P-13,
P-14, P-15) dan terhadap usulan tersebut dalam persidangan tidak dipneroleh fakta
maupun fakta hukum yang menunjukkan bahwa usulan tersebut ditolaIk oleh pejabat
h k
Pembina kepegawaian daerah kabupaten ponorogo, sehingga hal tersebut memberi
a i
harapan bagi Penggugat bahwa usia lpensiunnya dapat
m b
diperpanjang ;-------------------------------------------------
Menimbang, bahwa dari fakta-fakta hukum yang telah diuraikan diatas, dapat
disimpulkan bahwa tindakan Teergugat telah melanggar asas-asas umum
h a
a pemerintahan yang baik khususnya asas pemberian harapan yang wajar, sehingga i
M tuntutan Penggugat berkaitan dengan permohonan untuk tidak mengembalikan gaji
g e
49 o
h k

g e
h k
a i
m b

50
h a

a i
g e
terlanjur dibayar 7 (tujuh) bulan mulai bulan Juni sampai dengan Desember 2012 dan
gaji 13 sebesar Rp 28. 459.300,- adalah berdasar hukum untuk
dikabulkan ;------------------------------------------
Menimbang, bahwa mengenai tuntutan Penggugat yang memohon agar
Pengadilan mewajibkan Tergugat untuk mengembalikan Penggugat pada posisi dan
hjabatan semula serta seluruh hak-hak yang melekat didalkamnya, menurut Majelis
a i
Hakim tuntutan tersebut tidak relevan dan harus
m b
ditolak ;-----------------------------------------------------------------------------
a Menimbang, bahwa mengenai tuntutan Penggugat yang memohon kepada
Pengadilan supaya menerbitkan Penetapan Penundaan Pelaksanaan obyek sengketa,
h a
adalah tidak berdasar Rhukum untuk dikabulkan dan harus dinyatakan
a i
ditolak ;----------------------------------------------------------------------
g e
Menimbang, bahwa oleh karena tuntutan Penggugat dikabulkan untuk
sebagian, maka sesuai dengan kententuan pasal 110 UU No.5 Tahun 1986,
biaya……..
biaya yang timbul dalam perkara ini dibebankan kepada Tergugat yang besarnya
sebagaimana ditetapkan dalam amar putusan;--------------------------
h k
a Menimbang, bahwa dalam pasal 107 UU No. 5 Tahiun 1986 tentang PTUN
m b
disebutkan bahwa hakim menentukan apa yang harus dibuktikan, beban pembuktian
beserta penilaian pembuktian, maka bukti-bukti yang diajukan oleh para pihak
k merupakan bahan pertimbangan bagi Majelis Hakim, akan tetapi untuk memutus dan
h a
mengadili perkara ini hanya dipakai dan dipertimbangkan bukti-bukti yang relevan
a i
dengan pokok sengketanya, sedangkan bukti-bukti selainnya tidak dipertimbangkan s
g e
h k

g e
h k
a i
m b

51
h a

a i
g e
akan tetapi tetap sah dan terlampir dalam berkas perkara
ini ;---------------------------------------------
Memperhatikan pasal-pasal dalam UU No. 5 tahun 1986 yang telah diubah
dengan UU No.9 Tahun 2004, danterakhir diubah dengan UU No. 51 Tahun 2009,
serta peraturan perundang-undangan lainnya yang berkaitan dengan perkara
hini ;--------------------------------------------------------------------k--
a i
MENGADILI
m b
DALAM PENUNDAAN : -----------------------------------------------------
• Menolak permohonan penundaan pelaksanaan Surat Keterangan
Pemberhentian Pembayarane Nomor : 900/012/405.17/2013 tanggal 02 Januari
h a
a 2013 atas namaI SARDJONO, SP yang diterbitkan oleh Kepala Dinas i
M Pendapatan Penge lolaan Keuangan dan Aset Daerah Kabupaten Ponorogo
g e
atas nama Bupati Ponorogo ; ----------------------------------------- n
DALAMu EKSEPSI : ---------------------------------------------------------- o
• Menyatakan eksepsi Tergugat tidak diterima ;----------------------------------
DALAM……..
hDALAM POKOK PERKARA :-------------------------------------
------------
a • Mengabulkan gugatan Penggugat untuk sebagian ;-----i-----------------------
m b
• Menyatakan batal Surat Keterangan Pemberhentian Pembayaran Nomor :
900/012/405.17/2013 tanggal 2 Januari 2013 atas nama SARDJONO, SP,
yang diterbitkan oleh Kepala Dinas Pendapatan Pengelolaan Keuangan dan
h a
Aset Daerah KabupatenR Ponorogo atas nama Bupati Ponorogo, sepanjang
a i
mengenai kewajiban kepada Penggugat untuk mengembalikan gaji terlanjur
g e
51 o
h k

g e
h k
a i
m b

52
h a

a i
g e
dibayar 7 (tujuh) bulan mulai bulan Juni sampai dengan Desember 2012 dan
gaji 13 sebesar Rp 28.459.300,- ; ---------------------
• Memerintahkan kepada Tergugat untuk mencabut Surat Keterangan
Pemberhentian Pembayaran Nomor : 900/012/405.17/2013 tanggal 2 Januari
2013 atas nama SARDJONO, SP yang diterbitkan oleIh Kepala Dinas
h Pendapatan Pengelolaan Keuangan dan Aset Daerkah Kabupaten Ponorogo
a i
atas nama Bupati Ponorogo, sepanjang mlengenai kewajiban kepada
m b
Penggugat untuk mengembalikan gaji terlanjur dibayar 7 (tujuh) bulan mulai
bulan Juni sampai dengan Desember 2012 dan gaji 13 sebesar Rp
28.459.300,- ; --------------------------------------------------------
h a
• Menolak gugatan PeRnggugat untuk selain dan selebihnya ;------------------
a i
M • Membebankan ke pada Tergugat untuk membayar biaya perkara ini sebesar
g e
Rp. 232.000,- ( Dua ratus tiga puluh dua ribu rupiah );------------ n
Demikianlah diputus dalam rapat permusyawaratan Majelis Hakimo
Penggadilan Tata Usaha Negara Surabaya pada hari Senin tanggal 15 Juli 201d3 oleh
Akami ESAU NGEFAK, S.H., M.H. sebagai Hakim Ketua Majelis, INDARYADI,
S.H., M.H. danI GEDE EKA PUTRA SUARTANA, S.H., M.H.
h k
a i masing-masing…….
m masing-masing sebagai Hakim Anggota, putusan bmana diucapkan dalam
persidangan yang terbuka untuk umum pada hari Selasa tanggal 23 Juli 2013 oleh
k Majelis Hakim tersebut dengan dibantu oleh ARY SUSETYONINGTYAS, S.H.
h a
Panitera Pengganti Pengadilan Tata Usaha Negara Surabaya serta dihadiri oleh kuasa
a i
Penggugat dan Tergugat ; -------- s
g e
h k

g e
h k
a i
m b

53
h a

a i
g e
Hakim Anggota, Hakim Ketua Majelis,
1. INDARYADI, S.H., M.H. ESAU NGEFAK, S. H., M.H.
h k
a i
m b
a 2. I GEDE EKA PUTRA SUARTANA, S.H., M.H.
h a
a i
g e
Panitera Pengganti,
A ARY SUSETYONINGTYAS, S.H. n
h k
a i
m b
Perincian biaya perkara :
k 1 Pendaftaran Gugatan : Rp. 30.000,-
h a
2 Biaya Kepaniteraan : Rp. 191.000,-
a i
3 Redaksi : Rp. 5.000,- s
g e
4 Meterai : Rp. 6.000,-
53 o
h k

g e
h k
a i
m b

54
h a

a i
g e
Jumlah : Rp 232.000,-
( Dua ratus tiga puluh dua ribu rupiah ).
CATATAN :
1 Dicatat disini, bahwa putusan ini belum mempunyai kekuatan hukum tetap,
oleh karena masih dalam tenggang waktu para pihak dIalam mengajukan
h upaya hukum Banding. k
a i
2 Dicatat disini, bahwa pada hari Senin, tanggal 29 Juli 2013 salinan putusan
m b
ini telah diberikan kepada ABD. KHOLIQ, S.H., M.Hum selaku Kuasa
Hukum Penggugat.
3 Dicatat disini, bahwa pada hari Senin, tanggal 29 Juli 2013 salinan putusan
h a
ini telah diberikanR kepada BAMBANG TRI WAHONO, S.H., MM
a i
(KEPALA DINA S PENDAPATAN, PENGELOLAAN KEUANGAN DAN
g e
ASET DAERAH KABUPATEN PONOROGO) selaku Tergugat.
A Surabaya, 29 Juli 2013 n
PANITERA,
h k
a i
m b
NURSYAM B. SUDHARSONO,
pS.H.
h Perincian Salinan Putusan : e a
a 1 Meterai : Rp. 7.000,- i
g2 Legalisasi tanda tangan : Rp. 10.000,- e
h k

g e
h k
a i
m b

55
h a

a i
g e
3 Leges : Rp. 3.000,-
4 Foto copy 49 X 500 : Rp. 24.500,-
5 Lain-lain : Rp. 54.700,-
Jumlah : Rp. 99.200,-
(Sembilan puluh sembilan ribu dua ratus rupiah).
h k
a i
m b
h a
a i
g e
h k
a i
m b
h a
a i
g e
55 o
h k

g e
h k
a i
m b

56
h a

a i
g e
Demikianlah diputuskan dalam Rapat Permusyawaratan Majelis Hakim
Pengadilan Tata Usaha Negara Surabaya pada hari ………….., tanggal
h ………………….. oleh kami ESAU NGEFAK, S.Hk., M.H. sebagai Hakim
a i
Ketua Majelis, INDARYADI, S.H., M.H. danl I GEDE EKA PUTRA
m b
SUARTANA, S.H. masing-masing sebagai Hakim Anggota, putusan tersebut
diucapkan dalam sidang yang terbuka untuk umum pada hari ……………, tanggal
h …………………. oleh Majelis Heakim tersebut diatas dengan dibantu oleh a
a ARY SUSETYONINGTYAS, S.H. sebagai i
Panitera Pengganti gdan dihadiri oleh Kuasa Penggugat, tanpa hadirnya Kuasa e
Tergugat. n
Hakim Anggota, Hakim Ketua Majelis,
h k
a i
m b
a 1. INDARYADI, S.H., M.H. ESAU NGEFAK, S.H., M.H.
h a
a i
2. I GEDE EKA PUTRA SUARTANA, S.H., M.H.
g e
h k

g e
h k
a i
m b

57
h a

a i
g e
Panitera Pengganti,
h k
ARY SUSETYONINGTYAS, S.H.
a i
m b
Perincian biaya perkara :
5 Pendaftaran Gugatan : Rp. p 30.000,-
h 6 Biaya Kepaniteraan : e Rp.2.274.000,- a
a 7 Redaksi : Rp. 5.000,- i
8 Materai g : Rp. 6.000,- e
Jumlah n : Rp.2.315.000,- n
u ( Dua juta tiga ratus lima belas ribu ruliah ).
CATATAN :
h k
a Dicatat disini, bahwa salinan putusan ini belum memipunyai kekuatan hukum
m b
tetap, oleh karena pada hari Kamis, tanggal 14 Pebruari 2013 pihak Tergugat II
Intervensi 1 telah mengajukan Banding.
h a
Surabaya, 14 Pebruari 2013
a i
PANITERA, s
g e
57 o
h k

g e
h k
a i
m b

58
h a

a i
g e
NURSYAM B. SUDHARSONO,
S.H.
h k
a i
m b
C A T A T A N :
h a
1 Dicatat disinRi, bahwa pada hari Senin, tanggal 25 Pebruari 2013
a i
salinan put usan ini telah diberikan kepada H. MM. HADIDARSONO,
g e
S.H. selaku Kuasa Hukum Tergugat II Intervensi 1.
2 Dicatat disini, bahwa pada hari Selasa, tanggal 5 Maret 2013 salinan
putusan ini telah diberikan kepada DARMAJI, S.H., M.H. dselaku
A Kuasa Hukum Penggugat. n
h k
Surabaya, 5 Maret 2013
a i
P A N I T E R A,
m b
e NURSYAM B. SUDHARSONO, S.H.
h a
a i
g e
h k

g e
h k
a i
m b

59
h a

a i
g e
h k
a i
m b
h a
Perincian Salinan PutusanR :
a i
1 Meterai : Rp. 6.000,-
g e
2 Legalisasi tanda tangan : Rp. 10.000,-
3 Leges : Rp. 3.000,- o
g 4 Foto copy 95 X 300 : Rp. 28.500,- d
A9 Lain-lain : Rp. 42.000,-
Jumlah : Rp. 89.500,-
h k
(Delapan puluh Sembilan ribu lima ratus rupiah).
a i
m b
h a
a i
g e
59 o
h k

g e
h k
a i
m b

60
h a

a i
g e
h k
a i
m b
h a
a i
g e
h k
a i
m b
C A T A T A N : p
h Dicatat disini, bahwa salinean putusan ini dikirim kepada Kuasa a
a KuasaTergugat untuk memenuhi pasal 51 angka 2 Undang-undang Nomor 51 Tahun i
g e
h k

g e
h k
a i
m b

61
h a

a i
g e
2009 tentang Perubahan Kedua Atas Undang-undang Nomor 5 Tahun 1986 tentang
Peradilan Tata Usaha Negara, salinan ini tidak dapat dijadikan alat bukti.
h k
a i
m b
h a
a i
g e
h k
a i
m b
Perincian Salinan Putusan :
h a
1 MReterai : Rp. 6.000,-
a i
M 2 Legalisasi tanda tangan : Rp. 10.000,-
g e
61 o
h k

g e
h k
a i
m b

62
h a

a i
g e
3 Leges : Rp. 3.000,-
4 Foto copy 95 X 300 : Rp. 28.500,-
10 Lain-lain : Rp. 42.000,-
Jumlah : Rp. 89.500,-
(Delapan puluh Sembilan ribu lima ratus rupiah).
h k
a i
m b
h a
a i
g e
h k
a i
m b
h a
a i
g e
h k