# Halaman 1

MENTERI KEUANGAN
REPUBLIK INDONESIA

SALINAN

KEPUTUSAN MENTERI KEUANGAN REPUBLIK INDONESIA

NOMOR 199 /MK/SJ.5/2025
TENTANG

PEMBERHENTIAN DARI JABATAN FUNGSIONAL PRANATA KOMPUTER MAHIR
DAN PEMINDAHAN PEGAWAI NEGERI SIPIL ANTAR UNIT JABATAN PIMPINAN
TINGGI MADYA DI LINGKUNGAN KEMENTERIAN KEUANGAN
ATAS NAMA SDR. NININ SAPTO HARGIYANTO (NIP 19860720 200701 1 001)

Menimbang

MENTERI KEUANGAN REPUBLIK INDONESIA,

a. bahwa Sdr. Ninin Sapto Hargiyanto (NIP 19860720

200701 1 001) Penata Muda (III/a) Pranata Komputer
Mahir pada Badan Teknologi, Informasi, dan Intelijen
Keuangan tidak memenuhi kualifikasi pendidikan yang
dipersyaratkan untuk menduduki Jabatan Fungsional
Pranata Komputer Mahir sesuai dengan peraturan
perundang-undangan terkait Jabatan Fungsional
Pranata Komputer,

. bahwa Sdr. Ninin Sapto Hargiyanto (NIP 19860720

200701 1 001) Penata Muda (III/a) mengajukan
permohonan mutasi Pelaksana ke lingkungan Badan
Pendidikan dan Pelatihan Keuangan,

. bahwa dengan mempertimbangkan huruf a dan huruf b

di atas, Sekretaris Badan Teknologi, Informasi, dan
Intelijen Keuangan dengan Nota Dinas Nomor ND-
684/TI.1/2025 mengusulkan pemberhentian Sdr. Ninin
Sapto Hargiyanto (NIP 19860720 200701 1 001) Penata
Muda (III/a) dari Jabatan Pranata Komputer Mahir dan
menyetujui permohonan mutasi ke lingkungan Badan
Pendidikan dan Pelatihan Keuangan:

. bahwa berdasarkan pertimbangan sebagaimana

dimaksud dalam huruf a, huruf b, dan huruf c perlu
menetapkan Keputusan Menteri Keuangan tentang
Pemberhentian dari Jabatan Fungsional Pranata
Komputer Mahir dan Pemindahan Pegawai Negeri Sipil
antar Unit Jabatan Pimpinan Tinggi Madya di
Lingkungan Kementerian Keuangan atas nama Sdr.
Ninin Sapto Hargiyanto (NIP 19860720 200701 1 001);



# Halaman 2

Mengingat

Menetapkan

KESATU

KEDUA

1. Undang-Undang Nomor 20 Tahun 2023 tentang
Aparatur Sipil Negara (Lembaran Negara Republik
Indonesia Tahun 2023 Nomor 141, Tambahan Lembaran
Negara Republik Indonesia Nomor 6897):

2. Peraturan Pemerintah Nomor 11 Tahun 2017 tentang
Manajemen Pegawai Negeri Sipil (Lembaran Negara
Republik Indonesia Tahun 2017 Nomor 63, Tambahan
Lembaran Negara Republik Indonesia Nomor 6037)
sebagaimana telah diubah dengan Peraturan
Pemerintah Nomor 17 Tahun 2020 (Lembaran Negara
Republik Indonesia Tahun 2020 Nomor 68, Tambahan
Lembaran Negara Republik Indonesia Nomor 6477),

3. Peraturan Menteri Pendayagunaan Aparatur Negara dan
Reformasi Birokrasi Nomor 1 Tahun 2023 tentang
Jabatan Fungsional (Berita Negara Republik Indonesia
Tahun 2023 Nomor 54),

4. Peraturan Menteri Keuangan Nomor 224/PMK.01/2020
tentang Manajemen Karier di Lingkungan Kementerian
Keuangan (Berita Negara Republik Indonesia Tahun
2020 Nomor 1656),

5. Keputusan Menteri Keuangan Nomor 74/KMK.01/2012
tentang Penunjukan Para Pejabat di Lingkungan
Kementerian Keuangan yang Diberi Kuasa untuk dan
Atas Nama Menteri Keuangan Menandatangani
Surat/Keputusan Mutasi Kepegawaian dan Lain
Sebagainya di Bidang Kepegawaian sebagaimana telah
diubah dengan Keputusan Menteri Keuangan Nomor
404/KMK.01/2013;

MEMUTUSKAN:

KEPUTUSAN  'MENTERI KEUANGAN TENTANG
PEMBERHENTIAN DARI JABATAN FUNGSIONAL PRANATA
KOMPUTER MAHIR DAN PEMINDAHAN PEGAWAI NEGERI
SIPIL ANTAR UNIT JABATAN PIMPINAN TINGGI MADYA DI
LINGKUNGAN KEMENTERIAN KEUANGAN ATAS NAMA
SDR. NININ SAPTO HARGIYANTO (NIP 19860720 200701 1
001).

Memberhentikan dengan hormat Sdr. Ninin Sapto
Hargiyanto (NIP 19860720 200701 1 001) Penata Muda
(HI/a) dari jabatannya sebagai Pranata Komputer Mahir
terhitung mulai tanggal 1 November 2025 dengan ucapan
terima kasih atas pelaksanaan tugas dan pekerjaannya
selama ini.

Memindahkan Sdr. Ninin Sapto Hargiyanto (NIP 19860720
200701 1 001) Penata Muda (IlI/a) ke dalam jabatan



# Halaman 3

KETIGA

KEEMPAT

KELIMA

Pelaksana pada Badan Pendidikan dan Pelatihan Keuangan
terhitung mulai tanggal 1 November 2025.

Atasan langsung pada tempat kedudukan baru wajib
melakukan pembekalan terkait tugas, fungsi, target kinerja
serta melakukan pengembangan kompetensi yang
diperlukan dalam pelaksanaan tugas jabatan kepada
Pegawai Negeri Sipil sebagaimana dimaksud dalam Diktum
KEDUA.

Apabila di kemudian hari ternyata terdapat kekeliruan
dalam Keputusan Menteri ini akan diadakan perbaikan
sebagaimana mestinya.

Keputusan Menteri ini mulai berlaku pada tanggal
ditetapkan dan berlaku surut sejak 1 November 2025.
Salinan Keputusan Menteri ini disampaikan kepada:

1. Menteri Keuangan,

2. Kepala Badan Kepegawaian Negara,

3. Sekretaris Badan Teknologi Informasi dan Intelijen
Keuangan, Kementerian Keuangan,

4. Sekretaris Badan Pendidikan dan Pelatihan Keuangan,
Kementerian Keuangan,

5. Kepala Biro Perencanaan dan Keuangan, Kementerian
Keuangan,

6. Kepala Kantor Pelayanan Perbendaharaan Negara
terkait:

7. Kepala Bagian Perencanaan dan Pengadaan Sumber
Daya Manusia, Biro Sumber Daya Manusia,
Kementerian Keuangan,

8. Sdr. Ninin Sapto Hargiyanto (NIP 19860720 200701 1
001).

Ditetapkan di Jakarta
pada tanggal 13 November 2025

a.n. MENTERI KEUANGAN REPUBLIK INDONESIA
KEPALA BIRO SUMBER DAYA MANUSIA,

ttd.

RUKIJO

Salinan sesuai dengan aslinya,
Kepala Bagian Mutasi dan Kepangkatan


