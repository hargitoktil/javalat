# -*- coding: utf-8 -*-
"""
TIMELINE KRONOLOGI PERKARA No. 119/G/2026/PTUN.JKT
Ninin Sapto Hargiyanto vs Menteri Keuangan RI

Bentuk: alur serpentin (meander/"usus"), dibaca kiri->kanan lalu berbelok turun.
Bobot visual diatur kolom `tier`: 3 = objek sengketa, 2 = simpul kunci,
1 = pendukung, 0 = konteks (abu-abu, kecil).
Modifikasi: Penambahan panah penunjuk arah pada setiap ruas garis.
"""
from functools import lru_cache

import numpy as np
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, Circle, Polygon

# ============================================================ 1. PALET
PAL = {
    "norma":    "#4F6D8C",
    "hak":      "#0F8A6A",
    "studi":    "#6D4AA6",
    "internal": "#D98324",
    "sengketa": "#BE2A2A",
    "proses":   "#2F5FBF",
}
LEGEND = [("norma", "Dasar hukum & norma"), ("hak", "Pengakuan resmi & hak Penggugat"),
          ("studi", "Penyetaraan pendidikan"), ("internal", "Proses internal Tergugat"),
          ("sengketa", "Objek sengketa & kerugian"), ("proses", "Upaya hukum & persidangan")]
BG, INK, INK2 = "#F6F4EF", "#1B2430", "#4A5568"
GREY, GREY_TX, GREY_TX2 = "#A7AEB6", "#6E7681", "#8B929A"
BAND = "#F1EDE3"

# ==================================== 2. DATA  (tgl, judul, keterangan, kode, kategori, tier, gelembung)
E = [
 ("Jul 2003","Kepmenpan 66/2003","Syarat pengangkatan Prakom keterampilan: SLTA / D-I",["AD-19"],"norma",1,None),
 ("07 Sep 2009","KMK 1105/KM.1/UP.11/2009","Pengangkatan pertama sah, TMT 1 Agt 2009 — verkregen recht",["P-1"],"hak",1,None),
 ("26 Mei 2020","Permenpan RB 32/2020","Ps. 59(3) wajib D-III TI dalam 5 th; Ps. 59(2) tetap bertugas",["AD-20"],"norma",1,None),
 ("Okt–Des 2020","Sosialisasi aturan","Undangan & penyampaian Permenpan 32/2020 ke unit-unit",["T-1","T-2"],"internal",0,None),
 ("30 Mar 2022","KMK 321.1/KM.1/UP.11/2022","Naik jenjang jadi Prakom Mahir — pendidikan tidak dipersoalkan",["P-2","T-3"],"hak",1,None),
 ("14 Apr 2023","ND PEM-8/TPAK/2023","Nota Pemberitahuan: wajib ijazah D-III TI sebelum 26 Mei 2025",["T-4","T-5"],"internal",0,None),
 ("2023","Permenpan RB 1/2023","Ps. 41(5): wajib diperiksa lebih dahulu dan izin PyB sebelum diberhentikan",["AD-21"],"norma",1,None),

 ("14 Mei 2024","Kepmenpan SKJ.4/2024","Standar kompetensi JF Prakom; Diktum XI: berlaku prospektif",["AD-22"],"norma",1,None),
 ("15 Mei 2024","KET-137/PP.7/2024","BPPK: jalur pengalaman TI >=5 th diakui, bukan hanya ijazah",["P-3"],"hak",0,None),
 ("Okt 2024","Sertifikat BPS “Kompeten”","Instansi Pembina menilai Penggugat KOMPETEN",["P-4"],"hak",2,
   "Satu-satunya penilaian\nInstansiPembinadalam: KOMPETEN"),
 ("16 Mei 2025","ND-472/PP.7/2025","Unit Tergugat memproses kelanjutan pendidikan Penggugat",["P-6","T-6"],"studi",1,
   "pendidikan diproses\nSEBELUM tenggat"),
 ("26 Mei 2025","TENGGAT versi Tergugat","Batas 5 tahun Ps. 59(3) yang didalilkan Tergugat",["T-9"],"internal",2,None),
 ("10 Jun 2025","ST-497/PP.1/2025","Tugas belajar mandiri: tetap pegawai aktif dengan hak jabatan",["P-7","T-7"],"studi",1,None),
 ("19 Jun 2025","KMK 117/MK/SJ.5/2025","Ditempatkan sebagai Prakom di BaTii dan diberi tunjangan jabatan fungsional setiap bulan",["P-8"],"hak",2,
   "SK PERTAMA PASCA-TENGGAT\n24 hari setelah 26 Mei 2025"),

 ("23 Jun 2025","KEP-2/TI/2025","Dinyatakan “cakap dan memenuhi syarat” menduduki jabatan",["P-9","T-8"],"hak",2,
   "SK KEDUA PASCA-TENGGAT\n28 hari setelah 26 Mei 2025"),
 ("Agt 2025","Tunjangan kinerja penuh","Rp9.773.000 diterima sah selaku Prakom Mahir",["P-29"],"hak",0,None),
 ("29 Sep 2025","ND-489/TI.1/2025","Konfirmasi antar-unit — Penggugat tidak dipanggil",["T-9"],"internal",0,
   "“dalam data\nmonitoring kami”"),
 ("08 Okt 2025","ND-120/TI.5/2025","Usulan pemberhentian atas dasar penelitian terhadap data",["T-10"],"internal",0,None),
 ("16 Okt 2025","Pertemuan di BaTii","Opsi TMT tidak surut dibahas secara internal",["P-14"],"sengketa",2,
   "Kabag SDM menyebut\npemindahan “mal-administrasi”"),
 ("23 Okt 2025","KMK 188/MK/SJ.5/2025","Dua rekan sejawat diberhentikan secara prospektif (berlaku 1 Nov)",["P-15","P-16"],"sengketa",2,
   "Rekan sejawat: PROSPEKTIF\nPenggugat: SURUT"),
 ("30 Okt 2025","Percakapan WhatsApp","Pejabat Tergugat: “pasti bulan ini” — rencana SK sudah disusun",["P-11","P-13"],"internal",0,None),

 ("TW III 2025","Evaluasi kinerja","Predikat “Sangat Baik”, capaian “Istimewa”",["P-10"],"hak",1,None),
 ("01 Nov 2025","TMT surut pemberhentian","Tanggal yang di-surut-kan oleh Diktum KELIMA",["P-18"],"sengketa",1,None),
 ("05 Nov 2025","ND-684/TI.1/2025","Permohonan pemberhentian ke Biro SDM — usulan sepihak",["T-11"],"internal",0,
   "“berdasarkan penelitian\nterhadap data”"),
 ("07 Nov 2025","ST-182/TI.1/2025","Masih ditugaskan sebagai “Prakom Mahir” (training 10–14 Nov)",["P-17"],"hak",2,
   "6 hari SETELAH TMT surut,\nPrakom masih dijalankan"),
 ("13 Nov 2025","OBJEK SENGKETA","KMK 199/MK/SJ.5/2025 — berlaku surut sejak 1 Nov 2025, tanpa pemeriksaan terhadap Penggugat",["P-18","T-12"],"sengketa",3,
   "cacat wewenang, prosedur\n& substansi sekaligus"),
 ("08 Des 2025","KEP-57/PP/PP.1/2025","Ditempatkan sebagai Pelaksana di BPPK — tindak lanjut SK",["P-20","T-13"],"sengketa",0,None),
 ("23 Des 2025","Keberatan administratif","Surat 1/Hargi/2025 kepada Pejabat Pembina Kepegawaian",["P-21","P-22"],"proses",0,None),

 ("Jan 2026","Penarikan tunjangan","Tukin ditarik via SIMPONI: Rp1.500.000 dalam 10 cicilan",["P-19"],"sengketa",1,None),
 ("23 Jan 2026","KMK 9/MK/SJ/2026","Keberatan ditolak; dasar hukum baru ditambahkan di Mengingat",["P-23","T-14"],"sengketa",1,None),
 ("29 Jan 2026","Dibaca di Nadine","Titik awal tenggang 90 hari (jo. SEMA 5/2021)",["P-24","AD-24"],"proses",0,None),
 ("10 Feb 2026","Pelantikan Prakom baru","Pegawai S.M./S.E. dilantik sebagai Pranata Komputer",["P-26"],"sengketa",0,None),
 ("02 Apr 2026","Gugatan didaftarkan","PTUN Jakarta — dalam tenggang waktu 90 hari",["AD-13"],"proses",1,None),
 ("08 Jul 2026","Saksi Riyanto Sihaloho","Di bawah sumpah: tidak pernah diperiksa; penghasilan saksi turun",[],"proses",1,None),
 ("25 Jul 2026","Surat Keterangan Lulus","D-III Manajemen Informatika selesai",["P-32"],"studi",2,
   "Premis faktual pemberhentian\nkini terpenuhi seluruhnya"),
]

DASHED = {"TENGGAT versi Tergugat"}   # judul simpul yang digambar putus-putus (garis batas/tenggat)

# ==================================== 3. UKURAN PER TIER
TIER = {                       # w, h, fs_judul, fs_ket, fs_chip, r_node, lw_pita
    0: dict(w=9.0,  h=6.3, fj=10.0, wj=28, fk=8.6,  wk=35, fc=8.2,  rn=0.62, lw=8),
    1: dict(w=10.2, h=7.3, fj=11.5, wj=26, fk=10.0, wk=34, fc=9.3,  rn=0.95, lw=11),
    2: dict(w=10.8, h=8.3, fj=13.0, wj=25, fk=10.6, wk=32, fc=9.8,  rn=1.20, lw=14),
    3: dict(w=11.6, h=9.9, fj=16.5, wj=22, fk=12.2, wk=29, fc=11.5, rn=1.65, lw=18),
}

# ==================================== 4. GEOMETRI SERPENTIN
NCOL, COL_W, ROW_H = 7, 12.4, 19.6
R = ROW_H / 2.0
NROW = int(np.ceil(len(E) / NCOL))
X0, X1 = 0.0, (NCOL - 1) * COL_W
TOP_GAP = 1.15                    # jarak pita ke tepi atas kartu
BUB_GAP = 2.35                    # jarak pita ke tepi bawah gelembung

def build_path():
    """Polyline serpentin; berhenti tepat di simpul terakhir."""
    pts, idx = [], []
    for r in range(NROW):
        y = -r * ROW_H
        xs = np.linspace(X0, X1, NCOL)
        if r % 2:
            xs = xs[::-1]
        for c, x in enumerate(xs):
            if r == 0 and c == 0:
                pts.append((x, y))
            else:
                xa, ya = pts[-1]
                for t in np.linspace(0, 1, 26)[1:]:
                    pts.append((xa + (x - xa) * t, ya))
            idx.append(len(pts) - 1)
            if len(idx) == len(E):
                return np.array(pts[:idx[-1] + 1]), idx
        if r < NROW - 1:
            cx, cy = (X1 if r % 2 == 0 else X0), y - R
            th = (np.linspace(np.pi / 2, -np.pi / 2, 70) if r % 2 == 0
                  else np.linspace(np.pi / 2, 3 * np.pi / 2, 70))
            for t in th[1:]:
                pts.append((cx + R * np.cos(t), cy + R * np.sin(t)))
    return np.array(pts), idx

PTS, NODE = build_path()
xy = lambda i: PTS[NODE[i]]

# ==================================== 5. KANVAS (dibuat lebih dulu agar teks bisa diukur)
SCALE = 0.33
TITLE_FS, TITLE_Y = 31, 13.0
LEG_FS = 12.5
LX = X0 - R - 1.6
XR = X1 + R + 2.4
H_MAX = max(TIER[e[5]]["h"] for e in E)
bottom_y = min(xy(i)[1] - TOP_GAP - TIER[e[5]]["h"] for i, e in enumerate(E)) - 1.4

W = (X1 - X0 + 2 * R + 5.0) * SCALE
H = ((NROW - 1) * ROW_H + 34) * SCALE
fig, ax = plt.subplots(figsize=(W, H))
fig.patch.set_facecolor(BG); ax.set_facecolor(BG)
# batas dipasang SEBELUM pengukuran: skala data->piksel tidak boleh berubah lagi
ax.set_xlim(X0 - R - 2.4, XR)
ax.set_ylim(bottom_y - 2.5, TITLE_Y + 3.0)
ax.set_aspect("equal"); ax.axis("off")
fig.canvas.draw()
REND = fig.canvas.get_renderer()

# ==================================== 5b. PENGUKUR TEKS (satuan data)
@lru_cache(maxsize=8192)
def ukur(txt, fs, bold=False):
    """Lebar & tinggi teks dalam satuan data."""
    t = ax.text(0, 0, txt, fontsize=fs, fontweight="bold" if bold else "normal")
    bb = t.get_window_extent(renderer=REND); t.remove()
    (x0, y0), (x1, y1) = ax.transData.inverted().transform([(bb.x0, bb.y0), (bb.x1, bb.y1)])
    return x1 - x0, y1 - y0

def lebar(txt, fs, bold=False):
    return ukur(txt, fs, bold)[0]

def tinggi_baris(fs, bold=False, ls=1.0):
    return ukur("HgÁy", fs, bold)[1] * ls

def potong_kata(kata, fs, bold, maxw):
    """Pecah satu kata yang lebih lebar dari kolom."""
    out, cur = [], ""
    for ch in kata:
        if cur and lebar(cur + ch, fs, bold) > maxw:
            out.append(cur); cur = ch
        else:
            cur += ch
    if cur:
        out.append(cur)
    return out

def bungkus(txt, fs, maxw, bold=False):
    """Pembungkus baris berbasis lebar terukur (bukan hitungan karakter)."""
    lines = []
    for para in txt.split("\n"):
        cur = ""
        for kata in para.split():
            cand = (cur + " " + kata).strip()
            if cur and lebar(cand, fs, bold) > maxw:
                lines.append(cur)
                if lebar(kata, fs, bold) > maxw:
                    pecah = potong_kata(kata, fs, bold, maxw)
                    lines.extend(pecah[:-1]); cur = pecah[-1]
                else:
                    cur = kata
            else:
                cur = cand
        lines.append(cur)
    return [l for l in lines if l != ""] or [""]

# ==================================== 5c. TATA LETAK GELEMBUNG (terukur)
def layout_bub(bub, tier, S):
    bw = S["w"] + (1.2 if tier == 3 else 0.0)
    inner = bw - 1.2
    fs = 11.6 if tier == 3 else 10.3
    while True:
        lines = bungkus(bub, fs, inner, bold=True)
        if max(lebar(l, fs, True) for l in lines) <= inner or fs <= 7.0:
            break
        fs -= 0.3
    step = tinggi_baris(fs, True, 1.34)
    bh = len(lines) * step + 0.95
    return dict(bw=bw, bh=bh, lines=lines, fs=fs, step=step)

BUB = {i: layout_bub(e[6], e[5], TIER[e[5]]) for i, e in enumerate(E) if e[6]}

# ==================================== 5d. TATA LETAK KARTU (terukur, dijamin muat)
CHIP_PADX, CHIP_PADY, CHIP_GAP = 0.34, 0.30, 0.32

def layout_chip(kode, fs, inner):
    """Susun chip bukti jadi beberapa baris bila melebihi lebar kartu."""
    if not kode:
        return [], 0.0
    h = ukur("Hg", fs, True)[1] + 2 * CHIP_PADY
    rows, cur, curw = [], [], 0.0
    for k in kode:
        w = lebar(k, fs, True) + 2 * CHIP_PADX
        if cur and curw + w > inner + 1e-6:
            rows.append(cur); cur, curw = [], 0.0
        cur.append((k, w)); curw += w + CHIP_GAP
    if cur:
        rows.append(cur)
    return rows, h

def layout_kartu(judul, ket, kode, S, tier):
    cw, ch = S["w"], S["h"]
    bar_w = 0.44
    pad_l = bar_w + 0.52
    pad_r = 0.62
    inner = cw - pad_l - pad_r
    top_pad = 0.95 if tier == 3 else 0.78
    bot_pad = 0.45
    gap_jk = 0.42                      # judul -> keterangan
    gap_kc = 0.5                       # keterangan -> chip
    hasil = None
    for s in np.arange(1.0, 0.639, -0.02):
        fj, fk, fc = S["fj"] * s, S["fk"] * s, S["fc"] * s
        jl = bungkus(judul, fj, inner, bold=True)
        kl = bungkus(" ".join(ket.split()), fk, inner)
        chip_rows, chip_h = layout_chip(kode, fc, inner)
        sj = tinggi_baris(fj, True, 1.2)
        sk = tinggi_baris(fk, False, 1.36)
        h_chip = len(chip_rows) * (chip_h + CHIP_GAP) if chip_rows else 0.0
        tot = (top_pad + len(jl) * sj + gap_jk + len(kl) * sk
               + (gap_kc + h_chip if chip_rows else 0.0) + bot_pad)
        hasil = dict(fj=fj, fk=fk, fc=fc, jl=jl, kl=kl, sj=sj, sk=sk,
                     chip_rows=chip_rows, chip_h=chip_h, h_chip=h_chip,
                     pad_l=pad_l, inner=inner, top_pad=top_pad, bot_pad=bot_pad,
                     gap_jk=gap_jk, gap_kc=gap_kc, tot=tot)
        if tot <= ch:
            break
    return hasil

KARTU = {i: layout_kartu(e[1], e[2], e[3], TIER[e[5]], e[5]) for i, e in enumerate(E)}

BAND_TOP = BUB_GAP + max([b["bh"] for b in BUB.values()] or [0]) + 0.5
BAND_BOT = TOP_GAP + H_MAX + 0.9

def periksa_tata_letak():
    """Peringatan dini bila hasil suntingan data menimbulkan tumpang tindih."""
    K = []
    for i, ev in enumerate(E):
        x, y = xy(i); S = TIER[ev[5]]
        K.append(dict(i=i, judul=ev[1], tier=ev[5], x=x, y=y,
                      x0=x - S["w"] / 2, x1=x + S["w"] / 2,
                      y0=y - TOP_GAP - S["h"], y1=y - TOP_GAP, w=S["w"]))
    pesan = []
    for a in K:
        for b in K:
            if a["i"] >= b["i"]:
                continue
            if (a["x0"] < b["x1"] - 1e-6 and b["x0"] < a["x1"] - 1e-6
                    and a["y0"] < b["y1"] - 1e-6 and b["y0"] < a["y1"] - 1e-6):
                pesan.append("kartu bertabrakan: %s <-> %s" % (a["judul"], b["judul"]))
    for b in K:
        B = BUB.get(b["i"])
        if not B:
            continue
        atas = b["y"] + BUB_GAP + B["bh"]
        for a in K:
            if a["i"] == b["i"] or a["y0"] <= b["y"]:
                continue
            if (a["x0"] < b["x"] + B["bw"] / 2 and b["x"] - B["bw"] / 2 < a["x1"]
                    and a["y0"] < atas + 0.4):
                pesan.append("gelembung %s menabrak kartu %s" % (b["judul"], a["judul"]))
    if pesan:
        print("PERIKSA TATA LETAK:")
        for t in dict.fromkeys(pesan):
            print("  -", t)
    else:
        print("Tata letak aman: kartu, gelembung, dan isinya tidak ada yang melewati tepi.")

# --- pita latar selang-seling (menutupi gelembung sampai kartu) ---
for r in range(NROW):
    if r % 2:
        y = -r * ROW_H
        ax.add_patch(FancyBboxPatch((X0 - R - 1.0, y - BAND_BOT), X1 - X0 + 2 * R + 2.0,
                                    BAND_TOP + BAND_BOT,
                                    boxstyle="round,pad=0.02,rounding_size=1.2",
                                    fc=BAND, ec="none", zorder=0))

# --- pita dasar ---
ax.plot(PTS[:, 0], PTS[:, 1], color="#CFC8B8", lw=24, solid_capstyle="round", alpha=.45, zorder=1)
ax.plot(PTS[:, 0], PTS[:, 1], color="#E4DFD3", lw=20, solid_capstyle="round", zorder=2)

# --- ruas berwarna: tebal, pekat, & penambahan PANAH PETUNJUK ARAH ---
for i in range(len(E) - 1):
    tn = E[i + 1][5]
    seg = PTS[NODE[i]:NODE[i + 1] + 1]
    col = PAL[E[i + 1][4]] if tn >= 1 else GREY
    putus = E[i + 1][1] in DASHED or E[i][1] in DASHED
    kw = (dict(dashes=(1.25, 0.85), dash_capstyle="round") if putus
          else dict(solid_capstyle="round"))
    
    # 1. Gambar segment garis
    ax.plot(seg[:, 0], seg[:, 1], color=col, lw=TIER[tn]["lw"], zorder=3,
            alpha=.95 if tn >= 1 else .55, **kw)
    
    # 2. Hitung posisi tengah garis untuk meletakkan panah arah
    diffs = np.diff(seg, axis=0)
    dists = np.linalg.norm(diffs, axis=1)
    cum_dists = np.concatenate(([0], np.cumsum(dists)))
    tot_dist = cum_dists[-1]
    
    if tot_dist > 0:
        # Titik 55% perjalanan di garis (sedikit off-center agar lebih dinamis)
        frac = 0.55
        target_dist = tot_dist * frac
        idx = np.searchsorted(cum_dists, target_dist) - 1
        idx = max(0, min(idx, len(dists) - 1))
        
        rem = target_dist - cum_dists[idx]
        ratio = rem / dists[idx] if dists[idx] > 0 else 0
        p1, p2 = seg[idx], seg[idx + 1]
        
        # Koordinat pusat panah
        cx = p1[0] + ratio * (p2[0] - p1[0])
        cy = p1[1] + ratio * (p2[1] - p1[1])
        
        # Sudut kemiringan (arah)
        angle = np.arctan2(p2[1] - p1[1], p2[0] - p1[0])
        
        # Menggambar poligon panah (segitiga yang menempel di atas garis)
        asz = 0.9  # Ukuran dasar panah (satuan data)
        sweep = np.pi * 0.83  # Sudut "sayap" panah di belakang
        
        # 3 Titik pembentuk panah: ujung, sayap kiri, sayap kanan
        ptip = [cx + asz * 0.4 * np.cos(angle), cy + asz * 0.4 * np.sin(angle)]
        pleft = [cx + asz * np.cos(angle + sweep), cy + asz * np.sin(angle + sweep)]
        pright = [cx + asz * np.cos(angle - sweep), cy + asz * np.sin(angle - sweep)]
        
        # Gambar patch panah, beri garis pinggir putih (outline) agar pop-out (menonjol)
        arrow_poly = Polygon(
            [ptip, pleft, pright], closed=True,
            fc=col, ec="#FFFFFF", lw=1.2,
            zorder=4, alpha=.95 if tn >= 1 else .65
        )
        ax.add_patch(arrow_poly)

# ==================================== 6. SIMPUL + KARTU + GELEMBUNG
for i, (tgl, judul, ket, kode, kat, tier, bub) in enumerate(E):
    x, y = xy(i)
    S = TIER[tier]
    live = tier >= 1
    col = PAL[kat] if live else GREY          # warna kartu (diredam bila tier 0)
    bcol = PAL[kat]                           # gelembung selalu berwarna penuh
    tx1 = INK if live else GREY_TX
    tx2 = INK2 if live else GREY_TX2
    dash = judul in DASHED

    # --- garis batas putus-putus (tenggat) ---
    if dash:
        ax.plot([x, x], [y + BAND_TOP - 0.6, y - TOP_GAP - S["h"] - 1.4], color=col, lw=2.0,
                linestyle=(0, (4, 3)), zorder=4, alpha=.85)

    # --- gelembung penekanan ---
    if bub:
        B = BUB[i]
        bw, bh = B["bw"], B["bh"]
        by = y + BUB_GAP
        ax.add_patch(FancyBboxPatch((x - bw / 2, by), bw, bh,
                                    boxstyle="round,pad=0.02,rounding_size=0.6",
                                    fc="#FFFFFF", ec=bcol, lw=2.6 if tier == 3 else 1.9, zorder=8))
        ax.add_patch(Polygon([[x - 0.75, by + 0.06], [x + 0.75, by + 0.06], [x, by - 0.95]],
                             closed=True, fc="#FFFFFF", ec=bcol, lw=1.9, zorder=8))
        ax.add_patch(Polygon([[x - 0.62, by + 0.10], [x + 0.62, by + 0.10], [x, by - 0.78]],
                             closed=True, fc="#FFFFFF", ec="#FFFFFF", lw=2.4, zorder=9))
        ty0 = by + bh - (bh - len(B["lines"]) * B["step"]) / 2 - B["step"] / 2
        for n, l in enumerate(B["lines"]):
            ax.text(x, ty0 - n * B["step"], l, ha="center", va="center",
                    fontsize=B["fs"], color=bcol, fontweight="bold", zorder=10)

    # --- chip tanggal ---
    ax.text(x, y + 1.42, tgl, ha="center", va="center",
            fontsize=12.5 if tier == 3 else (11.4 if live else 9.8),
            fontweight="bold", color="#FFFFFF" if live else GREY_TX, zorder=7,
            bbox=dict(boxstyle="round,pad=0.4", fc=col if live else "#E8E5DD", ec="none"))

    # --- simpul ---
    if tier == 3:
        ax.add_patch(Circle((x, y), S["rn"] + 1.15, facecolor="none", edgecolor=col, lw=2.2, alpha=.35, zorder=5))
        ax.add_patch(Circle((x, y), S["rn"] + 0.55, facecolor="none", edgecolor=col, lw=2.8, alpha=.6, zorder=5))
    elif tier == 2:
        ax.add_patch(Circle((x, y), S["rn"] + 0.55, facecolor="none", edgecolor=col, lw=2.0, alpha=.4, zorder=5))
    ax.add_patch(Circle((x, y), S["rn"], facecolor="#FFFFFF", edgecolor=col,
                        lw=5.0 if tier == 3 else (3.6 if live else 2.4), zorder=6,
                        linestyle=(0, (3, 2)) if dash else "solid"))
    ax.add_patch(Circle((x, y), S["rn"] * 0.45, facecolor=col, edgecolor="none", zorder=7))

    # --- kartu ---
    C = KARTU[i]
    cw, ch = S["w"], S["h"]
    cx, cy = x - cw / 2, y - TOP_GAP - ch
    if live:
        ax.add_patch(FancyBboxPatch((cx + 0.14, cy - 0.18), cw, ch,
                                    boxstyle="round,pad=0.02,rounding_size=0.55",
                                    fc="#D9D3C6", ec="none", zorder=4))
    ax.add_patch(FancyBboxPatch((cx, cy), cw, ch, boxstyle="round,pad=0.02,rounding_size=0.55",
                                fc="#FFFDF8" if tier == 3 else ("#FFFFFF" if live else "#FAF8F3"),
                                ec=col if tier >= 2 else ("#E3DED2" if live else "#E6E2D9"),
                                lw=3.2 if tier == 3 else (2.2 if tier == 2 else 1.3),
                                linestyle=(0, (5, 3)) if dash else "solid", zorder=5))
    ax.add_patch(FancyBboxPatch((cx + 0.001, cy + 0.35), 0.30 if not live else 0.44, ch - 0.7,
                                boxstyle="round,pad=0.01,rounding_size=0.2",
                                fc=col, ec="none", alpha=1.0 if live else .45, zorder=6))

    # --- judul, keterangan, chip: ditumpuk dari hasil pengukuran ---
    tleft = cx + C["pad_l"]
    yy = cy + ch - C["top_pad"]
    for l in C["jl"]:
        ax.text(tleft, yy, l, ha="left", va="top", fontsize=C["fj"], fontweight="bold",
                color=col if tier == 3 else tx1, zorder=8)
        yy -= C["sj"]
    yy -= C["gap_jk"]
    for l in C["kl"]:
        ax.text(tleft, yy, l, ha="left", va="top", fontsize=C["fk"], color=tx2, zorder=8)
        yy -= C["sk"]

    if C["chip_rows"]:
        yy -= C["gap_kc"]
        for row in C["chip_rows"]:
            bx = tleft
            for k, w in row:
                ax.add_patch(FancyBboxPatch((bx, yy - C["chip_h"]), w, C["chip_h"],
                                            boxstyle="round,pad=0.02,rounding_size=0.3",
                                            fc=col, ec="none", alpha=.16 if live else .12, zorder=7))
                ax.text(bx + w / 2, yy - C["chip_h"] / 2, k, ha="center", va="center",
                        fontsize=C["fc"], fontweight="bold",
                        color=col if live else GREY_TX, zorder=8)
                bx += w + CHIP_GAP
            yy -= C["chip_h"] + CHIP_GAP

# ==================================== 7. KEPALA & KAKI
ax.text(LX, TITLE_Y, "KRONOLOGI PERKARA No. 119/G/2026/PTUN.JKT",
        ha="left", va="center", fontsize=TITLE_FS, fontweight="bold", color=INK)

# --- legenda: bungkus baris memakai lebar terukur, jarak baris dari tinggi teks ---
leg_h = tinggi_baris(LEG_FS)
tit_h = tinggi_baris(TITLE_FS, True)
MARK_R = max(0.42, leg_h * 0.42)
GAP_MARK = 2 * MARK_R + 0.55           # tepi kiri penanda -> awal teks
GAP_ITEM = 2.2                         # antar butir dalam satu baris
ROW_G = max(leg_h * 1.9, 1.7)          # antar baris legenda
AVAIL = XR - LX

baris, cur, curw = [], [], 0.0
for k, v in LEGEND:
    w = lebar(v, LEG_FS)
    item = GAP_MARK + w
    if cur and curw + item > AVAIL:
        baris.append(cur); cur, curw = [], 0.0
    cur.append((k, v, w)); curw += item + GAP_ITEM
if cur:
    baris.append(cur)

# ruang aman: di bawah judul, di atas chip tanggal baris pertama timeline
ROW0_TOP = 1.42 + tinggi_baris(12.5, True) / 2 + 0.8
ly = TITLE_Y - tit_h / 2 - 1.2 - leg_h / 2
if ly - (len(baris) - 1) * ROW_G - leg_h / 2 < ROW0_TOP:
    ROW_G = max(leg_h * 1.5, (ly - leg_h / 2 - ROW0_TOP) / max(len(baris) - 1, 1))

for row in baris:
    lx = LX
    for k, v, w in row:
        ax.add_patch(Circle((lx + MARK_R, ly), MARK_R, facecolor=PAL[k], edgecolor="none", zorder=6))
        ax.text(lx + GAP_MARK, ly, v, ha="left", va="center", fontsize=LEG_FS, color=INK)
        lx += GAP_MARK + w + GAP_ITEM
    ly -= ROW_G

periksa_tata_letak()

fig.savefig("timeline_kronologi_119G2026.png", dpi=140, facecolor=BG, bbox_inches="tight")
fig.savefig("timeline_kronologi_119G2026.pdf", facecolor=BG, bbox_inches="tight")   # vektor, untuk cetak
plt.show()