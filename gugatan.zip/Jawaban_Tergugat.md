Jawaban  Perkara  Tata  Usaha  Negara  Jakarta  Nomor  119/G/2026/PTUN.Jkt  Halaman  1 dari  30  KEMENTERIAN  KEUANGAN  REPUBLIK  INDONESIA
PERKARA  TATA  USAHA  NEGARA  NOMOR 119/G/2026/PTUN .JKT
PENGADILAN  TATA  USAHA  NEGARA  JAKARTA
JAWABAN TERGUGAT
Dalam  Perkara  Nomor  119/G/PTUN .JKT
Menteri Keuangan Republik Indonesia , beralamat di Gedung Djuanda I
Lantai 3 Kementeria n Keuangan, Jalan Dr. Wahidin Raya Nomor 1, Jakarta
Pusat, untuk selanjutnya disebut sebagai ................... ....................... ................
TERGUGAT
m e l a w a n
Ninin Sapto Hargiyanto , beralamat di Jalan Bedeng 10 Kampung
Rawakaong RT 002/RW 00, Grogol Limo, Depok, Provinsi Jawa Barat ,
untuk selanjutnya disebut sebagai........................ ........................................
PENGGUGAT
---------- 00000O00000 ----------
Jakarta , 20 Mei 2026
Yth. Majelis Haki m
Perkara  Tata Usaha Negara  Nomor 119/G/2065/PTUN .JKT
Pengadilan Tata Usaha Negara Jakarta
di Jakarta
Dengan  hormat,
Kami yang bertanda tangan di bawah ini, berdasarkan Surat Kuasa Khusus Nomor SKU -
24/MK.01/2026 tanggal 29 April 2026 , bertindak  untuk  dan atas nama  serta  mewakili
kepentingan Menteri Keuangan Republik Indonesia sebagai Tergugat dalam Perkara Nomor
119/G/2026/PTUN .JKT di Pengadilan Tata Usaha Negara Jakarta, dengan ini menyampaikan
Jawaban atas Gugatan Penggugat tanggal 7 Mei 2026 sebagai berikut:
I. PENDAHULUAN
1. Bahwa  sebelum  menyampaikan  Jawaban,  perlu  Tergugat  sampaikan  bahwa
sebagaimana  dinyatakan  oleh Penggugat  dalam  surat  gugatannya,  Objek  Sengketa
dalam perkara a quo adalah Keputusan Menteri Keuangan Republik Indonesia Nomor
199/MK/SJ.5/2025 tentang Pemberhentian dari Jabatan Fungsional Pranata Komputer
Mahir  dan Pemindahan  Pegawai  Negeri  Sipil  Antar  Unit  Jabatan  Pimpinan  Tinggi
Madya di Lingkungan Kementerian Keuangan Atas Nama Sdr. Ninin Sapto Hargiyanto
tertanggal 13 November 2025 (selanjutnya disebut “ KMK 199/2025 ”).
2. Bahwa dalam gugatannya, pada intinya Penggugat mendalilkan penerbitan KMK
199/2025 tidak sah karena:
a. Melanggar ketentuan Pasal 58 ayat (6) Undang -Undang Nomor 30 Tahun 2014
karena objek sengketa berlaku surut karena penerbitan objek sengketa diterbitkan
tanggal 13 November 2025 dan berlaku surut sejak tanggal 1 November 2025.
b. Mela nggar ketentuan Pasal 41 ayat (5) Peraturan Menteri Pendayagunaan Aparatur
Negara dan Birokrasi Negara Nomor 1 Tahun 2023 yang mengamanatkan
Jawaban  Perkara  Tata  Usaha  Negara  Jakarta  Nomor  119/G/2026/PTUN.Jkt  Halaman  2 dari  30  bahwa pejabat fungsional yang akan diberhentikan harus diperiksa terlebih
dahulu.
c. Melanggar Asas Kepastian Hukum se suai ketentuan Pasal 2 huruf a Undang -
Undang  Nomor  20 Tahun  2023  karena  Tergugat  menetapkan  Penggugat  “cakap
dan memenuhi  syarat”  setelah  tenggat  waktu  pemenuhan  syarat  pendidikan
tanggal  26 Mei 2025.
d. Melanggar Asas Non Diskriminatif sesuai ketentuan Pasal  2 huruf j Undang -
Undang Nomor 20 Tahun 2023 terkait dengan penerapan standar kualifikasi bidang
teknologi informasi yang tidak konsisten.
e. Melanggar Pasal 61 Peraturan Menteri Pendayagunaan Aparatur Negara dan
Birokrasi Negara Nomor 1 Tahun 2023 karena pen erapan Pasal 59 Peraturan
Menteri Pendayagunaan Aparatur Negara dan Birokrasi Negara Nomor 32
Tahun 2020 tanpa melakukan harmonisasi.
f. Melanggar  Asas  Kepastian  Hukum  sesuai  ketentuan  Pasal  2 huruf  a Undang -
Undang  Nomor  20 Tahun  2023  karena  dasar  hukum  subst antif  permberhentian
tidak  dicantumkan  dalam  Bagian  Mengingat  pada  Objek  Sengketa.
3. Bahwa  dapat  Tergugat  sampaikan,  KMK  199/2025  diterbitkan  oleh  Menteri
Keuangan selaku pejabat yang berwenang secara atributif, yang telah melalui proses
dan telah sesuai dengan ketentuan yang berlaku. Dengan demikian, penerbitan
KMK 199/2025 telah  memenuhi  unsur  keabsahan  formil  dan materil,  tidak  bersifat
sewenang -wenang, dan justru mencerminkan penerapan A sas-asas Umum
Pemerintahan yang Baik (“AUPB”) .
II. DALAM  POKOK  PERKARA
Bahwa Tergugat dengan sangat tegas menolak seluruh dalil -dalil Penggugat dalam
gugatannya, karena hal -hal tersebut hanyalah suatu pembelaan diri dari Penggugat
yang tidak berdasar  hukum , kecuali yang diakui secara tegas kebenarannya dan
Tergugat tidak akan menanggapi dalil -dalil Penggugat yang tidak terkait dengan
kewenangan dari Tergugat.
A. Kronologis
Bahwa sebelum Tergugat menanggapi dalil -dalil Penggugat , perlu kiranya
Tergugat jelaskan terlebih dahulu mengenai kronologis penerbitan KMK 199/2025
sebaga i berikut:
1. Bahwa Tergugat dalam menerbitkan KMK 199/2025 berpedoman pada
beberapa ketentuan diantaranya yakni Undang -Undang Nomor 20 Tahun 2023
tentang Aparatur Sipil Negara (UU No. 20/2023), Peraturan Pemerintah Nomor
11 Tahun 2017 tentang Manajemen Pegaw ai Negeri Sipil (PP No 11/2017),
Peraturan Menteri Pendayagunaan Aparatur Negara dan Reformasi Birokrasi
Nomor 1 Tahun 2023 tentang Jabatan Fungsional (Permenpan RB No. 1/2023),
Peraturan Menteri Keuangan Nomor 224/PMK.01/2020 tentang Manajemen
Karier di L ingkungan Kementerian Keuangan (PMK No. 224/2020), Keputusan
Menteri Keuangan Nomor 74/KMK.01/2012 tentang Penunjukkan Para Pejabat
di Lingkungan Kementerian Keuangan yang Diberi Kuasa Untuk dan Atas
Nama Menteri Keuangan Menandatangani Surat/Keputusan Mut asi
Kepegawaian dan Lain Sebagainya di Bidang Kepegawaian sebagaimana telah
diubah dengan Keputusan Menteri Keuangan Nomor 404/KMK.01/2013 (KMK
No. 404/2013)
2. Bahwa pada mulanya, Penggugat diangkat menjadi Jabatan Fungsional Pranata
Komp uter pada  Badan  Pend idikan  dan Pelatihan  Keuangan  (BPPK)
Kementerian  Keuangan melalui pengangkatan pertama kali berdasarkan
Jawaban  Perkara  Tata  Usaha  Negara  Jakarta  Nomor  119/G/2026/PTUN.Jkt  Halaman  3 dari  30  Keputusan Menteri Keuangan Nomor 1105/KM.1/UP.11/2009 tentang
Pengangkatan Pertama Dalam Jabatan Fungsional Pranata Komputer Para Pegawai
Negeri Sipil d i Lingkungan Departemen Keuangan tanggal 7 September 2009.
3. Bahwa pengangkatan pertama Penggugat menjadi  Jabatan Fungsional Pranata
Komputer didasarkan pada Keputusan Menteri Pendayagunaan Aparatur
Negara Nomor  66/KEP/M.PAN/7/2003  tentang  Jabatan  Fungsional  Pranata
Komp uter dan Angka Kreditnya (Kepmenpan 66/2003), dimana dalam ketentuan
Pasal 22 ayat (1) Kepmenpan 66/2003 telah menjelaskan:
”Pasal  22
(1) Persyaratan  untuk  dapat  diangkat  dalam  Jabatan  Fungsional  Pranata  Komputer
tingkat terampil adalah:
a. Berijazah  serendah -rendahnya  SLTA/D.1  sesuai  dengan  kualifikasi  yang
ditentukan;
b. Menduduki  pangkat  serendah -rendahnya  Pengatur  Muda,  golongan  ruang  II/a;
c. Lulus  pendidikan  dan pelatihan  fungsional  di bidang  teknologi  informasi,  kecuali
bagi yang memiliki Diploma bidang Teknologi Informasi; dan
d. Setiap  unsur  penilaian  pelaksanaan  pekerjaan  (DP3)  sekurang -kurangnya
bernilai baik dalam 1 (satu) tahun terakhir. ”
4. Bahwa  selanjutnya,  guna  menindaklanjuti  Kepmenpan  66/2003  yang
memperkuat standar kualifikasi pendidikan jabatan fungsional pranata
komputer, maka Badan Pusat Statistik (”BPS”) selaku Instansi Pembina Jabatan
Fungsional Pranata Komputer ( vide Pasal 2 ayat (2) Kepmenpan 66/2003)
kemudian menerbitan Keputusan Kepala Badan Pusat Statistik Nomor 290
Tahun 2004 te ntang Standar Kompetensi Jabatan Fungsional Pranata Komputer
(Kep. Bps No. 290/2004), dimana  dalam  Bab II Unsur  Kompetensi  angka  2.1
Unsur  Pendidikan  huruf  a angka  1 Kep. Bps No. 290/2004 menegaskan bahwa
pendidikan minimal yang dipersyaratkan menjadi Pran ata Komputer Tingkat
Terampil adalah SLTA/D -I.
5. Bahwa Kementerian Pendayagunaan Aparatur Negara dan Reformasi Birokrasi
kemudian menerbitkan Peraturan Menteri Pendayagunaan Aparatur Negara
dan Reformasi Birokasi Nomor 32 Tahun 2020 tentang Jabatan Fungsiona l
Pranata Komputer yang telah diundangkan pada tanggal 27 Mei 2020
(PermenpanRB No. 32/2020)  untuk  menggantikan  Kepmenpan  66/2003,
dimana  dalam  bagian  pertimbangan  salah  satunya  menjelaskan  ” bahwa
ketentuan  jabatan  fungsional  yang diatur   dalam   Keputusan   Menteri   Negara
Pendayagunaan   Aparatur Negara  Nomor  66/KEP/M.PAN/7/2003  tentang  Jabatan
Fungsional  Pranata  Komputer  dan Angka  Kreditnya,  sudah  tidak  sesuai  perkembangan
hukum  saat ini sehingga  perlu  diganti ”.
6. Bahwa latar belakang diterbitkannya Permenpan RB No. 32/2020 sebagai
aturan baru yang menggantikan Kepmenpan 66/2003 adalah sebagai berikut:
a. Bahwa untuk pengembangan karier dan peningkatan profesionalisme
Pegawai Negeri Sipil yang mempunyai ruang lingkup, tugas, tanggung
jawab, dan wewenang di bidang sistem teknologi informasi berbasis
komputer, serta untuk meningk atkan kinerja organisasi, perlu
menyesuaikan pengaturan mengenai jabatan fungsional pranata komputer
dan angka kreditnya.
b. Bahwa ketentuan jabatan fungsional yang diatur dalam Keputusan Menteri
Negara  Pendayagunaan  Aparatur  Negara  Nomor
Jawaban  Perkara  Tata  Usaha  Negara  Jakarta  Nomor  119/G/2026/PTUN.Jkt  Halaman  4 dari  30  66/KEP/M.PAN/7/2003  tentang Jabatan Fungsional Pranata Komputer
dan Angka Kreditnya, sudah tidak sesuai perkembangan hukum saat ini
sehingga perlu diganti.
7. Bahwa kemudian di dalam ketentuan Pasal  59 Permenpan RB 32/2020 telah
menegaskan dan menjelaskan sebagai berikut:
Pasal  59
(1) Pada  saat Peraturan  Menteri  ini berlaku:
a. Pranata Komputer Pelaksana Pemula, pangkat pengatur muda, golongan ruang
II/a; dan
b. Pranata  Komputer  Pelaksana,  pangkat  pengatur  muda  Tingkat  I, golongan  ruang
II/b;
diangkat dan melaksanakan kegiatan sebagai Pranata Komputer Terampil sebagaimana
tercantum  dalam  Lampiran  I yang  merupakan  bagian  tidak  terpisahkan  dari Peraturan
Menteri ini berdasarkan Peraturan Menteri ini.
(2) Pranata K omputer kategori terampil yang belum memperoleh ijazah minimal diploma
tiga, tetap melaksanakan tugas jabatan sesuai dengan jenjang jabatannya berdasarkan
Peraturan Menteri ini;
(3) Pranata  Komputer  sebagaimana  dimaksud  pada ayat (1) dan ayat (2) wajib  memperoleh
ijazah  minimal  diploma  tiga di bidang  teknomogi  informasi  paling  lama  5 (lima)  tahun
sejak Peraturan Menteri ini diundangkan.
(4) Pejabat Fungsional Pranata Komputer kategori keterampilan yang belum memperoleh
ijazah  minimal  diploma  tiga sampai  dengan  batas  waktu  sesuai  ketentuan  sebagaimana
dimaksud pada ayat (3), diberhentikan dari jabatan fungsionalnya.
8. Bahwa selanjutnya, Penggugat memperoleh kenaikan Jabatan Fungsional Pranata
Komputer dari Pemula/Terampil ke dalam Jabatan Fungsional Pranata Komputer
Mahir melalui Keputusan Menteri Keuangan Republik Indoensia Nomor
321.1/KM.1/UP.11/2022  tentang  Kenaikan  Jabatan  Fungsional  Pranata
Komputer di  Lingkungan  Kementerian  Keuangan  tanggal  30 Maret  2022.
9. Bahwa pada tanggal 14 April 2023, Penggugat memp eroleh Nota Pemberitahuan
Jabatan  Fungsional  Pranata  Komputer  Nomor  PEM -8/TPAK/2023  dari Pusat
Sistem Informasi dan Teknologi Keuangan Kementerian Keuangan selaku unit yang
membina  jabatan  fungsional  pranata  komputer  di Kementerian  Keuangan  yang
pada pokoknya menyampaikan perolehan angka kredit yang sudah diperoleh oleh
Penggugat dari bahan penilaian Semester 1 Tahun 2022 sampai dengan Semester 2
Tahun 2022, selain itu dalam nota pemberitahuan dimaksud terdapat catatan yang
menyebutkan bahwa Penggugat wajib memperoleh ijazah minimal diploma tiga
di bidang teknologi informasi sebelum 26 Mei 2025 .
10. Bahwa dapat Tergugat sampaikan, tujuan diterbitkannya Nota Pemberitahuan
adalah sebagai respons atas hasil penilaian yang belum memenuhi persyaratan
minimal angka kredit kumulatif untuk kenaikan pangkat atau kenaikan jabatan
yang ditandatangani oleh Ketua Tim Penilai dan disampaikan kepada pejabat
pengusul melalui Sekretariat Tim Penilai dan dikirimkan kepada pejabat
fungsional yang  bersangkutan  melalui  atasan  langsung  yang  kemudian  oleh
pejabat  fungsional yang menerima Nota Pemberitahuan diberikan kesempatan
untuk melengkapi kekurangan angka kredit atau memperbaiki dokumen bukti
fisik.
11. Bahwa selanjutnya, Sekretariat BPPK Kementerian Keuangan telah
mengi rimkan pemberitahuan  melalui  Nota  Dinas  Nomor  ND –
Jawaban  Perkara  Tata  Usaha  Negara  Jakarta  Nomor  119/G/2026/PTUN.Jkt  Halaman  5 dari  30  1684/PP.1/2023  tanggal  3 Mei 2023 kepada Kepala Pusat Pendidikan dan
Pelatihan Keuangan Umum sebagai unit tempat Penggugat bekerja yang pada
pokoknya menjelaskan bahwa Penggugat sebagai salah satu pegawai yang
memperoleh Nota Pemberitahuan yang disertai dengan adanya catatan Wajib
mem peroleh  ijazah  minimal  diploma  tiga di bidang teknologi informasi sebelum
26 Mei 2025 .
12. Bahwa guna melaksanakan ketentuan Pasal 2 ayat (2) Peraturan Menteri
Pendayagunaan Aparatur Negara dan Reformasi Birokrasi Nomor 38 Tahun
2017 tentang Standar Kompetensi  Jabatan Aparatur Sipil Negara, maka
kemudian diterbitkan Keputusan Menteri Pendayagunaan Aparatur Negara
Dan Reformasi Birokrasi Nomor SKJ.4 Tahun 2024 Tentang Standar Kompetensi
Jabatan Fungsional Pranata Komputer (KepMenpan RB SKJ.4/2024).
13. Bahwa di dalam Lampiran Kepmenpan RB SKJ.4/2024 mengenai Standar
Kompetensi Jabatan Fungsional Pranata Komputer Kategori Keterampilan
menegaskan bahwa untuk memenuhi persyaratan jabatan harus berupa
Diploma Tiga Bidang ilmu Teknologi Informasi dan kualifikasi pendi dikan
lainnya yang ditetapkan oleh instansi Pembina.
14. Bahwa Kementerian Keuangan kemudian membentuk  Badan Teknologi,
Informasi, dan Intelijen Keuangan  (BaTii) Kemenkeu berdasarkan ketentuan
Pasal 7 huruf l Peraturan Presiden Nomor 158 Tahun 2024 tentang Kementerian
Keuangan dan Peraturan Menteri Keuangan Nomor 124 Tahun 2024 tentang
Organisasi dan Tata Kerja Kementerian Keuangan ,
15. Bahwa dalam rangka pengisian Jabatan Fungsio nal Pranata Komput er di BaTii,
dilakukan pemindahan Penggugat dari BPPK ke BaTii berdasarkan Keputusan
Menteri Keuangan Nomor 117/MK/SJ.5/2025 tentang Pemindahan Para Pejabat
Fungsional Kategori Keterampilan di Lingkungan Kementerian Keuangan tanggal
19 Juni 2025.
16. Bahwa Kep utusan Menteri Keuangan Nomor 117/MK/SJ.5/2025 tentang
Pemindahan Para Pejabat Fungsional Kategori Keterampilan di Lingkungan
Kementerian Keuangan kemudian dikuatkan dengan adanya Keputusan Kepala
Badan  Teknologi,  Informasi,  dan Intelijen  Keuangan  Nomor  KEP – 2/TI/2025
tentang Mutasi Pejabat Fungsional di Lingkungan Badan Teknologi, Informasi, dan
Intelijen Keuangan yang diterbitkan tanggal 23 Juni 2025, dimana Penggugat adalah
salah  satu pegawai  yang  dimutasikan  dan ditempatkan  di Pusat  Data  dan
Informasi,  BaTii.
17. Bahwa selanjutnya, pada Triwulan III Tahun 2025 BaTii menyampaikan
Laporan Pemantauan dan Evaluasi Pembinaan Jabatan Fungsional Pranata
Komputer di Lingkungan Kementerian Keuangan Triwulan III Tahun 2025,
dimana melalui pemeriksaan latar belakang p endidikan, terdapat 4 pegawai
yang masih memiliki latar belakang pendidikan SLTA/sederajat sehingga
belum memenuhi ketentuan Permenpan RB 32/2020.
18. Bahwa Sekretaris BaTii melalui Nota Dinas Nomor ND -489/TI.1/2025 tanggal 29
September 2025 hal Permintaan Kon firmasi Status Jabatan Fungsional Pranata
Komputer kepada Kepala Pusat Data dan Informasi meminta konfirmasi terkait
dengan   status   administrasi   Penggugat,   utamanya   terkait   kepemilikan   ijazah
minimal Diploma III yang diakui sebagaimana ketentuan Pasa l 59 ayat (3)
Permenpan RB No. 32/2020. Dalam hal ternyata Penggugat belum memiliki ijazah
Diploma III, maka sesuai dengan ketentuan Pasal 59 ayat (4) Permenpan RB No.
32/2020,  Penggugat  akan  diberhentikan  dari jabatan  fungsional  pranata  komputer.
19. Bahwa ad apun dasar penerbitan Nota Dinas Nomor ND -489/TI.1/2025 tanggal 29
Jawaban  Perkara  Tata  Usaha  Negara  Jakarta  Nomor  119/G/2026/PTUN.Jkt  Halaman  6 dari  30  September 2025 adalah dalam rangka penataan kepegawaian dalam Jabatan
Fungsional  Pranata  Komputer  dan dalam  rangka  memastikan  ketertiban
administrasi kepegawaian  sehingga tertib administrasi .
20. Bahwa Kepala Pusat Data dan Informasi melalui Nota Dinas Nomor ND -
120/TI.5/2025 hal Penyampaian Usulan Pemberhentian dari Jabatan Fungsional
Pranata Komputer di Lingkungan Pusat Data dan Informasi tanggal 8 Oktober 2025
telah  menyampaikan bahwa berdasarkan penelitian terhadap data Pranata
Komputer di lingkungan Pusat Data dan Informasi diketahui jika Penggugat belum
memenuhi ketentuan Pasal 59 ayat (3) Permenpan RB No. 32/2020 sehingga
terhadap Penggugat diusulkan pemberhentia nnya dari Jabatan Fungsional Pranata
Komputer.
21. Bahwa Sekretaris BaTii melalui Nota Dinas Nomor ND – 684/TI.1/2025 tanggal
5 November  2025  hal Permohonan  Pemberhentian  dari Jabatan  Fungsional
Pranata Komputer  Keterampilan  dan Pemindahan  Pegawai  Negeri  Sipil  Antar
Unit  Jabatan Pimpinan Tinggi Madya di Lingkungan Kementerian Keuangan
kepada Biro Sumber Daya Manusia, Sekretariat Jenderal, Kementerian
Keuangan telah menyampaikan hal -hal sebagai berikut:
a. Berdasarkan Pasal 59 Permenpan RB 32/2020, bahwa Pranata Ko mputer
Kategori  Keterampilan  wajib  memperoleh  ijazah  minimal  diploma  tiga di
bidang teknologi informasi paling lama 5 (lima) tahun sejak Peraturan Menteri
ini diundangkan dan dapat diberhentikan dari jabatan fungsionalnya apabila
belum  memperoleh  ijazah  sampai  dengan  batas  waktu  sesuai  ketentuan.
b. Permenpan  RB 32/2020  mulai  diundangkan  pada  tanggal  27 Mei 2020,
sehingga telah berlaku 5 (lima) tahun sejak tanggal diundangkan dan
berdasarkan penelitian terhadap data Pranata Komputer di lingkungan Pusat
Data dan Informasi, diketahui bahwa Penggugat belum memenuhi ketentuan
Pasal  59 Permenpan  RB 32/2020  sehingga  terhadap  Penggugat  diusulkan
untuk dimutasi ke BPPK sebagai pelaksana.
22. Bahwa kemudian Penggugat diberhentikan dari Jabatan Fungsional Pranata
Komputer melalui Keputusan Menteri Keuangan Republik Indonesia Nomor
199/MK/SJ.5/2025 tentang Pemberhentian Dari Jabatan Fungsional Pranata
Komputer  Mahir  Dan Pemindahan  Pegawai  Negeri  Sipil  Antar  Unit  Jabatan
Pimpinan  Tinggi  Madya  Di Lingkungan  Kementerian  Keuangan  Atas  Nama  sdr.
Ninin Sapto Hargiyanto (NIP 19860720 200701 1 001) tanggal 13 November 2025.
23. Bahwa Penggugat selanjutnya menyampaikan keberatan atas penerbitan objek
sengketa kepada Tergugat melalui surat Nomor 1/Hargi/2025 tanggal 23 Desember
2025  yang selanjutnya, terhadap penerbitan objek sengketa telah diterbitkan
Keputusan  Menteri  Keuangan  Nomor  9/MK/SJ/2026  tentang  Penguatan
Keputusan Menteri Keuangan Nomor 199/MK/SJ.5/2025 Tentang Pemberhentian
Dari  Jabatan  Fungsional  Pranata  Komputer  Mahir  Dan Pemindahan  Pegawai
Negeri  Sipil  Antarunit  Jabatan  Pimpinan  Tinggi  Madya  Di Lingkungan
Kementerian Keuangan Atas Nama Sdr. Ninin Sapto Hargiyanto (NIP 19860720
200701 1 001) (“KMK No. 9/2026”).
24. Bahwa  penerbitan  KMK  No. 9/2026  telah  sesuai  dengan  ketentuan  Pasal  6 ayat
(1) Peraturan Pemerintah Nomor 79 Tahun 2021 tentang Upaya Administratif
dan Badan Pertimbangan Aparatur Sipil Negara (“PP 79/2021”) yang
menyatakan:
“PPK  dapat  memperkuat,  memperingan,  memperberat,  mengubah,  mencabut,  atau
membatalk an keputusan yang diajukan Keberatan.”
Jawaban  Perkara  Tata  Usaha  Negara  Jakarta  Nomor  119/G/2026/PTUN.Jkt  Halaman  7 dari  30  25. Bahwa selanjutnya, guna mengakomodir dan menindaklanjuti keputusan objek
sengketa, maka Tergugat kemudian menempatkan Penggugat sebagai
pelaksana pada Subbagian Analisis Data Pembelajaran, Bagian Manajemen
Pengetahuan , Komunikasi, dan Kerja Sama, Sekretariat Badan, BPPK,
Kementerian Keuangan.
26. Bahwa  berdasarkan  kronologis  yang  telah  Tergugat  sampaikan  dan jelaskan
diatas, maka penerbitan objek sengketa telah sesuai dengan ketentuan yang
berlaku.
B. Penerbitan  KMK  199/2025  Telah  Sesuai  Dengan  Ketentuan  Peraturan  Perundang -
undangan  Serta  Telah  Memenuhi  Asas -asas Umum  Pemerintahan  Yang  Baik  (AUPB)
Bahwa penerbitan KMK 199/2025 telah sesuai dengan ketentuan peraturan perundang -
undangan serta telah memenuhi AUPB, sehingga sah dan tidak dapat dibatalkan,
hal tersebut sebagaimana akan Tergugat uraikan dibawah ini:
1. KMK 199/2025 Telah Sesuai Dengan Ketentuan Peraturan Perundang -undangan
Yang Berlaku.
a. Bahwa  dalam  melakukan  pengujian  apakah  suatu  Keputusan  Tata  Usaha
Negara (TUN)  dapat dibatalkan  atau  tidak,  dapat  merujuk  pada  ketentuan
Pasal  66 ayat  (1) Undang -Undang  Nomor  30 Tahun  2014  tentang  Administrasi
Pemerintahan (UU 30/2014) yang menyatakan:
“Pasal  66
(1) Keputusan  hanya  dapat  dibatalkan  apabila  terdapat  cacat:
a. wewenang;
b. prosedur; dan/atau
c. substansi. ”
b. Bahwa apabila dilihat dari aspek wewenang, aspek prosedur maupun aspek
substansi, maka penerbitan KMK 199/2025 telah sesuai dengan ketentuan
peraturan perundang -undangan serta telah memenuhi AUPB sehingga tidak
dapat dibatalkan, sebagaimana dapat Tergugat jelaskan sebagai berikut:
1) Penerbitan  KMK  199/2025  Memenuhi  Aspek  Kewenangan
a. Bahwa ketentuan mengenai kewenangan pemberhentian dari jabatan
fungsional  pranata  komputer  telah  diatur  dalam  ketentuan  Permenpan
RB No. 1/2023 sebagai berikut:
Pasal  1
25. Pejabat yang Berwenang yang selanjutnya disingkat PyB adalah pejabat
yang mempunyai kewenangan melaksanakan proses pengangkatan,
pemindahan, dan pemberhentian Pegawai ASN sesuai dengan ketentuan
peraturan perundang -undangan.
26. Pejabat Pembina Kepegawaian yang selanjutnya disingkat PPK adalah
pejabat yang mempunyai kewenangan menetapkan pengangkatan,
pemindahan,  dan pemberhentian  Pegawai  ASN  dan pembinaan  Manajemen
ASN  di instansi  pemerintah  sesuai  dengan  ketentuan  peraturan  perundang -
undangan.
b. Bahwa  berdasarkan  ketentuan  tersebut  maka  Tergugat  selaku
Pejabat Pembina  Kepegawaian  pada  Instansi  Kementerian  Keuangan
memiliki  kewenangan dalam memberhentikan Aparatur Sipil Negara
(ASN) dari jabatan fungsional di lingkungan Kementerian Keuangan.
Jawaban  Perkara  Tata  Usaha  Negara  Jakarta  Nomor  119/G/2026/PTUN.Jkt  Halaman  8 dari  30  c. Bahwa berdasarkan ketentuan pasal 41 ayat (1) huruf f , Pasal 43 huruf b,
dan Pasal 45 Permenpan RB No. 1/2023 yang menyatakan:
Pasal  41
(1) Pejabat  Fungsional  diberhentikan  dari jabatannya  apabila:
f. Tidak  memenuhi  persyaratan  JF.
Pasal  43
Pejabat  Fungsional  yang  tidak  memenuhi  persyaratan  jabatan  sebagaimana
dimaksud dalam Pasal 41 ayat (1) huruf f apabila:
b. Tidak  memenuhi  standar  kompetensi  yang  ditentukan  pada JF yang  diduduki
Pasal  45
(1) Setiap  jenjang  JF memiliki  standar  kompetensi  yang  terdiri  atas:
a. Kompetensi  teknis;
b. Kompetensi  manajerial;  dan
c. Kompetensi  sosial  kultural.
(2) Penyusunan  standar  kompetensi  dilaksanakan  sesuai  dengan  ketentuan
peraturan perundang -undangan.
d. Bahwa guna memenuhi ketentuan Pasal 45 Permenpan RB No. 1/2023,
maka diterbitkanlah Kepmenpan RB SKJ.4/2024, dimana di dalam
Lampiran Kepmenpan RB SKJ.4/2024 mengenai Standar Kompetensi
Jabatan  Fungsional  Pranata  Komputer  Kategori  Keterampilan
menegaskan bahwa untuk memenuhi persyaratan jabatan harus berupa
Diploma  Tiga Bidang  ilmu  Teknologi  Informasi  dan kualifikasi
pendidikan  lainnya  yang  ditetapkan  oleh instansi  Pembina.
e. Bahwa sesuai dengan ketentuan Pasal 45 ayat (2) huruf f Peraturan
Menteri Keuangan Nomor 224/PMK.01/2020 tentang Manajemen Karier
di Lingkungan  Keme nterian  Keuangan  telah  menegaskan:
(2) PNS  diberhentikan  dari Jabatan  sebagaimana  dimaksud  pada ayat (1)
apabila:
f. Tidak  memenuhi  persyaratan  Jabatan.
f. Bahwa berdasarkan ketentuan -ketentuan tersebut maka Tergugat selaku
Pejabat Pembina Kepegawaian pada Instansi Kementerian Keuangan
berwenang melakukan pemberhentian dari Jabatan Fungsional
Pranata Komputer kepada Penggugat.
2) Penerbitan  KMK  199/2025  Memenuhi  Aspek  Prosedur
a. Bahwa sebagaimana telah Tergugat sampaikan pada bagian
kronologis penerbitan KMK 199/2025 tersebut di atas, telah terbukti
penerbitan objek  sengketa  dimaksud  telah  sesuai  dengan  prosedur
dalam  peraturan perundang -undangan.
b. Bahwa  perlu  Tergugat  sampaikan  kembali,  dalam  menerbitkan
KMK  199/2025  berpe doman  pada  beberapa  ketentuan  di antaranya
UU No  20/2023,  PP 94/2021,  PP No 11/2017,  Permenpan  RB 1/2023,
PMK No. 224/2020, dan KMK No. 404/2013.
c. Bahwa sebagaimana telah Tergugat sampaikan di atas, berdasarkan hasil
Laporan Pemantauan dan Evaluasi Pembinaan Jabatan Fungsional
Pranata  Komputer  di Lingkungan  Kementerian  Keuangan  Triwulan  III
Jawaban  Perkara  Tata  Usaha  Negara  Jakarta  Nomor  119/G/2026/PTUN.Jkt  Halaman  9 dari  30  Tahun 2025 oleh BaTii, Penggugat terbukti belum memenuhi
kualifikasi pendidikan persyaratan Jabatan Fungsional Pranata
Komputer sebagaimana disyaratkan dalam pasa l 41 ayat (1) huruf f dan
Pasal 45 Permenpan RB No. 1/2023.
d. Bahwa Sekretaris BaTii melalui Nota Dinas Nomor ND -489/TI.1/2025
tanggal 29 September 2025 hal Permintaan Konfirmasi Status Jabatan
Fungsional Pranata Komputer kepada Kepala Pusat Data dan Informasi
meminta konfirmasi terkait dengan status administrasi Penggugat,
utamanya terkait kepemilikan ijazah minimal Diploma III yang diakui
sebagaimana ketentuan Pasal 59 ayat (3) Permenpan RB No. 32/2020.
Dalam hal ternyata Penggugat belum memiliki ija zah Diploma III, maka
sesuai dengan ketentuan Pasal 59 ayat (4) Permenpan RB No. 32/2020,
Penggugat  akan  diberhentikan  dari jabatan  fungsional  pranata
komputer.
e. Bahwa  Kepala  Pusat  Data  dan Informasi  melalui  Nota  Dinas  Nomor
ND-120/TI.5/2025 hal Penyampaian  Usulan Pemberhentian dari Jabatan
Fungsional Pranata Komputer di Lingkungan Pusat Data dan Informasi
tanggal 8 Oktober 2025 telah menyampaikan bahwa berdasarkan
penelitian  terhadap  data  Pranata  Komputer  di lingkungan  Pusat  Data
dan Informasi  diketahui  jika Penggugat  belum  memenuhi  ketentuan
Pasal 59 ayat (3) Permenpan RB No. 32/2020 sehingga terhadap
Penggugat diusulkan pemberhentiannya dari Jabatan Fungsional Pranata
Komputer.
f. Bahwa selanjutnya, Penggugat secara informal melalui aplikasi whatsapp
pada tanggal 8 Oktober 2025 telah meminta agar dapat dipindahkan ke
BPPK karena dirinya mengetahui bahwa dirinya akan diberhentikan dari
jabatan fungsional pranata komputer dan dikembalikan dalam jabatan
struktural sebagai pelaksana.
g. Bahwa BaTii melalui Nota Di nas Nomor ND – 684/TI.1/2025 tanggal
5 November 2025 kepada Biro Sumber Daya Manusia, Sekretariat
Jenderal, Kementerian Keuangan telah menyampaikan yang pada
pokoknya bahwa Penggugat belum memenuhi ketentuan Pasal 59
Permenpan RB 32/2020 sehingga terhadap Penggugat diusulkan
untuk diberhentikan dari jabatan fungsional dan dimutasi sebagai
pelaksana di BPPK.
h. Bahwa Menteri Keuangan ( in casu Tergugat) selaku Pejabat Pembina
Kepegawaian Instansi Pusat dengan kewenangannya menetapkan
pemberhentian dari jabatan f ungsional pranata komputer dan
pemindahan pegawai bagi Sdr. Ninin Sapto Hargiyanto sebagaimana
dituangkan dalam KMK 199/2025.
i. Bahwa berdasarkan fakta -fakta hukum tersebut maka proses penerbitan
telah sesuai dengan prosedur yang diatur dalam ketentuan perat uran
perundang -undangan yang berlaku, dengan demikian penerbitan KMK
199/2025 telah memenuhi aspek prosedur .
3) Penerbitan  KMK  199/2025  Memenuhi  Aspek  Substansi
a. Bahwa sebagaimana telah Tergugat sampaikan sebelumnya, bahwa
secara  substansi  Penggugat  belum  memenuhi  kualifikasi  jabatan
fungsional  pranata  komputer  sampai  dengan  batas  waktu  yang
sudah ditetapkan berupa:
Jawaban  Perkara  Tata  Usaha  Negara  Jakarta  Nomor  119/G/2026/PTUN.Jkt  Halaman  10 dari  30  1) Pasal 59 ayat (2) s.d. ayat (4) Permenpan RB 32/2020 yang telah
menjelaskan sebagai berikut:
(2) Pranata Komputer kategori terampil yang belum memp eroleh ijazah
minimal  diploma  tiga, tetap  melaksanakan  tugas  jabatan  sesuai  dengan
jenjang jabatannya berdasarkan Peraturan Menteri ini;
(3) Pranata Komputer sebagaimana dimaksud pada ayat (1) dan ayat (2)
wajib memperoleh ijazah minimal diploma tiga di bidang teknomogi
informasi paling lama 5 (lima) tahun sejak Peraturan Menteri ini
diundangkan.
(4) Pejabat Fungsional Pranata Komputer kategori ket erampilan yang
belum memperoleh ijazah minimal diploma tiga sampai dengan batas
waktu sesuai ketentuan sebagaimana dimaksud pada ayat (3),
diberhentikan dari jabatan fungsionalnya.
2) Bahwa sejak Permenpan RB 32/2020 diundangkan, Unit Pembina
Internal  (UPI)  melalui  UND -144/IT/2020  tertanggal  6 Oktober
2020 telah  menyampaikan  undangan  kepada  unit-unit
kerja/SDM terkait untuk menghadiri sosialiasi sehubungan
dengan penerbitan Permenpan RB 32/2020 yang pelaksanaannya
dilakukan media daring  (zoom  meeting ) kepada  Pejabat
Kepegawaian  dan perwakilan Pranata  Komputer,  dikarenakan
pada  waktu  tersebut,  keadaan  tidak memungkinan untuk
dilaksanakan secara kehadiran fisik karena sedang dalam masa
covid -19.
3) Bahwa selanjutnya, melalui Nota Dinas Nomor ND –
1043/IT/2020 terta nggal 1 Desember 2020, UPI telah
melampirkan salinan resmi Permenpan RB 32/2020 kepada unit -
unit kerja terkait.
4) Bahwa Penggugat memperoleh Nota Pemberitahuan Jabatan
Fungsional Pranata Komputer Nomor PEM -8/TPAK/2023 dari
Pusat Sistem Informasi dan Teknolog i Keuangan Kementerian
Keuangan selaku unit yang membina jabatan fungsional pranata
komputer  di Kementerian  Keuangan  yang  telah  memberikan
catatan bahwa Penggugat Wajib memperoleh ijazah minimal
diploma tiga di bidang  teknologi  informasi  sebelum  26 Mei 2025 .
5) Bahwa Penggugat belum memenuhi kualifikasi jabatan
sebagaimana yang disyaratkan dalam Keputusan Menteri
Pendayagunaan Aparatur  Negara  Dan Reformasi  Birokrasi
Nomor  SKJ.4  Tahun  2024 Tentang  Standar  Kompetensi  Jabatan
Fungsional  Pranata  Komputer yang m enegaskan bahwa untuk
memenuhi persyaratan jabatan harus berupa Diploma Tiga
Bidang Ilmu Teknologi Informasi dan kualifikasi pendidikan
lainnya yang ditetapkan oleh instansi Pembina.
6) Bahwa guna menerapkan ketentuan Permenpan RB 32/2020, maka
selanjutnya, S ekretaris BaTii melalui Nota Dinas Nomor ND –
684/TI.1/2025 tanggal 5 November 2025 kepada Biro Sumber Daya
Manusia, Sekretariat Jenderal, Kementerian Keuangan telah
menyampaikan permohonan agar dapat diterbitkan suatu keputusan
untuk  memberhentikan  Penggugat  dari jabatan  fungsional  pranata
komputer  dan mengembalikan  kedudukan  Penggugat  sebagai
pelaksana.
Jawaban  Perkara  Tata  Usaha  Negara  Jakarta  Nomor  119/G/2026/PTUN.Jkt  Halaman  11 dari  30  7) Bahwa perlu Tergugat sampaikan, selain karena belum memenuhi
kualifikasi  persyaratan  pendidikan,  Penggugat  juga  telah
mengajukan permohonan untuk da pat dimutasi karena telah
mengetahui bahwa Penggugat akan diberhentikan dari jabatan
fungsional pranata komputer melalui pesan (aplikasi whatsapp ) pada
tanggal 8 Oktober 2025 dan objek sengketa yang diterima pada
tanggal 11 Desember 2025.
b. Bahwa berdasarkan  penjelasan tersebut maka jelas penerbitan KMK
199/2025 telah memenuhi aspek substansi dalam suatu Keputusan TUN.
2. Penerbitan  KMK  199/2025  Telah  Berdasarkan  Atas  Asas -asas Umum  Pemerintahan
Yang Baik (AUPB)
a. Bahwa dalam menerbitkan KMK 199/2025 Tergugat selain memperhatikan
prosedur peraturan perundang -undangan yang berlaku juga telah
memperhatikan  AUPB,  sehingga  penerbitan  KMK  199/2025  telah  sesuai
dengan AUPB sebagaimana dapat Tergugat uraikan sebagai berikut:
1) Asas  Kepastian  Hukum
a) Bahwa penerbitan KMK 199/2025 telah sesuai dengan Asas Kepastian
Hukum, yang berdasarkan atas ketentuan Pasal 59 ayat (3) dan ayat (4)
Permenpan RB No 32/2020 jo. Pasal 41 ayat (1) huruf f dan Pasal 43 huruf
b Permenpan  RB No. 1/2023  jo. Lampiran  Kepmenpan  RB SKJ.4/2024 .
b) Bahwa  apabila Tergugat tidak menerbitkan KMK 199/2025 atas
pelanggaran  yang  telah  dilakukan  oleh  Penggugat,  maka  justru
Tergugat sebagai Pejabat Pembina Kepegawaian Instansi Pusat telah
mengabaikan asas kepastian hukum.
2) Asas  Tidak  Menyalahgunakan  Wewenang
a) Bahwa  Asas Tidak Menyalahgunakan Wewenang, adalah asas yang
mewajibkan setiap Badan dan/atau Pejabat Pemerintahan tidak
menggunakan kewenangannya untuk kepentingan pribadi atau
kepentingan yang lain dan tidak sesuai dengan tujuan pemberian
kewenangan tersebut, tidak melampaui, tidak menyalahgunakan,
dan/atau tidak mencampuradukkan kewenangan.
b) Bahwa sebagaimana telah dijelaskan pada bagian kronologis penerbitan
KMK 199/2025 penerbitannya telah melalui serangkaian prosedur dan
pemeriksaan sesuai dengan kewenangan yang dimiliki oleh Pejabat
berwenang.
3) Asas  Ketidakberpihakan
a) Bahwa Asas Ketidakberpihakan, adalah asas yang mewajibkan Badan
dan/atau Pejabat Pemerintahan dalam menetapkan dan/atau
melakukan Kep utusan dan/atau Tindakan dengan
mempertimbangkan kepentingan p ara pihak secara keseluruhan dan
tidak diskriminatif.
b) Bagaimana Tergugat dalam menerbitkan KMK 199/2025 selalu
berpedoman pada peraturan yang ada. Tergugat juga telah
melakukan seluruh rangkaian kegiatan didasari pada ketentuan
peraturan perundang -undangan  yang bersifat umum.
c) Bahwa penerbitan  KMK 199/2025, telah melalui pengumpulan
informasi, penelusuran bukti,  dan pencarian data/informasi melalui
permintaan keterangan kepada pihak -pihak terkait.
Jawaban  Perkara  Tata  Usaha  Negara  Jakarta  Nomor  119/G/2026/PTUN.Jkt  Halaman  12 dari  30  d) Berdasarkan fakta -fakta dimaksud, maka terbukti seluruh Tindakan
Tergugat dalam rangka penerbitan KMK 199/2025 telah sesuai
dengan Asas ketidakberpihakkan.
4) Asas  Proporsionalitas
a) Bahwa sebelum diterbitkannya KMK 199/2025, Tergugat telah
melakukan serangkaian prosedur yang telah sesuai terkait dengan
penelitian l atar belakang pendidikan pegawai yang menduduki
jabatan fungsional pranata komputer pada unit BaTii dan ditemukan
sejumlah pegawai yang belum memenuhi ketentuan dari Permenpan
RB No.32/2020  sebagai  aturan  yang  mengatur  mengenai  jabatan
fungsional pranata komputer, dimana salah satunya adalah
Penggugat.
b) Bahwa dengan menjunjung tinggi asas proporsionalitas, Penggugat
sebelumnya telah diberitahukan melalui sosialisasi -sosialisasi terkait
dengan diterbitkannya aturan yang secara spesifik mengatur mengenai
jabatan fungsional pranata komputer yaitu Permenpan RB No. 32/2020
dan adanya Nota Pemberitahuan pada tahun 2023 yang menyampaikan
bahwa  Penggugat  diwajibkan  untuk  memiliki  ijazah  Diploma  III di
bidang Teknologi Informasi sebelum tanggal 26 Mei 2025.
c) Dengan de mikian, penerbitan KMK 199/2025 telah sesuai dengan
asas proporsionalitas  karena  telah  memperhatikan  keseimbangan
antara  hak dan kewajiban ASN dalam penerbitan suatu keputusan
TUN.
5) Asas  Keadilan
a) Bahwa berdasarkan penjelasan Pasal 2 huruf l UU 20/2023 Yang
dimaksud dengan asas keadilan dan kesetaraan adalah pengaturan
penyelenggaraan Manajemen ASN mencerminkan rasa keadilan dan
kesempatan yang sama dalam fungsi dan peran sebagai Pegawai
ASN.
b) Bahwa penerbitan KMK 199/2025 jelas telah memperhatikan asas
keadil an dan kesetaraan, bahwa apabila terhadap pelanggaran
disiplin yang telah dilakukan oleh Penggugat namun tidak
ditindaklanjuti dengan pembebasan dari jabatan fungsional pranata
komputer maka justru  Tergugat  telah  menciderai  asas keadilan  dan
kesetaraan  terhadap ASN lain yang tidak melakukan pelanggaran
disiplin.
6) Asas  Kemanfaatan
a) Bahwa  asas  kemanfaatan  merupakan  hal yang  harus  diperhatikan
secara seimbang antara kepentingan individu yang satu dengan
kepentingan individu yang lain; kepentingan individu dengan
masyarakat; kepentingan Warga Masyarakat dan masyarakat asing;
serta kepentingan kelompok masyarakat yang satu dengan yang lain.
b) Bahwa  dengan  tidak  dipenuhinya  persyaratan  kualifikasi  pendidikan
yang  dibutuhkan  dalam  menduduki  jabatan  fungsional  pranata
komputer sebagaimana ketentuan yang mengatur yang dilakukan oleh
Penggugat  yang  apabila  tidak  dijatuhi  dengan  pemberhentian  dari
jabatan fungsional pranata komputer sebagaimana KMK 199/2025 justru
akan  bertentangan  dengan  asas kemanfaatan,  karena  Tergugat  tidak
memperhatikan kepentingan ASN lain yang telah disiplin dalam
Jawaban  Perkara  Tata  Usaha  Negara  Jakarta  Nomor  119/G/2026/PTUN.Jkt  Halaman  13 dari  30  menjalankan  ketentuan  Pasal  49 ayat  (3) dan ayat  (4) Permenpan  RB
No 32/2020  jo. Pasal  41 ayat  (1) huruf  f dan Pasal  43 huruf  b Permenpan
RB No. 1/2023 jo. Lampiran Kepmenpan RB SKJ.4/2024 yang telah
dilanggar oleh Penggugat.
c) Bahwa selain itu dapat Tergugat sampaikan, bahwa Penggugat
sebagai ASN yang bekerja dan menerima gaji dari pajak yang telah
dibayarkan oleh masyarakat berkewajiban untuk b ekerja dan menaati
peraturan, bahwa  apabila  Tergugat  tidak  mengenakan
pemberhentian  dari jabatan fungsional pranata komputer kepada
Penggugat atas perbuatan pelanggaran disiplin yang dilakukannya,
maka Tergugat telah menciderai kepercayaan masyarakat denga n
tidak memperhatikan keseimbangan antara kepentingan individu
(dhi Penggugat) dengan kepentingan masyarakat luas, sehingga
Tergugat dapat dikatakan melanggar asas kemanfaatan.
7) Asas  Kecermatan
Bahwa  penerbitan  KMK  199/2025  telah  melalui  proses  yang  sesuai
dengan peraturan perundang -undangan dan Tergugat secara nyata telah
menerbitkan  Objek  Sengketa  dengan  penuh  kecermatan  dan kehati -hatian
di mana sebelum diterbitkannya KMK 199/2025, terlebih dahulu telah
dilakukan pengumpulan bukti -bukti dan dokumen -dokume n terkait
sebelum menerbitkan KMK 199/2025..
b. Bahwa berdasarkan hal -hal tersebut di atas, secara nyata bahwa penerbitan
Objek Sengketa telah sesuai dan berdasarkan atas AUPB sehingga tidak
terdapat alasan untuk menyatakan batal KMK 199/2025.
C. Tanggapan  Atas  Dalil -Dalil  Penggugat
1. Terhadap  Dalil  Penggugat  Yang  Menyatakan  Bahwa  Melanggar  Ketentuan  Pasal
58 ayat (6) Undang -Undang Nomor 30 Tahun 2014 Karena Objek Sengketa
Berlaku Surut Karena Penerbitan Objek Sengketa Diterbitkan Tanggal 13
November 2025 Dan Berlaku Surut Sejak Tanggal 1 November 2025.
a. Bahwa  Tergugat  dengan  tegas  menolak  dalil  Penggugat  pada  angka  1 halaman
7 s.d. 9 yang pada pokoknya menyatakan bahwa objek sengketa telah
diberlakukan  surut  kepada  Penggugat,  sehingga  Tergugat  melanggar
ketentu an Pasal 58 ayat (6) Undang -Undang Nomor 30 Tahun 2014 tentang
Administrasi Pemerintahan (“ UU AP ”).
b. Bahwa sebelum Tergugat membantah dalil Penggugat, dapat Tergugat
sampaikan ketentuan Pasal 58 ayat (6) UU AP:
(6) ”Keputusan  tidak  dapat  berlaku  surut,  kecuali  untuk  menghindari  kerugian  yang
lebih besar dan/atau terabaikannya hak Warga Masyarakat”
c. Bahwa Dalil Penggugat yang menyatakan bahwa penerbitan Objek
Sengketa melanggar ketentuan Pasal 58 ayat (6) UU AP karena dianggap
berlaku surut adalah dalil ya ng tidak berdasar hukum dan keliru dalam
memahami makna keberlakuan keputusan tata usaha negara. Ketentuan
Pasal 58 ayat (6) UU AP pada pokoknya melarang keputusan berlaku surut
apabila merugikan warga masyarakat, kecuali ditentukan lain oleh
peraturan per undang -undangan. Namun  demikian,  penetapan  tanggal
mulai  berlakunya  suatu  keputusan  administratif  tidak  serta  merta  dapat
dikualifikasikan  sebagai  “berlaku  surut” yang dilarang oleh undang -
undang.
Jawaban  Perkara  Tata  Usaha  Negara  Jakarta  Nomor  119/G/2026/PTUN.Jkt  Halaman  14 dari  30  d. Bahwa  Objek  Sengketa  yang  diterbitkan  pada  tanggal  13 November  2025
dengan penetapan berlaku efektif sejak tanggal 1 November 2025 semata -mata
merupakan penetapan tanggal administratif ( administrative effective date ) yang
berkaitan dengan penyesuaian status kepegawaian dan tertib administrasi
kepegawaian, buk an pemberlakuan surut terhadap hak atau kewajiban baru
yang  menimbulkan  kerugian  hukum  secara  retroaktif.
e. Bahwa  terkait  dengan  dalil  Penggugat  yang  menggunakan  perbandingan
dengan Keputusan Menteri Keuangan Nomor 188/MK/SJ.5/2025 tanggal 23
Oktober 2025 ya ng memberhentikan Sdr. Riyanto Sihaloho dan Sdr. Agus
Riyanto dari Jabatan Pranata Komputer dengan mendasarkan bahwa tidak
memenuhi kualifikasi pendidikan namun ditetapkan berlaku tanggal 1
November  2025,  dapat  Tergugat  sampaikan  penjelasan  sebagai  berikut:
1) Bahwa Sekretaris BaTii melalui Nota Dinas Nomor ND – 489/TI.1/2025
tanggal 29 September 2025, menyampaikan permohonan konfirmasi
kepada  Kepala  Pusat  Data  dan Informasi  terkait  dengan  adanya  salah
satu pegawai di lingkungan Pusat Data dan Informasi  atas nama
Penggugat yang  belum  memenuhi  ketentuan  Pasal  59 ayat  (3)
Permenpan  RB Nomor 32/2020 yaitu kepemilikan ijazah minimal D III
yang diakui dan apabila belum  terdapat  ijazah  sebagaimana  yang
dipersyaratkan,  maka  Sekretaris BaTii  meminta  usulan  pemberhentian
Penggugat  dari Jabatan  Fungsional Pranata Komputer.
2) Bahwa selanjutnya, guna menindaklanjuti Nota Dinas dimaksud, maka
Kepala Pusat Data dan Informasi melalui Nota Dinas Nomor ND –
120/TI.5/2025 tanggal 8 Oktober 2025 menyampaikan yang pada
pokoknya bahwa berdasarkan data yang dimiliki ditemukan fakta
bahwa Penggugat belum memenuhi ketentuan Pasal 59 ayat (3)
Permenpan RB Nomor 32/2020, sehingga kepada yang bersangkutan
diusulkan untuk dapat  diterbtkan  Surat  Keputusan  Pemberhentian  dari
Jabatan  Fungsional Pranata Komputer sesuai ketentuan Pasal 59 ayat
(4) Permenpan RB Nomor 1/2020.
3) Bahwa melalui aplikasi pesan whatsapp , Penggugat secara informal
mengirimkan pesan kepada salah satu staf pada BPPK tertanggal 8
Oktober  2025  yang  menginformasikan  bahwa  Penggugat  mengetahui
jika Penggugat akan diberhentikan dari jabatan fungsional pranata
komputer dan meminta agar Penggugat dapat dimutasikan ke BPPK
selaku instansi awal Penggugat sebelum dimutasikan ke BaTii.
4) Bahwa selanjutnya, dalam proses pengurus an dan penerbitan objek
sengketa, Penggugat kembali menyampaikan secara informal melalui
pesan singkat aplikasi whatsapp kepada salah satu staf di BaTii pada
tanggal 10 November 2025 yang pokoknya menyampaikan bahwa
Penggugat memohon untuk dapat dimutasi k e salah satu unit di
Kementerian Keuangan yaitu Direktorat Jenderal Anggaran (”DJA)”)
dan meminta agar Surat Keputusan yang awalnya akan ditempatkan di
BPPK dapat dirubah ke DJA. Namun demikian, tidak ada informasi
lebih lanjut dari Penggugat dan Penggugat  akhirnya tetap dimutasi ke
BPPK sebagaimana keinginan Penggugat sejak awal dan setelah BaTii
melakukan konfirmasi kepada DJA ditemukan fakta bahwa tidak
pernah terdapat tawaran untuk perpindahan dari BaTii ke DJA.
f. Bahwa tindakan Tergugat sama sekali bukan  penerapan retroaktif yang
sewenang -wenang, melainkan bentuk kebijakan afirmatif/diskresi
pelindungan finansial .
Jawaban  Perkara  Tata  Usaha  Negara  Jakarta  Nomor  119/G/2026/PTUN.Jkt  Halaman  15 dari  30  g. Bahwa penerbitan Objek Sengketa tidak dapat dikualifikasikan sebagai
keputusan tata usaha negara yang berlaku surut (retroaktif), melainkan
merupakan penegasan status administratif kepegawaian berdasarkan
kondisi faktual dan hasil evaluasi administrati  yang  telah  ada sebelumnya,
yaitu  tidak terpenuhinya persyaratan jabatan fungsional sesuai ketentuan
peraturan perundang -undangan. Dengan demikian,  tanggal 1 November
2025 merupakan tanggal efektif administratif atas status yang secara hukum
dan faktual telah terjadi, sehingga tidak dapat dimaknai sebagai
pemberlakuan surut yang bertentangan dengan Pasal 58 ayat (6) UU AP.
h. Bahwa esensi larangan retro aktif sebagaimana dimaksud dalam Pasal 58 ayat
(6) UU AP  adalah larangan bagi Badan dan/atau Pejabat Pemerintahan untuk
menetapkan keputusan yang menciptakan akibat hukum baru terhadap
keadaan hukum yang telah selesai pada masa lampau.  Sedangkan dalam
perk ara a quo , Objek Sengketa diterbitkan sebagai tindak lanjut administratif
atas fakta objektif bahwa Penggugat tidak memenuhi persyaratan kualifikasi
pendidikan Jabatan Fungsional Pranata Komputer sampai batas waktu yang
telah ditentukan berdasarkan ketentuan peraturan perundang -undangan .
i. Bahwa pencantuman tanggal efektif administratif yang berbeda dengan
tanggal penandatanganan keputusan tidak otomatis menjadikan keputusan
tersebut bersifat retroaktif.  Dalam praktik administrasi kepegawaian,
penetapa n tanggal efektif administratif lazim dilakukan untuk:
1) penyesuaian administrasi kepegawaian;
2) tertib pembinaan ASN;
3) sinkronisasi data kepegawaian;
4) serta penyesuaian hak administratif dan jabatan.
Hal tersebut tidak dapat dimaknai sebagai pemberlakuan surut yang dilarang
sepanjang:
1) Tidak menghilangkan hak -hak yang telah sah diperoleh sebelumnya secara
melawan hukum;
2) Tidak menimbulkan sanksi terhadap perbuatan masa lampau;  dan
3) Tidak menimbulkan kerugian hukum yang bertentangan dengan asas
kepastian hukum.
j. Bahw a apabila pejabat yang tidak memenuhi persyaratan jabatan tetap
dipertahankan dalam jabatan fungsional, justru akan bertentangan dengan
prinsip sistem merit dan asas kepastian hukum dalam penyelenggaraan
manajemen ASN.
k. Bahwa dasar tuntu tan untuk melakukan pengembalian didasarkan pada
Peraturan Menteri Keuangan Nomor 218 Tahun 2017 tentang Tata Cara
Tunjangan Ganti Kerugian Negara Terhadap Pegawai Negeri Bukan
Bendahara Di Lingkungan Kementerian Keuangan jo. Peraturan
Pemerintah Nomor 38 Tahun 2016 tentang T ata Cara Tuntutan Ganti
Kerugian Negara/ Daerah Terhadap Pegawai Negeri Bukan· Bendahara
atau Pejabat Lain.
l. Bahwa jeda waktu penetapan Objek Sengketa menjadi 13 November 2025 sama
sekali  bukan  kelalaian  administratif  Tergugat.  Waktu  tersebut  digunakan
oleh  internal Tergugat untuk melakukan koordinasi secara intensif guna
mengembalikan Penggugat ke BPPK agar kelas jabatannya terselamatkan
di Grade  8 yang  apabila  diputuskan  bahwa  Penggugat  tetap  ditempatkan  di
Jawaban  Perkara  Tata  Usaha  Negara  Jakarta  Nomor  119/G/2026/PTUN.Jkt  Halaman  16 dari  30  BaTii, akan dikhawatirkan kelas jabatan Penggugat akan turun secara
signifikan karena  BaTii  adalah  organisasi  baru  dan Penggugat  (termasuk
semua  pegawai) tidak memiliki sejarah pekerjaan di unit baru. Hal tersebut
juga berlaku dengan pegawai yang berasal d ari DJA, jika ditempatkan di
BaTii, Penggugat akan diberikan grading terendah di kelas jabatan sesuai
dengan pendidikan yaitu Grade 6 (pendidikan SMA), akan tetapi jika
ditempatkan di unit asal, Penggugat bisa jadi diberikan grading yang lebih
tinggi dari itu karena memiliki  histori  jabatan.  Penggugat  memutarbalikkan
fakta  untuk  menyerang kebijakan yang secara nyata menyelamatkan status
finansialnya.
m. Bahwa berdasarkan hal -hal tersebut diatas, maka dalil Penggugat yang
menyatakan bahwa objek sengketa telah d iberlakukan surut kepada
Penggugat, sehingga Tergugat melanggar ketentuan Pasal 58 ayat (6) UU
AP sudah sepatutnya ditolak.
2. Terhadap  Dalil  Penggugat  Yang  Menyatakan  Bahwa  Penerbitan  Objek  Sengketa
Melanggar Ketentuan Pasal 41 Ayat (5) Permenpan RB Nomor 1/2023 Yang
Mengamanatkan Bahwa Pejabat Fungsional Yang Akan Diberhentikan Harus
Diperiksa Terlebih Dahulu.
a. Bahwa  Tergugat  dengan  tegas  menolak  dalil  Penggugat  pada  angka  2
halaman 9 s.d. 11 yang pada pokoknya menyatakan bahwa penerbitan
Objek Sengketa tel ah melanggar ketentuan Pasal 41 ayat (5) Permenpan RB
No. 1/2023 yang mengamanatkan bahwa pejabat fungsional yang akan
diberhentikan harus diperiksa terlebih dahulu.
b. Bahwa  ketentuan  Pasal  41 ayat  (5) Permenpan  RB No. 1/2023  masih
memiliki korelasi dengan ketentuan Pasal 43 huruf b Permenpan RB No.
1/2023 yang menegaskan:
“Pejabat  Fungsional  yang  tidak  memenuhi  persyaratan  jabatan
sebagaimana dimaksud dalam Pasal 41 ayat (1) huruf f apabila:
b. tidak  memenuhi  standar  kompetensi  yang  ditentukan  pada JF yang  diduduki. ”
c. Bahwa terkait dengan standar kompetensi yang ditentukan sebagaimana
ditegaskan  dalam  Pasal  43 huruf  b Permenpan  RB No. 1/2023  telah
ditegaskan dalam ketentuan Pasal 59 ayat (3) Permenpan RB No. 32/2020
yang menyatakan:
(3) “Pranata Komputer sebagaimana dimaksud pada ayat (1) dan ayat (2) wajib
memperoleh  ijazah  minimal  diploma  tiga di bidang  teknologi  informasi  paling  lama
5 (lima) tahun sejak Peraturan Menteri ini diundangkan. ”
d. Bahwa ketentuan Pasal 59 ayat (3) Permenpan RB No. 32/2020 masih tetap
diberlakukan walaupun terdapat aturan baru yang diterbitkan yaitu
Permenpan RB No. 1/2023 karena Permenpan RB No. 1/2023 tidak menghapus
ketentuan mengenai syarat kualifikasi pendidikan  jabatan pranata
komputer sebagaimana yang ditegaskan dalam Pasal 59 ayat (3) Permenpan
RB No. 32/2020.
e. Bahwa  sesuai  dengan  ketentuan  Pasal  62 huruf  b angka  169 Permenpan  RB
No. 1/2023 yang menyatakan:
“Pada saat  Peraturan Menteri  ini berlaku:
b. Ketentuan mengenai unsur dan sub unsur kegiatan, butir kegiatan dan angka
kreditnya, hasil kerja, penilai kinerja, penilaian Angka Kredit, pejabat pengusul
Angka Kredit, pejabat penetap Angka Kredit, tim penilai Angka Kredit, Angka
Jawaban  Perkara  Tata  Usaha  Negara  Jakarta  Nomor  119/G/2026/PTUN.Jkt  Halaman  17 dari  30  Kredit pemeliharaan, uns ur penunjang, unsur pengembangan profesi,
pengangkatan dalam JF, kenaikan pangkat, dan kenaikan jenjang JF dalam:
169. Peraturan Menteri Pendayagunaan Aparatur Negara dan Reformasi
Birokrasi Nomor 32 Tahun 2020 tentang Jabatan Fungsional Pranata
Komputer (Berita Negara Republik Indonesia Tahun 2020 Nomor 527);
dicabut  dan dinyatakan  tidak  berlaku.
f. Bahwa penegasan mengenai syarat kualifikasi pendidikan terkait jabatan
fungsional  pranata  komputer  dinyatakan  kembali  dalam  Lampiran
Keputusan Menteri Pendayagunaan Aparatur Negara dan Reformasi
Birokrasi Republik Indonesia Nomor SKJ.4 Tahun 2024 tentang Standar
Kompetensi Jabatan Fungsional Pranata Komputer (“SKJ.4/2024”) yang
menyatakan bahwa Penggugat yang memiliki jabatan Pranata Ko mputer
Mahir dalam Jabatan Fungsional Keterampilan harus memiliki pendidikan
minimal diploma tiga di bidang teknologi informasi dan kualifikasi
pendidikan lainnya yang ditetapkan oleh instansi Pembina.
g. Bahwa selain itu, dalil Penggugat yang menyatakan bahw a tidak pernah
dilakukan pemeriksaan terhadap yang bersangkutan sebelum
diterbitkannya keputusan  administrasi  adalah  tidak  tepat  dan tidak  relevan
apabila  dikaitkan dengan karakter objek keputusan yang diterbitkan.
h. Bahwa objek keputusan dimaksud diterbitka n berdasarkan hasil verifikasi
administratif terhadap pemenuhan syarat jabatan sebagaimana diatur
dalam Permenpan  RB No. 32/2020.  Dalam  proses  tersebut,  Tergugat
terlebih  dahulu melakukan klarifikasi dan konfirmasi kepada unit kerja asal
pegawai melalui Nota Dinas Nomor ND -489/TI.1/2025 tanggal 29 September
2025 terkait status pendidikan pegawai Pranata Komputer kategori
keterampilan.
i. Selanjutnya, Kepala Pusat Data dan Informasi memberikan jawaban resmi
melalui Nota Dinas Nomor ND -120/TI.5/2025 tanggal 8 Oktober 2025 yang
pada pokoknya  menerangkan  bahwa  pegawai  yang bersangkutan  belum
memenuhi  persyaratan  pendidikan  minimal  Diploma  Tiga  (D-III)
sebagaimana diwajibkan dalam ketentuan Pasal 59 Permenpan RB No.
32/2020.
j. Bahwa dalil Tergugat dapat dikuatkan de ngan adanya ND – 472/PP.7/2025
tanggal  16 Mei 2023  yang  meminta  agar  dapat  diterbitkan  Surat  Tugas
Belajar Mandiri bagi Penggugat karena Penggugat baru akan melanjutkan
studi belajarnya dan penerbitan Surat Tugas Belajar Mandiri Tidak
Diberhentikan Nomor ST – 497/PP.1/2025 yang dikeluarkan oleh Sekretariat
BPPK tanggal 10 Juni 2025,  serta  adanya  laporan  dari Penggugat  yang
menyampaikan  Laporan Perkembangan Studi Tugas Belajar Mandiri
tanggal 10 Maret 2026.
k. Bahwa dengan demikian, tindakan administrasi  yang dilakukan Tergugat
didasarkan pada data dan hasil penelitian administratif dari unit kerja yang
berwenang terhadap status kepegawaian dan kualifikasi pendidikan
Penggugat, bukan berdasarkan asumsi atau tindakan sepihak.
l. Bahwa selain itu, perlu dipaha mi bahwa pemeriksaan dalam konteks
pelanggaran disiplin pegawai berbeda dengan verifikasi administratif atas
pemenuhan syarat jabatan. Objek sengketa a quo bukan merupakan
hukuman disiplin, melainkan tindak lanjut administratif akibat tidak
terpenuhinya pe rsyaratan normatif jabatan fungsional sebagaimana
Jawaban  Perkara  Tata  Usaha  Negara  Jakarta  Nomor  119/G/2026/PTUN.Jkt  Halaman  18 dari  30  ditentukan oleh peraturan perundang -undangan.
m. Bahwa mekanisme pemeriksaan atau penilaian sebagaimana ketentuan
Pasal 43 huruf b Permenpan RB No. 1/2023 adalah mengenai Standar
kompetensi mencakup kompetensi  teknis, manajerial, dan sosial kultural
sesuai dengan jenjang  jabatannya  yang  aturannya  telah  ditetapkan
berdasarkan  SKJ.4/2024.
n. Bahwa oleh karena itu, dalil Penggugat yang menyatakan tidak adanya
pemeriksaan tidak serta -merta membuktikan adanya cacat prosedur, sebab
proses yang dilakukan Tergugat telah melalui tahapan klarifikasi
administratif, penelitian data, dan konfirmasi kepad a unit kerja terkait
sebelum keputusan diterbitkan.
o. Bahwa dalil Penggugat yang menggunakan KMK Nomor 117/MK/SJ.5/2025
tanggal    19   Juni   2025    dan   Keputusan    Kepala    BaTii
Nomor KEP -2/TI/2025 tanggal 23 Juni 2025 sebagai legitimasi kompetensi
adala h keliru.  Surat  Keputusan  tersebut  murni  merupakan  produk
administrasi mutasi kelembagaan (bedol desa) akibat reorganisasi eks -Pusintek
dan unit IT terdampak ke dalam BaTii. Pemindahan struktural massal ini sama
sekali tidak menghapuskan, menunda, atau mem utihkan kewajiban mutlak
pemenuhan  kualifikasi  pendidikan  strata  Diploma  III.
p. Bahwa berdasarkan hal -hal tersebut, maka dalil Penggugat yang
menyatakan bahwa  penerbitan  Objek  Sengketa  telah  melanggar  ketentuan
Pasal  41 ayat  (5) Permenpan RB No. 1/2023 yang mengamanatkan bahwa
pejabat fungsional yang akan diberhentikan harus diperiksa terlebih
dahulu sudah sepatutnya ditolak.
3. Terhadap  Dalil  Penggugat  Yang  Menyatakan  Bahwa  Penerbitan  Objek  Sengketa
Melanggar Asas Kepastian Hukum sesuai ketentuan Pasal 2 huruf a Undang -
Undang  Nomor  20 Tahun 2023  Karena  Tergugat  Menetapkan Penggugat  “Cakap
Dan Memenuhi Syarat” Setelah Tenggat Waktu Pemenuhan Syarat Pendidikan
Tanggal 26 Mei 2025
a. Bahwa  Tergugat  dengan  tegas  menolak  dalil  Penggugat  pada  angka  3
halaman 11 s.d. 14 yang pada pokoknya menyatakan bahwa Tergugat
melanggar Asas Kepastian  Hukum  sesuai  ketentuan  Pasal  2 huruf  a
Undang -Undang  Nomor  20 Tahun  2023  karena  Tergugat  menetapkan
Penggugat  “cakap  dan memenuhi syarat” setela h tenggat waktu
pemenuhan syarat pendidikan tanggal 26 Mei 2025.
b. Bahwa selanjutnya, Penggugat dalam dalilnya menyatakan sesuai dengan
Surat Keterangan Plt. Kepala Pusat Pendidikan dan Pelatihan Keuangan
Umum BPPK Nomor KET -137/PP.7/2024 tanggal 15 Mei 2024  menyatakan
Penggugat  memenuhi  persyaratan  minimal  kualifikasi  karena
“berkecimpung di ranah Teknologi Informasi minimal 5 (lima) tahun
terakhir” dan Sertifikat Pelatihan Fungsional Pranata Komputer Kategori
Keterampilan Nomor 0024/PRAKOMTERAMPIL/106/BPS/I II/2024  dengan
keterangan  “Kompeten”, Keputusan Menteri Keuangan Nomor
117/MK/SJ.5/2025 yang menetapkan Penggugat menduduki Jabatan
Fungsional Pranata Komputer Mahir pada Badan Teknologi, Informasi, dan
Intelijen Keuangan, dan Keputusan  Kepala  Badan  Teknol ogi, Informasi,  dan
Intelijen  Keuangan  Nomor KEP -2/TI/2025  merupakan bukti pengakuan
Tergugat bahwa Penggugat memenuhi  kualifikasi  untuk  menduduki
jabatan  fungsional  pranata  komputer, namun ternyata Tergugat melalui
objek sengketa telah memberhentikan Penggugat dari jabatan fungsional
Jawaban  Perkara  Tata  Usaha  Negara  Jakarta  Nomor  119/G/2026/PTUN.Jkt  Halaman  19 dari  30  pranata komputer.
c. Bahwa sebagaimana telah Tergugat sampaikan dan jelaskan, pelatihan -
pelatihan  yang  dilakukan  oleh  Penggugat  dan mutasi  dalam  jabatan
fungsional pranata komputer bukan berarti secara otomatis Penggugat
memiliki persyaratan jabatan yang diharuskan dalam menduduki jabatan
fungsional pranata komputer dalam Permenpan RB No. 32/2020 dan
SKJ.4/2024 yaitu memiliki kualifikasi pendidikan D iploma III di bidang
Teknologi Informasi. Selain itu, pengangkatan dan mutasi Penggugat dari
BPPK ke BaTii murni merupakan  produk  administrasi  mutasi  kelembagaan
akibat  reorganisasi  eks-Pusintek  dan unit IT terdampak  ke dalam  BaTii.
Pemindahan  struktural  massal ini sama sekali tidak menghapuskan,
menunda, atau memutihkan kewajiban mutlak pemenuhan kualifikasi
pendidikan strata Diploma III.
d. Bahwa selain itu, terkait dengan dalil Penggugat pada angka 3.8 yang
menyatakan bahwa Tergugat melakukan pengabaian terhadap proses
pendidikan yang sedang berjalan (tugas belajar Mandiri), dapat Tergugat
sampaikan hal -hal sebagai berikut:
1) Bahwa Kepala Pusat Pendidikan dan Pelatihan Keuangan Umum
melalui Nota Dinas Nomor ND – 472/PP.7/2025 tanggal 16 Mei 2025
hal Pengaju an Permohonan Izin Belajar Man diri a.n. Ninin Sapto
Hargiyant o telah mengajukan permohonan kepada Sekretaris BPPK
agar dapat diterbitkan surat tugas belajar a.n. Penggugat dikarenakan
Penggugat akan melanjutkan belajar di Universitas Siber Asia untuk
progr am studi S – 1 bidang Sistem Informasi .
2) Bahwa selanjutnya diterbitkan Surat Tugas Belajar Mandiri Tidak
Diberhentikan Nomor ST – 497/PP.1/2025 yang dikeluarkan oleh
Sekretariat BPPK tanggal 10 Juni 2025 yang pokoknya menerangkan bahwa
Penggugat akan melanj utkan tugas belajar di Universitas Siber Asia
program  studi  S – 1 Sistem  Informasi  terhitung tanggal 1 September 2025
s.d. 31 Agustus  2028.
3) Bahwa  namun  demikian,  Penggugat  melalui  Laporan  Perkembangan
Studi Tugas Belajar Mandiri tanggal 10 Maret 2026, menyampaikan
bahwa Penggugat  saat ini sedang  menjalani  sekolah  di Politeknik LP3I
Jakarta  program  studi  Diploma  III Manajemen  Informasi  dengan
dasar penugasan ST – 497/PP.1/2025.
4) Bahwa sesuai dengan website https://pddikti.kemdiktisaintek.go.id ,
tercatat  bahwa  Penggugat  saat ini tercatat  sebagai  mahasiswa
Politeknik LP3I Jakarta program studi Diploma III Manajemen
Informasi dan bukan  sebagai  mahasiswa  Universitas  Siber  Asia
program  studi  S – 1 Sistem  Informasi  sebagaimana  yang  dilaporkan
dalam permohonan  izin belajar Mandiri.
5) Bahwa  terkait  dengan  hal-hal tersebut,  maka  terdapat  perbedaan
dalam pengajuan izin belajar dimana dalam permohonannya untuk
tugas belajar, Penggugat melaporkan Universitas Siber Asia Studi S –
1 program studi Sistem Informasi untuk izin belajar namun dalam
laporan perkembangan  studinya,  Penggugat  malah  melaporkan  bahwa
Penggugat telah menjalani perkuliahan di Politeknik LP3I Jakarta
program studi Diploma III Manajemen Informasi , dimana perbedaan
tempat perkuliahan dimaksud tidak pernah dilaporkan kepada BPPK
sebagai instansi yang menerbitkan izin belajar mandiri kepada
Jawaban  Perkara  Tata  Usaha  Negara  Jakarta  Nomor  119/G/2026/PTUN.Jkt  Halaman  20 dari  30  Penggugat.
e. Bahwa, penerbitan objek sengketa telah didasarkan pula pada asas
kepastian hukum karena penerbitan objek sengketa didasarkan pada aturan
dan ketentuan yang berlaku dan tidak bertentangan dengan aturan yang
lebih tinggi dan tidak menggunakan atura n yang sudah tidak berlaku.
f. Bahwa berdasarkan hal -hal tersebut, maka dalil Penggugat yang
menyatakan bahwa Tergugat melanggar Asas Kepastian Hukum sesuai
ketentuan Pasal 2 huruf a Undang -Undang Nomor 20 Tahun 2023 karena
Tergugat menetapkan Penggugat “caka p dan memenuhi syarat” setelah
tenggat waktu pemenuhan syarat pendidikan tanggal 26 Mei 2025 sudah
sepatutnya ditolak.
4. Terhadap  Dalil  Penggugat  Yang  Menyatakan  Bahwa  Penerbitan  Objek  Sengketa
Melanggar Asas Non Diskriminatif Sesuai Ketentuan Pasal 2 Huruf j Undang -
Undang Nomor 20 Tahun 2023 Terkait Dengan Penerapan Standar Kualifikasi
Bidang Teknologi Informasi Yang Tidak Konsisten
a. Bahwa  Tergugat  dengan  tegas  menolak  dalil  Penggugat  pada  angka  4 halaman
14 s.d. 16 yang pada pokoknya menyatakan penerbitan Objek Sengketa
melanggar Asas Non Diskriminatif sesuai ketentuan Pasal 2 huruf j
Undang -Undang Nomor 20 Tahun 2023 terkait dengan penerapan standar
kualifikasi bidang teknologi informasi yang tidak konsisten.
b. Bahwa  pelanggaran  yang  Penggugat  dalilkan  dalam  Poin  ini berkenaan
dengan CACAT SUBSTANTIF yang melekat pada penerapan dalil
Tergugat: standar kualifikasi pendidikan di bidang Teknologi Informasi
diterapkan secara ketat untuk memberhentikan Penggugat, sekaligus
secara longgar untuk membiarkan dan/atau mengangkat pegawai lain
dalam kondisi serupa di lingkungan Tergugat.
c. Bahwa tuduhan diskriminasi dari Penggugat adalah komparasi yang sesat
logika ( false equivalence ) karena dengan sengaja mencampuradukkan Syarat
Strata  Pendidikan  (Jenjang)  dengan Syarat  Rumpun  Ilmu  (Bidang) .
d. Bahwa Penggugat diberhentikan karena secara absolut gagal memenuhi batas
minimal strata pendidikan (Diploma Tiga / D -3). Fakta mutlak yang tidak
terbantahkan  menunjukkan  Penggugat  hanya  berijazah  Diploma  Satu  (D-1).
e. Bahwa Pegawai pembanding (Sarjana Manajemen/Ekonomi) yang
didalilkan Penggugat  adalah  subjek  yang  telah  secara  penuh  memenuhi
batas  minimal  strata pendidikan karena berijazah Strata Satu (S -1).
Membandingkan subjek yang gagal mutlak di level strata (D -1) dengan
subjek y ang telah lulus di level strata (S -1) adalah argumentasi hukum yang
cacat.
f. Bahwa SKJ.4 2024 memang memberikan ruang bagi Instansi Pembina (BPS)
untuk menetapkan "kualifikasi pendidikan lainnya" bagi rumpun ilmu Non -TI.
Namun,  pengecualian  tersebut  murni  hanya  berlaku  untuk  fleksibilitas
rumpun ilmunya, dan sama sekali tidak memberikan dasar hukum untuk
menurunkan batas minimum jenjang strata pendidikan dari D -3 menjadi D -1.
Pengangkatan pegawai pembanding S -1 Non -TI adalah sah secara regulasi,
sedangkan k etiadaan ijazah D -3/S-1 pada Penggugat adalah cacat permanen
yang  mengharuskan  pemberhentian  demi  hukum.
g. Bahwa berdasarkan hal -hal tersebut, maka dalil Penggugat yang
menyatakan bahwa penerbitan Objek Sengketa melanggar Asas Non
Diskriminatif sesuai ketent uan Pasal 2 huruf j Undang -Undang Nomor 20
Jawaban  Perkara  Tata  Usaha  Negara  Jakarta  Nomor  119/G/2026/PTUN.Jkt  Halaman  21 dari  30  Tahun 2023 terkait dengan penerapan standar kualifikasi bidang teknologi
informasi yang tidak konsisten sudah sepatutnya ditolak.
5. Terhadap  Dalil  Penggugat  Yang  Menyatakan  Bahwa  Penerbitan  Objek  Sengketa
Melanggar Pasal 61 Peraturan Menteri Pendayagunaan Aparatur Negara dan
Birokrasi Negara Nomor 1 Tahun 2023 Karena Penerapan Pasal 59 Peraturan
Menteri  Pendayagunaan  Aparatur  Negara  dan Birokrasi  Negara  Nomor  32 Tahun
2020 Tanpa Melakukan Harmonisasi
a. Bahwa Tergugat dengan tegas menolak dalil Penggugat pada angka 5 halama n
16 s.d. 19 yang  pada  pokoknya  menyatakan  bahwa  objek  sengketa  terdapa t
cacat substantif  yang melekat  pada das ar hukum Objek Sengketa karen a
penerapan  Pasal  59 Permenpan  RB Nomor  32 Tahun  2020  secara  aktif  tanpa
pengujian  harmonisasi  yang  dituntut  Pasal  61 Permenpan  RB Nomor  1
Tahun  2023,  padahal  peraturan  teknis  lama  tersebut wajib  disesuaikan
dengan  rezim  baru  dan sebagian  ketentuannya  telah  dicabut.
b. Bahwa  walaupun  ketentuan  Pasal  16 ayat (1) huruf  d angka  2 Permenpan
RB No. 1/2023 telah mengatur mengenai kualifikasi pendidikan yang
dipersyaratkan dalam pengangkatan dalam jabatan fungsional melalui
perpindahan  dari jabatan  lain yaitu  berijazah  paling  rendah  SLTA  atau
sederajat sesuai dengan kualifikasi pendidikan yang dibutuhkan untuk jabatan
fungsional  keterampilan,  namun  Permenpan  RB No. 1/2023  mengatur
ketentuan pengangkatan jabatan fungsional secara umum dan tidak spesifik
mengenai jabatan fungsional pranata komputer.
c. Bahwa ketentuan Pasal 61 Permenpan  RB No. 1/2023  pada pokoknya mengatur
mengenai mekanisme pengelolaan Jabatan Fungsional dalam kerangka
pembinaan ASN, namun ketentuan tersebut tidak dapat ditafsirkan secara
parsial dengan mengabaikan ketentuan lain yang mengatu r persyaratan
jabatan dan kewajiban pemenuhan kualifikasi pendidikan.
d. Bahwa berdasarkan hasil evaluasi administrasi kepegawaian, Penggugat
terbukti tidak memenuhi persyaratan kualifikasi pendidikan minimal Diploma
III bidang Teknologi Informasi/Komputer se bagaimana dipersyaratkan dalam
pengaturan Jabatan Fungsional Pranata Komputer.
e. Bahwa pemenuhan kualifikasi pendidikan merupakan syarat substantif jabatan
yang bersifat wajib dan fundamental dalam sistem merit ASN.  Oleh karena itu,
ketika Penggugat tidak da pat memenuhi persyaratan dimaksud sampai batas
waktu yang telah diberikan, maka secara hukum Penggugat tidak lagi
memenuhi syarat untuk tetap menduduki Jabatan Fungsional Pranata
Komputer.
f. Bahwa ketentuan dalam Permenpan  RB Nomor 1 Tahun 2023 tidak dapat
dipisahkan dari ketentuan teknis d an substantif yang diatur dalam  Permenpan
RB No. 32/2020 yang secara tegas mengatur kualifikasi pendidikan sebagai
syarat menduduki Jabatan Fungsional Pranata Komputer .
g. Bahwa dalam Permenpan RB No. 32/2020, syarat pendidik an untuk Jabatan
Fungsional  Pranata  Komputer  kategori  keterampilan  tetap  disebut
“berijazah paling rendah diploma tiga (D -III) di bidang teknologi
informasi ”, sedangkan Permenpan RB No. 1/2023 lebih bersifat aturan
umum mengenai manajemen Jabatan Fungsional, pengelompokan jenjang,
dan mekanisme pengangkatan. Peraturan ini tidak secara otomatis
mengubah seluruh kualifikasi pendidikan teknis pada tiap jabatan
fungsional menjadi SLTA/D -I. Bahwa apabila di Permenpan RB No.
32/2020 tertulis minimal D -III, maka ketentuan itu tetap berlaku sepanjang
Jawaban  Perkara  Tata  Usaha  Negara  Jakarta  Nomor  119/G/2026/PTUN.Jkt  Halaman  22 dari  30  belum ada aturan baru yang secara eksplisit mengubah syarat pendidikan
tersebut.
h. Bahwa ketentuan Pasal 15 ayat (1) huru f d Permenpan RB No. 32/2020
menyatakan:
“Pengangkatan  dalam  Jabatan  Fungsional  Pranata  Komputer  melalui  perpindahan  dari
jabatan lain sebagaimana dimaksud dalam Pasal 13 huruf b, harus memenuhi syarat
sebagai berikut:
d. berijazah paling rendah diploma tiga di bidang teknologi informasi bagi Jabatan
Fungsional Pranata Komputer kategori keterampilan .”
i. Bahwa ketentuan Pasal 15 ayat (1) huruf d Permenpan RB No. 32/2020
kemudian dipertegas kembali dalam ketentuan Pasal 59 ayat (2) s.d. ayat (4)
Permenpan RB No. 3 2/2020 yang menegaskan:
(2) Pranata  Komputer  kategori  keterampilan  yang  belum  memperoleh  ijazah  minimal
diploma  tiga, tetap  melaksanakan  tugas  jabatan  sesuai  dengan  jenjang  jabatannya
berdasarkan Peraturan Menteri ini.
(3) Pranata Komputer sebagaimana dimaksud pada ayat (1) dan ayat (2) wajib
memperoleh  ijazah  minimal  diploma  tiga di bidang  teknologi  informasi  paling  lama
5 (lima) tahun sejak Peraturan Menteri ini diundangkan.
(4) Pejabat Fungsional Pranata Komputer kategori keterampilan yang belum
memperoleh ijazah  minimal diploma tiga sampai dengan batas waktu sesuai
ketentuan sebagaimana dimaksud pada ayat (3), diberhentikan dari jabatan
fungsionalnya.
j. Bahwa ketentuan Pasal 59 ayat (3) Permenpan RB No. 32/2020 adalah relaksasi
yang diberikan kepada Penggugat, dimana Penggugat masih diberikan
kesempatan selama 5 (lima) tahun untuk dapat memenuhi kualifikasi
pendidikan yang dibutuhkan untuk tetap dapat menduduki jabatan fungsional
pranata komputer.
k. Bahwa penafsiran terkait dengan kata “SLTA/D – I” setelah penerbi tan
Permenpan  RB No. 1/2023  muncul  karena  beberapa  perubahan  konsep
dalam pengaturan jabatan fungsional, terutama terkait dengan
penyederhanaan jenjang dan penyetaraan jabatan hasil reformasi birokrasi,
namun Penggugat telah salah dalam melakukan penafsira n ayat dan pasal
dan mencampuradukkan dengan syarat pendidikan formasi jabatan
fungsional pranata  komputer.  Permenpan  RB No. 1/2023  merupakan
payung  umum  bagi pengaturan seluruh jabatan fungsional termasuk
kualifikasi pendidikan bagi kategori keahlian dan kategori keterampilan,
namun tidak mengatur secara spesifik mengenai jabatan fungsional pranata
komputer. Sedangkan syarat pendidikan  detail  mengenai  jabatan
fungsional  pranata  komputer  tetap  diatur dalam  Permenpan  RB No.
32/2020  sehingga  Permenpan  RB No. 1/2023  tidak secara otomatis
menggantikan syarat kualifikasi pendidikan.
l. Bahwa untuk dapat melihat gambaran secara utuh mengenai perbedaan
Permenpan RB No. 32/2020 dengan Permenpan RB No. 1/2023 dapat Tergugat
uraikan sebagai berikut:
Aspek  Permenpan  RB No. 32/2020  Permenpan  RB No. 1/2023
Sifat  aturan  Khusus  Umum
Jawaban  Perkara  Tata  Usaha  Negara  Jakarta  Nomor  119/G/2026/PTUN.Jkt  Halaman  23 dari  30  Fokus  Jabatan  fungsional  pranata
komputer  Semua  jabatan
fungsional ASN
Objek   yang
diatur  Tugas,  jenjang,  angka
kredit, kompetensi  pranata
komputer  Tata  kelola  dan manajemen
seluruh jabatan fungsional
Ruang  lingkup  Teknis  substantif  bidang
teknologi informasi  Administrasi  dan
manajemen jabatan
fungsional
Jenjang  jabatan  Mengatur  detail  jenjang
pranata komputer  Mengatur  pola  umum
jenjang jabatan fungsional
Angka  kredit  Detail butir kegiatan dan
Angka Kredit Pranata
Komputer  Menyederhanakan
mekanisme  Angka  Kredit
berbasis kinerja
Pendidikan  D-III bidang teknologi
informasi untuk kategori
keterampilan  Tidak menetapkan detail
pendidikan tiap Jabatan
Fungsional
Instansi
Pembina  Badan  Pusat  Statistik  Mengatur  peran  seluruh
instansi pembina
Tugas  jabatan  Merinci  butir  kegiatan
bidang teknologi
informasi  Tidak mengatur teknis
pekerjaan masing -masing
jabatan fungsional
m. Bahwa ketentuan di dalam Permenpan RB No. 1/2023 tidak mencabut
seluruhnya ketentuan Permenpan RB No. 32/2020 namun hanya beberapa saja
yaitu, mekanisme lama angka kredit, penilaian, tata kelola administrasi
jabatan fungsional  dan beberapa  ketentuan  manajemen  jabatan.  Sedangkan
yang  tetap berlalu adalah tugas pranata komputer, jenjang pranata
komputer, ruang lingkup  pekerjaan,  kompetensi  teknis,  dan syarat
pendidikan  spesifik.  Dengan demikian, hingga saat ini kualifikasi
pendidikan bagi jabatan fungsi onal pranata komputer adalah Diploma III
bidang Teknologi Informasi dan bukan SLTA/D – I.
n. Bahwa berdasarkan hal -hal tersebut, maka dalil yang menyatakan bahwa
penerapan ketentuan Pasal 59 Permenpan RB No. 32/2020 otomatis melanggar
ketentuan dalam Pasal 61  Permenpan RB No. 1/2023 adalah tidak tepat karena:
1) Ketentuan Pasal 59 Permenpan RB No. 32/2020 tidak dicabut secara
eksplisit.
2) Tidak  terdapat  pertentangan  normatif  langsung  yang  absolut;
3) Harmonisasi norma tidak identic dengan penghapusan keberlakuan
norma  lama.
Oleh  karenanya, sudah sepatutnya dalil  Penggugat untuk ditolak.
Jawaban  Perkara  Tata  Usaha  Negara  Jakarta  Nomor  119/G/2026/PTUN.Jkt  Halaman  24 dari  30  6. Terhadap  Dalil  Penggugat  Yang  Menyatakan  Bahwa  Penerbitan  Objek  Sengketa
Melanggar Asas Kepastian Hukum Sesuai Ketentuan Pasal 2 Huruf a Undang -
Undang  Nomor  20 Tahun  2023  Karena  Dasar  Hukum  Substantif  Permberhentian
Tidak Dicantumkan Dalam Bagian Mengingat pada Objek Sengketa
a. Bahwa  Tergugat  dengan  tegas  menolak  dalil  Penggugat  pada  angka  7 halaman
23 s.d. 25 yang  pada  pokoknya  menyatakan  bahwa  dasar  hukum
substantif  penerbitan  KTUN  tidak  dicantumkan  di bagian  Mengingat,
sehingga Tergugat  tidak  menjalankan  kewenangannya  berdasarkan
landasan  peraturan perundang -undangan yang sah dan dapat ditelusuri
sebagaimana diwajibkan Pasal 9 ayat (1) Undang -Undang Nomor 30 Tahun
2014. Bahwa KTUN seharusnya  menyebutkan  secara  rinci  dasar  hukum  apa
yang  tidak  terpenuhi
oleh  Penggugat,  sehingga  objek  sengketa  layak  disebut  dengan  cacat  motivering
(kurang  alasan).
b. Bahwa aturan yang dimaksudkan oleh Penggugat adalah Permenpan RB No.
32/2020 dan SKJ.4/2024 sebagai dasar pokok bagi pemberhentian Penggugat
dari jabatan fungsional pranata komputer.
c. Bahwa terhadap dalil Penggugat, dapat Tergugat sampaikan penjelasan
sebagai berikut:
1) Bahwa SKJ.4/2024 pada dasarnya mengatur standar kompete nsi jabatan
fungsional pranata komputer sehingga secara substansi regulasi tersebut
lebih  berfungsi  sebagai  pedoman  kompetensi  jabatan,  acuan
pengembangan karir, dasar uji kompetensi, atau standar kapasitas pejabat
fungsional dan bukan sebagai norma utama pemberhentian dari jabatan
fungsional .
2) Bahwa secara hukum administrasi, terhadap aturan SKJ.4/2024 tidak perlu
dicantumkan dan tidak merupakan dasar utama dalam keputusan
pemberhentian Penggugat dari jabatan fungsional pranata komputer.
3) Bahwa SKJ.4/2024 pada pokoknya hanya mengatur standar
kompetensi Jabatan Fungsional Pranata Komputer dan bukan
merupakan regulasi yang mengatur pemberhentian pejabat fungsional.
Oleh karena itu, tidak dicantumkannya regulasi dimaksud dalam
bagian “Mengingat” objek sengketa  tidak  memilik i relevansi  langsung
sebagai  dasar  pemberhentian Penggugat dari jabatan fungsional,
sehingga tidak menunjukkan adanya kekeliruan penerapan dasar
hukum dan pelanggaran asas kecermatan dalam penerbitan keputusan
tata usaha negara.
4) Bahwa selain itu, standar k ompetensi jabatan tidak dapat
dipersamakan dengan syarat formal kualifikasi pendidikan, sehingga
apabila Tergugat menggunakan aturan penggunaan SKJ.4/2024
sebagai salah satu dasar pemberhentian karena alasan pendidikan
merupakan bentuk pencampuradukan norm a kompetensi dengan
norma persyaratan administratif jabatan.
5) Bahwa dikarenakan adanya aturan terbaru yaitu Permenpan RB
No.1/2023, maka aturan lama Permenpan RB 32/2020 walaupun masih
terdapat  beberapa  ketentuan  yang  masih  berlaku  tidak  selalu  wajib
untuk dicantumkan.
6) Bahwa selain itu, Penggugat perlu memahami bahwa terdapat perbedaan
Jawaban  Perkara  Tata  Usaha  Negara  Jakarta  Nomor  119/G/2026/PTUN.Jkt  Halaman  25 dari  30  antara Permenpan RB No. 32/2020 dengan Permenpan RB No. 1/2023
dimana Permenpan RB No. 32/2020 lebih banya mengatur mengenai
kedudukan  jabatan,  kategori  dan jenjang,  syarat  pengangkatan,
kompetensi, dan tata kelola jabatan fungsional pranata komputer secara
khusus. Sedangkan Permenpan RB No. 1/2023 merupakan regulasi umum
mengenai manajemen jabatan fungsional, pengangkatan, perpindahan,
pemberhentian,  dan mekanisme  administra si jabatan  fungsional  ASN.
7) Bahwa oleh karena itu, apabila pemberhentian dari jabatan fungsional
pranata komputer dilakukan dengan alasan tidak memenuhi syarat
jabatan atau ketidaksesuaian kualifikasi pendidikan maka lebih relevan
menggunakan aturan Permenp an RB No. 1/2023 karena regulasi inilah
yang mengatur mekanisme dan prosedur pemberhentian Jabatan
Fungsional, termasuk kewajiban pemeriksaan dan tata cara
administrasi.
d. Bahwa berdasarkan hal -hal tersebut, maka dalil Penggugat yang
menyatakan bahwa  dasar  hukum  substantif  penerbitan  KTUN  tidak
dicantumkan  di bagian Mengingat, sehingga Tergugat tidak menjalankan
kewenangannya berdasarkan landasan peraturan perundang -undangan
yang sah dan dapat ditelusuri  sebagaimana  diwajibkan  Pasal  9 ayat  (1)
Undang -Undang  Nomor  30 Tahun  2014.  Bahwa  KTUN  seharusnya
menyebutkan  secara  rinci  dasar  hukum apa yang tidak terpenuhi oleh
Penggugat, sehingga objek sengketa layak disebut dengan cacat motivering
(kurang alasan) sudah sepatutnya ditolak.
III. DALAM PERMOHONAN PENUNDAAN
1. Bahwa  Tergugat menolak dengan tegas dalil dan petitum permohonan penundaan
pelaksanaan objek sengketa yang diajukan Penggugat, karena permohonan
penundaan Penggugat tersebut tidak beralasan hukum sama sekali.
2. Bahwa ketentuan Pasal 67 ayat (4) UU PTUN pada pokok nya menyatakan bahwa
permohonan penundaan pelaksanaan keputusan tata usaha negara tidak dapat
dikabulkan apabila kepentingan umum dalam rangka pembangunan
mengharuskan dilaksanakannya keputusan.
3. Bahwa setiap Keputusan Tata Usaha Negara itu haruslah diakui secara sah menurut
hukum sesuai dengan asas Praesumptio Iustae Causa karena suatu keputusan itu akan
diakui agar bisa dilakukan selama belum adanya pembuktian atau pembatalan.
4. Bahwa meskipun dalam ketentuan Pasal 67 ayat (2) UU PTUN memberikan hak
kepada P enggugat untuk mengajukan permohonan penundaan, namun nyatanya
alasan -alasan  penundaan yang disampaikan Penggugat dalam Surat Gugatannya
tersebut tidak  memenuhi  ketentuan  Pasal  67 ayat  (4) UU PTUN  yang  secara  terbatas
mengatur  sebagai berikut:
“Permohonan  penundaan  sebagaimana  dimaksud  dalam  ayat (2):
a. dapat dikabulkan hanya apabila terdapat keadaan yang sangat mendesak yang
mengakibatkan kepentingan penggugat sangat dirugikan jika Keputusan Tata Usaha
Negara yang digugat itu tetap dilaksanakan;
b. tidak dapat dikabulkan apabila kepentingan umum dalam rangka pembangunan
mengharuskan dilaksanakannya keputusan tersebut. ”
5. Bahwa menurut Dr. W. Riawan Tjandra, S.H., M.Hum. dalam bukunya “ Hukum
Acara  Peradilan  Tata  Usaha  Negara  Edisi  Revisi ” halaman  78 menyatakan  istilah
“keadaan  yang mendesak” seperti yang tercantum dalam Pasal 67 diartikan sebagai
keadaan dimana  kerugian yang akan diderita penggugat akan sangat tidak
Jawaban  Perkara  Tata  Usaha  Negara  Jakarta  Nomor  119/G/2026/PTUN.Jkt  Halaman  26 dari  30  seimbang dibanding manfaat  bagi kepentingan yang akan dilindungi oleh
pelaksanaan Keputusan Tata Usaha Negara  tersebut . Oleh  karena  itu, untuk  menilai
adanya  “keadaan  yang  sangat  mendesak”  harus dilihat secara kasuistis berdasarkan
fakta konkrit yang terjadi dan kemungkinan kerugian yang akan timbul harus dinilai
secara objektif.
6. Bahwa  selain  itu, ketentuan  Pasal  65 ayat (1) UU AP juga telah  menyatakan,
“Keputusan yang  sudah  ditetapkan  tidak  dapat  ditunda  pelaksanaannya,  kecuali  jika berpotensi
menimbulkan:
a. kerugian  negara;
b. kerusakan  lingkungan  hidup;  dan/atau
c. konflik  sosial. ”
7. Bahwa objek sengketa a quo nyata -nyata tidak berpotensi menimbulkan kerugian
negara, kerusakan lingkungan hidup, dan/atau konflik sosial sebagaimana
dimaksud dalam ketentuan  Pasal  65 ayat  (1) UU AP tersebut,  sehingga  tidak  terdapat
alasan  hukum  untuk mengabulkan permohonan penundaan yang diajukan Para
Penggugat.
8. Bahwa berdasarkan  fakta -fakta hukum tersebut, sudah sepatunya posita dan
petitum gugatan Penggugat yang meminta ditundanya pelaksanaan objek gugatan
a quo ditolak seluruhnya.
IV. SIMPULAN
Bahwa berdasarkan Jawaban yang telah disampaikan Tergugat tersebut, maka dapat
disimpulkan hal -hal sebagai berikut:
1. Bahwa terbukti dalil -dalil Penggugat yang disampaikan dalam Surat Gugatannya
adalah tidak benar dan tidak berdasar hukum karena pemberian pencabutan izin
kepada Penggugat telah sesuai dengan kewenangan, prosedur dan dan substansi yang
benar.
2. Bahwa dengan diberhentikannya Penggugat oleh Tergugat dari Jabatan Fungisonal
Pranata Komputer melalui Keputusan Menteri Keuangan Republik Indonesia Nomor
199/MK/SJ.5/2025 tentang Pembe rhentian dari Jabatan Fungsional Pranata Komputer
Mahir dan Pemindahan Pegawai Negeri Sipil Antar Unit Jabatan Pimpinan Tinggi
Madya di Lingkungan Kementerian Keuangan Atas Nama Sdr. Ninin Sapto
Hargiyanto tertanggal  13 November 2025 maka penerbitan Objek Sengketa telah sesuai
dengan ketentuan peraturan  perundang -undangan  dan Asas -Asas  Umum  Pemerintahan
yang  Baik  (AUPB).
3. Bahwa dengan demikian Keputusan Menteri Keuangan Republik Indonesia Nomor
199/MK/SJ.5/2025 tentang Pemberhentian dari Jabatan Fungsional Pranata Komputer
Mahir dan Pemindahan Pegawai Negeri Sipil Antar Unit Jabatan Pimpinan Tinggi
Madya di Lingkungan Kementerian Keuangan Atas Nama Sdr. Ninin Sapto
Hargiyanto tertanggal 13 November 2025 adalah sah secara hukum dan mengikat.
Berdasarkan hal -hal yang telah diuraikan tersebut di atas, Tergugat mohon kepada Majelis
Hakim Pengadilan Tata Usaha Negara Jakarta yang memeriksa dan mengadili perkara a quo ,
berkenaan memutus dengan amar sebagai berikut:
DALAM  POKOK  PERKARA :
1. Menolak  gugatan  Penggugat  untuk seluruhnya;
2. Menyatakan sah Objek Sengketa berupa Keputusan Menteri Keuangan Republik
Indonesia Nomor  199/MK/SJ.5/2025  tanggal  13 November  2025  tentang  Pemberhentian
dari Jabatan Fungsional Pranata Komputer Mahir dan Pemindahan Pegawai Negeri Sipil
Jawaban  Perkara  Tata  Usaha  Negara  Jakarta  Nomor  119/G/2026/PTUN.Jkt  Halaman  27 dari  30  Antar  Unit Jabatan Pimpinan Tinggi Madya di Lingkungan Kementerian Keuangan Atas
Nama Sdr. Ninin Sapto Hargiyanto.
3. Menghukum Penggugat un tuk membayar biaya perkara yang  timbul.
Terima kasih.
Jawaban  Perkara  Tata  Usaha  Negara  Jakarta  Nomor  119/G/2026/PTUN.Jkt  Halaman  28 dari  30  Hormat kami,
Kuasa  Tergugat  dalam  Perkara  Tata  Usaha  Negara
Nomor 119/G/2026/PTUN -JKT
Ditandatangani secara elektronik
Rofii Edy Purnomo, S.H., M.H.
Ditandatangani secara elektronik
Masayu Windri Asmara  Ditandatangani  secara  elektronik
Lulus  Hadi  Purnawan,  S.H.,
M.H.
Ditandatangani secara elektronik
Heru Joko Surono  Ditandatangani secara elek tronik
Sylvia Mulyawati
Ditandatangani secara elektronik
Daryan Ciptadi  Ditandatangani secara elektronik
Ikhwan Arif Rahman
Ditandatangani secara elektronik
Haenry Waskito Jati, S.H.  Ditandatangani secara elektronik
Irene Natalia Verda
Ditandatangani secara elektronik
Nasru Syava  Ditandatangani secara elektronik
Syahrul  Sidiq
Jawaban  Perkara  Tata  Usaha  Negara  Jakarta  Nomor  119/G/2026/PTUN.Jkt  Halaman  29 dari  30
Ditandatangani  secara  elektronik
Muhammad  Nurul  Falah  Huseini
Jawaban  Perkara  Tata  Usaha  Negara  Jakarta  Nomor  119/G/2026/PTUN.Jkt  Halaman  30 dari  30
Dokumen  ini telah  ditandatangani  menggunakan  sertifikat  elektronik  yang  diterbitkan  oleh Balai  Besar  Sertifikasi  Elektronik  (BSrE),  BSSN.  Untuk  memastikan  keaslian  tanda
tangan elektronik, silakan pindai QR Code pada laman https://satu.kemenkeu.go.id  atau unggah dokumen pada laman https://tte.komdigi.go.id/verifyPDF
Kronologi  Pemberhentian JF Pranata Komputer a.n Ninin Sapto Hargiyanto
1. Pegawai atas nama Ninin Sapto Hargiyanto diangkat menjadi JF Pranata Komputer
BPPK pada 1 Agustus 2009 melalui SK nomor 1105 /KM.1/UP.11/2009  dengan
pendidikan terakhir D1 STAN.
2. Terbit PermenPAN -RB nomor 32 Tahun 2020 tentang Jabatan Fungsional Pranata
Komputer  yang  menyatakan bahwa :
a. syarat Pengangkatan Perpindahan dari Jabatan Lain adalah berijazah paling
rendah diploma  tiga di bidang  teknologi informasi  bagi Jabatan Fungsional
Pranata Komputer kategori keterampilan  (pasal 15  ayat 1)
b. Pranata Komputer jenjang keterampilan  wajib memperoleh ijazah minimal
diploma tiga di bidang teknologi informasi paling lama 5 (lima) tahun  sejak
Peraturan Menteri ini diundangkan (P asal 59  ayat 3 ). PermenPAN -RB
diundangkan pada tanggal 27 Mei 2020 .
3. Pada bulan Mei 202 3, Sekretaris BPPK  menyampaikan ND nomor ND-1684/PP.1/2023
hal Penyampaian hasil Penilaian AK JF Prakom Semester II Tahun 2022  dimana dalam
lampiran ND dimaksud, juga melampirkan sejumlah  nama Jabatan Fungsional Pranata
Komputer yang memperoleh Nota Pemberitahuan, dimana salah satunya adalah
Penggugat yang berisi catatan Wajib memperoleh ijazah minimal diploma tiga di
bidang teknologi informasi sebelum 26 Mei 2025 .
4. Penggugat juga memperole h Nota Pemberitahuan Jabatan Fungsional Pranata
Komputer Nomor PEM – 8/TPAK/2023, dimana dalam nota dimaksud  juga memuat
catatan  Wajib memperoleh ijazah minimal diploma tiga di bidang teknologi
informasi sebelum 26 Mei 2025 .
5. BPPK tidak memproses pemberhentian Sdr. Ninin pada tanggal 26 Mei 2026, karena
Pejabat Fungsional Pranata Komputer BPPK sedang dalam proses
transisi/pemindahan ke BaTii dalam rangka penataan organisasi berdasarkan PMK
124 Tahun 2024.
6. Saudara Ninin pindah tugas ke Ba Tii dalam rangka Penataan Organisasi di Kemenkeu
pada tanggal 20 Juni 2025 berdasarkan keputusan nomor 117/MK/SJ.5/2025.
7. BaTii menyampaikan permohonan pemberhentian Saudara Ninin dari JF Pranata
Komputer ke pada Biro SDM melalui ND nomor ND-684/TI.1/2025 tanggal 5 November
2025.
8. Saudara Ninin diberhentikan dari JF Pranata Komputer melalui SK nomor
199/MK/SJ.5/2025  dengan TMT 1 November 2025.
9. Saudara Ninin mengajukan keberatan  atas pemberhentia nnya sebagai JF Pranata
Komputer kepada Kepala Biro Sumber Daya Manusia  tertanggal  23 Desember 2025
yang diterima pada tanggal 31 Desember 2025 , dengan alasan Pasal 59 ayat (3)
Permenpan RB Nomor 32 Tahun 2020 yang digunakan sebagai dasar untuk
memberhentikan nya, sudah tidak digunakan lagi dengan adanya norma baru dalam
Pasal 13 Ayat (1) huruf d angka 2 Permenpan RB No. 1 Tahun 2023.
10. Sesuai ketentuan Pasal 6 ayat (1) PP Nomor 79 Tahun 2021 tentang Upaya
Administratif Dan Badan Pertimbangan Aparatur Sipil Negara  kemudian dit erbitkan
KMK nomor 9/MK/S J/2026 tentang Penguatan Keputusan Menteri Keuangan Nomor
199/MK/SJ.5/2025 tentang Pemberhentian dari Jabatan Fungsional Pranata Komputer
Mahir dan Pemindahan Pegawai Negeri Sipil Antarunit Jabatan Pimpinan Tinggi Madya
di Lingkungan Kementerian Keuangan A tas Nama Sdr. Ninin Sapto Hargiyanto (N IP
19860720 200701 1 001) pada tanggal 23 Januari 2026.