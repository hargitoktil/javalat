# PUTUSAN
Nomor : 43/G/2019/PTUN.SMD
DEMI KEADILAN BERDASARKAN KETUHANAN YANG MAHA ESA
Pengadilan Tata Usaha Negara Samarinda yang memeriksa, memutus
dan menyelesaikan sengketa Tata Usaha Negara pada pe ngadilan tingkat
pertama  dengan  acara  biasa  telah  menjatuhkan  Putusan  sebagaimana
dibawah ini dalam sengketa antara :
Nama :   HANSEN, S.H., M.Si;
Kewarganegaraan :  Indonesia;
Pekerjaan : Mantan Pegawai Negeri Sipil;
Alamat : Kampung  Balok  Asa  RT.005  Kel.  Balok  Asa
Kecamatan  Barong  Tongkok,  Kabupaten  Kutai
Barat, Provinsi Kalimantan Timur, dalam hal ini
memberikan kuasa khusus kepada :
1. MASDIANTO, S.H. 
2. RABIN RABAHNI, S.H.
3. RONI, S.H.
Kesemuanya  berkewarganegaraan  Indonesia,
Para Advokat dan Konsultan Hukum baik secara
bersama-sama  maupun  sendiri-sendiri  pada
Kantor  ADVOKAT  DAN  KONSULTAN  HUKUM
“MASDIANTO,  SH  DAN  REKAN”,  Jalan
Pangeran Antasari II Ujung RT. 30 No. 82 Kel.
Teluk  Lerong  Ilir  Samarinda  Ulu  Kalimantan
Timur,   berdasarkan  Surat  Kuasa  Khusus
Nomor : 002/SK/VII/2019 tanggal 06 Mei 2019;
Selanjutnya disebut sebagai - PENGGUGAT;
M E L A W A N :
BUPATI  KUTAI  BARAT ,  berkedudukan  di  Jl.  Sendawar  I  Komplek
Perkantoran Kabupaten Kutai Barat ;
Dalam hal ini diwakili oleh kuasa hukumnya :
1. ADRIANUS  JONI,  S.H.,  M.H.,  Jabatan
Kepala  Bagian  Hukum  Kabupaten  Kutai
Barat;

Kepaniteraan Mahkamah Agung Republik Indonesia berusaha untuk selalu mencantumkan informasi paling kini dan akurat sebagai bentuk komitmen Mahkamah Agung untuk pelayanan publik, transparansi dan akuntabilitas
pelaksanaan fungsi peradilan. Namun dalam hal-hal tertentu masih dimungkinkan terjadi permasalahan teknis terkait dengan akurasi dan keterkinian informasi yang kami sajikan, hal mana akan terus kami perbaiki dari waktu kewaktu.
Dalam hal Anda menemukan inakurasi informasi yang termuat pada situs ini atau informasi yang seharusnya ada, namun belum tersedia, maka harap segera hubungi Kepaniteraan Mahkamah Agung RI melalui :

2. BASTIAR,  S.H.,  M.Si.,  Jabatan  Kepala
Sub. Bagian Bantuan Hukum dan Kerja Sama
Hukum Kabupaten Kutai Barat;
3. BURHAN  RANRENG,  S.H.,  pekerjaan
Advokat dan Konsultan Hukum Tim Advokasi;
Semuannya  adalah  Warga  Negara  Indonesia,
beralamat  di  Jl.  Sendawar  I  Komplek
Perkantoran Kabupaten Kutai Barat, berdasarkan
Surat  Kuasa  Khusus  Nomor  :  180/3253/HK-
TU.P/VIII/2019 tertanggal 28 Agustus 2019;
  Selanjutnya disebut sebagaiTERGUGAT;
Pengadilan Tata Usaha Negara Samarinda tersebut telah membaca;
- Penetapan Ketua Pengadilan Tata Usaha Negara Samarinda Nomor  :
43/PEN-DIS/2019/PTUN.SMD  tanggal  21  Agustus  2019  tentang
Pemeriksaan Perkara dengan Acara Biasa;
- Penetapan Ketua Pengadilan Tata Usaha Negara Samarinda Nomor  :
43/PEN-MH/2019/PTUN.SMD  tanggal  21  Agustus  2019  tentang
Penunjukkan Majelis Hakim yang memeriksa dan memutus perkara ini;
- Surat  Panitera   Pengadilan  Tata  Usaha  Negara  Samarinda  Nomor  :
43/G/2019/PTUN.SMD  tanggal  21  Agustus  2019  tentang  Surat
Penunjukan Panitera Pengganti dan Juru Sita Pengganti;
- Penetapan  Hakim  Ketua  Majelis  Pengadilan  Tata  Usaha  Negara
Samarinda  Nomor : 43/PEN-PP/2019/PTUN.SMD tanggal  22 Agustus
2019 tentang Pemeriksaan Persiapan;
- Penetapan  Hakim  Ketua  Majelis Pengadilan  Tata  Usaha  Negara
Samarinda Nomor : 43/PEN-HS/2019/PTUN.SMD tanggal 18 September
2019 tentang Hari dan Tanggal Sidang Pertama Terbuka Untuk Umum;
- Berkas-berkas yang berkaitan dengan perkara ini;
- Telah mendengarkan keterangan dari para pihak;

# TENTANG DUDUK SENGKETANYA

Menimbang,  bahwa  Penggugat  telah  mengajukan  gugatannya
tertanggal  20  Agustus  2019,  yang  terdaftar  di  Kepaniteraan  Pengadilan
Tata Usaha Negara Samarinda pada tanggal 20 Agustus 2019 dan telah
diperbaiki pada tanggal 18 September 2019 dengan Register Perkara Nomor
: 43/G/2019/PTUN.SMD yang mengemukakan dalil-dalil sebagai berikut : 

Kepaniteraan Mahkamah Agung Republik Indonesia berusaha untuk selalu mencantumkan informasi paling kini dan akurat sebagai bentuk komitmen Mahkamah Agung untuk pelayanan publik, transparansi dan akuntabilitas
pelaksanaan fungsi peradilan. Namun dalam hal-hal tertentu masih dimungkinkan terjadi permasalahan teknis terkait dengan akurasi dan keterkinian informasi yang kami sajikan, hal mana akan terus kami perbaiki dari waktu kewaktu.
Dalam hal Anda menemukan inakurasi informasi yang termuat pada situs ini atau informasi yang seharusnya ada, namun belum tersedia, maka harap segera hubungi Kepaniteraan Mahkamah Agung RI melalui :


## I. ADAPUN YANG MENJADI OBJEK SENGKETA DALAM PERKARA INI  
ADALAH   :  
KEPUTUSAN  BUPATI  KUTAI  BARAT  Nomor:  800.05.860/K.971/2018.
Tanggal  31  Desember  2018  Tentang  Pemberhentian  Karena  Melakukan
Tindak Pidana Kejahatan Jabatan Atau Tindak Pidana Kejahatan Yang Ada
Hubungannya  Dengan  Jabatan,  atas  nama  Hansen,  SH.,M.Si.  NIP:
197203172006041010 
  
II.TENGGANG WAKTU GUGATAN   A QUO   :  
Bahwa  mengenai  tenggang  waktu  dalam  mengajukan  gugatan,  yaitu
sebagaimana diatur dalam Pasal 55 UU TUN, ditegaskan sebagai berikut :
“Gugatan dapat diajukan hanya dalam waktu Sembilan puluh hari terhitung
saat diterimanya atau diumumkannya Keputusan Badan atau Pejabat Tata
Usaha Negara” 
Bahwa in casu objek sengketa diterbitkan oleh TERGUGAT pada tanggal 31
Desember  2018  dan  baru  diterima/diketahui  oleh  PENGGUGAT  Pada
Tanggal, 03 Mei 2019.

## III. UPAYA ADMINISTRASI
1. Bahwa berdasarkan PERMA No. 6 Tahun 2018 pasal 2 ayat 1
dan 2 maka Penggugat telah mengajukan upaya administrasi pada
Tanggal,  16  Juli  2019   terhadap  objek  sengketa  namun  setelah
PENGGUGAT  mengajukan  gugatan  ditolak  oleh  panitra   TUN
samarinda karena upaya administarsi oleh PENGGUGAT  dinyatakan
salah  alamat  karena  ditujukan  kepada  Gubernur  Kalimantan  Timur
yang semestinya ditujukan langsung kepada TERGUGAT dan telah
pula disarankan kembali kepada PENGGUGAT untuk mengajukan lagi
upaya  administrasi.  PENGGUGAT  atas  saran  tersebut  telah
mengajukan kembali upaya administarsi yaitu Pada tanggal, 30 Juli
2019 yang ditujukan langsung kepada TERGUGAT.
2. Bahwa sampai saat gugatan ini diajukan yaitu pada Tangga, 20
Agustus  2019  TERGUGAT  belum  memberikan  jawaban  atas
permohonan PENGGUGAT tersebut, maka berdasarkan Pasal 53 UU
No.  30  Tahun  2014  Tentang  Administrasi  Pemerintah,  maka
PENGGUGAT  menganggap  TERGUGAT  telah  mengeluarkan
keputusan.

Kepaniteraan Mahkamah Agung Republik Indonesia berusaha untuk selalu mencantumkan informasi paling kini dan akurat sebagai bentuk komitmen Mahkamah Agung untuk pelayanan publik, transparansi dan akuntabilitas
pelaksanaan fungsi peradilan. Namun dalam hal-hal tertentu masih dimungkinkan terjadi permasalahan teknis terkait dengan akurasi dan keterkinian informasi yang kami sajikan, hal mana akan terus kami perbaiki dari waktu kewaktu.
Dalam hal Anda menemukan inakurasi informasi yang termuat pada situs ini atau informasi yang seharusnya ada, namun belum tersedia, maka harap segera hubungi Kepaniteraan Mahkamah Agung RI melalui :

3. Bahwa berdasarkan hal tersebut diatas maka gugatan  a quo
diajukan masih dalam tenggang waktu yang ditentukan dalam pasal
55 UU PTUN tersebut diatas yakni 90 (Sembilan puluh) hari sejak saat
diterima  atau  diumumkan  keputusan  Badan  Tata  Usaha  Negara.
( Bahwa Tanggal, 03 Mei 2019 S/d 31 Juli 2019 adalah tengang waktu
90 hari gugatan a quo, gugatan diajukan tepatnya pada Tanggal, 20
Agustus 2019 yang artinya telah lewat waktu 17 hari dari tenggang
waktu  yang  dimaksud  dalam  Pasal  55  UU  PTUN).  Namun  dalam
penjelasan  PERMA  No.  6  Tahun  2018  Tentang  Pedoman
Penyelesaian   Sengketa  Administrasi  Pemerintahan  Setelah
Menempuh  Upaya  Administrasi  Pasal  5.  Ayat  1  menyatakan:
Tenggang  waktu  pengajuan  gugatan  di  pengadilan  dihitung  90
(Sembilan  puluh)  hari  sejak  keputusan  atas  upaya  administratif
diterima  oleh  warga  masyarakat  atau  diumumkan  oleh  badan
dan/atau  pejabat  administratif  pemerintahan  yang  menangani
penyelesaian upaya administratif. 
4. Bahwa  dimaknai  oleh  PENGGUGAT  tenggang  waktu  90
(Sembilan puluh) hari  yang dimaksud dalam PERMA No. 6 Tahun
2018 Pasal 5 ayat 1, secara otomatis terhenti sejak Tanggal, 30 Juli
2019  saat  PENGGUGAT  Melakukan  upaya  Administratif  kepada
TERGUGAT  dan  mulai  terhitung  kembali  sejak  gugatan  a  quo
diajukan.  Sehingga  tepat  pada  Tanggal,  20  Agustus  2019
PENGGUGAT memutuskan mengajukan gugatan  kepada Peradilan
Tata Usaha Negara Samarinda yang aritnya masih tersisa tenggang
waktu gugatan a quo dari Tanggal, 03 Mei 2019  S/d 31  Juli  2019
masih tersisa 4 (empat) hari lagi sebagaimana yang dimaksud dalam
Pasal 55 UU PTUN.
 

## IV. KEPENTINGAN PENGGUGAT YANG DIRUGIKAN
1. Bahwa  langkah  PENGGUGAT  mengajukan  gugatan  ini
didasarkan  pada  ketentuan  Pasal  53  ayat  (1),  UU  PTUN  yang
menetapkan  bahwa;  “Seseorang  atau  badan  hukum  perdata  yang
merasa kepentingannya dirugikan oleh suatu Keputusan Tata Usaha
Negara dapat mengajukan gugatan tertulis Kepada Pengadilan Tata
Usaha  Negara  yang disengketakan  itu  dinyatakan  batal atau tidak
sah,  dengan  atau  tanpa  disertai  tuntutan  ganti  rugi  dan/atau
rehabilitasi”  

Kepaniteraan Mahkamah Agung Republik Indonesia berusaha untuk selalu mencantumkan informasi paling kini dan akurat sebagai bentuk komitmen Mahkamah Agung untuk pelayanan publik, transparansi dan akuntabilitas
pelaksanaan fungsi peradilan. Namun dalam hal-hal tertentu masih dimungkinkan terjadi permasalahan teknis terkait dengan akurasi dan keterkinian informasi yang kami sajikan, hal mana akan terus kami perbaiki dari waktu kewaktu.
Dalam hal Anda menemukan inakurasi informasi yang termuat pada situs ini atau informasi yang seharusnya ada, namun belum tersedia, maka harap segera hubungi Kepaniteraan Mahkamah Agung RI melalui :

2. Bahwa oleh karena itu PENGGUGAT sangat berkepentingan
dalam perkara ini, terutama untuk melindungi hak-hak PENGGUGAT
yang  dilindungi  hukum  atas  tindakan  TERGUGAT  yang  telah
menerbitkan  Objek  Sengketa  tersebut,  yang  telah  merugikan
Kepentingan  PENGGUGAT,  karena  telah  menimbulkan  kehilangan
status  hukum  sebagai  Pegawai  Negeri  Sipil  kepada  PENGGUGAT
berkaitan dengan hak-hak kepegawaian, hak-hak keuangan, jenjang,
karier, dan lain-lain.  

## V. KEWENANGAN PENGADILAN TATA USAHA NEGARA
1. Bahwa ketentuan Pasal 1 angka 3 Undang-Undang RI No 5
Tahun  1986  tentang  Pengadilan  Tata  Usaha  Negara  sebagaimana
telah diubah menjadi Pasal 1 angka 9 Undang-Undang RI No  51
Tahun 2009 tentang Perubahan Kedua Undang-Undang No 5 Tahun
1986  tentang  Pengadilan  Tata  Usaha  Negara  mendefenisikan
Keputusan Tata Usaha Negara adalah “suatu penetapan tertulis yang
dikeluarkan oleh badan atau pejabat tata usaha negara yang berisi
tindakan  hukum  yang  berdasarkan  peraturan  perundang-undangan
yang  berlaku,  yang  bersifat  kongkret,  individual,  dan  final,  yang
membawa akibat hukum bagi seseorang atau badan hukum perdata”
2. Bahwa  berdasarkan  definisi  dalam  angka  1  di  atas,  maka
KEPUTUSAN BUPATI KUTAI BARAT Nomor: 800.05.860/K.971/2018.
Tanggal  31  Desember  2018  Tentang  Pemberhentian   Karena
Melakukan  Tindak  Pidana  Kejahatan  Jabatan  Atau  Tindak  Pidana
Kejahatan  Yang  Ada  Hubungannya  Dengan  Jabatan  atas  nama;
Hansen.  SH.,M.Si.  NIP:  197203172006041010  Adalah  terang
benderang  sebuah  keputusan  tertulis  yang  berisi  penetapan
(beschikking)  dan langsung  berlaku  sejak dikeluarkan  oleh  pejabat
yang membuatnya (einmalig);
3. Bahwa  BUPATI  merupakan  pejabat  publik  yang  memimpin
jalannya pelaksanaan setiap urusan roda  pemerintahan yang menjadi
wewenang daerah berdasarkan ketentuan dari perundang-undangan
yang berlaku. Jelas adalah “badan atau pejabat tata usaha negara”
sebagaimana dimaksudkan dalam Pasal 1 angka 8 Undang-Undang
No 51 Tahun 2009 tentang Perubahan Kedua Atas Undang-Undang
No 5 Tahun 1986 tentang Pengadilan Tata Usaha Negara;

Kepaniteraan Mahkamah Agung Republik Indonesia berusaha untuk selalu mencantumkan informasi paling kini dan akurat sebagai bentuk komitmen Mahkamah Agung untuk pelayanan publik, transparansi dan akuntabilitas
pelaksanaan fungsi peradilan. Namun dalam hal-hal tertentu masih dimungkinkan terjadi permasalahan teknis terkait dengan akurasi dan keterkinian informasi yang kami sajikan, hal mana akan terus kami perbaiki dari waktu kewaktu.
Dalam hal Anda menemukan inakurasi informasi yang termuat pada situs ini atau informasi yang seharusnya ada, namun belum tersedia, maka harap segera hubungi Kepaniteraan Mahkamah Agung RI melalui :

4. Bahwa   KEPUTUSAN  BUPATI  KUTAI  BARAT  Nomor:
800.05.860/K.971/2018.  Tanggal,  31  Desember  2016  Tentang
Pemberhentian  Karena Melakukan Tindak Pidana Kejahatan Jabatan
Atau  Tindak  Pidana  Kejahatan  Yang  Ada  Hubungannya  Dengan
Jabatan atas nama; Hansen. SH.,M.Si. NIP: 197203172006041010. 
jelas adalah suatu penetapan tertulis yang dikeluarkan oleh badan atau
pejabat tata  usaha negara yang berisi tindakan hukum tata usaha
negara  yang  berdasarkan  peraturan  perundang-undangan  yang
berlaku;
5. Bahwa  KEPUTUSAN  BUPATI  KUTAI  BARAT  Nomor:
800.05.860/K.971/2018.  Tanggal  31  Desember  2018  Tentang
Pemberhentian  Karena Melakukan Tindak Pidana Kejahatan Jabatan
Atau  Tindak  Pidana  Kejahatan  Yang  Ada  Hubungannya  Dengan
Jabatan  atas  nama;  Hansen.  SH.,M.Si  NIP:  197203172006041010
bersifat konkrit, individual dan final dengan alasan sebagai berikut :
- Bahwa Surat Keputusan Tergugat a-quo bersifat konkrit karena objek
yang  disebutkan  dalam  Surat  Keputusan  itu  tidak  abstrak,  tetapi
berwujud  dan  nyata-nyata  secara  tegas  menyebutkan   “nama
Penggugat sebagai subyek hukumnya”;
- Bahwa  Surat Keputusan  Tergugat  a-quo bersifat individual  karena
tidak ditujukan untuk umum, tetapi berwujud dan nyata-nyata secara
tegas menyebut nama Penggugat salah satu sebagai subjek hukum
didalamnya;
- Bahwa Surat Keputusan Tergugat  a-quo telah bersifat final karena
tidak lagi memerlukan persetujuan dari instansi tertentu baik bersifat
horizontal  maupun  vertikal.  Dengan  demikian  Surat  Keputusan
Tergugat tersebut telah bersifat definitif dan telah menimbulkan akibat
hukum; 
- Bahwa Surat Keputusan Tergugat  a-quo telah menimbulkan akibat
hukum,  yakni  Penggugat  telah  nyata-nyata  dicabut  status,
kedudukan, harkat dan martabatnya sebagai Pegawai Negeri Sipil
Yang Memenuhi Kriteria (MK) di lingkungan Pemerintah Kabupaten
Kutai Barat;
- Bahwa Penggugat, dengan alasan-alasan yuridis sebagaimana akan
diuraikan nanti, dengan tegas menolak Surat Keputusan Tergugat a-
quo dan menganggapnya sebagai tidak mempunyai kekuatan hukum
yang mengikat. Penolakan Penggugat ini sebagaimana didefinisikan

Kepaniteraan Mahkamah Agung Republik Indonesia berusaha untuk selalu mencantumkan informasi paling kini dan akurat sebagai bentuk komitmen Mahkamah Agung untuk pelayanan publik, transparansi dan akuntabilitas
pelaksanaan fungsi peradilan. Namun dalam hal-hal tertentu masih dimungkinkan terjadi permasalahan teknis terkait dengan akurasi dan keterkinian informasi yang kami sajikan, hal mana akan terus kami perbaiki dari waktu kewaktu.
Dalam hal Anda menemukan inakurasi informasi yang termuat pada situs ini atau informasi yang seharusnya ada, namun belum tersedia, maka harap segera hubungi Kepaniteraan Mahkamah Agung RI melalui :

dalam Pasal 1 angka 4 Undang-Undang No 5 Tahun 1986 tentang
Pengadilan Tata Usaha Negara jo Pasal 1 angka 10 Undang-Undang
RI  No  51  Tahun  2009  tentang  Perubahan  Kedua  Atas  Undang-
Undang  Nomor  5  Tahun  1986  tentang  Pengadilan  Tata  Usaha
Negara, adalah “sengketa tata usaha negara” 
- Bahwa  ketentuan Pasal  47  Undang-Undang  RI No  5 Tahun 1986
tentang  Pengadilan  Tata  Usaha  Negara  menegaskan  bahwa
Pengadilan Tata Usaha Negara “bertugas dan berwenang memeriksa,
memutus, dan menyelesaikan sengketa Tata Usaha Negara”

## VI. FAKTA DAN ALASAN YANG MENDASARI DIAJUKANNYA GUGATAN
1. Bahwa PENGGUGAT adalah Calon Pegawai Negeri Sipil pada
Pemerintah Kabupaten Kutai Barat dengan nama lengkap Hansen,
SH. NIP: 550 030 221 terhitung pada tanggal 1 April 2006 Bagian
Pembangunan Setkab. Kutai Barat Nomor: SK. 813.3/174/BKD-I/2007
Tanggal 16 Januari 2007.
2. Bahwa  PENGGUGAT telah  diangkat mejadi  Pegawai  Negeri
Sipil  berdasarkan  Keputusan  Kepala  Badan  Kepegawaian  Negara
Nomor: 0002/KV/VIII/26402/KEP/2008 Tanggal, 06 Oktober 2008 atas
nama  Hansen  NIP  Baru:  197203172006041010.  dilingkungan
Pemerintah Kabupaten Kutai Barat.
3. Bahwa  PENGGUGAT  menerima  kenaikan  Pangkat  pertama
berdasarkan  Surat  Keputusan  Bupati  No.  823.3/1141/BKD-
DKP/IX/2015  Tanggal,  10  September  2015  yang  menetapkan
kenaikan Pangkat PENGGUGAT terhitung mulai tanggal, 01 Januari
2015  dalam  Jabatan  Kepala  Seksi  Kebandarudaraan  Eselon:  IV.a
Dengan Golongan III/c.
4. Bahwa PENGGUGAT juga telah menerima kenaikan pangkat
berdasarkan  Surat  Pernyataan  Menduduki  Jabatan  No.
821.4/1460/BKPPD-VI/2018  Jabatan  Kepala  Seksi  Fasilitas
Kerjasama Antar  Kampung pada Dinas Pemberdayaan Masyarakat
dan Kampung Kabupaten Kutai Barat Tanggal, 07 Juni 2018. Penata
Tk. I (III/d).
5. Bahwa  PENGGUGAT  merupakan  Terpidana  kasus  korupsi
yang sudah memiliki kekuatan hukum tetap/incraht pada Tanggal, 26
April 2016 dengan bunyi Amar Putusan sebagai berikut:
MENGADILI:

Kepaniteraan Mahkamah Agung Republik Indonesia berusaha untuk selalu mencantumkan informasi paling kini dan akurat sebagai bentuk komitmen Mahkamah Agung untuk pelayanan publik, transparansi dan akuntabilitas
pelaksanaan fungsi peradilan. Namun dalam hal-hal tertentu masih dimungkinkan terjadi permasalahan teknis terkait dengan akurasi dan keterkinian informasi yang kami sajikan, hal mana akan terus kami perbaiki dari waktu kewaktu.
Dalam hal Anda menemukan inakurasi informasi yang termuat pada situs ini atau informasi yang seharusnya ada, namun belum tersedia, maka harap segera hubungi Kepaniteraan Mahkamah Agung RI melalui :

- Menyatakan  terdakwa  HANSEN,  SH.,  M.Si  tidak  terbukti  bersalah
secara  sah  dan  meyakinkan  bersalah  melakukan  Tindak  Pidana
sebaimana yang didakwakan dalam dakwaan Primair; HANSEN, SH.,
M.Si 
- Membebaskan terdakwa dari dakwaan Primair tersebut;
- Menyatakan terdawaka HANSEN, SH., M.Si tersebut diatas, terbukti
secara  sah  dan  meyakinkan  bersalah  melakukan  Tindak  Pidana
“Korupsi secara bersama-sama”
- Menjatuhkan pidana kepada Terdakwa oleh karena itu dengan pidana
penjara selama 1 (satu) Tahun 4 (empat) bulan dan denda sejumlah
Rp. 50.000.000 (lima puluh juta rupiah) dengan ketentuan apabila
denda tersebut tidak dibayar diganti dengan pidana kurungan selama
3 (bulan). 
- Menetapkan masa penahanan yang telah dijalani terdakwa HANSEN,
SH.,  M.Si  dikurangkan  seluruhnya  dari  pidana  yang
dijatuhkan;Menetapkan terdakwa HANSEN, SH., M.Si tetap ditahan;
6. Bahwa terhadap status PENGGUGAT selaku Pegawai Negeri
Sipil, saat ini telah dilakukan pemberhentian Tidak Dengan Hormat
sebagai Pegawai Negeri Sipil oleh TERGUGAT yang menjadi objek
sengketa dalam perkara ini terhadap PENGGUGAT. 
7. Bahwa  objek  sengketa  yang  diterbitkan  oleh  TERGUGAT
dengan  judul  “  Tentang  Pemberhentian  Karena  Melakukan  Tindak
Pidana Kejahatan Jabatan Atau Tindak Pidana Kejahatan Yang Ada
Hubungannya Dengan Jabatan adalah  in casu  karena TERGUGAT
tidak menjelaskan secara detail dan terperinci apakah PENGGUGAT
masuk di dalam Tindak Pidana Kejahatan Jabatan atau Tindak Pidana
Yang  Ada  Hubungannya  Dengan  Jabatan.  Karena  jelas  telah
menggunakan Kalimat/kata ATAU artinya merupakan jenis perbuatan
dan jenis kejahatan yang berbeda. 
8. Bahwa PENGGUGAT Mempertanyakan dan Keberatan; terkait
objek sengketa a quo yang menyatakan menimbang pada  huruf a
yaitu;  berdasarkan  Putusan  Pengadilan  Negeri  Samarinda  Nomor;
60/Pid.Sus-TPK/2015/PN  Smr  Tanggal,  27  April  2016  yang  telah
mempunyai  kekuatan  hukum  tetap,  Sdr.  HANSEN,  SH,M.Si  NIP:
19720317  200604  1  010  Penata  Tingkat  I Golongan  Ruang  (III/d)
dinyatakan  telah  terbukti  secara  sah  dan  meyakinkan  melakukan
tindak pidana korupsi. 

Kepaniteraan Mahkamah Agung Republik Indonesia berusaha untuk selalu mencantumkan informasi paling kini dan akurat sebagai bentuk komitmen Mahkamah Agung untuk pelayanan publik, transparansi dan akuntabilitas
pelaksanaan fungsi peradilan. Namun dalam hal-hal tertentu masih dimungkinkan terjadi permasalahan teknis terkait dengan akurasi dan keterkinian informasi yang kami sajikan, hal mana akan terus kami perbaiki dari waktu kewaktu.
Dalam hal Anda menemukan inakurasi informasi yang termuat pada situs ini atau informasi yang seharusnya ada, namun belum tersedia, maka harap segera hubungi Kepaniteraan Mahkamah Agung RI melalui :

Adalah  jelas  merupakan  cacat  hukum  karena  TERGUGAT  tidak
menjelaskan tindak pidana korupsi yang mana persisnya yang telah
dilakukan oleh PENGGUGAT. Jelas telah melanggar UU No. 30 Tahun
2014  Tentang  Administrasi  Pemerintahan  Pasal  10  huruf  d  (asas
kecermatan).
9. Bahwa PENGGUGAT selama didalam tahanan kepolisian Kutai
Barat,  Kejaksaan  Kutai  Barat  dan  menjalani  hukuman  tidak  ada
pemberhentian sementara dari Jabatan sebagai Pegawai Negeri Sipil
dilingkungan  Pemerintah  Kabupaten  Kutai  Barat  adalah  jelas
melanggar Pasal 276 huruf c Peraturan Pemerintah No. 11 Tahun
2017
10. Bahwa  PENGGUGAT selama  ini  tidak  pernah  mendapatkan
surat  pemberhentian  sementara  ataupun  teguran  dari  Badan
Kepegawaian Daerah Kabupaten Kutai Barat bahkan tetap menerima
gaji seratus persen (100%) sesuai dengan Pangkat/Golongan pada
saat  Penggugat  ditahan  sampai  kasus  hukum  PENGGUGAT
dinyatakan berkekuatan hukum tetap/incraht. Adalah jelas merupakan
pelanggaran  yang  nyata  dilakukan  oleh  TERGUGAT  karena  telah
melanggar  Pasal  281  ayat  1  PP  No.  11  Tahun  2017  Tentang
Administrasi Pemerintahan.  
11. Bahwa PENGGUGAT langsung aktif kembali sebagai Pegawai
Negeri Sipil sejak keluar dari Rutan dan telah bekerja dengan baik
serta beberapa kali dinaikan maupun dialihkan pangkat/jabatan serta
golongan. Dan belum pernah mendapatkan kembali hukuman disiplin
yang  lain,  baik  berupa  hukuman  disiplin  tingkat  ringan,  sedang
maupun berat.
12. Bahwa  KEPUTUSAN  BUPATI  KUTAI  BARAT  Nomor:
800.05.860/K.971/2018.  Tanggal  31  Desember  2018  Tentang
Pemberhentian  Karena Melakukan Tindak Pidana Kejahatan Jabatan
Atau Tindak Pidana Kejahatan Yang Ada Hubungan Dengan Jabatan
atas nama; Hansen. SH.,M.Si NIP: 197203172006041010. Terhitung
mulai Tanggal, 31 Desember 2018 adalah bentuk surat objek sengketa
dikeluarkan  oleh  Badan  atau  Pejabat  Tata  Usaha  Negara  tidak
mendasari  bentuk  formil  asas-asas  pemerintahan  yang  baik  oleh
sebab  penetapannya  dalam  konsider  menimbang  tertera  Putusan
Pengadilan Negeri Samarinda Nomor: 60/Pid.Sus-TPK/2015 PN Smr
Tanggal 27 April 2016 Hal ini salah dan berakibat tidak sah atau batal

Kepaniteraan Mahkamah Agung Republik Indonesia berusaha untuk selalu mencantumkan informasi paling kini dan akurat sebagai bentuk komitmen Mahkamah Agung untuk pelayanan publik, transparansi dan akuntabilitas
pelaksanaan fungsi peradilan. Namun dalam hal-hal tertentu masih dimungkinkan terjadi permasalahan teknis terkait dengan akurasi dan keterkinian informasi yang kami sajikan, hal mana akan terus kami perbaiki dari waktu kewaktu.
Dalam hal Anda menemukan inakurasi informasi yang termuat pada situs ini atau informasi yang seharusnya ada, namun belum tersedia, maka harap segera hubungi Kepaniteraan Mahkamah Agung RI melalui :

karena  tidak  memenuhi  formil  asas-asas  pemerintahan  yang  baik
yang  benar  adalah  Putusan  Pengadilan  Negeri  Samarinda  Nomor:
60/Pid.Sus-TPK/2015 PN Smr Tanggal 26 April 2016.
13. Bahwa PENGGUGAT keberatan dasar hukum yaitu:  Peraturan
Menteri  Pendayagunaan  Aparatur  Negara  Dan  Reformasi  Birokrasi
No. 26 Tahun 2016, PERDA Kabupaten Kutai Barat No. 07 Tahun
2017, PERDA Kabupaten Kutai Barat No. 7 Tahun 2016 dan PERDA
Kabupaten  Kutai  Barat  No.  18  Tahun  2017.  Oleh  Pejabat  TUN
Sebagai dasar terbitnya Surat Keputusan objek sengketa a quo oleh
TERGUGAT. Karena status hukum PENGGUGAT telah berkekuatan
hukum tetap/incraht. Tepatnya pada tanggal 26 April 2016 semestinya
TERGUGAT  pada  saat  itu  pula  secara  mutatis  mutandis
mengeluarkan  Surat  Keputusan  objek  sengketa  a  quo  oleh
TERGUGAT  terhadap  PENGGUGAT,  namun  faktanya  TERGUGAT
baru  mengeluarkan  surat  keputusan  objek  sengketa  a  quo pada
tanggal  31  Desember  2018  Adalah  jelas  merupakan  sikap  in-
konsisten/keragu-raguan  dari  TERGUGAT tehadap  hukum  atas  hal
tersebut  jelas  merupakan  pelanggaran  yang  nyata  dilakukan  oleh
TERGUGAT  telah  melanggar  pula  atas  Asas-Asas  Umum
Pemerintahan Yang baik yaitu; Asas Kepastian hukum  sebagaimana
diatur dalam Pasal 10 ayat 1 huruf a UU No. 30 Tahun 2014.
14. Bahwa  PENGGUGAT  keberatan  atas  dasar  Pertimbangan
TERGUGAT Pasal 250 hurup b Peraturan Pemerintah No. 11 Tahun
2017  yang  menjadi  dasar  diterbitkannya  Surat  Keputusan  objek
sengketa  a  quo oleh  TERGUGAT.  Oleh  sebab  itu  kembali  lagi
PENGGUGAT  tegaskan  bahwa  kasus  hukum  PENGGUGAT  telah
berkekuatan hukum tetap/incraht pada Tanggal, 26 April 2016 adalah
jelas  merupakan  pelanggaran  hukum  yang  nyata  dilakukan
TERGUGAT  diberlakukan  surut  kebelakang  oleh  karena  itu  telah
melanggar asas-asas hukum itu sendiri yang dianut oleh hukum positif
Indonesia yang tidak mengenal aturan yang berlaku surut ke belakang
atau Asas Retroaktif sesuai dengan UU Dasar 1945 Pasal 28 I.
15. Bahwa  Surat  Keputusan  objek  sengketa  a  quo  yang
dikeluarkan oleh TERGUGAT terhitung mulai Tanggal, 31 Desember
2018 adalah dikeluarkan oleh Badan atau Pejabat Tata Usaha Negara
tidak mendasari bentuk formil asas-asas pemerintahan yang baik oleh
sebab salah satunya adalah PENGGUGAT pada kenyataanya tetap

Kepaniteraan Mahkamah Agung Republik Indonesia berusaha untuk selalu mencantumkan informasi paling kini dan akurat sebagai bentuk komitmen Mahkamah Agung untuk pelayanan publik, transparansi dan akuntabilitas
pelaksanaan fungsi peradilan. Namun dalam hal-hal tertentu masih dimungkinkan terjadi permasalahan teknis terkait dengan akurasi dan keterkinian informasi yang kami sajikan, hal mana akan terus kami perbaiki dari waktu kewaktu.
Dalam hal Anda menemukan inakurasi informasi yang termuat pada situs ini atau informasi yang seharusnya ada, namun belum tersedia, maka harap segera hubungi Kepaniteraan Mahkamah Agung RI melalui :

bekerja dan menerima gaji sampai bulan Januari 2019 adalah jelas
salah dan berakibat tidak sah karena tidak memenuhi formil asas-asas
pemerintahan yang baik.
16. Bahwa  berdasarkan  ketentuan  Pasal  53  ayat  (2)  huruf  a
Undang-Undang  No.  5  Tahun  1986  Tentang  Peradilan  Tata  Usaha
Negara  menyebutkan  bahwa  alasan-alasan  yang  dapat  digunakan
dalam gugatan adalah Keputusan Tata Usaha Negara yang digugat itu
bertentangan dengan peraturan perundang-undangan yang berlaku. 
17. Bahwa penerapan Undang-Undang No. 5 Tahun 2014 Tentang
Aparatur Sipil Negara tidak ada alasan yang dapat dibenarkan oleh
hukum,  karena  semestinya  TERGUGAT pada  saat  itu  pula  secara
mutatis mutandis mengeluarkan Surat Keputusan objek sengketa  a
quo  oleh  TERGUGAT  terhadap  PENGGUGAT,  namun  faktanya
TERGUGAT baru mengeluarkan surat keputusan objek sengketa  a
quo  pada tanggal 31 Desember 2018 Adalah jelas merupakan sikap
in-konsisten/keragu-raguan dari TERGUGAT tehadap hukum atas hal
tersebut  jelas  merupakan  pelanggaran  yang  nyata  dilakukan  oleh
TERGUGAT  telah  melanggar  pula  atas  Asas-Asas  Umum
Pemerintahan Yang baik yaitu; Asas Kepastian hukum  sebagaimana
diatur dalam Pasal 10 ayat 1 huruf a UU No. 30 Tahun 2014.
18. Bahwa  disamping  in-konsisten/keragu-raguan  sehingga
berdampak  pelanggaran  terhadap  asas-asas  umum  pemerintahan
yang baik Pasal 10 ayat 1 huruf a UU No. 30 Tahun 2014 yaitu; asas
kepastian  hukum.  TERGUGAT  telah  pula  mengunakan  Pasal  250
huruf b Peraturan Pemerintah No. 11 Tahun 2017 Tentang Manajemen
Pegawai  Negeri  Sipil  dalam  Surat  Keputusan  yang  menjadi  objek
sengketa oleh TERGUGAT adalah In casu karena merupakan sanksi
hukum yang berlaku surut terhadap PENGGUGAT
19. Bahwa penerbitan Objek Gugatan juga bertentangan dengan
Asa-Asas Umum Pemerintahan Yang Baik sebagaimana di maksud
dalam  ketentuan  pasal  10  UU  No.  30  Tahun  2014  Tentang
Administrasi Pemerintahan;
Melanggar  asas  kepastian,  dalam  arti  tindakan  TERGUGAT telah
menerbitkan objek gugatan ketidakpastian hukum karena mengenai
proses tersebut yang alasan utamanya karena TERGUGAT telah in-
konsisten/keragu-raguan terhadap hukum terkait penerapan UU No.

Kepaniteraan Mahkamah Agung Republik Indonesia berusaha untuk selalu mencantumkan informasi paling kini dan akurat sebagai bentuk komitmen Mahkamah Agung untuk pelayanan publik, transparansi dan akuntabilitas
pelaksanaan fungsi peradilan. Namun dalam hal-hal tertentu masih dimungkinkan terjadi permasalahan teknis terkait dengan akurasi dan keterkinian informasi yang kami sajikan, hal mana akan terus kami perbaiki dari waktu kewaktu.
Dalam hal Anda menemukan inakurasi informasi yang termuat pada situs ini atau informasi yang seharusnya ada, namun belum tersedia, maka harap segera hubungi Kepaniteraan Mahkamah Agung RI melalui :

5 Tahun 2014 Pasal 87 ayat (4) huruf b.
a. Melanggar asas kecermatan/ketelitian, dalam arti TERGUGAT
telah/tidak menerapkan prinsip kecermatan/ketelitian terhadap data
yuridis  yang  disampaikan  sewaktu  memproses  penerbitan  objek
gugatan  serta  mengabaikan  kepentingan  PENGGUGAT.  Karena
bila mengacu pada asas-asas Peraturan Perundang-Undangan ini
sangat jelas  bahwa Peraturan Pemerintah Nomor 11 Tahun 2017
Tentang Manajemen Pegawai Negeri Sipil ini adalah berlaku surut,
yang seyogyanya asas Perundang-Undangan tidak boleh berlaku
surut (retroaktif).
b. Bahwa  TERGUGAT  juga  melanggar  Asas  Legalitas,  Asas
Legalitas tidak hanya dikenal  dalam hukum pidana sebagimana
dalam pasal 1 ayat (1) KUHP juga dalam HAM, Asas Legalitas
dalam  Hukum  Adminidtrasi  Negara  adalah  Asas  Legalitas
mengandung  makna  setiap  Pejabat  Tata  Usaha  Negara  yang
hendak mengeluarkan keputusan atau melakukan tindakan harus
berdasarkan pada peraturan Perundang-Undangan. Yaitu peraturan
yang berlaku secara positif di Indonesia yaitu hak kepastian hukum
dan hak untuk tidak dituntut atas dasar hukum yang berlaku surut
ke belakang.
c. Bahwa  TERGUGAT  juga  melanggar  asas  perlindungan
terhadap  hak  asasi  manusia,   sebagaimana  didalam  Undang-
Undang  No. 39  Tahun  1999 Tentang Hak Asasi Manusia dalam
Pasal  4  dan  Undang-Undang  Dasar  1945  Pasal  28  I  yang
menegaskan:  “Hak  untuk  hidup,hak  untuk  tidak  disiksa,  hak
kebebasan  pribadi,  pikiran  dan  hati  nurani,  hak  beragama,  hak
untuk  tidak  diperbudak,  hak  untuk  diakui  sebagai  pribadi  dan
persamaan dimata hukum, dan hak untuk tidak dituntut atas dasar
hukum yang berlaku surut  adalah hak asasi manusia yang tidak
dapat dikurangi dalam keadaan apapun dan oleh siapapun” 
20. Bahwa akibat tindakan TERGUGAT yang bertentangan dengan
peraturan  Perundang-Undangan  sebagaiman  tersebut  diatas,  maka
dengan terbitnya objek gugatan harus dinyatakan batal atau tidak sah.
21. Bahwa berdasarkan uraian diatas alasan-alasan PENGGUGAT
yang  menyatakan  objek  sengketa  merupakan  keputusan  yang
bertentangan dengan peraturan perundang-undangan yang berlaku,
sebagaimana dimaksud dalam Pasal 53 ayat (2) huruf a UU PTUN,

Kepaniteraan Mahkamah Agung Republik Indonesia berusaha untuk selalu mencantumkan informasi paling kini dan akurat sebagai bentuk komitmen Mahkamah Agung untuk pelayanan publik, transparansi dan akuntabilitas
pelaksanaan fungsi peradilan. Namun dalam hal-hal tertentu masih dimungkinkan terjadi permasalahan teknis terkait dengan akurasi dan keterkinian informasi yang kami sajikan, hal mana akan terus kami perbaiki dari waktu kewaktu.
Dalam hal Anda menemukan inakurasi informasi yang termuat pada situs ini atau informasi yang seharusnya ada, namun belum tersedia, maka harap segera hubungi Kepaniteraan Mahkamah Agung RI melalui :

yaitu telah bertentangan dengan peraturan perundang-undangan yang
berlaku baik itu secara prosedural/formal, material/subtansial dan juga
telah dilakukan dengan cara menyalahgunakan kewenangan, dengan
uraian sebagai berikut;
1. Objek  sengketa  bertentangan  dengan  ketentuan  peraturan
perundang-undangan  yang  bersifat  material/subtansial
(inhoudsgebreken), yang dalam prakteknya, hal ini menyangkut isi
objek  sengketa  yang  bertentangan  dengan  peraturan  dasarnya,
ataupun peraturan yang lebih tinggi, yaitu antara lain;
a) Bahwa  objek  sengketa  dalam  perkara  a  quo diterbitkan
berdasarkan salah satunya Pasal 87 ayat (4) huruf b Undang-
Undang Nomor 5 Tahun 2014 Tentang ASN yang menyebutkan “
PNS diberhentikan tidak dengan hormat”
Huruf b “Dihukum penjara atau kurungan berdasarkan putusan
pengadilan yang telah memiliki kekuatan hukum tetap karena
melakukan tindak pidana kejahatan jabatan atau tindak pidana
kejahatan yang ada hubungannya dengan jabatan/atau pidana
umum” 
b) Selain itu, berdasarkan pasal 250 Peraturan Pemerintah Nomor
11  Tahun  2017  Tentang  Manajemen  Pegawai  Negeri  Sipil
menyebutkan: “PNS diberhentikan tidak dengan hormat” Huruf b;
Dihukum  penjara  atau  kurungan  berdasarkan  putusan
pengadilan yang telah memiliki kekuatan hukum tetap karena
melakukan tindak pidana kejahatan jabatan atau tindak pidana
kejahatan yang ada hubungannya dengan jabatan/atau pidana
umum”
c) Bahwa kemudian pasal 252 Peraturan Pemerintah Nomor 11
tahun  2017  tentang  Manajemen  PNS  menyebutkan  bahwa
“pemberhentian sebagaimana dimaksud dalam huruf b dan huruf
d  dan pasal 251  ditetapkan terhitung  mulai  akhir bulan sejak
putusan  pengadilan  atas  perkaranya  yang  telah  memiliki
kekuatan hukum tetap”
d) Bahwa objek sengketa diterbitkan pada tanggal, 31 Desember
2018  dan  berlaku  terhitung  Tanggal,  26  April  2016,  sehingga
objek sengketa telah bertentangan dengan peraturan perundang-
undangan yaitu PP Nomor 11 Tahun 2017 Tentang Manajemen
PNS  Pasal  252  yang  mengatur  bahwa;  “Pemberhentian  PNS

Kepaniteraan Mahkamah Agung Republik Indonesia berusaha untuk selalu mencantumkan informasi paling kini dan akurat sebagai bentuk komitmen Mahkamah Agung untuk pelayanan publik, transparansi dan akuntabilitas
pelaksanaan fungsi peradilan. Namun dalam hal-hal tertentu masih dimungkinkan terjadi permasalahan teknis terkait dengan akurasi dan keterkinian informasi yang kami sajikan, hal mana akan terus kami perbaiki dari waktu kewaktu.
Dalam hal Anda menemukan inakurasi informasi yang termuat pada situs ini atau informasi yang seharusnya ada, namun belum tersedia, maka harap segera hubungi Kepaniteraan Mahkamah Agung RI melalui :

yang terlibat pidana” haruslah ditetapkan terhitung mulai akhir
bulan  sejak  putusan  pengadilan  atas  perkaranya  yang  telah
memiliki kekuatan hukum tetap/incraht” 
e) Bahwa  oleh  karena  PENGGUGAT  telah  diberhentikan  oleh
TERGUGAT  dengan  surat  keputusan  yang  menjadi  objek
sengketa  pada  Tanggal,  31  Desember  2018  maka  Peraturan
Pemerintah Nomor 11 Tahun 2017 Pasal 250 Huruf b tidak dapat
diberlakukan kepada PENGGUGAT
f) Bahwa  objek  sengketa  ditetapkan  dan  mengunakan  asas
retroaktif yang bertentangan dengan Undang-Undang Nomor 12
Tahun  2011  Tentang  Pembentukan  Peraturan  Perundang-
Undangan,  sebagaimana  disebutkan  pada  Bab  I  Angka  131
Lampiran II Undang-Undang Nomor 12 Tahun 2011, Yaitu: “Jika
suatu  peraturan  perundang-undangan  diberlakukan  surut,
peraturan perundangan-undanagn tersebut hendaknya memuat
ketentuan  mengenai  status  dari  tindakan  hukum  hukum  yang
terjadi,  atau  hubungan  hukum  yang  ada  di  dalam  tenggang
waktu antara tanggal mulai berlaku surut dan tanggal berlaku
pengundangannya.”
2. Bahwa  disamping  alasan  pada  huruf  a  diatas,  pada
kenyataannya objek sengketa merupakan bertentangan dengan
Asas-Asas  Umum  Pemerintahan  Yang  Baik  (AAUPB)
sebagaimana dimaksud dalam pasal 53 Ayat (2) huruf b Undang-
Undang PTUN, yaitu In casu khususnya asas kepastian hukum,
Asas  Tertib  Peyelengara  Negara,  dan  Asas  Profesionalitas
sebagaimana  dimaksud  dalam  Pasal  3  UU  Nomor  28  Tahun
1999 Tentang Penyelenggaraan Negara yang bersih dan bebas
dari  Korupsi,  Kolusi  dan  Nepotisme,  dengan  uraian  sebagai
berikut;
a) Objek  sengketa  bertentangan  dengan  asas  kepastian
hukum,  yaitu  sebagaimana  diuraikan  diatas  bahwa  jelas
TERGUGAT  dalam  menerbitkan  objek  sengketa  tidak
mengutamakan  ladasan  peraturan  perudang-undanagn,
kepatutan,  dan  keadilan  dalan  setiap  kebijakan/tindakan
peyelenggara Negara.
b) Bahwa objek sengketa bertentangan dengan asas tertib
peyelenggaraan Negara, yaitu sebagaimana diuraikan bahwa

Kepaniteraan Mahkamah Agung Republik Indonesia berusaha untuk selalu mencantumkan informasi paling kini dan akurat sebagai bentuk komitmen Mahkamah Agung untuk pelayanan publik, transparansi dan akuntabilitas
pelaksanaan fungsi peradilan. Namun dalam hal-hal tertentu masih dimungkinkan terjadi permasalahan teknis terkait dengan akurasi dan keterkinian informasi yang kami sajikan, hal mana akan terus kami perbaiki dari waktu kewaktu.
Dalam hal Anda menemukan inakurasi informasi yang termuat pada situs ini atau informasi yang seharusnya ada, namun belum tersedia, maka harap segera hubungi Kepaniteraan Mahkamah Agung RI melalui :

jelas TERGUGAT dalam menerbitkan objek sengketa TELAH
MENGABAIKAN  asas  yang  menjadi  landasan  untuk
terjaminya keteraturan, keserasian, dan keseimbangan dalam
pengendalian peyelenggaraan Negara. 
c) Bahwa  objek  sengketa  bertentangan  dengan  asas
Profesionalisme,  yaitu  sebagaimana  diuraikan  bahwa  jelas
TERGUGAT  dalam  menerbitkan  objek  sengketa  yang
diputuskan,  sepertinya  lalai  bahkan  terkesan  segaja
memaksakan  kehendaknya  untuk  memberhentikan
PENGGUGAT dengan sewenang-wenang.
Atas hal-hal tersebut, makan cukup bagi PENGGUGAT untuk mengajukan
dan menyelesaikan permasalahan ini melalui Pengadilan Tata Usaha Negara
Samarinda.
Bahwa  berdasarkan  hal-hal  yang  sudah  terurai  diatas  terhadap  objek
sengketa selain bertentangan dengan Peraturan Perundang-Undangan yang
berlaku juga bertentangan dengan Asas Umum Pemerintahan Yang Baik,
maka terhadap objek sengketa patutlah dinyatakan batal atau tidak sah dan
oleh  karenanya  patut  pula  diperintahkan  kepada  TERGUGAT  untuk
mencabut objek sengketa tersebut.

## VI. PERMOHONAN PUTUSAN

Bahwa berdasarkan uraian dan alasan-alasan sebagaimana tersebut diatas,
PENGGUGAT  sangat  berkepentingan  dalam  perkara  ini,  terutama  untuk
melindungi hak-hak PENGGUGAT yang dilindungi oleh hukum.
Bahwa  oleh  karena  itu,  selanjutnya  PENGGUGAT mohon  kepada  Ketua
Pengadilan  Tata  Usaha  Negara  Samarinda  Cq.  Majelis  Hakim  yang
memeriksa  dan  mengadili  perkara  ini  agar  memberikan  putusan  yang
amarnya sebagai berikut:

## VII. DALAM POKOK PERKARA

1. Mengabulkan gugatan PENGGUGAT untuk seluruhnya;
2. Menyatakan batal atau tidak sah Keputusan Bupati Kutai Barat
Nomor: 800.05.860/K.971/2018. Tanggal 31 Desember 2018 Tentang
Pemberhentian Karena Melakukan Tindak Pidana Kejahatan Jabatan
Atau  Tindak  Pidana  Kejahatan  Yang  Ada  Hubungannya  Dengan
Jabatan, atas nama Hansen, SH.,M.Si. NIP: 197203172006041010;

Kepaniteraan Mahkamah Agung Republik Indonesia berusaha untuk selalu mencantumkan informasi paling kini dan akurat sebagai bentuk komitmen Mahkamah Agung untuk pelayanan publik, transparansi dan akuntabilitas
pelaksanaan fungsi peradilan. Namun dalam hal-hal tertentu masih dimungkinkan terjadi permasalahan teknis terkait dengan akurasi dan keterkinian informasi yang kami sajikan, hal mana akan terus kami perbaiki dari waktu kewaktu.
Dalam hal Anda menemukan inakurasi informasi yang termuat pada situs ini atau informasi yang seharusnya ada, namun belum tersedia, maka harap segera hubungi Kepaniteraan Mahkamah Agung RI melalui :

3. Memerintahkan TERGUGAT untuk mencabut Keputusan Bupati
Kutai  Barat  Nomor:  800.05.860/K.971/2018.  Tanggal  31  Desember
2018  Tentang  Pemberhentian  Karena  Melakukan  Tindak  Pidana
Kejahatan  Jabatan  Atau  Tindak  Pidana  Kejahatan  Yang  Ada
Hubungannya  Dengan  Jabatan,  atas  nama  Hansen,SH.,M.Si.  NIP:
197203172006041010;
4. Memerintahkan kepada TERGUGAT dengan kewajiban untuk
merehabilitasi hak-hak dan kedudukan hokum PENGGUGAT sebagai
Pegawai Negeri Sipil Seperti keadaan semula;
5. Menghukum TERGGUGAT untuk membayar semua biaya yang
timbul dalam perkara ini;
Atau; apabila Majelis Hakim berpendapat lain, mohon putusan seadil-adilnya
(Ex ae quo et bono)
   
Menimbang bahwa terhadap gugatan Penggugat tersebut, Tergugat
melalui kuasanya telah mengajukan Jawaban tertanggal 25 September 2019,
yang mengemukakan dalil-dalil bantahan sebagai berikut;   

# DALAM EKSEPSI

1. Gugatan Penggugat telah lewat waktu ( kadaluarsa ). 
Bahwa sesuai ketentuan Pasal 55 Undang-Undang Nomor 5 Tahun
1986 tentang PeradilanTata Usaha Negara, sebagaimana telah diubah
dengan Undang-Undang Nomor 9 Tahun 2004, sangat tegas dan jelas
menyebutkan : 
   Gugatan dapat diajukan hanya dalam tenggang waktu 90 (sembilan
puluh)  hari  terhitung  sejak  saat  diterimanya  atau  diumumkannya
Keputusan Badan atau Pejabat Tata Usaha Negara. 
   Selanjutnya, dalam penjelasan pasal tersebut dijelaskan pula, bahwa
bagi pihak yang namanya tersebut dalam Keputusan Tata Usaha Negara
yang digugat, maka tenggang waktu Sembilan puluh hari itu, dihitung
sejak diterimanya Keputusan Tata Usaha Negara yang digugat;
   Bahwa obyek sengketa (vide Keputusan Bupati Kutai Barat Nomor :
800.05.860/K.971/2018  tanggal  31  Desember  2018  tentang
Pemberhentian  Karena  Melakukan  Tindak  Pidana  Kejahatan  Jabatan
Atau Tindak Pidana Kejahatan Yang ada Hubungannya Dengan Jabatan
atas  nama  Hansen,SH.,M.Si)  diterima  /  diketahui  Penggugat  sejak
tanggal  03  Mei  2019 .  Hal  ini,  diketahui  dari  Surat  Kepala  Dinas

Kepaniteraan Mahkamah Agung Republik Indonesia berusaha untuk selalu mencantumkan informasi paling kini dan akurat sebagai bentuk komitmen Mahkamah Agung untuk pelayanan publik, transparansi dan akuntabilitas
pelaksanaan fungsi peradilan. Namun dalam hal-hal tertentu masih dimungkinkan terjadi permasalahan teknis terkait dengan akurasi dan keterkinian informasi yang kami sajikan, hal mana akan terus kami perbaiki dari waktu kewaktu.
Dalam hal Anda menemukan inakurasi informasi yang termuat pada situs ini atau informasi yang seharusnya ada, namun belum tersedia, maka harap segera hubungi Kepaniteraan Mahkamah Agung RI melalui :

Pemberdayaan Masyarakat Dan Kampung Kabupaten Kutai Barat yang
ditujukan kepada HANSEN,SH.,M.Si agar menghadap bapak Faustinus
Syaidirahman,S.Sos.,MM pada hari Jum’at tanggal 03 Mei 2019, untuk
menerima Keputusan Bupati Kutai Barat Nomor : 800.05.860/K.971/2018
tanggal 31 Desember 2018 tentang Pemberhentian Karena Melakukan
Tindak Pidana Kejahatan Jabatan Atau Tindak Pidana Kejahatan Yang
ada Hubungannya Dengan Jabatan, kemudian Penggugat mendaftarkan
gugatannya di Pengadilan Tata Usaha Negara Samarinda pada tanggal
20 Agustus 2019  dengan Register Perkara Nomor : 43 / G / 2019 /
PTUN.SMD; 
   Bahwa dari ketentuan Pasal 55 Undang-Undang Nomor 5 Tahun 1986
tentang Peradilan Tata Usaha Negara, dihubungkan dengan tenggang
waktu pengajuan gugatan Penggugat (tanggal 20 Agustus 2019),  telah
melebihi  90  (Sembilan  puluh)  hari,  sehingga  sabagai  konsekuensi
hukumnya, gugatan Penggugat harus dinyatakan tidak dapat diterima; 
 
2. Upaya Administrasi diajukan setelah melewati waktu pengajuan
gugatan. 
Bahwa  Penggugat  mengajukan  upaya  administrasi  terhadap  obyek
sengketa (Keputusan Bupati Kutai Barat Nomor : 800.05.860/K.971/2018
tanggal 31 Desember 2018 tentang Pemberhentian Karena Melakukan
Tindak Pidana Kejahatan Jabatan Atau Tindak Pidana Kejahatan Yang
Ada Hubungannya Dengan Jabatan) setelah melewati waktu pengajuan
gugatan ( vide Pasal 55 UU No.5 Tahun 1986), yakni : pada tanggal 1
Agustus 2019.  Hal ini, diketahui dari surat Sekretaris Daerah (Sekda)
Kabupaten Kutai Barat yang ditujukan kepada Kabag Hukum tertanggal
1 Agustus 2019 dengan perintah : Segera tanggapi surat ini dengan
dasar hukum yang kuat dan jelas;   
3. Upaya administratif yang dilakukan oleh Penggugat tidak sesuai
dengan  ketentuan Peraturan Perundang-undangan.
Bahwa  sesuai  dengan  ketentuan  Pasal  48  Undang-Undang  Nomor  5
Tahun  1986  tentang  Peradilan  Tata  Udaha  Negara,  tidak  setiap
Keputusan Tata Usaha Negara sebagai objek sengketa dapat langsung
digugat melalui Pengadilan Tata Usaha Negara, karena apabila tersedia
Upaya Administratif maka sengketa tata usaha Negara tersebut harus

Kepaniteraan Mahkamah Agung Republik Indonesia berusaha untuk selalu mencantumkan informasi paling kini dan akurat sebagai bentuk komitmen Mahkamah Agung untuk pelayanan publik, transparansi dan akuntabilitas
pelaksanaan fungsi peradilan. Namun dalam hal-hal tertentu masih dimungkinkan terjadi permasalahan teknis terkait dengan akurasi dan keterkinian informasi yang kami sajikan, hal mana akan terus kami perbaiki dari waktu kewaktu.
Dalam hal Anda menemukan inakurasi informasi yang termuat pada situs ini atau informasi yang seharusnya ada, namun belum tersedia, maka harap segera hubungi Kepaniteraan Mahkamah Agung RI melalui :

diselesaikan terlebih dahulu melalui Upaya Administratif yang tersedia
sebelum diselesaikan melalui Pengadilan Tata Usaha Negara.
Lebih lanjut dalam Bab X tentang Upaya Administratif, Pasal 75 sampai
dengan  pasal  78  Undang-Undang  Nomor  30  Tahun  2014  tentang
Administrasi  Pemerintahan,  diatur  2  (dua)  bentuk  upaya  admnistratif
yang  dapat  dilakukan  sebagai  proses  penyelesaian  sengketa  akibat
dikeluarkannya  Keputusan  dan/atau  Tindakan  yang  merugikan  yaitu
Banding Administratif dan Keberatan. Selanjutnya disebutkan pula dalam
Pasal 75 ayat (3), “ Upaya Administratif tidak menunda pelaksanaan
Keputusan  dan/atau  tindakan  kecuali  ditentukan  lain  dalam
undang-undang dan menimbulkan kerugian yang lebih besar “
Kemudian dalam Pasal 77 ayat (1) Undang-Undang Nomor 30 Tahun 2014
disebutkan  “  Keputusan  dapat  diajukan  keberatan  dalam  waktu
paling lama 21 (dua puluh satu) hari kerja sejak diumumkannya
Keputusan tersebut oleh Badan dan/atau Pejabat Pemerintahan “.
Bahwa  jika  dihitung  jangka  waktu  21  (dua  puluh  satu)  hari  kerja  dari
diterbitkannya  objek  sengketa  yaitu  tanggal  31  Desember  2018,
seharusnya Upaya Admnistratif berupa Keberatan yang dilakukan oleh
Penggugat paling lambat diajukan sebelum tanggal 30 Januari 2019.
Ataupun bila dihitung dari tanggal diterimanya/diketahuinya Keputusan
yang  menjadi  objek  sengketa  yaitu  tanggal  03  Mei  2019,  maka
seharusnya Upaya Keberatan  tersebut paling lama diajukan sebelum
tanggal 04 Juni 2019,  b u k a n   baru diajukan pada tanggal 16 Juli
2019  (dinyatakan  salah  alamat  karena  ditujukan  langsung  kepada
Gubernur) dan diajukan untuk kedua kalinya pada tanggal 30 Juli 2019.
Bahwa Penggugat mendalilkan dalam gugatannya pada halaman 2 poin
ke-2  tentang  Upaya  Admnistratif,  karena  sampai  saat  gugatan  ini
diajukan dan Tergugat belum memberikan jawaban atas permohonan
Penggugat,  maka  berdasarkan  Pasal  53  Undang-Undang  Nomor  30
Tahun  2014  Tentang  Administrasi  Pemerintahan,  maka  Penggugat
menganggap Tergugat Telah mengeluarkan Keputusan. Dalil ini adalah
keliru  karena  merujuk  pada  ketentuan  pasal  yang  keliru  pula.
Mengapa  ?  Karena  ketentuan  Pasal  53  Undang-Undang  Nomor  30
Tahun 2014 mengatur tentang batas waktu kewajiban untuk menetapkan

Kepaniteraan Mahkamah Agung Republik Indonesia berusaha untuk selalu mencantumkan informasi paling kini dan akurat sebagai bentuk komitmen Mahkamah Agung untuk pelayanan publik, transparansi dan akuntabilitas
pelaksanaan fungsi peradilan. Namun dalam hal-hal tertentu masih dimungkinkan terjadi permasalahan teknis terkait dengan akurasi dan keterkinian informasi yang kami sajikan, hal mana akan terus kami perbaiki dari waktu kewaktu.
Dalam hal Anda menemukan inakurasi informasi yang termuat pada situs ini atau informasi yang seharusnya ada, namun belum tersedia, maka harap segera hubungi Kepaniteraan Mahkamah Agung RI melalui :

dan/atau  melakukan  Keputusan  dan/atau  Tindakan  sesuai  dengan
pengertian Keputusan pada Pasal 1 angka 7 Undang-Undang Nomor 30
Tahun  2014  bukan  mengenai  Keputusan  terhadap  permohonan
Keberatan yang diatur dalam Pasal 77 Undang-Undang Nomor 30 Tahun
2014.
Pasal  77  ayat (3)  disebutkan,  “  Dalam  hal  keberatan  diterima,  Badan
dan/atau  Pejabat  Pemerintahan  wajib  menetapkan  Keputusan  sesuai
permohonan keberatan “. Selanjutnya pada Pasal 77 ayat (4) dan ayat
(5) disebutkan,  “Badan dan/atau Pejabat Pemerintahan menyelesaikan
keberatan paling lama 10 (sepuluh) hari kerja dan dalam hal Badan
dan/atau Pejabat Pemerintahan tidak menyelesaikan keberatan dalam
jangka waktu tersebut, maka keberatan dianggap dikabulkan “.
Penggugat  telah  keliru  menganggap  Tergugat  telah  mengeluarkan
Keputusan  karena  Tergugat  belum  memberikan  jawaban  atas
permohonan  Keberatan  Penggugat.  Dan  salah  pula  bila  dikatakan
Keberatan  dianggap  dikabulkan  karena  dalam  tenggat waktu  10  hari
kerja  yang  ditentukan,  Tergugat  tidak  menyelesaikan  permohonan
keberatan,  karena hingga batas waktu 21 (dua puluh satu) hari kerja
yang  telah  ditentukan  oleh  undang-undang,  Penggugat  tidak
menggunakan  kesempatan  Upaya  Administratif  untuk  mengajukan
keberatan, dan baru mengajukan keberatan lagi tanggal 30 Juli 2019
yang telah lewat batas waktunya. Sehingga dapat dikatakan Penggugat
menerima Keputusan Tergugat yang menjadi objek sengketa. 
Dengan  demikian,  karena  Penggugat  mengajukan  Upaya  Administrasi
terhadap obyek sengketa setelah melewati tenggang waktu pengajuan
gugatan,  maka  menurut  hukum  dianggap  tidak  melakukan  upaya
administrasi sebelum mengajukan ke Pengadilan Tata Usaha  Negara
Samarinda, sebagaimana yang diamanatkan oleh Peraturan Mahkamah
Agung  RI  Nomor  6  Tahun  2018  tentang  Pedoman  Penyelesaian
Sengketa  Administrasi  Pemerintahan  Setelah  Menempuh  Upaya
Adminstrasif;  
Bahwa kalau seandainya (quad non) Penggugat dapat dibenarkan telah
menempuh upaya administrasi, maka berdasarkan ketentuan Pasal 15
ayat (3) Undang-Undang Nomor 9 Tahun 2004 tentang Perubahan atas
Undang-Undang Nomor 5 Tahun 2004 tentang Peradilan Tata Usaha
Negara, secara tegas menentukan :  

Kepaniteraan Mahkamah Agung Republik Indonesia berusaha untuk selalu mencantumkan informasi paling kini dan akurat sebagai bentuk komitmen Mahkamah Agung untuk pelayanan publik, transparansi dan akuntabilitas
pelaksanaan fungsi peradilan. Namun dalam hal-hal tertentu masih dimungkinkan terjadi permasalahan teknis terkait dengan akurasi dan keterkinian informasi yang kami sajikan, hal mana akan terus kami perbaiki dari waktu kewaktu.
Dalam hal Anda menemukan inakurasi informasi yang termuat pada situs ini atau informasi yang seharusnya ada, namun belum tersedia, maka harap segera hubungi Kepaniteraan Mahkamah Agung RI melalui :

Pengadilan  Tinggi  Tata  Usaha  Negara bertugas  dan  berwenang
memeriksa, memutus dan  menyelesaikan  ditingkat pertama  sengketa
Tata Usaha Negara sebagaimana dimaksud dalam Pasal 48 (vide pasal
48 UU No.9 Tahun 2004 ttg Perubahan atas UU No.5 Tahun 1986 ttg
Peradilan Tata Usaha Negara); 
Dengan berpedoman pada ketentuan-ketentuan hukum di atas, jelaslah
bahwa  Pengadilan  Tata  Usaha  Negara  Samarinda  tidak  berwenang
memeriksa, memutus dan menyelesaikan sengketa a’quo;  
Bahwa dari apa yang secara keseluruhan terurai di atas, sangatlah jelas
bahwa :  
1. Gugatan  Penggugat  telah  daluarsa,  karena  diajukan  melebihi
tenggang waktu yang ditentukan oleh Undang-Undang;  
2. Pengadilan Tata Usaha Negara Samarinda tidak berwenang mengadili
perkara a’quo, yang berwenang adalah Pengadilan Tinggi Tata Usaha
Negara; 
MAKA, dengan demikian sudah seharusnyalah menurut hukum gugatan ini
dinyatakan  “ tidak dapat diterima “  (niet onvankelijk verklaard),  tanpa
perlu lagi memeriksa pokok perkaranya.  

# DALAM POKOK PERKARA

Namun, jika sekiranya Pengadilan berpendirian lain dengan apa yang telah
terurai di atas dan menolak eksepsi Tergugat, sehingga perlu memeriksa
pokok  perkara,  maka  untuk  mudah  dan  sederhananya  mohon  agar
Pengadilan menerima apa yang terurai dalam eksepsi tersebut telah terurai
ulang pula dalam pokok perkara ini;  
1. Bahwa  pertama-tama  dan  utama  Tergugat  menolak  dengan  tegas
seluruh dalil-dalil gugatan Penggugat, kecuali hal-hal yang akan diakui
secara tegas kebenarannya;  
2. Bahwa memang benar, apa yang didalilkan Penggugat pada angka VI
romawi, poin 1, 2, 3 dan 4 posita gugatan :
2.1. Penggugat  adalah  seorang  Pegawai  Negeri  Sipil  (PNS)
diangkat  berdasarkan  Keputusan  Kepala  Badan  Kepegawaian
Negara  Nomor  :  0002/KV/VIII/26402/KEP/2008  tanggal  06
Oktober 2008 dengan NIP : 197203172006041010 dilingkungan
Pemerintah Kabupaten Kutai   Barat; 

Kepaniteraan Mahkamah Agung Republik Indonesia berusaha untuk selalu mencantumkan informasi paling kini dan akurat sebagai bentuk komitmen Mahkamah Agung untuk pelayanan publik, transparansi dan akuntabilitas
pelaksanaan fungsi peradilan. Namun dalam hal-hal tertentu masih dimungkinkan terjadi permasalahan teknis terkait dengan akurasi dan keterkinian informasi yang kami sajikan, hal mana akan terus kami perbaiki dari waktu kewaktu.
Dalam hal Anda menemukan inakurasi informasi yang termuat pada situs ini atau informasi yang seharusnya ada, namun belum tersedia, maka harap segera hubungi Kepaniteraan Mahkamah Agung RI melalui :

2.2. Penggugat menerima kenaikan Pangkat Pertama berdasarkan
Surat Keputusan Bupati No.823.3/1141/BKD-DKP/IX/2015 tanggal
10  September  2015,  terhitung  mulai  tanggal  01  Januari  2015
dalam  Jabatan  Kepala  Seksi  Kebandarudaraan  Eselon  IV.a
dengan Golongan III/c;  
2.3. Pengugat juga telah menerima kenaikan pangkat berdasarkan
Surat  Pernyataan  Menduduki  Jabatan  No.821.4/1460/BKPPD-
VI/2018 dengan Jabatan Kepala Seksi Fasilitas Kerjasama Antar
Kampung pada Dinas Pemberdayaan Masyarakat dan Kampung
Kabupaten Kutai Barat tanggal 07 Juni 2018, Penata Tk.I (III/d);  
3. Bahwa memang benar, apa yang didalilkan Penggugat pada angka 5
posita gugatan, Penggugat adalah merupakan Terpidana kasus korupsi
yang telah dijatuhi hukuman pidana penjara selama  1 (satu) Tahun 4
(empat) Bulan dan denda sejumlah Rp.50.000.000,00 (lima puluh juta
rupiah) dengan ketentuan apabila denda tersebut tidak dibayar diganti
dengan pidana kurungan selama  2 (dua) Bulan  berdasarkan putusan
Pengadilan Tindak Pidana Korupsi Pada Pengadilan Negeri Samarinda
Nomor : 60/Pid.Sus-TPK/2015/PN.Smr tanggal 26 April 2016, putusan
mana telah berkekuatan hukum tetap; 
4. Bahwa memang benar, apa yang didalilkan Penggugat pada angka 6
posita gugatan, bahwa Penggugat selaku Pegawai Negeri Sipil (PNS)
telah diberhentikan tidak dengan hormat (PTDH) berdasarkan Keputusan
Bupati Kutai Barat Nomor : 800.05.860/K.971/2018 tanggal 31 Desember
2018  tentang  Pemberhentian  Karena  Melakukan  Tindak  Pidana
Kejahatan  Jabatan  Atau  Tindak  Pidana  Kejahatan  Yang  Ada
Hubungannya Dengan Jabatan; 
5. Bahwa adapun kronologis dan landasan hukum terbitnya Keputusan
Bupati Kutai Barat Nomor : 800.05.860/K.971/2018 tanggal 31 Desember
2018  tentang  Pemberhentian  Karena  Melakukan  Tindak  Pidana
Kejahatan  Jabatan  Atau  Tindak  Pidana  Kejahatan  Yang  Ada
Hubungannya Dengan Jabatan, adalah sebagai berikut : 
5.1. Bahwa pada tanggal 10 September 2018, terbit Surat Edaran
Menteri  Dalam  Negeri   Nomor  :  180/6867/SJ  tanggal  10
September 2018. Dalam Surat Edaran tersebut Menteri Dalam
Negeri  (Mendagri)  meminta  kepada  para  Bupati/Wali  Kota  di
seluruh  Indonesia  untuk  segera  memberhentikan  dengan  tidak

Kepaniteraan Mahkamah Agung Republik Indonesia berusaha untuk selalu mencantumkan informasi paling kini dan akurat sebagai bentuk komitmen Mahkamah Agung untuk pelayanan publik, transparansi dan akuntabilitas
pelaksanaan fungsi peradilan. Namun dalam hal-hal tertentu masih dimungkinkan terjadi permasalahan teknis terkait dengan akurasi dan keterkinian informasi yang kami sajikan, hal mana akan terus kami perbaiki dari waktu kewaktu.
Dalam hal Anda menemukan inakurasi informasi yang termuat pada situs ini atau informasi yang seharusnya ada, namun belum tersedia, maka harap segera hubungi Kepaniteraan Mahkamah Agung RI melalui :

hormat  Aparatur  Sipil  Negera  (ASN)  yang  melakukan  tindak
pidana korupsi dan telah mendapatkan putusan inkracht sesuai
dengan ketentuan peraturan perundang-undangan yang berlaku,
karena  dinilai  tindak  pidana  korupsi  merupakan  extra  ordinary
crime yang pemberantasannya harus dilakukan secara luar biasa
dan sanksi yang tegas bagi yang melakukannya ;  
5.2. Bahwa pada tanggal 13 September 2018, terbit Surat Keputusan
Bersama  Menteri  Dalam  Negeri,  Menteri  Pendayagunaan
Aparatur  Negara  dan  Reformasi  Birokrasi  dan  Kepala  Badan
Kepegawaian Negara Nomor : 182/6597/SJ, Nomor : 15 Tahun
2018,  Nomor  :  153/KEP/2018  tentang  Penegakan  Hukum
terhadap  Pegawai  Negeri Sipil  yang  telah  dijatuhkan  hukuman
berdasarkan Putusan Pengadilan yang berkekuatan hukum tetap
karena melakukan tindak pidana kejahatan jabatan atau tindak
pidana kejahatan yang ada hubungannya dengan jabatan. Pada
Diktum  KEDUA  Keputusan  bersama  ini,  sangat  tegas
menyebutkan :   
a. Penjatuhan sanksi berupa pemberhentian tidak dengan
hormat sebagai PNS oleh Pejabat Pembina Kepegawaian dan
Pejabat  Yang  Berwenang  kepada  PNS  yang  telah  dijatuhi
hukuman berdasarkan putusan pengadilan yang berkekuatan
hukum  tetap  karena  melakukan  tindak  pidana  kejahatan
jabatan atau tindak pidana kejahatan yang ada hubungannya
dengan jabatan;  
b. Penjatuhan  sanksi  kepada  Pejabat  Pembina
Kepegawaian  dan  Pejabat  Yang  Berwenang  yang  tidak
melaksanakan  penjatuhan  sanksi  sebagaimana  dimaksud
pada huruf a;
Kemudian  pada  Diktum  KETIGA,  memberi  batasan  waktu
penyelesaian ruang lingkup Keputusan Bersama ini sebagaimana
dimaksud pada Diktum Kedua paling lama bulan Desember 2018;
5.3. Bahwa  pada  tanggal  2  Oktober  2018,  terbit  Surat  Kepala
Badan Kepegawaian Negara Nomor : K.26-30/V.139-8/99, prihal
surat  penyampaian  data  PNS  yang  dihukum  penjara  atau
kurungan karena melakukan tindak pidana kejahatan atau tindak
pidana  kejahatan  yang  ada  hubungannya  dengan  jabatan  dan

Kepaniteraan Mahkamah Agung Republik Indonesia berusaha untuk selalu mencantumkan informasi paling kini dan akurat sebagai bentuk komitmen Mahkamah Agung untuk pelayanan publik, transparansi dan akuntabilitas
pelaksanaan fungsi peradilan. Namun dalam hal-hal tertentu masih dimungkinkan terjadi permasalahan teknis terkait dengan akurasi dan keterkinian informasi yang kami sajikan, hal mana akan terus kami perbaiki dari waktu kewaktu.
Dalam hal Anda menemukan inakurasi informasi yang termuat pada situs ini atau informasi yang seharusnya ada, namun belum tersedia, maka harap segera hubungi Kepaniteraan Mahkamah Agung RI melalui :

Contoh  Keputusan  Pemberhentian  tidak  hormat  sebagai  PNS.
Dalam  surat tersebut menyampaikan  Data  PNS yang dihukum
penjara,  termasuk  didalamnya  Data  PNS  atas  nama
HANSEN,SH.,M.Si  ( Penggugat ), sekaligus memberikan
contoh Keputusan Pemberhentian tidak hormat sebagai PNS; 
5.4. Bahwa  pada  tanggal  18  Oktober  2018,  terbit  Surat  Kepala
Badan Kepegawaian Daerah Provinsi Kalimantan Timur Nomor :
800/V.1-6055/BKD, perihal penyampaian data PNS yang terkena
Tipikor. Dalam surat tersebut menyampaikan Daftar PNS Yang
Terlibat  Tipikor  Pada  Pemerintah  Kabupaten  Kutai  Barat,
diantaranya  termasuk  PNS  atas  nama  HANSEN,SH,  M.Si
(Penggugat);   
5.5. Bahwa pada tanggal 11 September 2018, Sekretaris Daerah
Kabupaten Kutai Barat bersurat kepada Kepala Kejaksaan Negeri
Kabupaten Kutai Barat Nomor : 800/4639/BKPPD-TU.P/XII/2018,
perihal permintaan Salinan Putusan Tipikor;  
5.6. Bahwa pada tanggal 7 Januari 2019, Bupati Kabupaten Kutai
Barat bersurat kepada Kepala Kejaksaan Negeri Kabupaten Kutai
Barat  Nomor : 862/058/BKPPD-TU.P/I/2019, perihal permintaan
Salinan Putusan Tipikor; 
5.7. Bahwa pada tanggal 15 Januari 2019, Surat balasan Kepala
Kejaksaan  Negeri  Kutai  Barat  Nomor  :  B-
37/Q.4.19/Fuh.1/01/2019, perihal permintaan Salinan Keputusan
Tindak  Pidana  Korupsi.  Pada  surat  tersebut  disampaikan  data
Aparatur Sipil Negara Kabupaten Kutai Barat yang telah terbukti
bersalah melakukan Tindak Pidana Korupsi berdasarkan Putusan
Pengadilan  yang  telah  berkekuatan  hukum  tetap  (incracht),
diantaranya termasuk HANSEN,SH.,M.Si, dihukum berdasarkan
Putusan  Pengadilan  Tindak  Pidana  Korupsi  pada  Pengadilan
Negeri Samarinda Nomor : 60/Pid.Sus-TPK/2015/PN.Smr tanggal
27 April 2018; 
5.8. Bahwa pada tanggal 12 Februari 2019, Badan Kepegawaian
Pendidikan  dan  Pelatihan  Daerah  telah  berkoordinasi  dan
berkonsultasi  serta  menyampaikan  Draf  Surat  Keputusan
pemberhentian tidak dengan hormat kepada PNS yang terkena
tipikor sesuai dengan Surat Kepala Badan Kepegawaian Negara
Nomor : K.26-30/V.139-8/99, perihal surat penyampaian data PNS

Kepaniteraan Mahkamah Agung Republik Indonesia berusaha untuk selalu mencantumkan informasi paling kini dan akurat sebagai bentuk komitmen Mahkamah Agung untuk pelayanan publik, transparansi dan akuntabilitas
pelaksanaan fungsi peradilan. Namun dalam hal-hal tertentu masih dimungkinkan terjadi permasalahan teknis terkait dengan akurasi dan keterkinian informasi yang kami sajikan, hal mana akan terus kami perbaiki dari waktu kewaktu.
Dalam hal Anda menemukan inakurasi informasi yang termuat pada situs ini atau informasi yang seharusnya ada, namun belum tersedia, maka harap segera hubungi Kepaniteraan Mahkamah Agung RI melalui :

yang dihukum penjara atau kurungan karena melakukan tindak
pidana  kejahatan  atau  tindak  pidana  kejahatan  yang  ada
hubungannya  dengan  jabatan  dan  contoh  Keputusan
Pemberhentian  tidak  hormat  sebagai  PNS,  dan  Surat  Kepala
Kejaksaan  Negeri  Kutai  Barat  Nomor  :  B-
37/Q.4.19/Fuh.1/01/2019, perihal permintaan Salinan Keputusan
Tindak Pidana Korupsi kepada Inspektorat Kabupaten Kutai Barat
dengan  Bagian  Hukum  Sekretariat  Daerah  Kabupaten  Kutai
Barat; 
5.9. Bahwa  pada  tanggal  28  Februari  2019,  terbit  Surat  Menteri
Pendayagunaan  Aparatur  Negara  dan  Reformasi  Birokrasi  RI
Nomor  :  B/50/M.SM.0000/2019,  perihal  petunjuk  pelaksanaan
penjatuhan  PTDH oleh PPK  terhadap  PNS yang telah dijatuhi
hukuman  berdasarkan  putusan  Pengadilan  yang  berkekuatan
hukum tetap;  
5.10. Bahwa  sesuai  ketentuan  Pasal  1  angka  5  Peraturan
Pemerintah  Nomor  9  Tahun  2003,  yang  telah  dirubah  dengan
Peraturan Pemerintah Nomor 63 Tahun 2009 tentang Wewenang
Pengangkatan, Pemindahan, dan Pemberhentian Pegawai Negeri
Sipil, menjelaskan :  
Pejabat  Pembina  Kepegawaian  daerah  Kabupaten/Kota  adalah
Bupati/Walikota;
5.11. Bahwa  dari  uraian  dan  ketentuan  hukum  di  atas,
Tergugat  (Bupati  Kutai  Barat)  sebagai  Pejabat  Pembina
Kepegawaian  Daerah  Kabupaten  Kutai  Barat  oleh  peraturan
perundang-undangan  diberi  kewenangan  memberhentikan
Penggugat sebagai  Pegawai  Negeri  Sipil.  Dan, pemberhentian
Penggugat sebagai Pegawai Negeri Sipil setelah adanya Putusan
Pengadilan  Tindak  Pidana  Korupsi  Pada  Pengadilan  Negeri
Samarinda Nomor 60/Pid.Sus-TPK/2015/PN.Smr tanggal 26 April
2016  yang  telah  berkekuatan  hukum  tetap  (incraht)  dan  Surat
Keputusan  Bersama  Menteri  Dalam  Negeri,  Menteri
Pendayaguanaan Aparatur Negara dan Reformasi Birokrasi dan
Kepala  Badan  Kepegawaian  Negara  Nomor  :  182/6597/SJ,
Nomor  :  15  Tahun  2018,  Nomor  :  153/KEP/2018  tanggal  13
September 2018 tentang Penegakan Hukum terhadap Pegawai
Negeri Sipil yang telah dijatuhi hukuman berdasarkan Putusan

Kepaniteraan Mahkamah Agung Republik Indonesia berusaha untuk selalu mencantumkan informasi paling kini dan akurat sebagai bentuk komitmen Mahkamah Agung untuk pelayanan publik, transparansi dan akuntabilitas
pelaksanaan fungsi peradilan. Namun dalam hal-hal tertentu masih dimungkinkan terjadi permasalahan teknis terkait dengan akurasi dan keterkinian informasi yang kami sajikan, hal mana akan terus kami perbaiki dari waktu kewaktu.
Dalam hal Anda menemukan inakurasi informasi yang termuat pada situs ini atau informasi yang seharusnya ada, namun belum tersedia, maka harap segera hubungi Kepaniteraan Mahkamah Agung RI melalui :

Pengadilan  yang  berkekuatan  hukum  tetap.  Oleh  karena  itu,
sangatlah jelas landasan hukum terbitnya Surat Keputusan Bupati
Kutai Barat Nomor : 800.05.860/K.971/2018 tanggal 31 Desember
2018 tentang Pemberhentian Karena Melakukan Tindak Pidana
Kejahatan  Jabatan  Atau  Tindak  Pidana  Kejahatan  Yang  Ada
Hubungannya Dengan Jabatan (obyek sengketa). Hal ini sudah
sesuai dengan yang diamanatkan ketentuan Pasal 87 ayat 4 huruf
b Undang-Undang Nomor 5 Tahun 2014 tentang Aparatur Sipil
Negara, jo Pasal 250 huruf b Peraturan Pemerintah  Nomor 11
Tahun 2017 tentang Manajemen Pegawai Negeri Sipil;  
Dengan demikian, tidaklah berdasar dan beralasan hukum, karenanya
harus ditolak dalil Penggugat yang menyebutkan : “Perbuatan Tergugat
menerbitkan  Keputusan  Bupati  Kutai  Barat  Nomor  :
800.05.860/K.971/2018  tanggal  31  Desember  2018  tentang
Pemberhentian  Karena  Melakukan  Tindak  Pidana  Kejahatan  Jabatan
Atau  Tindak  Pidana  Kejahatan  Yang  Ada  Hubungannya  Dengan
Jabatan”,  adalah  merupakan  perbuatan  yang  bertentangan  dengan
peraturan perundang-undangan yang berlaku dan melanggar azas-azas
umum pemerintah yang baik (AAUPB);  
6. Bahwa terhadap dalil Penggugat pada angka 7 posita gugatan, yang
pada intinya mempertanyakan, “ apakah Penggugat masuk dalam Tindak
Pidana Kejahatan Jabatan atau Tindak Pidana yang ada hubungannya
dengan  Jabatan “; 
Tergugat menanggapinya, sebagai berikut : 
Apa  yang  dimaksud  dengan  Kejahatan  Jabatan  ?.  Menurut  pendapat
Wirjono  Prodjodikiro  :  Kejahatan  Jabatan  adalah  kejahatan  yang
dilakukan oleh Pegawai Negeri Sipil atau Pejabat dengan menggunakan
sarana  dan  prasarana  yang  melekat  dengan  jabatannya  dan  harus
dihukum pidana; 
Bahwa ketentuan Pasal 87 ayat (4) huruf b Undang-Undang Nomor 5
Tahun 2014 tentang Aparatur Sipil Negara, tegas menyebutkan : 
Pegawai  Negeri  Sipil  diberhentikan  dengan  tidak  hormat  :  dihukum
penjara  atau  kurungan  berdasarkan  putusan  Pengadilan  yang  telah
memiliki  kekuatan  hukum  tetap  karena  melakukan  tindak  pidana

Kepaniteraan Mahkamah Agung Republik Indonesia berusaha untuk selalu mencantumkan informasi paling kini dan akurat sebagai bentuk komitmen Mahkamah Agung untuk pelayanan publik, transparansi dan akuntabilitas
pelaksanaan fungsi peradilan. Namun dalam hal-hal tertentu masih dimungkinkan terjadi permasalahan teknis terkait dengan akurasi dan keterkinian informasi yang kami sajikan, hal mana akan terus kami perbaiki dari waktu kewaktu.
Dalam hal Anda menemukan inakurasi informasi yang termuat pada situs ini atau informasi yang seharusnya ada, namun belum tersedia, maka harap segera hubungi Kepaniteraan Mahkamah Agung RI melalui :

kejahatan jabatan atau tindak pidana kejahatan yang ada hubungannya
dengan jabatan;
Bahwa  kemudian  dipertegas  lagi  pada  ketentuan  Pasal  250  huruf  b
Peraturan  Pemerintah  Nomor  11  Tahun  2017  tentang  Manajemen
Pegawai Negeri Sipil, menyebutkan : 
Pegawai Negeri Sipil diberhentikan tidak dengan hormat, apabila dipidana
dengan pidana penjara atau kurungan berdasarkan putusan Pengadilan
yang  telah  memiliki  kekuatan  hukum  tetap  karena  melakukan  tindak
pidana  kejahatan  jabatan  atau  tindak  pidana  kejahatan  yang  ada
hubungannya dengan jabatan;  
Bahwa  Penggugat  (HANSEN,SH.,M.Si)  adalah  Pegawai  Negeri  Sipil
(PNS)  pada  Dinas  Perhubungan,  Komunikasi  dan  Informatika  Kutai
Barat  (PPTK  Dinas  Perhubungan,  Komunikasi  dan  Informatika  Kutai
Barat  TA.2013),  telah  terbukti  secara  sah  dan  meyakinkan  bersalah
melakukan  tindak  pidana  korupsi  berdasarkan  Putusan  Pengadilan
Tindak  Pidana  Korupsi  Pada  Pengadilan  Negeri  Samarinda  Nomor
60/Pid.Sus-TPK/2015/PN.Smr tanggal 26 April 2016, putusan mana telah
berkekuatan hukum tetap; 
Bahwa dengan berpedoman pada doktrin dan ketentuan hukum di atas,
dihubungkan dengan status Penggugat sebagai Pegawai Negeri Sipil
yang telah terbukti menurut hukum melakukan tindak pidana korupsi,
maka jelaslah Penggugat melakukan tindak pidana kejahatan jabatan
atau tindak pidana kejahatan yang ada hubungannya dengan jabatannya
7. Bahwa terhadap dalil Penggugat pada angka 8 posita gugatan, yang
pada intinya mendalilkan, “ bahwa obyek sengketa a’quo adalah cacat
hukum karena Tergugat tidak menjelaskan tindak pidana korupsi yang
mana  persisnya  yang  dilakukan  oleh  Penggugat  “,  dengan  tegas
Tergugat tolak karena : 
7.1. Bahwa obyek sengketa a’quo yang diterbitkan Tergugat tidaklah
cacat hukum sebagaimana yang didalilkan Penggugat;  
7.2. Bahwa dalam konsideran bagian Menimbang obyek sengketa
a’quo telah disebutkan : “ bahwa berdasarkan putusan Pengadilan
Negeri Samarinda Nomor 60/pid.Sus-TPK/2015/PN.Smr tanggal
27 April 2016 yang telah mempunyai kekuatan hukum tetap, Sdr.

Kepaniteraan Mahkamah Agung Republik Indonesia berusaha untuk selalu mencantumkan informasi paling kini dan akurat sebagai bentuk komitmen Mahkamah Agung untuk pelayanan publik, transparansi dan akuntabilitas
pelaksanaan fungsi peradilan. Namun dalam hal-hal tertentu masih dimungkinkan terjadi permasalahan teknis terkait dengan akurasi dan keterkinian informasi yang kami sajikan, hal mana akan terus kami perbaiki dari waktu kewaktu.
Dalam hal Anda menemukan inakurasi informasi yang termuat pada situs ini atau informasi yang seharusnya ada, namun belum tersedia, maka harap segera hubungi Kepaniteraan Mahkamah Agung RI melalui :

HANSEN,SH,M.Si NIP 19720317 200604 1 010 Penata Tingkat I
Golongan Ruang (III/d) dinyatakan telah terbukti secara sah dan
meyakinkan melakukan tindak pidana korupsi, yang merupakan
tindak  pidana  kejahatan  jabatan  atau  tindak  pidana  kejahatan
yang ada hubugannya dengan jabatan “;
7.3. Bahwa  dalam  diktum  putusan  Pengadilan  Tindak  Pidana
Korupsi Pada Pengadilan Negeri Samarinda Nomor : 60/Pid.Sus-
TPK/2015/PN.Smr tanggal 26 April 2016, disebutkan : 
Menyatakan terdakwa HANSEN,SH.M.Si tidak terbukti secara sah
dan meyakinkan bersalah melakukan Tindak Pidana sebagaimana
yang  didakwakan  dalam  dakwaan  Primair,  sehingga
membebaskan terdakwa dari Dakwaan Primair tersebut; 
Namun, dalam diktum berikutnya, disebutkan : 
Menyatakan terdakwa HANSEN,SH.M.Si tersebut di atas, terbukti
secara sah dan meyakinkan bersalah melakukan tindak pidana
“Korupsi secara bersama-sama”, sehingga menjatuhkan pidana
kepada Terdakwa oleh karena itu dengan pidana penjara selama
1  (satu)  Tahun  4  (empat)  bulan  dan  denda  sejumlah
Rp.50.000.000,00  (lima  puluh  juta  rupiah)  dengan  ketentuan
apabila  denda  tersebut  tidak  dibayar  diganti  dengan  pidana
kurungan selama 2 (dua) Bulan; 
7.4. Bahwa  atas  diktum  putusan  tersebut  di  atas,  maka  yang
terbukti adalah Dakwaan Subsidair, melanggar Pasal 3, jo Pasal
18  Undang-Undang  Nomor  31  tahun  1999  tentang
Pemberantasan Tindak Pidana Korupsi sebagaimana yang telah
diubah dan ditambah dengan Undang-Undang Nomor 20 Tahun
2001 tentang Perubahan atas Undang-Undang Nomor 31 Tahun
1999 tentang Pemberantasan Tindak Pidana Korupsi, jo Pasal 55
ayat (1) ke-1 KUHP;  
Pasal  3  Undang-Undang  Nomor  31  tahun  1999,  rumusannya
adalah sebagai berikut 
Setiap orang yang dengan tujuan menguntungkan diri sendiri atau
orang  lain  atau  suatu  korporasi,  menyalahgunakan
kewenangan,  kesempatan  atau  sarana  yang  ada  padanya

Kepaniteraan Mahkamah Agung Republik Indonesia berusaha untuk selalu mencantumkan informasi paling kini dan akurat sebagai bentuk komitmen Mahkamah Agung untuk pelayanan publik, transparansi dan akuntabilitas
pelaksanaan fungsi peradilan. Namun dalam hal-hal tertentu masih dimungkinkan terjadi permasalahan teknis terkait dengan akurasi dan keterkinian informasi yang kami sajikan, hal mana akan terus kami perbaiki dari waktu kewaktu.
Dalam hal Anda menemukan inakurasi informasi yang termuat pada situs ini atau informasi yang seharusnya ada, namun belum tersedia, maka harap segera hubungi Kepaniteraan Mahkamah Agung RI melalui :

karena  jabatan  atau  kedudukan yang  dapat  merugikan
keuangan Negara atau perekonomian Negara, dipidana dengan
pidana penjara seumur hidup atau dengan pidana penjara paling
singkat 1 (satu) tahun dan paling lama 20 tahun dan atau denda
paling  sedikit  Rp.50.000.000,00  (lima  puluh  juta  rupiah)  dan
paling banyak Rp.1.000.000.000,00 (satu milyar rupiah);
7.5. Dengan demikian, dari uraian hukum di atas, maka jelaslah
terbukti bahwa Penggugat telah melakukan tindak pidana korupsi
yang  merupakan  tindak  pidana  kejahatan  jabatan  atau  tindak
pidana kejahatan yang ada hubungannya dengan jabatan. Itulah
sebabnya,  pada  Keputusan  Tergugat,  obyek  sengketa  a’quo
dengan  judul  :  PEMBERHENTIAN  KARENA  MELAKUKAN
TINDAK PIDANA KEJAHATAN JABATAN ATAU TINDAK PIDANA
KEJAHATAN YANG ADA HUBUNGANNYA DENGAN JABATAN,
sesuai  dengan  format/contoh  Keputusan  Pemberhentian  Tidak
Dengan Hormat Sebagai PNS yang Melakukan Tipikor Setelah
Berlakunya Undang-Undang Nomor 5 Tahun 2014 Tetapi Sebelum
Berlakunya Peraturan Pemerintah Nomor 11 Tahun 2017, yang
terdapat  pada  Lampiran  Surat  Badan  Kepegawaian  Negara
Nomor : K.26-30/V.139-8/99 tanggal 2 Oktober 2018;
8. Bahwa terhadap dalil Penggugat pada angka 9, 10 dan 11 posita
gugatan, yang pada intinya mendalilkan,  “ bahwa selama Penggugat
diproses,  mulai  tingkat  penyidikan,  penuntutan,  pemeriksaan  di
persidangan  pengadilan  sampai  selesai  melaksanakan/menjalankan
putusan,  tidak  pernah  mendapatkan  surat  pemberhentian  sementara.
Dan belum pernah mendapatkan hukuman disiplin yang lain, baik berupa
hukuman disiplin tingkat ringan, sedang maupun berat “;
Tergugat menanggapinya, sebagai berikut :   
Bahwa status Pemeberhentian Tidak Dengan Hormat Penggugat sebagai
Pegawai  Negeri  Sipil  yang  telah  terbukti  menurut  hukum  melakukan
tindak pidana korupsi berdasarkan Putusan Pengadilan Tindak Pidana
Korupsi  Pada  Pengadilan  Negeri  Samarinda  Nomor  60/Pid.Sus-
TPK/2015/PN.Smr tanggal 26 April 2016 adalah sudah benar menurut
hukum  dan  mendasarkan  pada  ketentuan  Pasal  87  ayat  (4)  huruf  b
Undang-Undang  Nomor  5  Tahun  2014  yang  menyebutkan  :  “PNS

Kepaniteraan Mahkamah Agung Republik Indonesia berusaha untuk selalu mencantumkan informasi paling kini dan akurat sebagai bentuk komitmen Mahkamah Agung untuk pelayanan publik, transparansi dan akuntabilitas
pelaksanaan fungsi peradilan. Namun dalam hal-hal tertentu masih dimungkinkan terjadi permasalahan teknis terkait dengan akurasi dan keterkinian informasi yang kami sajikan, hal mana akan terus kami perbaiki dari waktu kewaktu.
Dalam hal Anda menemukan inakurasi informasi yang termuat pada situs ini atau informasi yang seharusnya ada, namun belum tersedia, maka harap segera hubungi Kepaniteraan Mahkamah Agung RI melalui :

diberhentikan  tidak  dengan  hormat  karena  dihukum  penjara  atau
kurungan berdasarkan putusan pengadilan yang telah memiliki kekuatan
hukum tetap karena melakukan tindak pidana kejahatan jabatan atau
tindak  pidana  kejahatan  yang  ada  hubungannya  dengan  jabatan
dan/atau pidan umum”,  sehingga tidak perlu adanya lagi pemberhentian
sementara ataupun pemberian hukuman disiplin tingkat ringan, sedang
maupun berat. 
Kalaupun seandainya Tergugat harus diberikan hukuman disiplin terlebih
dahulu adalah salah dan keliru, karena sesuai  peraturan  perundang-
undangan kepegawaian, dalam hal terdapat Pegawai Negeri Sipil yang
seharusnya  diberhentikan  karena  dihukum  penjara  atau  kurungan
berdasarkan putusan pengadilan yang telah memiliki kekuatan hukum
tetap  karena  melakukan  tindak  pidana  kejahatan  jabatan  atau  tindak
pidana  kejahatan  yang  ada  hubungannya  dengan  jabatan  namun
pegawai negeri sipil yang bersangkutan telah dijatuhi sanksi lain berupa
sanksi  disiplin  atau  pemberhentian  sementara,  maka  Keputusan
penjatuhan  hukuman  disiplin  dimaksud  harus  dicabut  dan  segera
ditetapkan  Keputusan  Pemberhentian  Tidak  Dengan  Hormat  (PTDH)
sebagai Pegawai Negeri Sipil;
Dengan demikian, dalil inipun harus ditolak karena tidak berdasar dan
beralasan hukum;
9. Bahwa  terhadap dalil Penggugat pada angka 12 posita gugatan, yang
pada intinya mendalilkan : “ bahwa Keputusan Tergugat (obyek sengketa
a’quo) tidak mendasari bentuk formil azas-azas pemerintahan yang baik,
sebab dalam konsideran menimbang tertera Putusan Pengadilan Negeri
Samarinda  Nomor  :  60/Pid.Sus-TPK/2015/PN.Smr  tanggal  27  April
2016, hal ini salah dan berakibat tidak sah dan batal karena yang benar
adalah  Putusan  Pengadilan  Negeri  Samarinda  Nomor  :  60/Pid.Sus-
TPK/2015/PN.Smr tanggal 26 April 2016, dengan tegas Tergugat tolak,
karena :  
9.1. Bahwa  Tergugat  menerbitkan  Keputusan  Bupati  Kutai  Barat
Nomor  :  800.05.860/K.971/2018  tanggal  31  Desember  2018
tentang  Pemberhentian  Karena  Melakukan  Tindak  Pidana
kejahatan  Jabatan  Atau  Tindak  Pidana  Kejahatan  Yang  Ada

Kepaniteraan Mahkamah Agung Republik Indonesia berusaha untuk selalu mencantumkan informasi paling kini dan akurat sebagai bentuk komitmen Mahkamah Agung untuk pelayanan publik, transparansi dan akuntabilitas
pelaksanaan fungsi peradilan. Namun dalam hal-hal tertentu masih dimungkinkan terjadi permasalahan teknis terkait dengan akurasi dan keterkinian informasi yang kami sajikan, hal mana akan terus kami perbaiki dari waktu kewaktu.
Dalam hal Anda menemukan inakurasi informasi yang termuat pada situs ini atau informasi yang seharusnya ada, namun belum tersedia, maka harap segera hubungi Kepaniteraan Mahkamah Agung RI melalui :

Hubungannya dengan Jabatan, berdasarkan Data atau Dokumen
yang diserahkan, baik oleh Badan Kepegawaian Negara, Badan
Kepegawaian Daerah Provinsi Kalimantan Timur,  maupun Kepala
Kejaksaan Negeri Kutai Barat;  
9.2. Bahwa dalam Data atau Dokumen tersebut disebutkan : Daftar
PNS  yang   terlibat  Tipikor  pada  Pemerintah  Kabupaten  Kutai
Barat  yang  sudah  berkekuatan  hukum  tetap  (Inkracht),
diantaranya,  Identitas  Terpidana  :  HANSEN,SH.,M.Si,  Pasal
Dakwaan yang terbukti : Pasal 3 jo Pasal 18 Undang-Undang
Nomor; 31 Tahun 1999 tentang Pemberantasan Tindak Pidana
Korupsi,  sebagaimana  telah  diubah  dan  ditambah  dengan
Undang-Undang Nomor : 20 Tahun 2001 tentang Perubahan atas
Undang-Undang No.31 Tahun 1999, jo Pasal 55 ayat (1) ke-1
KUHP,  Nomor  Tgl.Putusan  (Inkracht)  :  Putusan  Pengadilan
Tindak  Pidana  Korupsi  pada  Pengadilan  Negeri Samarinda
No. 60/Pid.Sus-TPK/2015/PN.Smr tanggal 27 April 2016; 
9.3. Bahwa Tergugat tidak pernah menerima salinan resmi putusan
Pengadilan  Tindak  Pidana  Korupsi  pada  Pengadilan  Negeri
Samarinda  No.60/Pid.Sus-TPK/2015/PN.Smr  tersebut  sampai
diterbitkannya  Keputusan  Bupati  Kutai  Barat  Nomor  :
800.05.860/K.971/2018  tanggal  31  Desember  2018  (obyek
sengketa); 
9.4. Bahwa  oleh  karena  itu,  dengan  adanya  kekeliruan
pencantuman tanggal 27 April 2016 (yang seharusnya tanggal 26
April  2016),  tidaklah  berakibat  Keputusan  Tergugat  (obyek
sengketa) tidak sah atau batal, karena yang dimaksud Tergugat
adalah  Putusan  Pengadilan  Tindak  Pidana  Korupsi  Pada
Pengadilan  Negeri  Samarinda  Nomor  :  60/Pid.Sus-
TPK/2015/PN.Smr tanggal 26 April 2016.  Lagi pula, bukankah
pada  bagian  akhir  Keputusan  Bupati  Kutai  Barat  Nomor  :
800.05.860/K.971/2018 tanggal 31 Desember 2018, menyebutkan
: 
Apabila  dikemudian  hari  ternyata  terdapat  kekeliruan  dalam
Keputusan ini akan diadakan perbaikan sebagaimana mestinya;
10. Bahwa terhadap dalil Penggugat pada angka 14 posita gugatan, yang
mendalilkan “Penggugat keberatan atas dasar pertimbangan Tergugat

Kepaniteraan Mahkamah Agung Republik Indonesia berusaha untuk selalu mencantumkan informasi paling kini dan akurat sebagai bentuk komitmen Mahkamah Agung untuk pelayanan publik, transparansi dan akuntabilitas
pelaksanaan fungsi peradilan. Namun dalam hal-hal tertentu masih dimungkinkan terjadi permasalahan teknis terkait dengan akurasi dan keterkinian informasi yang kami sajikan, hal mana akan terus kami perbaiki dari waktu kewaktu.
Dalam hal Anda menemukan inakurasi informasi yang termuat pada situs ini atau informasi yang seharusnya ada, namun belum tersedia, maka harap segera hubungi Kepaniteraan Mahkamah Agung RI melalui :

Pasal 250 huruf b Peraturan Pemerintah Nomor 11 Tahun 2017 yang
menjadi  dasar  diterbitkannya  Surat Keputusan  obyek  sengketa  a’quo
karena  diberlakukan  surut  ke  belakang  terhadap  kasus  hukum
Penggugat yang telah berkekuatan hukum tetap pada tanggal 26 April
2016 sehingga melanggar azas hukum yang dianut oleh hukum positif
Indonesia yang tidak mengenal aturan yang berlaku surat atau Azas
Rektroaktif sesuai dengan UUD 1945 Pasal 281“;  
Tergugat menanggapinya, sebagai berikut :
Apabila dicermati ketentuan Pasal 28 huruf I ayat (1) Amandemen Kedua
UUD  Negara  RI  Tahun  1945  tersebut,  mengatakan  bahwa  :  “Setiap
orang tidak dapat dituntut atas dasar hukum yang berlaku surut yang
merupakan  hak  asasi  manusia  yang  tidak  dapat  dikurangi  dalam
keadaan apapun”. Ketentuan ini sama halnya dengan rumusan Pasal 1
ayat (1) KUHP yang kita kenal dengan asas “Noellum Delictum, Noella
Poena Sine Praevia Lege Poenal” (Azas Legalitas).  Rumusan tersebut
tertuang pula dalam Pasal 18 ayat (2) Undang-Undang Nomor 39 Tahun
1999 tentang Hak Asasi Manusia yang menyatakan : “Setiap orang tidak
boleh dituntut untuk hukum atau dijatuhi pidana, kecuali berdasarkan
suatu peraturan perundang-undangan yang sudah ada sebelum tindak
pidana dilakukannya.”
Bahwa  ketentuan  Pasal  250  huruf  b  Peraturan  Pemerintah  Nomor  11
Tahun 2017 tidak boleh dilihat sebagai peraturan yang berdiri sendiri
tetapi  harus  dilihat  sebagai  bentuk  peraturan  pelaksana  dan  saling
mengisi dari ketentuan Pasal 87 ayat (4) huruf b Undang-Undang Nomor
5 Tahun 2014 tentang Aparatur Sipil Negera. Pasal 87 ayat (4) huruf b
UU Nomor 5 Tahun 2014 disebutkan “Pegawai Negeri Sipil diberhentikan
tidak  dengan  hormat  karena  dihukum  penjara  atau  kurungan
berdasarkan putusan pengadilan yang telah memiliki kekuatan hukum
tetap  karena melakukan  tindak pidana kejahatan  jabatan atau  tindak
pidana kejahatan yang ada hubungannya dengan jabatan”.  Selanjutnya
dalam  Pasal  89  UU  Nomor  5  Tahun  2014  dijelaskan  kembali  :
“Ketentuan  lebih  lanjut  mengenai  tata  cara  pemberhentian,
pemberhentian  sementara,  dan  pengaktifan  kembali  Pegawai  Negeri
Sipil  sebagaimana  dimaksud  dalam  Pasal  87  dan  Pasal  88  diatur
dengan Peraturan Pemerintah.”
Peraturan Pemerintah Nomor 11 Tahun 2017 tentang Manajemen PNS
merupakan Peraturan Pelaksana dari Undang-Undang Nomor 5 tahun
2014 sebagaimana disebutkan dalam konsideran bagian menimbang PP
Nomor  11  Tahun  2017  yang  berbunyi  :  “bahwa  untuk  melaksankan

Kepaniteraan Mahkamah Agung Republik Indonesia berusaha untuk selalu mencantumkan informasi paling kini dan akurat sebagai bentuk komitmen Mahkamah Agung untuk pelayanan publik, transparansi dan akuntabilitas
pelaksanaan fungsi peradilan. Namun dalam hal-hal tertentu masih dimungkinkan terjadi permasalahan teknis terkait dengan akurasi dan keterkinian informasi yang kami sajikan, hal mana akan terus kami perbaiki dari waktu kewaktu.
Dalam hal Anda menemukan inakurasi informasi yang termuat pada situs ini atau informasi yang seharusnya ada, namun belum tersedia, maka harap segera hubungi Kepaniteraan Mahkamah Agung RI melalui :

ketentuan Pasal 17, Pasal 18 ayat (4), Pasal 19 ayat (4), Pasal 20 ayat
(4), Pasal 57, Pasal 67, Pasal 68 ayat (7), Pasal 74, Pasal 78, Pasal 81,
Pasal 85, Pasal 86 ayat (4), Pasal 89, Pasal 91 ayat (6), Pasal 92 ayat
(4),  dan  Pasal  125  Undang-Undang  Nomor  5  Tahun  2014  tentang
Aparatur Sipil Negara, perlu menetapkan Peraturan Pemerintah tentang
Manajemen Pegawai Negeri Sipil”.
Bahwa  dalam  menerbitkan  Surat  Keputusan  objek  sengketa  a  quo,
Tergugat mendasarkannya pada putusan Pengadilan Negeri Samarinda
Nomor: 60/Pid.Sus-TPK/2015 PN Smr tanggal 26 April 2016 yang sudah
ada dan diatur setelah berlakunya Undang-Undang Nomor 5 Tahun 2014
tentang Aparatur Sipil Negara. Dengan demikian adalah tidak benar dalil
Penggugat yang menyatakan Tergugat memberlakukan undang-undang
secara berlaku surut (rektroaktif) terhadap kasus hukum Penggugat yang
telah berkekuatan hukum tetap/ incraht. Dalil inipun harus ditolak, karena
tidak berdasar dan beralasan hukum;  
 
11. Bahwa terhadap dalil Penggugat pada angka 21 posita gugatan, yang
pada  intinya  mendalilkan,  “bahwa  penerbitan  obyek  gugatan
bertentangan  dengan  peraturan  perundang-undangan  yang  berlaku
sebagaimana dimaksud dalam Pasal 53 ayat (2) huruf (a) dan (b) UU
PTUN”, dalil inipun dengan tegas Tergugat tolak, karena :
 
11.1. Bahwa terhadap dalil Penggugat pada angka 21 poin 1
huruf  a,  b,  c,  d,  e  dan  f,  ternyata  adalah  dalil  pengulangan
sebelumnya yang sudah ditanggapi tergugat pada dalil jawaban di
atas, sehingga tidak perlu ditanggapi lagi. Namun untuk tegasnya,
dalil inipun Tergugat tolak karena tidak berdasar dan beralasan
hukum;   
11.2. Bahwa terhadap dalil Penggugat pada angka 21 poin 2
huruf a, b dan c, Tergugat menanggapinya, sebagai berikut :
1. Bahwa Tergugat menerbitkan Surat Keputusan Nomor :
800.05.860 / K.971 / 2018 tanggal 31 Desember 2018 tentang
Pemberhentian Karena Melakukan Tindak Pidana Kejahatan
Jabatan  Atau  Tindak  Pidana  Kejahatan  Yang  Ada
Hubungannya Dengan Jabatan atas nama HANSEN,SH.M.Si,
tidak  bertentangan  dengan  ketentuan  perundang-undangan
yang berlaku, sebagaimana telah diuraikan di atas, dan tidak
bertentangan dengan Azas-Azas Umum Pemerintahan yang
Baik;  

Kepaniteraan Mahkamah Agung Republik Indonesia berusaha untuk selalu mencantumkan informasi paling kini dan akurat sebagai bentuk komitmen Mahkamah Agung untuk pelayanan publik, transparansi dan akuntabilitas
pelaksanaan fungsi peradilan. Namun dalam hal-hal tertentu masih dimungkinkan terjadi permasalahan teknis terkait dengan akurasi dan keterkinian informasi yang kami sajikan, hal mana akan terus kami perbaiki dari waktu kewaktu.
Dalam hal Anda menemukan inakurasi informasi yang termuat pada situs ini atau informasi yang seharusnya ada, namun belum tersedia, maka harap segera hubungi Kepaniteraan Mahkamah Agung RI melalui :

2. Bahwa  jika  dikatakan  bertentangan  dengan  azas
kepastian  hukum.  Bukankah,  Tergugat  menerbitkan  obyek
sengketa  (vide  Surat  Keputusan  Nomor  :
800.05.860/K.971/2018  tanggal  31  Desember  2018),  cukup
jelas dalam Konsiderannya, menyebutkan :   
a. Bahwa  berdasarkan  putusan  Pengadilan  Negeri
Samarinda  No.60/Pid.Sus-TPK/2015/PN.Smr  tanggal  27
April 2016 yang telah mempunyai kekuatan hukum tetap,
Sdr.  HANSEN,SH,M.Si  NIP  19720317  200604  1  010
Penata Tingkat I Golongan Ruang (III/d) dinyatakan telah
terbukti  secara  sah  dan  meyakinkan  melakukan  tindak
pidana korupsi, yang merupakan tindak pidana kejahatan
jabatan  atau  tindak  pidana  kejahatan  yang  ada
hubungannya dengan jabatan; 
b. Bahwa sesuai dengan ketentuan pasal 87 ayat (4) huruf
b Undang-Undang Nomor 5 Tahun 2014 tentang Aparatur
Sipil Negara dan Pasal 250 huruf b Peraturan Pemerintah
Nomor 11 Tahun 2017 tentang Manajemn PNS, dItentukan
bahwa PNS  diberhentikan tidak  dengan hormat apabila
dihukum  dengan  penjara  atau  kurungan  berdasarkan
putusan pengadilan yang telah memiliki kekuatan hukum
tetap karena melakukan tindak pidana kejahatan jabatan
atau  tindak  pidana  kejahatan  yang  ada  hubungannya
dengan jabatan;
c. Bahwa  berdasarkan  pertimbangan  sebagaimana
dimaksud pada huruf a dan huruf b dipandang perlu untuk
menetapkan  keputusan  Bupati  Kutai  Barat  tentang
pemberhentian karena melakukan tindak pidana kejahatan
jabatan  atau  tindak  pidana  yang  ada  hubungannya
dengan jabatan; 
  Dan, berdasarkan ketentuan Pasal 1 angka 5 Peraturan
Pemerintah  No.9  Tahun  2003,  yang  telah  dirubah  dengan
Peraturan Pemerintah No.63 Tahun 2009 tentang wewenang,
pengangkatan,  pemindahan,  dan  pemberhentian  Pegawai
Negeri Sipil, Tergugat diberi wewenang untuk itu, Oleh sebab

Kepaniteraan Mahkamah Agung Republik Indonesia berusaha untuk selalu mencantumkan informasi paling kini dan akurat sebagai bentuk komitmen Mahkamah Agung untuk pelayanan publik, transparansi dan akuntabilitas
pelaksanaan fungsi peradilan. Namun dalam hal-hal tertentu masih dimungkinkan terjadi permasalahan teknis terkait dengan akurasi dan keterkinian informasi yang kami sajikan, hal mana akan terus kami perbaiki dari waktu kewaktu.
Dalam hal Anda menemukan inakurasi informasi yang termuat pada situs ini atau informasi yang seharusnya ada, namun belum tersedia, maka harap segera hubungi Kepaniteraan Mahkamah Agung RI melalui :

itu,  penerbitan  obyek  sengketa  tidak  bertentangan  dengan
peraturan perundang-undangan yang   berlaku;
3. Bahwa jika dikatakan bertentangan dengan Azas Tertib
Penyelenggaraan  Negara.  Bukankah,  Tergugat  dalam
menerbitkan  obyek  sengketa  sudah  sesuai  dengan  tertib
hukum dan sama sekali tidak menimbulkan pro kontra dalam
masyarakat, selain Penggugat sendiri;   
4. Bahwa  jika  dikatakan  bertentangan  dengan  Azas
Profesionalisme. Tergugat menerbitkan obyek sengketa sudah
sesuai bidang dan tugas/kewenangannya (vide Pasal 1 angka
5 Peraturan Pemerintah No.9 Tahun 2003, yang telah dirubah
dengan Peraturan Pemerintah No.63 Tahun 2009);
Dengan demkikian, dalil Penggugat yang menyatakan penerbitan Surat
Keputusan Nomor : 800.05.860/K.971/2018 tanggal 31 Desember 2018
tentang  Pemberhentian  Karena  melakukan  Tindak  Pidana  Kejahatan
Jabatan Atau Tindak Pidana Kejahatan Yang Ada Hubungannya Dengan
Jabatan, memenuhi Pasal 53 ayat (2) huruf (a) dan (b) Undang-Undang
No.9 Tahun 2004 tentang Perubahan Atas Undang-Undang No.5 Tahun
1986 tentang Peradilan Tata Usaha Negara, sama sekali tidak terbukti
serta tidak berdasar dan beralasan hukum, karenanya harus ditolak;
12. Bahwa oleh karena gugatan Penggugat tidak berdasar dan beralasan
hukum,  maka  tuntutan  Penggugat  agar  Surat  Keputusan  Tergugat
Nomor  :  800.05.860/K.971/2018  tanggal  31  Desember  2018  tentang
Pemberhentian  Karena  Melakukan  Tindak  Pidana  Kejahatan  Jabatan
Atau Tindak Pidana Kejahatan Yang Ada Hubungannya Dengan Jabatan,
dinyatakan  batal  atau  tidak  sah  dan  memerintahkan  Tergugat  untuk
mencabut obyek sengketa serta mengembalikan/memulihkan nama baik,
harkat dan martabat Penggugat serta menghukum Tergugat membayar
biaya perkara, haruslah ditolak; 
13. Bahwa  terhadap  dalil-dalil  gugatan  Penggugat  selebihnya,  karena
selain hanya merupakan pengulangan yang sudah ditanggapi Tergugat,
juga tidak berdasar dan beralasan hukum, secara tegas pula Tergugat
tolak; 
Berdasar atas alasan-alasan yang dikemukakan di atas, Tergugat mohon
kepada Majelis Hakim yang memeriksa dan mengadili perkara ini berkenan
memutuskan : 

Kepaniteraan Mahkamah Agung Republik Indonesia berusaha untuk selalu mencantumkan informasi paling kini dan akurat sebagai bentuk komitmen Mahkamah Agung untuk pelayanan publik, transparansi dan akuntabilitas
pelaksanaan fungsi peradilan. Namun dalam hal-hal tertentu masih dimungkinkan terjadi permasalahan teknis terkait dengan akurasi dan keterkinian informasi yang kami sajikan, hal mana akan terus kami perbaiki dari waktu kewaktu.
Dalam hal Anda menemukan inakurasi informasi yang termuat pada situs ini atau informasi yang seharusnya ada, namun belum tersedia, maka harap segera hubungi Kepaniteraan Mahkamah Agung RI melalui :


# DALAM EKSEPSI

1. Menerima eksepsi Tergugat; 
2. Menyatakan gugatan Penggugat tidak dapat diterima;  
3. Menyatakan  Pengadilan  Tata  Usaha  Negara  Samarinda  tidak
berwenang mengadili perkara a’quo;

# DALAM POKOK PERKARA

1. Menolak atau setidak-tidaknya menyatakan gugatan Penggugat tidak
dapat diterima; 
2. Menghukum Penggugat membayar biaya perkara; 
Menimbang, bahwa terhadap jawaban Tergugat tersebut,  Penggugat
telah  mengajukan  Repliknya  tertanggal  02  Oktober  2019  dan  Tergugat
mengajukan  Duplik nya tertanggal  04  Oktober  2019  yang  diterima
dipersidangan tanggal 09 Oktober 2019;
Menimbang  bahwa  untuk  menguatkan  dalil  - dalil  gugatannya,
Penggugat telah mengajukan bukti  - bukti tertulis berupa foto  kopi surat -
surat yang telah bermeterai cukup dan telah dicocokkan dengan asli atau
foto  kopinya di persidangan, bukti  - bukti surat tersebut diberi tanda P  - 1
sampai dengan P - 12, sebagai berikut : 
Bukti P – 1 : Foto  kopi  sesuai  dengan  aslinya  Surat  Keputusan  Bupati
Kutai  Barat  Nomor  :  800.05.860/K.971/2018  tanggal  31
Desember 2018 tentang Pemberhentian Karena Melakukan
Tindak  Pidana  Kejahatan  Jabatan  Atau  Tindak  Pidana
kejahatan  Yang  Ada  Hubungannya  Dengan  Jabatan,  atas
nama HANSEN, SH, M.Si, NIP. 19720317 200604 1 010;
Bukti P – 2 : Foto kopi sesuai dengan aslinya Berita Acara Penyerahan
Surat Keputusan Bupati Kutai Barat Tentang Pemberhentian
Kepada  Pegawai  Negeri  Sipil  Dilingkungan  Pemerintah
Kabupaten Kutai Barat tanggal 03 Mei 2019;
Bukti  P– 3 : Foto kopi sesuai dengan aslinya Surat dari Kantor Advokat
Dan  Konsultan  Hukum  Masdianto,  SH  &  Rekan  (kuasa
hukum HANSEN, S.H.) , Nomor : 001/KT-A/VII/2019 tanggal
30 Juli 2019, Perihal : Surat Keberatan, ditujukan kepada
Bapak BUPATI KUTAI BARAT;
Bukti  P– 3.A: Foto kopi sesuai dengan aslinya Tanda Bukti Terima Surat
Keberatan Penggugat oleh LIA ADC BUPATI KUTAI BARAT,
tanggal 30 Agustus 2019;

Kepaniteraan Mahkamah Agung Republik Indonesia berusaha untuk selalu mencantumkan informasi paling kini dan akurat sebagai bentuk komitmen Mahkamah Agung untuk pelayanan publik, transparansi dan akuntabilitas
pelaksanaan fungsi peradilan. Namun dalam hal-hal tertentu masih dimungkinkan terjadi permasalahan teknis terkait dengan akurasi dan keterkinian informasi yang kami sajikan, hal mana akan terus kami perbaiki dari waktu kewaktu.
Dalam hal Anda menemukan inakurasi informasi yang termuat pada situs ini atau informasi yang seharusnya ada, namun belum tersedia, maka harap segera hubungi Kepaniteraan Mahkamah Agung RI melalui :

Bukti  P– 3.B: Foto  kopi  dari  foto  kopi  Surat  dari  Kantor  Advokat  Dan
Konsultan Hukum  Masdianto, SH  & Rekan  (kuasa hukum
HANSEN, S.H.), Nomor : 002/KT-A/VII/2019 tanggal 16 juli
2019,  Perihal  :  Surat  Keberatan,  ditujukan  kepada  Bapak
GUBERNUR KALIMANTAN TIMUR;
Bukti  P– 3.C: Foto  kopi  sesuai  dengan  aslinya  tanda  Pengiriman  Surat
Keberatan dan Tanda Terima surat keberatan;
Bukti  P– 4 : Foto  kopi  sesuai  dengan  aslinya  Surat  PT.  Bank
Pembangunan  Daerah  Kalimantan  Timur  Dan  Kalimantan
Utara Kantor Cabang Pembantu Linggang Bigung, Nomor :
10/C-2/BPD-CPLB/X/2019  tanggal  04  Oktober  2019,
Perihal : Surat keterangan SK dan Taspen menjadi jaminan
di PT. BPD Kaltim Kaltara Kcp Linggang Bigung;
Bukti  P– 4.A: Foto kopi dari foto kopi Kartu Tanda Penduduk atas nama
HANSEN, SH, M.Si.;
Bukti  P– 4.B: Foto  kopi  dari  foto  kopi  Kartu  Pegawai  Negeri  Sipil  atas
nama HANSEN, SH;
Bukti  P– 4.C: Foto kopi dari foto kopi Salinan Keputusan Bupati Kutai Barat
Nomor : SK.813.3/174/BKD-I/2007 tanggal 16 Januari 2007,
Tentang Pengangkatan Calon Pegawai Negeri Sipil Daerah
atas nama HANSEN, SH;
Bukti  P– 4.D: Foto kopi dari foto kopi Surat Keputusan Bupati Kutai Barat
Nomor : SK. 813.3/972/BKD-I/2007 tanggal 28 Maret 2008
Tentang  Pengangkatan  Pegawai  Negeri  Sipil  atas  nama
HANSEN, SH;
Bukti  P– 4.E: Foto kopi dari foto kopi Surat Badan Kepegawaian Negara
Petikan  Keputusan  Kepala  Badan  Kepegawaian  Negara
Nomor : 0002/KV/VIII/26402/KEP/2008 Tanggal 06 Oktober
2008;
Bukti  P– 4.F : Foto  kopi  dari  foto  kopi  Keputusan  Bupati  Kutai  Barat
Nomor  :  823.3/1141/BKD-DKP/IX/2015  tanggal  10
September 2015 Tentang Kenaikan Pangkat Pegawai Negeri
Sipil atas nama HANSEN, SH, M.Si;
Bukti  P– 4.G: Foto kopi dari foto kopi Petikan Keputusan Bupati Kutai Barat
Nomor  :  800.05.871.1/K.435/2018  tanggal  07  Juni  2018
Tentang Pengangkatan Dan Pemberhentian Pejabat Eselon
II.b,  III.a,  III.b,  IV.a  Dan  IV.b,  Dilingkungan  Pemerintah

Kepaniteraan Mahkamah Agung Republik Indonesia berusaha untuk selalu mencantumkan informasi paling kini dan akurat sebagai bentuk komitmen Mahkamah Agung untuk pelayanan publik, transparansi dan akuntabilitas
pelaksanaan fungsi peradilan. Namun dalam hal-hal tertentu masih dimungkinkan terjadi permasalahan teknis terkait dengan akurasi dan keterkinian informasi yang kami sajikan, hal mana akan terus kami perbaiki dari waktu kewaktu.
Dalam hal Anda menemukan inakurasi informasi yang termuat pada situs ini atau informasi yang seharusnya ada, namun belum tersedia, maka harap segera hubungi Kepaniteraan Mahkamah Agung RI melalui :

Kabupaten Kutai Barat Tahun 2018;
Bukti  P– 4.H: Foto kopi dari foto kopi Surat Badan Keuangan Dan Aset
Daerah  Kabupaten  Kutai  Barat  Nomor  :  900/241/BKAD-
perbend/I/2019,  tanggal  07  Januari  2019,  Perihal  :
Penghentian Gaji sementara Bagi PNS yang bermasalah;
Bukti P – 5 : Foto kopi  dari foto kopi PETIKAN PUTUSAN 60/Pid.Sus-
TPK/2015/PN Smr;
Bukti  P– 6 : Foto kopi dari foto kopi  Rekapitulasi Kehadiran ASN Dan
TKK Pada Dinas Pemberdayaan Masyarakat Dan Kampung
Kabupaten Kutai Barat Tahun 2018 ( dari bulan Juni 2018
sampai dengan bulan Desember 2018 );
Bukti  P– 7 : Foto  kopi  dari  foto  kopi   Daftar  Gaji  Pegawai  atas  nama
HANSEN NIP. 197203172006041010;
Bukti  P– 8 : Foto kopi ad. Informandum  Peraturan Pemerintah Republik
Indonesia  Nomor  11  Tahun  2017  Tentang  Manajemen
Pegawai Negeri Sipil , Pasal 276 huruf c, Pasal 280 ayat (1)
dan Pasal 282;
Bukti  P– 8.A: Foto kopi ad. Informandum Peraturan Pemerintah Nomor 4
Tahun  1966  Tentang  Pemberhentian/Pemberhentian
Sementara Pegawai Negeri, Pasal 2 ayat (1) dan Pasal 8;
Bukti  P– 9 : Foto  kopi  ad.  Informandum  Undang-Undang  Republik
Indonesia Nomor 39 Tahun 1999 Tentang Hak Asasi Manusia
Pasal 4;
Bukti  P– 10 : Foto kopi ad. Informandum Undang-Undang Dasar Republik
Indonesia 1945 Pasal 28I;
Bukti  P– 11 : Foto kopi ad. Informandum Peraturan Pemerintah Nomor 11
Tahun 2017 Tentang Manajemen Pegawai Pasal 252;
Bukti  P– 12 : Foto  kopi  ad.  Informandum  Undang-Undang  Republik
Indonesia  Nomor  30  Tahun  2014  tentang  Adminsitrasi
Pemerintahan, Pasal 10;
 Menimbang  bahwa  untuk  menguatkan  dalil  -  dalil  bantahannya,
Tergugat melalui kuasa hukumnya telah  mengajukan  bukti  - bukti  tertulis
berupa  foto  kopi surat  - surat  yang  telah  bermeterai  cukup  dan  telah
dicocokkan dengan asli atau foto kopinya di persidangan, selanjutnya diberi
tanda T - 1 sampai dengan T – 17b, sebagai berikut : 
Bukti T – 1 : Foto  kopi  sesuai  dengan  aslinya  Keputusan  Bupati  Kutai
Barat Nomor : 800.05.860/K.971/2018 tanggal 31 Desember

Kepaniteraan Mahkamah Agung Republik Indonesia berusaha untuk selalu mencantumkan informasi paling kini dan akurat sebagai bentuk komitmen Mahkamah Agung untuk pelayanan publik, transparansi dan akuntabilitas
pelaksanaan fungsi peradilan. Namun dalam hal-hal tertentu masih dimungkinkan terjadi permasalahan teknis terkait dengan akurasi dan keterkinian informasi yang kami sajikan, hal mana akan terus kami perbaiki dari waktu kewaktu.
Dalam hal Anda menemukan inakurasi informasi yang termuat pada situs ini atau informasi yang seharusnya ada, namun belum tersedia, maka harap segera hubungi Kepaniteraan Mahkamah Agung RI melalui :

2018  Tentang  Pemberhentian  Karena  Melakukan  Tindak
Pidana  Kejahatan  Jabatan  Atau  Tindak  Pidana  Kejahatan
Yang  Ada  Hubungannya  Dengan  Jabatan,  atas  nama
HANSEN, SH, M.Si, NIP. 19720317 200604 1 010;
Bukti T – 2 : Foto kopi sesuai dengan salinan Putusan Pengadilan Tindak
Pidana Korupsi Pada Pengadilan Negeri Samarinda Nomor :
60/Pid.Sus/TPK/2015/PN.Smr tanggal 26 April 2016;
Bukti T – 3 : Foto kopi dari foto kopi Undang-Undang Republik Indonesia
Nomor 5 Tahun 2014 Tentang Aparatur Sipil Negara;
Bukti T – 4 : Foto  kopi  dari  foto  kopi  Peraturan  Pemerintah  Republik
Indonesia Nomor 63 Tahun 2009 Tentang Perubahan Atas
Peraturan  Pemerintah  Nomor  9  Tahun  2003  Tentang
Wewenang  Pengangkatan,  Pemindahan,  Dan
Pemberhentian Pegawai Negeri Sipil;
Bukti T – 5 : Foto  kopi  dari  foto  kopi  Peraturan  Pemerintah  Republik
Indonesia  Nomor  11  Tahun  2017  Tentang  Manajemen
Pegawai Negeri Sipil;
Bukti T – 6 : Foto kopi dari foto kopi Surat Edaran Menteri Dalam Negeri
Republik  Indonesia  Nomor  180/6867/SJ  tanggal  10
September  2018  Tentang  Penegakan  Hukum  Terhadap
Aparatur  Sipil  Negara  Yang  Melakukan  Tindak  Pidana
Korupsi;
Bukti T – 7 : Foto kopi dari foto kopi Keputusan Bersama Menteri Dalam
Negeri,  menteri  Pendayagunaan  Aparatur  Negara  Dan
Reformasi  Birokrasi  Dan  Kepala  Badan  kepegawaian
Nnegara Nomor 182/6597/SJ, Nomor 15 Tahun 2018, Nomor
153/KEP/2018  tanggal  13  September  2018  Tentang
Penegakan  Hukum  Terhadap  Pegawai  Negeri  Sipil  Yang
Telah  Dijatuhi  Hukuman  Berdasarkan  Putusan  Pengadilan
Yang Berkekuatan Hukum Tetap Karena Melakukan Tindak
Pidana  Kejahatan  Jabatan  Atau  Tindak  Pidana  Kejahatan
Yang Ada Hubungannya Dengan Jabatan;
Bukti T – 8a : Foto kopi dari foto kopi Surat Badan Kepegawaian Negara
Nomor : K.26-30/V.139-8/99 tanggal 2 Oktober 2018 Perihal :
Surat Penyampaian Data PNS Yang Dihukum Penjara atau
Kurungan  Karena  melakukan  Tindak Pidana  Jabatan  atau
Tindak Pidana Kejahatan Yang Ada Hubungannya Dengan

Kepaniteraan Mahkamah Agung Republik Indonesia berusaha untuk selalu mencantumkan informasi paling kini dan akurat sebagai bentuk komitmen Mahkamah Agung untuk pelayanan publik, transparansi dan akuntabilitas
pelaksanaan fungsi peradilan. Namun dalam hal-hal tertentu masih dimungkinkan terjadi permasalahan teknis terkait dengan akurasi dan keterkinian informasi yang kami sajikan, hal mana akan terus kami perbaiki dari waktu kewaktu.
Dalam hal Anda menemukan inakurasi informasi yang termuat pada situs ini atau informasi yang seharusnya ada, namun belum tersedia, maka harap segera hubungi Kepaniteraan Mahkamah Agung RI melalui :

Jabatan  dan  Contoh  Keputusan  Pemberhentian  Tidak
Dengan Hormat Sebagai PNS;
Bukti T – 8b : Foto  kopi  dari  foto  kopi  Daftar  PNS  Yang  Terlibat  Tipikor
Pada Pemerintah Kabupaten Kutai Barat;
Bukti T – 8c : Foto kopi dari foto kopi Contoh 1 : Keputusan Pemberhentian
Tidak Dengan Hormat Sebagai PNS Yang Melakukan Tipikor
Sebelum Berlakunya Undang-Undang Nomor 5 Tahun 2014;
Bukti T – 8d : Foto kopi dari foto kopi Contoh 2 : Keputusan Pemberhentian
Tidak Dengan Hormat Sebagai PNS Yang Melakukan Tipikor
Setelah Berlakunya Undang-Undang Nomor 5 Tahun 2014
tetapi Sebelum Berlakunya peraturan Pemerintah Nomor 11
Tahun 2017;
Bukti T – 8e : Foto kopi dari foto kopi Contoh 3 : Keputusan Pemberhentian
Tidak Dengan Hormat Sebagai PNS Yang Melakukan Tipikor
Setelah Berlakunya Undang-Undang Nomor 5 Tahun 2014
Dan Peraturan Pemerintah Nomor 11 Tahun 2017;
Bukti T – 9 : Foto  kopi  sesuai  dengan  aslinya  Surat  Kepala  Badan
Kepegawaian Daerah Nomor : 800/IV.1-6055/BKD tanggal 18
Oktober  2018,  Perihal  :  Penyampaian  Data  PNS  yang
Terkena Tipikor;
Bukti T – 10 : Foto kopi sesuai dengan aslinya Surat Sekretariat Daerah
Kabupaten  Kutai  Barat  Nomor  :  800/4639/BKPPD-
TU.P/XII/2018  tanggal  11  Desember  2018  Perihal  :
Permintaan Salinan Keputusan TIPIKOR;
Bukti T – 11 : Foto  kopi  sesuai  dengan  aslinya  Surat  Kepala  Badan
Kepegawaian  Negara  Nomor  : K.26-30/V.100-1/99  tanggal
26 desember 2018 Perihal : Tindaklanjut Keputusan bersama
menteri  Dalam Negeri, Menteri PAN  dan  RB, dan  Kepala
BKN;
Bukti T – 12 : Foto kopi sesuai dengan aslinya Surat Bupati Kutai Barat
Nomor  :  862/059/BKPPD-TU.P/1/2019  tanggal  07  Januari
2019 Perihal : Permintaan Salinan Keputusan TIPIKOR;
Bukti T – 13 : Foto  kopi  sesuai  dengan  aslinya  Surat Kepala  Kejaksaan
Negeri  Kutai  Barat  Nomor  :  B-37/Q.4.19/Fuh.1/01/2019
tanggal  15  Januari  2019  Perihal  :  Permintaan  Salinan
keputusan Tindak Pidana Korupsi;
Bukti T – 14 : Foto  kopi  dari  foto  kopi  Surat  Menteri  Pendayagunaan

Kepaniteraan Mahkamah Agung Republik Indonesia berusaha untuk selalu mencantumkan informasi paling kini dan akurat sebagai bentuk komitmen Mahkamah Agung untuk pelayanan publik, transparansi dan akuntabilitas
pelaksanaan fungsi peradilan. Namun dalam hal-hal tertentu masih dimungkinkan terjadi permasalahan teknis terkait dengan akurasi dan keterkinian informasi yang kami sajikan, hal mana akan terus kami perbaiki dari waktu kewaktu.
Dalam hal Anda menemukan inakurasi informasi yang termuat pada situs ini atau informasi yang seharusnya ada, namun belum tersedia, maka harap segera hubungi Kepaniteraan Mahkamah Agung RI melalui :

Aparatur  Negara  Dan  Reformasi  Birokrasi  Nomor  :
B/50/M.SM.00.00/2019  tanggal  28  Februari  2019  Hal  :
petunjuk Pelaksanaan Penjatuhan PTDH oleh PPK Terhadap
PNS  yang  Telah  Dijatuhi  Hukuman  berdasarkan  Putusan
Pengadilan yang Berkekuatan Hukum Tetap;
Bukti T – 15 : Foto kopi sesuai dengan aslinya Berita Acara Penyampaian
Surat Keputusan Bupati Kutai Barat Tentang Pemberhentian
Kepada  Pegawai  negeri  Sipil  Dilingkungan  Pemerintah
Kabupaten Kutai Barat tanggal 29 April 2019;
Bukti T – 16 : Foto  kopi  sesuai  dengan  aslinya  Surat  Kepala  Dinas
Pemberdayaan Masyarakat Dan Kampung Kabupaten Kutai
Barat, yang ditujukan kepada HANSEN, SH, M.Si;
Bukti T – 17a: Foto  kopi  sesuai  dengan  aslinya  Surat  Kuasa  Hukum
MASDIANTO,  SH  &  REKAN  Nomor  :  001/KT-A/VII/2019
Perihal : Surat Keberatan;
Bukti T – 17b: Foto kopi sesuai dengan aslinya Disposisi Sekretaris Daerah
Kabupaten  Kutai  Barat  tertanggal  1  Agustus  2019  agar
Kabag Hukum segera tanggapi surat tersebut;
Menimbang bahwa  Penggugat dan Tergugat tidak mengajukan saksi
meskipun sudah diberikan kesempatan yang seluas-luasnya;
Menimbang,  bahwa  Penggugat  dan  Tergugat  masing-masing  telah
mengajukan Kesimpulannya secara tertulis tertanggal 13 Nopember 2019;
Menimbang, bahwa untuk mempersingkat Putusan ini, maka segala
sesuatu  yang  termuat  dalam  Berita  Acara  dianggap  tercantum  dan
merupakan bagian yang tidak terpisahkan dengan putusan ini;
Menimbang, bahwa selanjutnya para pihak menyatakan cukup dan
mohon Putusan;
TENTANG PERTIMBANGAN HUKUM
Menimbang, bahwa maksud dan tujuan gugatan Penggugat  adalah
sebagaimana termuat dalam bagian duduk sengketa tersebut diatas;
Menimbang, bahwa yang menjadi objek sengketa dalam perkara ini
adalah Keputusan Bupati Kutai Barat Nomor :800.05.860/K.971/2018 tanggal

Kepaniteraan Mahkamah Agung Republik Indonesia berusaha untuk selalu mencantumkan informasi paling kini dan akurat sebagai bentuk komitmen Mahkamah Agung untuk pelayanan publik, transparansi dan akuntabilitas
pelaksanaan fungsi peradilan. Namun dalam hal-hal tertentu masih dimungkinkan terjadi permasalahan teknis terkait dengan akurasi dan keterkinian informasi yang kami sajikan, hal mana akan terus kami perbaiki dari waktu kewaktu.
Dalam hal Anda menemukan inakurasi informasi yang termuat pada situs ini atau informasi yang seharusnya ada, namun belum tersedia, maka harap segera hubungi Kepaniteraan Mahkamah Agung RI melalui :

31  Desember  2018  tentang  Pemberhentian  Karena  Melakukan  Tindak
Pidana  Kejahatan  Jabatan  atau  Tindak  Pidana  Kejahatan  yang  ada
Hubungannya  dengan  Jabatan  atas  nama
Hansen,SH.,M.Si.NIP.197203172006041010 (Bukti P-1=T-1);
Menimbang, bahwa terhadap gugatan Penggugat, di dalam Jawaban
Tergugat terdapat eksepsi tentang gugatan telah daluarsa karena diajukan
melebihi  tenggang  waktu  oleh  karena  itu,  sebelum  mempertimbangkan
pokok  sengketa,  terlebih  dahulu  Majelis  Hakim  akan  mempertimbangkan
eksepsi Tergugat tersebut sebagai berikut:
Menimbang,  bahwa  Tergugat  pada  pokoknya  mendalilkan  bahwa
upaya  administrative  yang  dilakukan  penggugat  tidak  sesuai  dengan
peraturan perundang-undangan dan penggugat telah melewati batas waktu
21 hari kerja untuk mengajukan upaya administratif;
Menimbang,  bahwa  terhadap  eksepsi  tersebut,  Penggugat  dalam
repliknya pada persidangan yang terbuka untuk umum tanggal 02 Oktober
2019 yang pada pokoknya membantah eksepsi Tergugat dan tetap pada
dalil-dalil gugatan dan Tergugat menyatakan secara tertulis dupliknya yang
pada pokoknya tetap pada dalil jawaban pada persidangan yang terbuka
untuk umum tanggal 09 Oktober 2019;
Menimbang,  bahwa  terhadap  pertentangan  dalil  antara  Penggugat
dengan Tergugat, Majelis Hakim berpendapat bahwa yang menjadi persoalan
hukumnya adalah apakah suatu dasar penerbitan Keputusan Tata Usaha
Negara dapat dijadikan suatu objek sengketa sehingga Pejabat Tata Usaha
Negara yang menerbitkan suatu Keputusan tata usaha Negara yang menjadi
dasar  penerbitan  objek  sengketa  dapat  diikutsertakan  sebagai  Tergugat
dalam perkara a quo;
Menimbang, bahwa berdasarkan Pasal 1 angka 9 Undang-Undang RI
Nomor 51 Tahun 2009 tentang Perubahan kedua atas Undang-Undang RI
Nomor 5 Tahun 1986 tentang Peradilan Tata Usaha Negara (selanjutnya
disebut sebagai Undang-Undang Peratun) Jo. Pasal 87 Undang-Undang RI
Nomor  30  Tahun  2014  tentang  Administrasi  Pemerintahan  (selanjutnya
disebut sebagai Undang-Undang Nomor 30 Tahun 2014) menyatakan pada
pokoknya  objek  sengketa  tata  usaha  negara  adalah  berupa  Penetapan
tertulis yang dikeluarkan oleh badan/pejabat tata usaha Negara yang berisi

Kepaniteraan Mahkamah Agung Republik Indonesia berusaha untuk selalu mencantumkan informasi paling kini dan akurat sebagai bentuk komitmen Mahkamah Agung untuk pelayanan publik, transparansi dan akuntabilitas
pelaksanaan fungsi peradilan. Namun dalam hal-hal tertentu masih dimungkinkan terjadi permasalahan teknis terkait dengan akurasi dan keterkinian informasi yang kami sajikan, hal mana akan terus kami perbaiki dari waktu kewaktu.
Dalam hal Anda menemukan inakurasi informasi yang termuat pada situs ini atau informasi yang seharusnya ada, namun belum tersedia, maka harap segera hubungi Kepaniteraan Mahkamah Agung RI melalui :

tindakan hukum tata usaha Negara yang mencakup tindakan faktual yang
berdasarkan  peraturan  perundang-undangan  dan  AUPB  yang  berlaku
bersifat  konkret,individual  dan  final  serta  berpotensi  menimbulkan  akibat
hukum bagi seseorang/warga masyarakat atau badan hukum perdata;
Menimbang,  bahwa  berdasarkan  bukti  P-2  diperoleh  fakta  hukum
bahwa objek sengketa a quo diterima oleh Penggugat pada tanggal 03 Mei
2019,  kemudian  mengajukan  keberatan  administrasi  kepada  Gubernur
Kalimantan Timur tanggal 16 Juli 2019 (bukti P-3.b) kemudian penggugat
kembali mengajukan keberatan kepada Tergugat tanggal 30 Juli 2019 (bukti
P-3);
Menimbang,  bahwa  yang  dipermasalahkan  Tergugat  dari  segi
tenggang waktu tersebut adalah: 
- Upaya Keberatan sudah melewati tenggang waktu 21 hari kerja
berdasarakan  Undang-Undang  Administrasi  Pemerintahan
pasal 77;
Menimbang,  bahwa  Majelis  Hakim  dalam  pertimbangan  tentang
tenggang waktu mengacu kepada Undang-Undang  Nomor 5 Tahun 1986
tentang Peradilan Tata Usaha Negara Pasal 55 Jo.Undang-Undang Nomor
30  Tahun  2014  Pasal  77   tentang  Administrasi  Pemerintahan  Jo.Perma
Nomor 6 Tahun 2018 Pasal 2;
Menimbang, bahwa Majelis Hakim berpendapat aturan tentang upaya
administratif  yang  tertuang  dalam  pasal  77  ayat  (1)  Undang-Undang
Administrasi  Pemerintahan  terdapat  frasa  “dapat”  mengajukan
keberatan…….” yang diatur lebih lanjut oleh Perma Nomor 6 Tahun 2018
khususnya  pasal  2  ayat  (1)  hanya  menegaskan  bahwa  Pengadilan
berwenang  menerima,  menyelesaikan  sengketa  administrasi  setelah
menempuh upaya administrasi hal mana juga diatur dalam Pasal 75 Undang-
Undang Administrasi Pemerintahan;
Menimbang, bahwa  terhadap  aturan  diatas  menurut Majelis  Hakim
pengaturan  21  hari  kerja  masih  belum  diatur  lebih  lanjut,  oleh  karena
peraturan pemerintah terhadap pelaksanaan Undang-Undang Administrasi
Pemerintahan  juga  sampai  saat  ini  belum  ada,  untuk  itu  Majelis  Hakim
berpendapat terhadap tenggang waktu pengajuan gugatan, dimana diketahui
oleh Penggugat pada tanggal 03 mei 2019 maka sejak tanggal itulah waktu
90 hari berjalan sesuai dengan pasal 55 Undang-Undang Peradilan Tata

Kepaniteraan Mahkamah Agung Republik Indonesia berusaha untuk selalu mencantumkan informasi paling kini dan akurat sebagai bentuk komitmen Mahkamah Agung untuk pelayanan publik, transparansi dan akuntabilitas
pelaksanaan fungsi peradilan. Namun dalam hal-hal tertentu masih dimungkinkan terjadi permasalahan teknis terkait dengan akurasi dan keterkinian informasi yang kami sajikan, hal mana akan terus kami perbaiki dari waktu kewaktu.
Dalam hal Anda menemukan inakurasi informasi yang termuat pada situs ini atau informasi yang seharusnya ada, namun belum tersedia, maka harap segera hubungi Kepaniteraan Mahkamah Agung RI melalui :

Usaha  Negara,kemudian  penggugat  telah  mengajukan  keberatan  kepada
Gubernur Kalimantan Timur dan Tergugat dan sampai gugatan ini didaftarkan
tanggal  20  Agustus  2019  yang  mana  lebih  dari  10  hari  Tergugat  tidak
menanggapi keberatan dari penggugat;
Menimbang, bahwa mengacu pada Pasal 55 Undang-Undang Peratun
ketika  penggugat  mengajukan  upaya  keberatan  tanggal  30  Juli  2019
terhitung sejak diterimanya objek sengketa a quo adalah 88 hari  sehingga
Majelis  Hakim  berkesimpulan  bahwa  pengajuan  gugatan  aquo  diajukan
masih dalam tenggang waktu pengajuan gugatan sebagaimana dimaksud
Pasal 55 Undang-Undang Peratun;
Menimbang,  bahwa  dari  uraian  diatas  Majelis  Hakim  berpendapat
eksepsi Tergugat tentang gugatan daluarsa tidaklah berdasar hukum dan
haruslah dinyatakan tidak diterima;
Menimbang,  bahwa  selanjutnya  sebelum  mempertimbangkan  pokok
sengketa, Majelis Hakim akan mempertimbangkan secara ringkas mengenai
formalitas  gugatan  Penggugat  yang  meliputi  kewenangan  mengadili
Pengadilan Tata Usaha Negara dan Kedudukan Hukum Penggugat sebagai
berikut:
Menimbang, bahwa mengenai kewenangan mengadili dari Pengadilan
Tata  Usaha  Negara  tersebut akan  Majelis  Hakim  pertimbangkan  sebagai
berikut:
Menimbang, bahwa dengan menelaah ketentuan dalam Pasal 1 angka
9 Undang-Undang Peratun jo Pasal 87 Undang-Undang Nomor 30 Tahun
2014, yang dihubungkan dengan objek sengketa  aquo  (bukti P-1 dan T-1)
yang  merupakan  sengketa  kepegawaian  (pemberhentian  tidak  dengan
hormat)  maka  Majelis  Hakim  berpendapat  bahwa  objek  sengketa  aquo
merupakan Keputusan Tata Usaha Negara dan juga bukan Keputusan Tata
Usaha  Negara  yang  dibatasi  sebagaimana  dimaksud  ketentuan  Pasal  2
Undang-Undang  Nomor 9 Tahun 2004  Tentang  Perubahan  atas  Undang-
Undang  Nomor  5  Tahun  1986  Tentang  Peradilan  Tata  Usaha  Negara
(selanjutnya  disebut  sebagai  Undang  Undang  Peratun)  oleh  karenanya
apabila dihubungkan dengan Pasal 1 angka 10 Undang-Undang Peratun

Kepaniteraan Mahkamah Agung Republik Indonesia berusaha untuk selalu mencantumkan informasi paling kini dan akurat sebagai bentuk komitmen Mahkamah Agung untuk pelayanan publik, transparansi dan akuntabilitas
pelaksanaan fungsi peradilan. Namun dalam hal-hal tertentu masih dimungkinkan terjadi permasalahan teknis terkait dengan akurasi dan keterkinian informasi yang kami sajikan, hal mana akan terus kami perbaiki dari waktu kewaktu.
Dalam hal Anda menemukan inakurasi informasi yang termuat pada situs ini atau informasi yang seharusnya ada, namun belum tersedia, maka harap segera hubungi Kepaniteraan Mahkamah Agung RI melalui :

maka  Majelis  Hakim  berpendapat  bahwa  sengketa  aquo merupakan
sengketa tata usaha negara;
Menimbang, bahwa sesuai pertimbangan hukum di atas yaitu bahwa
sengketa  aquo merupakan  sengketa  tata  usaha  negara  oleh  karenanya
apabila  dihubungkan  dengan  Pasal  47  dan  Pasal  50  Undang-Undang
Peratun, maka Majelis Hakim berkesimpulan bahwa Pengadilan Tata Usaha
Negara secara absolut memiliki kewenangan untuk  memeriksa, memutus
dan meyelesaikan sengketa aquo;
Menimbang,  bahwa  selanjutnya  Majelis  Hakim  akan
mempertimbangkan  mengenai  Kedudukan  hukum  Penggugat  dalam
mengajukan gugatan sebagai berikut;
Menimbang, bahwa dengan menafsirkan ketentuan Pasal 53 ayat (1)
Undang-Undang Peratun, Majelis Hakim berpendapat bahwa untuk dapat
memiliki  kedudukan  hukum  atau  kapasitas  hukum  untuk  mengajukan
gugatan  di  Pengadilan  Tata  Usaha  Negara,  seorang  penggugat  harus
memenuhi kriteria:
Berupa subjek hukum Orang atau badan hukum perdata; dan
Adanya kepentingan yang dirugikan; 
Menimbang,  bahwa  berdasarkan  ketentuan  Pasal  1  angka  10
Undang-Undang  Peratun,  dihubungkan  dengan  surat  gugatan  Penggugat
dan seluruh bukti surat para pihak dapat dikualifikasikan bahwa Penggugat
adalah selaku subjek hukum orang, dan dengan demikian Penggugat telah
memenuhi kriteria berupa subjek hukum orang;
Menimbang, bahwa terkait dengan Kepentingan yang dirugikan, baik
Undang-Undang  Peratun  beserta  perubahannya  maupun  Undang-Undang
Administrasi Pemerintahan tidak mendefinisikan apa yang dimaksud dengan
kepentingan.  Oleh  karena  itu  untuk  mendefinisikan  apa  yang  dimaksud
dengan kepentingan dalam kaitannya dengan hukum acara peradilan tata
usaha  negara,  Majelis  Hakim  menggunakan  doktrin  hukum  yang
dikemukakan oleh Indroharto;
Menimbang, bahwa menurut Indroharto, yang dimaksud kepentingan
dalam kaitannya dengan hukum acara tata usaha negara mengandung arti,
yaitu: Pertama menunjuk kepada nilai yang harus dilindungi oleh hukum dan

Kepaniteraan Mahkamah Agung Republik Indonesia berusaha untuk selalu mencantumkan informasi paling kini dan akurat sebagai bentuk komitmen Mahkamah Agung untuk pelayanan publik, transparansi dan akuntabilitas
pelaksanaan fungsi peradilan. Namun dalam hal-hal tertentu masih dimungkinkan terjadi permasalahan teknis terkait dengan akurasi dan keterkinian informasi yang kami sajikan, hal mana akan terus kami perbaiki dari waktu kewaktu.
Dalam hal Anda menemukan inakurasi informasi yang termuat pada situs ini atau informasi yang seharusnya ada, namun belum tersedia, maka harap segera hubungi Kepaniteraan Mahkamah Agung RI melalui :

Kedua  kepentingan  proses,  yaitu  apa  yang  hendak  dicapai  dengan
melakukan  suatu  proses  gugatan  yang  bersangkutan.  Dalam  kaitannya
dengan kepentingan nilai yang harus dilindungi oleh hukum tersebut, dapat
kita lihat adanya hubungan antara orang yang bersangkutan disatu pihak
dengan  Keputusan  Tata  Usaha  Negara  yang  bersangkutan  di  lain  pihak
(Indroharto,  Usaha  Memahami  Undang-Undang  tentang  Peradilan  Tata
Usaha Negara: Buku II Beracara di Pengadilan Tata Usaha Negara, Penerbit
Pustaka Sinar Harapan, Jakarta, 2005, hlm. 37-38);
Menimbang, bahwa berdasarkan bukti P-1 dan T-1 diperoleh fakta
hukum bahwa Penggugat sebagai orang yang dituju langsung oleh objek
sengketa  dimana  penggugat  telah  diberhentikan  tidak  dengan  hormat
sebagai Pegawai Negeri Sipil dan dengan demikian (sesuai fakta  notoir)
hak-hak  Penggugat  sebagai  Pegawai  Negeri  Sipil  berupa  Gaji  dan
tunjangan  lainnya  juga  diberhentikan,  sehingga  apabila  fakta  hukum
tersebut dihubungkan dengan doktrin hukum yang dikemukakan Indroharto,
maka Majelis Hakim berpendapat bahwa Penggugat memiliki kepentingan
yang dirugikan atas terbitnya objek sengketa aquo;
Menimbang, bahwa oleh karena Penggugat telah memenuhi kriteria
berupa subjek hukum orang dan adanya kepentingan yang dirugikan atas
terbitnya objek sengketa  aquo, apabila dikaitkan dengan Pasal 53 ayat (1)
Undang-Undang  Peratun  dan  dengan  memperhatikan  asas  hukum  no
interest, no action , maka Majelis Hakim berkesimpulan bahwa Penggugat
memiliki  kedudukan  hukum  atau  Kapasitas  Hukum  untuk  mengajukan
gugatan aquo;
Menimbang, bahwa berdasarkan pertimbangan-pertimbangan hukum
diatas,  maka  Majelis  Hakim  berkesimpulan  bahwa  formalitas  Gugatan
Penggugat telah terpenuhi dan selanjutnya akan dipertimbangkan mengenai
pokok sengketanya sebagai berikut;
Dalam Pokok Sengketa 
Menimbang, bahwa dari dalil-dalil Penggugat dan dalil-dalil Tergugat,
menurut  hemat  Majelis  Hakim  yang  menjadi  permasalahan  hukum
administrasi  yang  harus  dipertimbangkan  dalam  sengketa  aquo  adalah
apakah  objek  sengketa  yang  diterbitkan  oleh  Tergugat   sesuai  dengan

Kepaniteraan Mahkamah Agung Republik Indonesia berusaha untuk selalu mencantumkan informasi paling kini dan akurat sebagai bentuk komitmen Mahkamah Agung untuk pelayanan publik, transparansi dan akuntabilitas
pelaksanaan fungsi peradilan. Namun dalam hal-hal tertentu masih dimungkinkan terjadi permasalahan teknis terkait dengan akurasi dan keterkinian informasi yang kami sajikan, hal mana akan terus kami perbaiki dari waktu kewaktu.
Dalam hal Anda menemukan inakurasi informasi yang termuat pada situs ini atau informasi yang seharusnya ada, namun belum tersedia, maka harap segera hubungi Kepaniteraan Mahkamah Agung RI melalui :

peraturan perundang-undangan yang berlaku dan Asas Umum Pemerintahan
Yang Baik atau tidak?;
Menimbang,  bahwa  dasar  pengujian  oleh  Majelis  Hakim  terhadap
permasalahan hukum tersebut diatas adalah meliputi I. Aspek Kewenangan,

## II. Aspek Prosedur, dan III. Aspek Substansi, yang akan dipertimbangkan
sebagai berikut:

## I. Aspek Kewenangan;
Menimbang,  bahwa  terlebih  dahulu  Majelis  Hakim  akan
mempertimbangkan  Aspek  Kewenangan  penerbitan  objek  sengketa  yaitu
apakah Tergugat memiliki kewenangan untuk menerbitkan Keputusan Tata
Usaha Negara yang menjadi objek sengketa aquo?
Menimbang, bahwa setelah mencermati Peraturan Pemerintah Nomor
9  tahun  2003  tentang  Wewenang  Pengangkatan,  Pemindahan  dan
Pemberhentian  Pegawai  Negeri  Sipil  (selanjutnya  disebut  Peraturan
Pemerintah  Nomor  9  Tahun  2003)  dan  Peraturan  Pemerintah  Nomor  11
Tahun 2017 tentang Manajemen Pegawai Negeri Sipil (selanjutnya disebut
Peraturan Pemerintah Nomor 11 Tahun 2017), Majelis Hakim berpendapat
bahwa  dengan  diundangkannya  Peraturan  Pemerintah  Nomor  11  Tahun
2017  telah  terjadi  pergeseran  norma  hukum  dalam  hal  kewenangan
menetapkan pemberhentian Pegawai Negeri Sipil, yaitu dahulu kewenangan
menetapkan pemberhentian Pegawai Negeri Sipil didasarkan kepada jenjang
Golongan/Pangkat seorang Pegawai Negeri Sipil kini telah berubah menjadi
kewenangan menetapkan pemberhentian Pegawai Negeri Sipil didasarkan
pada jenjang Jabatan seorang Pegawai Negeri Sipil;
Menimbang, bahwa Pasal 53 Undang-Undang Nomor 5 Tahun 2014
Tentang Aparatur Sipil Negara (selanjutnya disebut Undang-Undang Nomor 5
Tahun  2014)  berbunyi:  “Presiden  selaku  pemegang  kekuasaan  tertinggi
pembinaan  ASN  dapat  mendelegasikan  kewenangan  menetapkan
pengangkatan,  pemindahan,  dan  pemberhentian  pejabat  selain  pejabat
pimpinan tinggi utama dan madya, dan pejabat fungsional keahlian utama
kepada:”
a.menteri di kementerian;
b.pimpinan lembaga di lembaga pemerintah nonkementerian;

Kepaniteraan Mahkamah Agung Republik Indonesia berusaha untuk selalu mencantumkan informasi paling kini dan akurat sebagai bentuk komitmen Mahkamah Agung untuk pelayanan publik, transparansi dan akuntabilitas
pelaksanaan fungsi peradilan. Namun dalam hal-hal tertentu masih dimungkinkan terjadi permasalahan teknis terkait dengan akurasi dan keterkinian informasi yang kami sajikan, hal mana akan terus kami perbaiki dari waktu kewaktu.
Dalam hal Anda menemukan inakurasi informasi yang termuat pada situs ini atau informasi yang seharusnya ada, namun belum tersedia, maka harap segera hubungi Kepaniteraan Mahkamah Agung RI melalui :

c.sekretaris  jenderal  di  sekretariat  lembaga  negara  dan  lembaga
nonstruktural;
d.gubernur di provinsi; dan
e.bupati/walikota di kabupaten/kota.
Menimbang, bahwa Pasal 289 ayat (1) Peraturan Pemerintah Nomor
11 Tahun 2017 juga mengatur hal serupa dengan Pasal 53 Undang-Undang
Nomor 5 Tahun 2014;
Menimbang, bahwa Pasal 292 Peraturan Pemerintah Nomor 11 Tahun
2017  berbunyi:  PPK  instansi  daerah  kabupaten/kota  menetapkan
pemberhentian terhadap:
Calon PNS yang tidak memenuhi syarat untuk diangkat menjadi PNS
di lingkungannya; dan
1. PNS yang menduduki:
2. JPT pratama;
3. JA;
4. JF ahli madya, JF ahli muda, dan JF ahli pertama; dan
5. JF penyelia, JF mahir, JF terampil dan JF pemula
Menimbang,  bahwa  dengan  menafsirkan  secara  gramatikal  dan
sistematis Pasal 53 Undang-undang Nomor 5 Tahun 2014 jis Pasal 50, Pasal
289 ayat (1) dan Pasal 292 Peraturan Pemerintah Nomor 11 Tahun 2017,
Majelis Hakim berpendapat bahwa Bupati/Walikota selaku Pejabat Pembina
Kepegawaian  daerah  Kabupaten/Kota  telah  menerima  pendelegasian
wewenang dari Presiden untuk menetapkan pemberhentian Pegawai Negeri
Sipil yang menduduki jabatan administrasi (JA);
Menimbang, bahwa Pasal 50 Peraturan Pemerintah Nomor 11 Tahun
2017 berbunyi:
Jenjang JA dari yang paling tinggi ke yang paling rendah terdiri atas:
a.Jabatan administrator;
b.Jabatan pengawas; dan
c. Jabatan pelaksana

Kepaniteraan Mahkamah Agung Republik Indonesia berusaha untuk selalu mencantumkan informasi paling kini dan akurat sebagai bentuk komitmen Mahkamah Agung untuk pelayanan publik, transparansi dan akuntabilitas
pelaksanaan fungsi peradilan. Namun dalam hal-hal tertentu masih dimungkinkan terjadi permasalahan teknis terkait dengan akurasi dan keterkinian informasi yang kami sajikan, hal mana akan terus kami perbaiki dari waktu kewaktu.
Dalam hal Anda menemukan inakurasi informasi yang termuat pada situs ini atau informasi yang seharusnya ada, namun belum tersedia, maka harap segera hubungi Kepaniteraan Mahkamah Agung RI melalui :

Menimbang, bahwa berdasarkan bukti P-1 dan T-1, diperoleh fakta
hukum  bahwa  jabatan  terakhir  Penggugat  adalah  Kepala  Seksi  Fasilitas
Antar Kampung Dinas Pemberdayaan Masyarakat dan Kampung Kabupaten
Kutai  Barat  yang  apabila  dihubungkan  dengan  Pasal  50  Peraturan
Pemerintah Nomor 11 Tahun 2017 maka Jabatan tersebut adalah jabatan
pelaksana yang merupakan jabatan administrasi;
Menimbang, bahwa berdasarkan bukti P-1 dan T-1 diperoleh fakta
hukum  bahwa  objek  sengketa  a  quo  ditetapkan  oleh  FX  Yapan  yang
merupakan Bupati Kutai Barat masa jabatan 2016 - 2021;
Menimbang, bahwa apabila  fakta hukum jabatan terakhir Penggugat
adalah Kepala Seksi Kebandarudaraan Dishubkominfo yang diberhentikan
tidak dengan hormat sebagai Pegawai Negeri Sipil oleh Bupati Kabupaten
Kutai  Barat,  apabila  dihubungkan  dengan  ketentuan  Pasal  53  Undang-
undang Nomor 5 Tahun 2014 jis Pasal 50, Pasal 289 ayat (1) dan Pasal 292
Peraturan  Pemerintah  Nomor  11  Tahun  2017,  maka  Majelis  Hakim
berkesimpulan  bahwa  Tergugat  (Bupati  Kabupaten  Kutai  Barat)  memiliki
kewenangan  untuk  menerbitkan  objek  sengketa  a  quo,  oleh  karenanya
penerbitan objek sengketa oleh Tergugat dari Aspek Kewenangannya telah
sesuai  ketentuan  peraturan  perundang-undangan  yang  berlaku  yaitu
ketentuan Undang-undang Nomor 5 Tahun 2014 jo Peraturan Pemerintah
Nomor 11 Tahun 2017;

## II. Aspek Prosedur;
Menimbang,  bahwa  selanjutnya  Majelis  Hakim  akan
mempertimbangkan apakah dari aspek prosedur penerbitan objek sengketa
telah sesuai dengan ketentuan peraturan perundang-undangan yang berlaku
dan asas umum pemerintahan yang baik?;
Menimbang, bahwa terhadap permasalahan hukum tersebut, Majelis
Hakim memberikan pertimbangan hukum sebagai berikut:
Menimbang, bahwa ketentuan Pasal 88 ayat (1) huruf c dan ayat (2)
Undang-Undang  Nomor  5  Tahun  2014  tentang  Aparatur  Sipil  Negara
menyebutkan: 

Kepaniteraan Mahkamah Agung Republik Indonesia berusaha untuk selalu mencantumkan informasi paling kini dan akurat sebagai bentuk komitmen Mahkamah Agung untuk pelayanan publik, transparansi dan akuntabilitas
pelaksanaan fungsi peradilan. Namun dalam hal-hal tertentu masih dimungkinkan terjadi permasalahan teknis terkait dengan akurasi dan keterkinian informasi yang kami sajikan, hal mana akan terus kami perbaiki dari waktu kewaktu.
Dalam hal Anda menemukan inakurasi informasi yang termuat pada situs ini atau informasi yang seharusnya ada, namun belum tersedia, maka harap segera hubungi Kepaniteraan Mahkamah Agung RI melalui :

ayat (1)   : PNS diberhentikan sementara, apabila: c. ditahan karena menjadi
tersangka tindak pidana;
ayat  (2)  :  Pengaktifan  kembali  PNS  yang  diberhentikan  sementara
sebagaimana dimaksud pada ayat (1) dilakukan oleh Pejabat
Pembina Kepegawaian.
Menimbang,  bahwa  ketentuan  Pasal  87  ayat  (4)  huruf  b  dan  d
Undang-Undang  Nomor  5  Tahun  2014  tentang  Aparatur  Sipil  Negara
menyebutkan:  PNS diberhentikan tidak dengan hormat karena: b. dihukum
penjara atau kurungan berdasarkan putusan pengadilan yang telah memiliki
kekuatan hukum tetap karena melakukan tindak pidana kejahatan jabatan
atau  tindak  pidana  kejahatan  yang  ada  hubungannya  dengan  jabatan
dan/atau pidana umum; d. dihukum penjara berdasarkan putusan pengadilan
yang telah memiliki kekuatan hukum tetap karena melakukan tindak pidana
dengan  pidana  penjara  paling  singkat  2  (dua)  tahun  dan  pidana  yang
dilakukan dengan berencana;
Menimbang,  bahwa  ketentuan  Pasal  89  Undang-Undang  Nomor  5
Tahun  2014  tentang  Aparatur  Sipil  Negara  menyebutkan:Ketentuan  lebih
lanjut mengenai tata cara pemberhentian, pemberhentian sementara, dan
pengaktifan kembali PNS sebagaimana dimaksud dalam Pasal 87 dan Pasal
88 diatur dengan Peraturan Pemerintah;
Menimbang, bahwa Pasal 266 Peraturan Pemerintah Nomor 11 Tahun
2017 berbunyi:
(1) Pemberhentian dengan hormat atau tidak dengan hormat PNS yang
melakukan tindak pidana/ penyelewengan diusulkan oleh: 
a. PPK kepada Presiden bagi PNS yang menduduki JPT utama,
JPT madya, dan JF ahli utama; atau
b.  PyB kepada PPK bagi PNS yang menduduki JPT pratama, JA,
JF selain JF ahli utama. 
(2) Presiden  atau  PPK  menetapkan  keputusan  pemberhentian  dengan
hormat atau tidak dengan hormat sebagai PNS sebagaimana dimaksud
pada  ayat  (1)  dengan  mendapat  hak  kepegawaian  sesuai  dengan
ketentuan peraturan perundang-undangan.

Kepaniteraan Mahkamah Agung Republik Indonesia berusaha untuk selalu mencantumkan informasi paling kini dan akurat sebagai bentuk komitmen Mahkamah Agung untuk pelayanan publik, transparansi dan akuntabilitas
pelaksanaan fungsi peradilan. Namun dalam hal-hal tertentu masih dimungkinkan terjadi permasalahan teknis terkait dengan akurasi dan keterkinian informasi yang kami sajikan, hal mana akan terus kami perbaiki dari waktu kewaktu.
Dalam hal Anda menemukan inakurasi informasi yang termuat pada situs ini atau informasi yang seharusnya ada, namun belum tersedia, maka harap segera hubungi Kepaniteraan Mahkamah Agung RI melalui :

(3) Keputusan  pemberhentian  sebagaimana  dimaksud  pada  ayat  (2)
ditetapkan  paling  lama  21  (dua  puluh  satu)  hari  kerja  setelah  usul
pemberhentian diterima.
Menimbang, bahwa Pasal 276 huruf c Peraturan Pemerintah Nomor
11  Tahun  2017  berbunyi  “PNS  diberhentikan  sementara  apabila  ditahan
karena menjadi tersangka tindak pidana”;
Menimbang, bahwa Pasal 287 ayat (1) Peraturan Pemerintah Nomor
11  Tahun  2017  berbunyi  :  PNS  yang  telah  selesai  menjalankan  pidana
penjara  paling  singkat  2  (dua)  tahun  dan  pidana  yang  dilakukan  tidak
berencana,  mengajukan  pengaktifan  kembali  sebagai  PNS  kepada  PPK
melalui  PyB  paling  lama  30  (tiga  puluh)  hari  terhitung  sejak  selesai
menjalankan pidana penjara;
Menimbang, bahwa dengan mencermati ketentuan-ketentuan diatas,
Majelis  Hakim  berpendapat  bahwa  prosedur  bagi  PNS  yang  melakukan
tindak pidana/penyelewengan adalah sebagai berikut:
a. Apabila  ditahan  karena  menjadi  tersangka  tindak  pidana,  PNS
diberhentikan sementara;
b. Dalam hal PNS tersebut terbukti bersalah melakukan tindak pidana,
maka setelah mendapat salinan Putusan Pengadilan yang berkekuatan
hukum tetap, dapat dilakukan dua skema yaitu:
1. Diaktifkan/diangkat kembali apabila sesuai dengan ketentuan
dimungkinkan  untuk  diaktifkan  kembali  dan  tersedia  lowongan
jabatan untuk PNS tersebut;
2. Diberhentikan dengan hormat atau dengan tidak hormat sesuai
dengan jenis pelanggarannya;
Menimbang, bahwa berdasarkan uraian diatas dapat diketahui bahwa
bagi PNS yang melakukan tindak pidana dan telah diterbitkan pemberhentian
sementara, maka tahapan berikutnya adalah dapat diberhentikan atau dapat
diaktifkan  kembali,  sehingga  pemberhentian  atau  pengaktifan  kembali
merupakan  pilihan  bagi  PPK  untuk  menentukan  status  hukum  bagi  PNS
tersebut,  dengan  demikian   tidak  mungkin  diaktifkan  kembali  setelah
diberhentikan  dan  tidak  mungkin  juga  diberhentikan  setelah  diaktifkan
kembali;

Kepaniteraan Mahkamah Agung Republik Indonesia berusaha untuk selalu mencantumkan informasi paling kini dan akurat sebagai bentuk komitmen Mahkamah Agung untuk pelayanan publik, transparansi dan akuntabilitas
pelaksanaan fungsi peradilan. Namun dalam hal-hal tertentu masih dimungkinkan terjadi permasalahan teknis terkait dengan akurasi dan keterkinian informasi yang kami sajikan, hal mana akan terus kami perbaiki dari waktu kewaktu.
Dalam hal Anda menemukan inakurasi informasi yang termuat pada situs ini atau informasi yang seharusnya ada, namun belum tersedia, maka harap segera hubungi Kepaniteraan Mahkamah Agung RI melalui :

Menimbang,bahwa apabila ingin mengaktifkan kembali PNS yang telah
diberhentikan  maka  harus  mengikuti  kembali  tahapan  penerimaan  PNS
sebagaimana  ketentuan  yang  berlaku,  demikianpun  apabila  ingin
memberhentikan PNS yang sudah diaktifkan kembali, maka harus ditemukan
pelanggaran baru/tindak pidana baru yang dilakukan PNS tersebut setelah
diaktifkan kembali yang selanjutnya diproses sesuai dengan ketentuan yang
berlaku; 
Menimbang,  bahwa  berdasarkan  bukti-bukti  yang  diajukan
dipersidangan diperoleh fakta-fakta hukum sebagai berikut:
1. Bahwa  berdasarkan  bukti  T-5  berupa  Putusan  Pengadilan  Tindak
Pidana Korupsi pada Pengadilan Negeri Samarinda Nomor 60/Pid.sus-
TPK/2015/PN.Smr tanggal 02 Mei 2016, Penggugat dinyatakan terbukti
secara sah dan meyakinkan bersalah melakukan tindak pidana dalam
korupsi  secara  bersama-sama  dan  dijatuhi  hukuman  pidana  penjara
selama 1 (satu) tahun 4 bulan dan denda sejumlah Rp. 50.000.000,-
(lima puluh juta rupiah) dengan ketentuan apabila denda tidak dibayar
diganti dengan pidana kurungan selama 2 bulan;
2. Bahwa  berdasarkan  bukti  P-4  (Penggugat)  dilantik  dan  diangkat
kembali sebagai Kepala Seksi Fasilitas Kerjasama antar Kampung pada
Dinas Pemberdayaan Masyarakat dan Kampung Kabupaten Kutai Barat
tanggal 07 Juni 2018 (bukti P-4);
3. Objek sengketa di terbitkan  pada tanggal 31 Desember  2018  dan
diterima oleh penggugat tanggal 3 Mei 2019;
Menimbang, bahwa berdasarkan fakta-fakta hukum tersebut diatas,
dapat diketahui Tergugat belum melakukan pemberhentian sementara saat
Penggugat pertama kali ditahan dan bukti P-4 dan P-6 fakta hukum lain
menyatakan  bahwa  ketika  penggugat  telah  selesai  menjalani  hukuman
penggugat diaktifkan kembali sebagai PNS di lingkungan Kabupaten Kutai
Barat;
Menimbang, bahwa dari uraian diatas terbukti ketika penggugat telah
selesai menjalani masa hukumannya penggugat kembali aktif sebagai PNS
jika hal ini dianalogikan dengan pasal 30 ayat (3) bahwa PNS tidak dapat
dijatuhi hukuman disiplin dua kali atau lebih untuk satu pelanggaran disiplin
maka penggugat selaku PNS yang dalam fakta hukum pada saat ditahan

Kepaniteraan Mahkamah Agung Republik Indonesia berusaha untuk selalu mencantumkan informasi paling kini dan akurat sebagai bentuk komitmen Mahkamah Agung untuk pelayanan publik, transparansi dan akuntabilitas
pelaksanaan fungsi peradilan. Namun dalam hal-hal tertentu masih dimungkinkan terjadi permasalahan teknis terkait dengan akurasi dan keterkinian informasi yang kami sajikan, hal mana akan terus kami perbaiki dari waktu kewaktu.
Dalam hal Anda menemukan inakurasi informasi yang termuat pada situs ini atau informasi yang seharusnya ada, namun belum tersedia, maka harap segera hubungi Kepaniteraan Mahkamah Agung RI melalui :

tidak  menerima  gaji  namun  tidak  ditemukan  fakta  hukum  terdapat
pemberhentian  sementaranya  kemudian  langsung  diberhentikan  tidak
dengan  hormat  menurut  Majelis  Hakim  prosedur  pemberhentian  tidak
diproses dengan benar dan oleh karenanya pemberhentian tidak dengan
hormat penggugat terbukti telah cacat prosedur;
Menimbang, bahwa tindakan Tergugat tersebut terbukti bertentangan
dengan ketentuan  Pasal 88 ayat (2) Undang-Undang Nomor 5 Tahun 2014
tentang  Aparatur  Sipil  Negara,  pemberhentian  sementara  tidak  dilakukan
maka  Majelis  Hakim  berpendapat  bahwa  tindakan  Tergugat  menerbitkan
keputusan objek sengketa a quo tidak  memperhatikan prosedur yang sesuai
dengan peraturan perundang-undangan;

## III. Aspek Substansi;
Menimbang,  bahwa  selanjutnya  Majelis  Hakim  akan
mempertimbangkan apakah dari aspek substansi penerbitan objek sengketa
telah sesuai dengan ketentuan peraturan perundang-undangan yang berlaku
dan  asas  umum  pemerintahan  yang  baik,  sebagaimana  akan  diuraikan
sebagai berikut;
Menimbang, bahwa yang  menjadi  permasalahan  hukumnya  adalah
apakah  Pemberhentian  Tidak  dengan  Hormat  sebagai  PNS  kepada
Penggugat telah sesuai dengan ketentuan hukum yang berlaku?;
Menimbang, bahwa terhadap permasalahan hukum tersebut, Majelis
Hakim memberikan pertimbangan hukum sebagai berikut:
Menimbang, bahwa mencermati permasalahan-permasalahan terkait
tindak pidana Korupsi oleh Aparatur Pemerintahan, Majelis Hakim melihat
bahwa ada kalanya tindakan aparatur pemerintahan tersebut bukan murni
merupakan tindak pidana korupsi dengan niat untuk memperkaya diri sendiri
atau  orang  lain  tetapi  lebih  dikarenakan  kesalahan  didalam  penerapan
prosedur yang tidak sesuai, penerapan peraturan perundang-undangan yang
tidak  pas  dan  atau  melaksanakan  perintah  atasan  langsung  yang
bersangkutan;
Menimbang, bahwa terkait dengan Surat Keputusan Bersama Menteri
Dalam  Negeri  Nomor  182/6597/SJ,  Menteri  Pendayagunaan  Aparatur

Kepaniteraan Mahkamah Agung Republik Indonesia berusaha untuk selalu mencantumkan informasi paling kini dan akurat sebagai bentuk komitmen Mahkamah Agung untuk pelayanan publik, transparansi dan akuntabilitas
pelaksanaan fungsi peradilan. Namun dalam hal-hal tertentu masih dimungkinkan terjadi permasalahan teknis terkait dengan akurasi dan keterkinian informasi yang kami sajikan, hal mana akan terus kami perbaiki dari waktu kewaktu.
Dalam hal Anda menemukan inakurasi informasi yang termuat pada situs ini atau informasi yang seharusnya ada, namun belum tersedia, maka harap segera hubungi Kepaniteraan Mahkamah Agung RI melalui :

Negara dan Reformasi Birokrasi Nomor 15 Tahun 2018 dan Kepala Badan
Kepegawaian  Negara  Nomor  153/KEP/2018  tanggal  13  September  2018
tentang  Penegakan  hukum  terhadap  PNS  yang  telah  dijatuhi  hukuman
berdasarkan  Putusan  Pengadilan  yang  berkekuatan  hukum  tetap  karena
melakukan tindak pidana kejahatan jabatan atau tindak pidana yang ada
hubungannya dengan jabatan (selanjutnya disebut SKB 3 Menteri) (bukti T-7)
secara garis besar Majelis Hakim sependapat dengan Keputusan bersama
tersebut, meskipun demikian Majelis Hakim berpendapat bahwa penegakan
hukum  berupa  pemberhentian  tidak  dengan  hormat  sebagai  PNS  harus
diterapkan secara kasuistis dengan memperhatikan tingkat kesalahan yang
dilakukan  dan  tetap  harus  mengacu  kepada  Undang-Undang  Nomor  30
Tahun 2014 yang merupakan umbrella act dalam pelaksanaan Administrasi
Pemerintahan, dimana  salah  satu  tujuan  dari  Undang-Undang  Nomor  30
Tahun 2014 tersebut adalah sebagai bentuk perlindungan hukum terhadap
aparatur pemerintahan (Pegawai Negeri Sipil) dalam pelaksanaan tugasnya,
oleh karenanya didalam menjatuhkan sanksi administrasi terhadap aparatur
pemerintahan (PNS) haruslah mempertimbangkan unsur proporsional dan
keadilan sebagaimana dimaksud dalam Pasal 83 ayat (1) Undang-Undang
Administrasi Pemerintahan tersebut;
Menimbang,  bahwa  apabila  kita  hubungkan  semangat  penegakan
hukum  terhadap  PNS  yang  terlibat  tindak  pidana  korupsi  sebagaimana
tertuang  dalam  SKB  3  Menteri  tersebut  dengan  tujuan  Undang-Undang
Nomor  30  Tahun  2014  untuk  memberikan  perlindungan  hukum  terhadap
aparatur pemerintahan (PNS) dalam pelaksanaan tugasnya serta  dengan
mempertimbangkan  unsur  proporsional  dan  Keadilan  sebagaimana
dimaksud Pasal 83 ayat (1) Undang-Undang Nomor 30 Tahun 2014 dan
dengan  mempertimbangkan  bahwa  ada  kalanya  tindakan  aparatur
pemerintahan bukan merupakan murni tindak pidana korupsi dengan niat
untuk  memperkaya  diri  sendiri  atau  orang  lain  tetapi  lebih  dikarenakan
kesalahan  didalam  penerapan  prosedur  yang  tidak  sesuai,  penerapan
peraturan  perundang-undangan  yang  tidak  pas  dan  atau  melaksanakan
perintah  atasan  langsung  yang  bersangkutan,  maka  Majelis  Hakim
berpendapat  bahwa  penjatuhan  sanksi  kepada  aparatur  pemerintahan
khususnya Pegawai Negeri Sipil yang terlibat dalam kasus tindak pidana
korupsi hanya dapat dilakukan apabila memenuhi kriteria:

Kepaniteraan Mahkamah Agung Republik Indonesia berusaha untuk selalu mencantumkan informasi paling kini dan akurat sebagai bentuk komitmen Mahkamah Agung untuk pelayanan publik, transparansi dan akuntabilitas
pelaksanaan fungsi peradilan. Namun dalam hal-hal tertentu masih dimungkinkan terjadi permasalahan teknis terkait dengan akurasi dan keterkinian informasi yang kami sajikan, hal mana akan terus kami perbaiki dari waktu kewaktu.
Dalam hal Anda menemukan inakurasi informasi yang termuat pada situs ini atau informasi yang seharusnya ada, namun belum tersedia, maka harap segera hubungi Kepaniteraan Mahkamah Agung RI melalui :

1. Dilakukan  oleh  seseorang  yang  pada  saat  melakukan  tindak
pidananya telah menjabat sebagai PNS;
2. Merupakan tindak pidana kejahatan dalam Jabatan atau yang ada
hubungannya dengan jabatan.
Menimbang,  bahwa  selanjutnya  apabila  dua  kriteria  diatas  secara
kumulatif terpenuhi maka dapat diterapkan sanksi administrasi berupa:
1. apabila PNS tersebut terbukti secara sah dan meyakinkan bersalah
melakukan tindak pidana sebagaimana dalam dakwaan primair penuntut
umum dan PNS yang bersangkutan memperoleh (menikmati) hasil (uang
dan barang) dari tindak pidana korupsinya tersebut maka terhadapnya
dikenakan Sanksi Administrasi Berat sebagaimana dimaksud Pasal 81
ayat  (3)  Undang-Undang  Administrasi  Pemerintahan  atau  Ketentuan
Hukum Lain yang berlaku;
2. apabila  PNS  tersebut  tidak  terbukti  secara  sah  dan  meyakinkan
bersalah melakukan tindak pidana sebagaimana dalam dakwaan primair
penuntut umum atau (dalam hal ini) terbukti secara sah dan meyakinkan
melakukan  tindak  pidana  sebagaimana  dakwaan  sekunder  penuntut
umum dan PNS yang bersangkutan tidak memperoleh (menikmati) hasil
(uang  dan  barang)  dari  tindak  pidana  korupsinya  tersebut,  maka
terhadapnya  dikenakan  Sanksi  Administrasi  ringan  atau  Sanksi
Administrasi Sedang sebagaimana dimaksud Pasal 81 ayat (1) dan ayat
(2) Undang-Undang Administrasi Pemerintahan atau Ketentuan Hukum
Lain yang berlaku;
Menimbang, bahwa didalam Penjelasan Pasal 10 ayat (1) Undang-
Undang Administrasi Pemerintahan, yang dimaksud dengan asas kepastian
hukum adalah asas dalam negara hukum yang mengutamakan landasan
ketentuan  peraturan  perundang-undangan,  kepatutan,  keajegan  dan
keadilan dalam setiap kebijakan penyelenggaraan pemerintahan;
Menimbang, bahwa tindak pidana yang dijatuhkan kepada penggugat
adalah pada saat Penggugat sebagai Pegawai Negri Sipil di Lingkungan
Kabupaten Kutai Barat dimana Penggugat terakhir sebagai Kepala Seksi
Fasilitas  Antar  kampung  pada  dinas  pemberdayaan  masyarakat  dan
kampung kabupaten kutai barat (bukti P-4);

Kepaniteraan Mahkamah Agung Republik Indonesia berusaha untuk selalu mencantumkan informasi paling kini dan akurat sebagai bentuk komitmen Mahkamah Agung untuk pelayanan publik, transparansi dan akuntabilitas
pelaksanaan fungsi peradilan. Namun dalam hal-hal tertentu masih dimungkinkan terjadi permasalahan teknis terkait dengan akurasi dan keterkinian informasi yang kami sajikan, hal mana akan terus kami perbaiki dari waktu kewaktu.
Dalam hal Anda menemukan inakurasi informasi yang termuat pada situs ini atau informasi yang seharusnya ada, namun belum tersedia, maka harap segera hubungi Kepaniteraan Mahkamah Agung RI melalui :

Menimbang,  bahwa  terhadap  kriteria  pertama  yaitu  Dilakukan  oleh
seseorang  yang  pada  saat  melakukan  tindak  pidananya  telah  menjabat
sebagai  PNS,  berdasarkan  pengakuan  Penggugat  (dalam  gugatannya)
bahwa  tindak  pidana  yang  dijatuhkan  kepadanya  adalah  pada  saat
Penggugat menjabat  Kepala  Seksi  Kebandarudaraan  Dishubkominfo
sehingga kriteria pertama terpenuhi;
Menimbang, bahwa terhadap kriteria kedua yaitu Merupakan tindak
pidana  sebagaimana  dalam  dakwaan  primair  penuntut  umum  dan
berdasarkan bukti T-2 berupa Putusan Pengadilan Tindak Pidana Korupsi
pada  Pengadilan  Negeri  Samarinda  Nomor  60/Pid.sus-TPK/2015/PN.Smr
tanggal  02  Mei  2016  dimana  didalam  amar  putusannya  pada  pokoknya
bahwa   Penggugat  tidak  terbukti  secara  sah  dan  meyakinkan  bersalah
melakukan tindak pidana  sebagaimana dakwaan primer Penuntut Umum
dan  terbukti melakukan tindak pidana korupsi secara bersama-sama serta
tidak  ditemukan  fakta  ada  harta  benda  yang  bersumber  dari  kerugian
keuangan  negara  sebagai  akibat  tindak  pidana  korupsi  oleh  karenanya
kriteria kedua tidak terpenuhi;
Menimbang,  bahwa  berdasarkan  uraian  diatas,  Majelis  Hakim
berkesimpulan penggugat yang pada faktanya tidak terbukti dalam dakwaan
primair dan tidak memenuhi unsur memperkaya diri sendiri seharusnya tetap
dikenakan  sanksi  administrasi  yang  sesuai  dengan  Undang-Undang
Administrasi Pemerintahan;
Menimbang, bahwa kemudian setelah dikeluarkannya SKB 3 Menteri
(bukti T-7), Tergugat menerbitkan objek sengketa a quo (bukti P-1 dan T-1)
dan dalam penerbitan objek sengketa disebutkan PP Nomor 11 Tahun 2017
dijadikan salah satu dasar peraturan, sementara putusan pengadilan T-2 di
bacakan  pada  tanggal  2  Mei  2016,  artinya  SKB  3  Menteri  bukti  T-7
diterbitkan tanggal 13 September 2018  dan PP Nomor 11 tahun 2017 yang
substansinya  memberhentikan  tidak  dengan  hormat  Penggugat  sebagai
Pegawai Negeri Sipil berlaku mundur  terhitung tanggal 31 Mei 2018, yang
menurut  Majelis  Hakim  tidaklah  tepat  dalam  menghukum  seseorang
menggunakan dasar hukum yang diterbitkan setelah peristiwa hukum nya
telah selesai;

Kepaniteraan Mahkamah Agung Republik Indonesia berusaha untuk selalu mencantumkan informasi paling kini dan akurat sebagai bentuk komitmen Mahkamah Agung untuk pelayanan publik, transparansi dan akuntabilitas
pelaksanaan fungsi peradilan. Namun dalam hal-hal tertentu masih dimungkinkan terjadi permasalahan teknis terkait dengan akurasi dan keterkinian informasi yang kami sajikan, hal mana akan terus kami perbaiki dari waktu kewaktu.
Dalam hal Anda menemukan inakurasi informasi yang termuat pada situs ini atau informasi yang seharusnya ada, namun belum tersedia, maka harap segera hubungi Kepaniteraan Mahkamah Agung RI melalui :

Menimbang,  bahwa  berdasarkan  fakta  hukum  dalam  bukti  T-2
(Putusan  Pengadilan  Tindak  Pidana  Korupsi  pada  Pengadilan  Negeri
Samarinda Nomor 60/Pid.sus-TPK/2015/PN.Smr tanggal 02 Mei 2016), yaitu
bahwa   Penggugat  tidak  terbukti  secara  sah  dan  meyakinkan  bersalah
melakukan tindak pidana korupsi sebagaimana dakwaan primer Penuntut
Umum dan  terbukti melakukan tindak pidana korupsi secara bersama-sama,
serta unsur  memperkaya diri sendiri dalam perbuatan materiil penggugat
tidak terpenuhi hal demikian apabila dihubungkan dengan unsur proporsional
dan  Keadilan  sebagaimana  dimaksud  Pasal  83  ayat (1)  Undang-Undang
Administrasi Pemerintahan maka penerbitan objek sengketa oleh Tergugat
telah tidak sesuai unsur proporsional dan Keadilan sebagaimana dimaksud
Pasal 83 ayat (1) Undang-Undang Administrasi Pemerintahan dan telah pula
tidak sesuai dengan asas umum pemerintahan yang baik khususnya asas
kecermatan dan asas kepastian hukum;
Menimbang,  bahwa  berdasarkan  rangkaian  pertimbangan  hukum
mengenai substansi penerbitan objek sengketa  aquo tersebut diatas maka
Majelis Hakim berkesimpulan bahwa penerbitan objek sengketa  aquo telah
bertentangan  dengan  unsur  proporsional  dan  Keadilan  sebagaimana
dimaksud Pasal 83 ayat (1) Undang-Undang Administrasi Pemerintahan dan
telah pula tidak sesuai dengan asas umum pemerintahan yang baik yakni
asas  kecermatan  dan  asas  kepastian  hukum  khususnya  ketika  Tergugat
memberlakukan mundur tanggal penerbitan objek sengketa a quo;
Menimbang, bahwa meskipun Tergugat memiliki kewenangan, namun
prosedur penerbitan objek sengketa a quo tidak sesuai dan mengandung
cacat substansi sehingga telah bertentangan dengan unsur proporsional dan
Keadilan  sebagaimana  dimaksud  Pasal  83  ayat  (1)  Undang-Undang
Administrasi Pemerintahan dan telah pula bertentangan dengan asas umum
pemerintahan yang baik khususnya Asas Kepastian hukum, oleh karenanya
objek sengketa a quo terbukti telah beralasan hukum untuk dinyatakan batal
oleh karenanya gugatan haruslah dikabulkan dan sesuai Pasal 97 ayat (9)
huruf a jo ayat (11) Undang-Undang Peratun kepada Tergugat diwajibkan
untuk  mencabut  objek  sengketa  a  quo dan  diwajibkan  pula  melakukan
pemenuhan hak-hak Penggugat dengan mengaktifkan kembali Penggugat
sebagai Pegawai Negeri Sipil, rehabilitasi berupa pemulihan nama baik dan
penghasilan serta kejelasan penempatan kerja;

Kepaniteraan Mahkamah Agung Republik Indonesia berusaha untuk selalu mencantumkan informasi paling kini dan akurat sebagai bentuk komitmen Mahkamah Agung untuk pelayanan publik, transparansi dan akuntabilitas
pelaksanaan fungsi peradilan. Namun dalam hal-hal tertentu masih dimungkinkan terjadi permasalahan teknis terkait dengan akurasi dan keterkinian informasi yang kami sajikan, hal mana akan terus kami perbaiki dari waktu kewaktu.
Dalam hal Anda menemukan inakurasi informasi yang termuat pada situs ini atau informasi yang seharusnya ada, namun belum tersedia, maka harap segera hubungi Kepaniteraan Mahkamah Agung RI melalui :

Menimbang, bahwa oleh karena gugatan Penggugat dikabulkan maka
sesuai ketentuan Pasal 110 jo Pasal 112 Undang-Undang Nomor 5 Tahun
1986, kepada Tergugat dihukum untuk membayar biaya yang timbul dalam
perkara ini yang jumlahnya akan disebutkan dalam amar putusan ini;
Menimbang,  bahwa  sesuai  ketentuan  Pasal  107  Undang-Undang
Nomor  5  Tahun  1986,  maka  untuk  memberikan  pertimbangan  dan
memutuskan  serta  menyelesaikan  sengketa  ini  Majelis  Hakim  telah
memeriksa dan menelaah seluruh alat bukti yang diajukan oleh para pihak,
dan dengan alat-alat bukti tersebut telah menimbulkan keyakinan kepada
Majelis  Hakim  dalam  memberikan  putusan  yang  amar  nya  sebagaimana
termuat di bawah ini, dan terhadap seluruh alat bukti yang diajukan para
pihak tetap terlampir satu kesatuan dalam berkas perkara;
Memperhatikan,  Undang-Undang  Nomor  5  Tahun  1986  tentang
Peradilan Tata Usaha Negara sebagaimana telah diubah dengan Undang-
Undang Nomor 9 Tahun 2004 dan terakhir dengan Undang-Undang Nomor
51 Tahun 2009 tentang perubahan kedua atas Undang-Undang Nomor 5
Tahun 1986 dan Peraturan perundang-undangan beserta ketentuan hukum
lain yang berkaitan;
M E N G A D I L I :
Dalam Eksepsi
-  Menyatakan eksepsi Tergugat tidak diterima;
Dalam Pokok Perkara:
1. Mengabulkan gugatan Penggugat untuk seluruhnya; 
2. Menyatakan  batal  Surat  Keputusan  Bupati  Kutai  Barat  Nomor  :
800.05.860/K.971/2018  tanggal  31  Desember  2018  tentang
Pemberhentian  Karena  Melakukan  Tindak  Pidana  Kejahatan  Jabatan
atau Tindak Pidana Kejahatan yang ada Hubungannya dengan Jabatan
atas nama Hansen,SH.,M.Si.NIP.197203172006041010;
3. Memerintahkan kepada Tergugat untuk mencabut  Surat Keputusan
Bupati Kutai Barat Nomor :800.05.860/K.971/2018 tanggal 31 Desember
2018  tentang  Pemberhentian  Karena  Melakukan  Tindak  Pidana
Kejahatan  Jabatan  atau  Tindak  Pidana  Kejahatan  yang  ada

Kepaniteraan Mahkamah Agung Republik Indonesia berusaha untuk selalu mencantumkan informasi paling kini dan akurat sebagai bentuk komitmen Mahkamah Agung untuk pelayanan publik, transparansi dan akuntabilitas
pelaksanaan fungsi peradilan. Namun dalam hal-hal tertentu masih dimungkinkan terjadi permasalahan teknis terkait dengan akurasi dan keterkinian informasi yang kami sajikan, hal mana akan terus kami perbaiki dari waktu kewaktu.
Dalam hal Anda menemukan inakurasi informasi yang termuat pada situs ini atau informasi yang seharusnya ada, namun belum tersedia, maka harap segera hubungi Kepaniteraan Mahkamah Agung RI melalui :

Hubungannya  dengan  Jabatan  atas  nama
Hansen,SH.,M.Si.NIP.197203172006041010;
4. Memerintahkan  kepada  Tergugat  dengan  kewajiban  untuk
merehabilitasi  hak-hak  dan  kedudukan  Penggugat  sebagai  Pegawai
Negeri Sipil seperti keadaan semula;
5.   Menghukum Tergugat untuk membayar biaya perkara yang timbul dalam
sengketa ini sejumlah Rp. 336.000,- (Tiga Ratus Tiga Puluh Enam Ribu
Rupiah);
Demikian diputuskan dalam Rapat Permusyawaratan Majelis Hakim
Pengadilan Tata Usaha Negara Samarinda pada hari  Selasa, tanggal  26
November  2019 oleh  kami,  DEDI  WISUDAWAN  GAMADI  S .H., M.Kn.,
sebagai Hakim Ketua Majelis,  AYI SOLEHUDIN, S.H., M.H., dan FEBRINA
PERMADI, S.H., masing-masing  sebagai  Hakim  Anggota.  Putusan  mana
diucapkan dalam sidang yang terbuka untuk umum pada hari Rabu, tanggal
27  November  2019  oleh  Majelis  Hakim  tersebut  dengan  dibantu  oleh
RIDUANSYAH, S.H.,  sebagai Panitera Pengganti Pengadilan Tata Usaha
Negara Samarinda dengan dihadiri oleh Penggugat dan Tergugat;
HAKIM-HAKIM ANGGOTA,   HAKIM KETUA MAJELIS,
 
AYI SOLEHUDIN, S.H., M.H.  DEDI WISUDAWAN GAMADI S .H., M.Kn. 
   
FEBRINA PERMADI, S.H.
PANITERA PENGGANTI,
 RIDUANSYAH, S.H.

Kepaniteraan Mahkamah Agung Republik Indonesia berusaha untuk selalu mencantumkan informasi paling kini dan akurat sebagai bentuk komitmen Mahkamah Agung untuk pelayanan publik, transparansi dan akuntabilitas
pelaksanaan fungsi peradilan. Namun dalam hal-hal tertentu masih dimungkinkan terjadi permasalahan teknis terkait dengan akurasi dan keterkinian informasi yang kami sajikan, hal mana akan terus kami perbaiki dari waktu kewaktu.
Dalam hal Anda menemukan inakurasi informasi yang termuat pada situs ini atau informasi yang seharusnya ada, namun belum tersedia, maka harap segera hubungi Kepaniteraan Mahkamah Agung RI melalui :

   Perincian Biaya Perkara Nomor : 43/G/2019/PTUN.SMD  
Biaya Pendaftaran Gugatan : Rp.   30.000, -
Biaya ATK : Rp. 100.000, -
Biaya Panggilan : Rp. 170.000,-
Biaya Pemeriksaan Setempat : Rp.  -
Sumpah : Rp.  -
Materai : Rp. 6.000,-
Redaksi : Rp.   10.000,-
Jumlah   Rp. 336.000,-
   (Tiga Ratus Tiga Puluh Enam Ribu Rupiah)

Kepaniteraan Mahkamah Agung Republik Indonesia berusaha untuk selalu mencantumkan informasi paling kini dan akurat sebagai bentuk komitmen Mahkamah Agung untuk pelayanan publik, transparansi dan akuntabilitas
pelaksanaan fungsi peradilan. Namun dalam hal-hal tertentu masih dimungkinkan terjadi permasalahan teknis terkait dengan akurasi dan keterkinian informasi yang kami sajikan, hal mana akan terus kami perbaiki dari waktu kewaktu.
Dalam hal Anda menemukan inakurasi informasi yang termuat pada situs ini atau informasi yang seharusnya ada, namun belum tersedia, maka harap segera hubungi Kepaniteraan Mahkamah Agung RI melalui :

 

Kepaniteraan Mahkamah Agung Republik Indonesia berusaha untuk selalu mencantumkan informasi paling kini dan akurat sebagai bentuk komitmen Mahkamah Agung untuk pelayanan publik, transparansi dan akuntabilitas
pelaksanaan fungsi peradilan. Namun dalam hal-hal tertentu masih dimungkinkan terjadi permasalahan teknis terkait dengan akurasi dan keterkinian informasi yang kami sajikan, hal mana akan terus kami perbaiki dari waktu kewaktu.
Dalam hal Anda menemukan inakurasi informasi yang termuat pada situs ini atau informasi yang seharusnya ada, namun belum tersedia, maka harap segera hubungi Kepaniteraan Mahkamah Agung RI melalui :
Halaman 60